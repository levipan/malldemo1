// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  return await cloud.database().collection("goodsList").doc(event.id)
  .get()
  .then(res => {
    console.log('获取云函数成功',res);
    return res
  })
  .catch(err => {
    console.log('获取云函数失败',err);
    return err
  })
}