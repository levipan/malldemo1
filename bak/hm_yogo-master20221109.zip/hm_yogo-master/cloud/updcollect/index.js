// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  return await cloud.database().collection("goodsList").doc(event.id)
  .update({
    data: {
      isCollect: event.isCollect,
    }
  })
  .then(res => {
    console.log('云函数更改状态成功',res);
    return res
  })
  .catch(err => {
    console.log('云函数更改状态失败',err);
    return err
  })
}