// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
  let db = cloud.database()
  return await db.collection("goodsList")
  .where({
    title:db.RegExp({
      regexp: event.value,
      options: 'i'
    })
  })
  .get()
  .then(res => {
    console.log('云函数模糊查询成功',res);
    return res
  })
  .catch(err => {
    console.log('云函数模糊查询失败',err);
    return err
  })
}