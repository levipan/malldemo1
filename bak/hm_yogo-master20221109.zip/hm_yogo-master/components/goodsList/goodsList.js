// components/goodsList.js
Component({
  properties: {
    goodsList: Array,
  },
  data: {

  },
  methods: {
    goDetail(e){
      wx.navigateTo({
        url: '/pages/goods_detail/goods_detail?id=' + e.currentTarget.dataset.id,
      })
    }
  }
})
