// pages/auth/auth.js
import { request } from '../../request/index'
import regeneratorRuntime from '../../lib/runtime/runtime'
import { login } from '../../utils/asyncWx'

Page({
  async handleGetUserInfo(e) {
    // console.log(e)
    try {
      // 获取用户信息
      const { encryptedData, rawData, iv, signature } = e.detail;
      // 获取小程序登录成功后的code
      const {code} = await login();
      // console.log(code)
      const loginParams = { encryptedData, rawData, iv, signature, code };
      console.log(loginParams);
      const res = await request({
        url: "/users/wxlogin",
        data: loginParams,
        method: "post"
      });
      // 这一步支付授权无法实现，所以直接拿了老师的token值
      wx.setStorageSync("token", 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjIzLCJpYXQiOjE1NjQ3MzAwNzksImV4cCI6MTAwMTU2NDczMDA3OH0.YPt-XeLnjV-_1ITaXGY2FhxmCe4NvXuRnRB8OMCfnPo');
      wx.navigateBack({
        delta: 1
      });
    } catch (error) {
      console.log(error);
    }
  }
})