import { request } from '../../request/index';
import regeneratorRuntime from '../../lib/runtime/runtime';

Page({
  data: {
    swiperList:[],
    hotList: [],
    goodsList:[]
  },
  onLoad: function(options) {
    wx.showLoading({
      title: '加载中',
    })
    const swiperList = wx.getStorageSync('swiperList')
    const hotList = wx.getStorageSync('hotList')
    const goodsList = wx.getStorageSync('goods')
    if(!swiperList) {
      this.getSwiperList()
    } else {
      this.setData({
        swiperList:swiperList
      })
      console.log(this.data.swiperList);
    }
    if(!hotList) {
      this.getHotList()
    } else {
      this.setData({
        hotList
      })
    }
    if(!goodsList) {
      this.getGoodsList()
    } else {
      this.setData({
        goodsList
      })
    }
    setTimeout(function () {
      wx.hideLoading()
    }, 1500)
  },
  async getSwiperList() {
   wx.cloud.database().collection("swiperdata")
   .get()
   .then(res => {
     console.log(res);
     this.setData({
      swiperList: res.data
     })
     wx.setStorageSync('swiperList', this.data.swiperList)
   })
  },
  getHotList() {
    wx.cloud.database().collection("hotsaleList")
   .get()
   .then(res => {
     console.log(res);
     this.setData({
      hotList: res.data
     })
     wx.setStorageSync('hotList', this.data.hotList)
   })
  },
  getGoodsList() {
    wx.cloud.callFunction({
      name: 'getgoods',
    })
    .then(res => {
      console.log('云函数获取商品列表',res);
      this.setData({
        goodsList: res.result.data
      })
      wx.setStorageSync('goods', this.data.goodsList)
    })
  },
  onReachBottom: function() {
    wx.showToast({
      title: '没有下一页了~'
    });
  }
})
  