import { request } from '../../request/index';
import regeneratorRuntime from '../../lib/runtime/runtime';

Page({
  data: {
    tabs:[
      {
        id: 0,
        value: "综合",
        isActive: true
      },
      {
        id: 1,
        value: "销量",
        isActive: false
      },
      {
        id: 2,
        value: "价格",
        isActive: false
      }
    ],
    goodsInfo: [],
    goodsSell: [],
    goodsPrice: []
  },
  // 全局变量 总页数
  totalPages: 1,
  // 接口要的参数
  QueryParams:{
    query: "",
    cid: "",
    pagenum: 1,
    pagesize: 10
  },
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    const {id} = options;
    const goodsInfo = wx.getStorageSync('goodsInfo')
    const goodsSell = wx.getStorageSync('goodsSell')
    const goodsPrice = wx.getStorageSync('goodsPrice')
    if(!goodsInfo) {
      this.getGoodsInfo(id);
    }
    if(goodsInfo[0].cat_id !== id) {
      this.getGoodsInfo(id);
    } else {
    this.setData({
      goodsInfo
    })
    console.log(this.data.goodsInfo);
    }
    if(!goodsSell) {
      this.getSell(id);
    } 
    if(goodsSell[0].cat_id !== id) {
      this.getSell(id);
    } 
    else {
    this.setData({
      goodsSell
    })
    console.log(this.data.goodsSell);
    }
    if(!goodsPrice) {
      this.getPrice(id);
    } 
    if(goodsPrice[0].cat_id !== id) {
      this.getPrice(id);
    } 
    else {
    this.setData({
      goodsPrice
    })
    console.log(this.data.goodsPrice);
    }
    setTimeout(function () {
      wx.hideLoading()
    }, 1500)
  },
  async getGoodsInfo(id) {
    await wx.cloud.database().collection("goodsList")
    .where({
      cat_id: id 
    })
   .get()
   .then(res => {
     console.log(res);
     this.setData({
      goodsInfo: res.data
     })
     wx.setStorageSync('goodsInfo', this.data.goodsInfo)
   })
    // 获取总条数
    // const total = res.total;
    // 计算总页数
    // this.totalPages = Math.ceil(total / this.QueryParams.pagesize);
    // this.setData({
    //   //拼接了数组
    //   goodsInfo: [...this.data.goodsInfo,...res.goods]
    // })
    //关闭下拉刷新窗口
    wx.stopPullDownRefresh();
  },
  async getSell(id) {
    await wx.cloud.database().collection("goodsList")
    .where({
      cat_id: id 
    })
    .orderBy('click','desc')
    .get()
    .then(res => {
      console.log(res);
      this.setData({
        goodsSell: res.data
      })
      wx.setStorageSync('goodsSell', this.data.goodsSell)
    })
  },
  async getPrice(id) {
    await wx.cloud.database().collection("goodsList")
    .where({
      cat_id: id 
    })
    .orderBy('market_price','desc')
    .get()
    .then(res => {
      console.log(res);
      this.setData({
        goodsPrice: res.data
      })
      wx.setStorageSync('goodsPrice', this.data.goodsPrice)
    })
  },
  handleItemChange(e) {
    // 获取被点击的标题索引
    const {index} = e.detail;
    // 修改源数组
    let {tabs} = this.data;
    tabs.forEach((v,i) => {
      i === index ? v.isActive = true : v.isActive = false
    });
    // 赋值到data中
    this.setData({
      tabs
    })
  },
  /**
   * 下拉刷新页面
   * 1 触发下拉刷新事件,需要在页面json文件中配置
   * 2 重置数据 数组
   * 3 重置页码为1
   * 4 数据请求回来后需要手动关闭等待效果
   */
  onPullDownRefresh: function() {
    this.setData({
      goodsInfo:[]
    })
    // this.QueryParams.pagenum = 1;
    this.getGoodsInfo();
  },

  onReachBottom: function() {
    if(this.QueryParams.pagenum >= this.totalPages){
      //没有下一页数据
      wx.showToast({
        title: '没有下一页了~'
      });
    }else{
      //还有下一页数据
      this.QueryParams.pagenum++;
      this.getGoodsInfo();
    }
  }
})