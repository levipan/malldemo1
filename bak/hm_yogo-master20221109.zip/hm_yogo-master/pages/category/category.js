import { request } from '../../request/index';
import regeneratorRuntime from '../../lib/runtime/runtime';

Page({
  data: {
    cateList: [],
    //左侧的菜单数据
    leftMenuList:[],
    //右侧的商品数据
    rightContent:[],
    //左侧被点击激活的菜单
    currentIndex: 0,
    //右侧内容的滚动条距离顶部的距离
    scrollTop: 0
  },
  //接口的返回数据
  Cates:[],
  onLoad: function (options) {
    //获取本地存储中的数据 (小程序中也存在本地存储)
    const Cates = wx.getStorageSync("cateList");
    //判断
    if(!Cates){
      //不存在，发送请求获取数据
      this.getCates();
    }else{
      //可以使用旧的数据
      this.Cates = Cates;
      let leftMenuList = this.Cates.map(v => v.cat_name);
      let rightContent = this.Cates[0].children
      this.setData({
        leftMenuList,
        rightContent
      })
    }
  },
  async getCates() {
    wx.cloud.database().collection("catList")
   .get()
   .then(res => {
     console.log(res);
     this.setData({
      cateList: res.data
     })
     wx.setStorageSync('cateList', this.data.cateList)
   })
      this.Cates = this.data.cateList;
      //构造左侧的菜单数据
      let leftMenuList = this.Cates.map(v => v.cat_name);
      let rightContent = this.Cates[0].children
      this.setData({
        leftMenuList,
        rightContent
      })
  },
  handleItemTap(e){
    const {index} = e.currentTarget.dataset;
    console.log(index);
    let rightContent = this.Cates[index].children;
    this.setData({
      currentIndex: index,
      rightContent,
      scrollTop:0
    })
  }
})