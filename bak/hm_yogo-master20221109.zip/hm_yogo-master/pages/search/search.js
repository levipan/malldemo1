import { request } from '../../request/index';
import regeneratorRuntime from '../../lib/runtime/runtime';

Page({
  data: {
    goods: [],
    // 按钮的显示与隐藏
    isFocus: false,
    // 输入框默认显示的值
    inpValue: ''
  },
  TimeId: -1,
  // 输入框内的值改变触发该事件
  handleInput (e) {
    // 1.获取输入框内的值
    const {value} = e.detail;
    // 2.检测合法性
    if(!value.trim()) {
      // 值不合法
      this.setData({
        goods: [],
        isFocus: false
      })
      return;
    }
    // 防抖，防止重复输入,重复发送请求
    this.setData({
      isFocus: true
    })
    clearTimeout(this.TimeId);
    this.TimeId = setTimeout(() => {
      this.getSearch(value);
    }, 1000);
  },
  // 发送请求获取数据
  async getSearch(value) {
    wx.cloud.callFunction({
      name: 'getSearch',
      data: {
        value
      }
    })
    .then(res => {
      wx.showLoading({
        title: '加载中',
      })
      console.log('模糊查询获取商品列表',res);
      if(res.result.data.length == 0) {
        wx.showToast({
          title: '暂无相关商品',
          icon: 'error',
          duration: 1000
        })
      }
      setTimeout(function () {
        wx.hideLoading()
      }, 1500)
      this.setData({
        goods: res.result.data
      })
    })
  },
  // 取消按钮
  handleCancel () {
    this.setData({
      inpValue: '',
      isFocus: false,
      goods: []
    })
  }
})