
import { getSetting,chooseAddress,openSetting, showModal, showToast } from '../../utils/asyncWx.js';

Page({
  data: {
    address:{},
    cart:[],
    goodsList: [],
    allChecked:false,
    totalPrice: 0,
    totalNum: 0
  },
  onLoad(){
    wx.showLoading({
      title: '加载中',
    })
    //获取缓存中的收货地址信息
    const address = wx.getStorageSync("address");
    const goodsList = wx.getStorageSync("goods")
    //获取缓存中购物车数据
    const cart = wx.getStorageSync("cart") || [];
    this.setData({
      address,
      goodsList
    });
    this.setCart(cart);
    setTimeout(function () {
      wx.hideLoading()
    }, 1500)
  },
  async handleGetAddress(){
    //1 获取权限状态
    try {
      const res1 = await getSetting();
      const scopeAddress = res1.authSetting["scope.address"];
      //2 判断 权限状态
      if(scopeAddress === false){
        //3 先诱导用户打开授权页面
        await openSetting();
        }
        //4 再重新调用获取收货地址的api
        const address = await chooseAddress();
        //5 存入到缓存中
        wx.setStorageSync("address", address);
        this.onLoad()
    } catch (error) {
      console.log(error);
    }
  },
  // 商品的选中
  handleItemChange(e) {
    // 1.获取被修改的商品的id
    const goods_id = e.currentTarget.dataset.id;
    // 2.获取购物车数组
    let {cart} = this.data;
    // 3.找到被修改的商品对象
    let index = cart.findIndex(v => v.goods_id === goods_id);
    // 4.对商品对象的选中状态取反
    cart[index].checked = !cart[index].checked;
    // 5.把购物车数据重新设置回data和缓存中
    // 6.重新计算全选、总价格和总数量
    this.setCart(cart);
  },
  // 计算购物车全选、总价格和总数量
  setCart(cart) {
    let allChecked = true;
    //总价格 总数量
    let totalPrice = 0;
    let totalNum = 0;
    cart.forEach(v => {
      if(v.checked) {
        totalPrice += v.num * v.market_price;
        totalNum += v.num; 
      }else{
        allChecked = false;
      }
    });
    //判断数组是否为空
    allChecked = cart.length != 0 ? allChecked:false;
    //给 data赋值
    this.setData({
      cart,
      allChecked,
      totalNum,
      totalPrice
    })
    wx.setStorageSync('cart', cart);
  },
  // 设置商品全选
  handleItemAllChecked() {
    // 1.获取data中的数据
    let {cart, allChecked} = this.data;
    // 2.修改值
    allChecked = !allChecked;
    // 3.循环修改cart数组中的商品选中状态
    cart.forEach(v => v.checked = allChecked);
    // 4.返回修改的值
    this.setCart(cart);
  },
  // 商品数量编辑
  async handleItemNumChange(e) {
    const {operation, id} = e.currentTarget.dataset;
    let {cart} = this.data;
    const index = cart.findIndex(v => v.goods_id = id);
    // 判断是否执行删除功能
    if(cart[index].num === 1 && operation === -1) {
      const res = await showModal({content: '您是否需要删除？'})
      if (res.confirm) {
        cart.splice(index, 1);
        this.setCart(cart);
      }
    }else {
      cart[index].num += operation;
      this.setCart(cart);
    }
  },
  // 跳转支付
  handlePay() {
    const {address, totalNum} = this.data;
    // 1.判断是否选择收货地址
    if(!address.userName) {
      showToast({title: "您还没有选择收货地址！"})
      return
    }
    // 2.判断是否选择商品
    if(totalNum === 0) {
      showToast({title: "您还没有选择商品！"})
      return
    }
    // 3.跳转到支付页面
    wx.navigateTo({
      url: '/pages/pay/pay'
    });
  }
})