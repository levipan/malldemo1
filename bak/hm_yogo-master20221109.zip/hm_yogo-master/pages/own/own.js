Page({
  data: {
    userInfo: {}
  },
  onLoad: function (options) {
    const userInfo = wx.getStorageSync('userInfo')
    this.setData({
      userInfo
    })
  },
  logout() {
    if(this.data.userInfo) {
      wx.removeStorageSync('userInfo')
    .then(res => {
      console.log(res);
      wx.showToast({
        title: '退出成功',
        icon: 'success',
        duration: 1000
      })
    })
      wx.navigateTo({
        url: '/pages/login/login'
      })
    } else {
      wx.navigateTo({
      url: '/pages/login/login'
      })
    }
  }
})