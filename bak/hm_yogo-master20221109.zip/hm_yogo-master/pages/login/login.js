import { request } from '../../request/index'
import regeneratorRuntime from '../../lib/runtime/runtime'
import { login } from '../../utils/asyncWx'

Page({
  data: {
    account: null,
    pwd: null,
  },
  onLoad() {
    const userInfo = wx.getStorageSync('userInfo');
    if(userInfo) {
      wx.switchTab({
        url: "/pages/index/index"
      }) 
    }
  },
  getAccount(e) {
    this.setData({
      account:e.detail.value
    });
    console.log(this.data.account);
  },
  getPwd(e) {
    this.setData({
      pwd:e.detail.value
    });
    console.log(this.data.pwd);
  },
  regist() {
    const db = wx.cloud.database();
    const userInfo = db.collection("userInfo");
    let flag = false  //表示账户是否存在,false为初始值
    userInfo.get({
      success: (res) => {
        let user = res.data;  //获取到的对象数组数据
        console.log(user);
        user.forEach(item => {
          if (this.data.account === item.account) { //账户已存在
            flag = true;
          }
        })
        if (flag === true) {  //账户已存在
          wx.showToast({
            title: '账号已注册！',
            icon: 'error',
            duration: 1000
          })
        }
        else {  //账户未注册
          userInfo.add({
            data:{
              account:this.data.account,
              pwd:this.data.pwd
            }
          })
          wx.showToast({	//显示注册成功信息
            title: '注册成功！',
            icon: 'success',
            duration: 1000
          })
          userInfo.get().then(res => {
            console.log('注册成功',res);
            wx.setStorageSync('userInfo', res.data[res.data.length - 1])
          })
          wx.switchTab({	//注册成功后跳转页面
            url: "/pages/index/index"
          }) 
        }
      }
    })
  },
  login() {
    const db = wx.cloud.database();
    const userInfo = db.collection("userInfo");
    let flag = false  //表示账户是否存在,false为初始值
    userInfo.get({
      success: (res) => {
        let user = res.data;
        console.log(user);
        if(!this.data.account) {
          wx.showToast({
            title: '请输入账号！',
            icon: 'error',
            duration: 1000
          });
          return
        }
        if(!this.data.pwd) {
          wx.showToast({
            title: '请输入密码！',
            icon: 'error',
            duration: 1000
          });
          return
        }
        user.forEach((item, i) => {
          if (this.data.account === item.account) { //账户已存在
            if (this.data.pwd !== item.pwd) {  //判断密码正确与否
              wx.showToast({  //显示密码错误信息
                title: '密码错误！！',
                icon: 'error',
                duration: 1000
              });
            } else {
              wx.setStorageSync('userInfo', item)
              wx.showToast({  //显示登录成功信息
                title: '登录成功！',
                icon: 'success',
                duration: 1000
              })
              flag = true;
              wx.switchTab({  //登录成功后跳转页面
                url: "/pages/index/index",
              })
            }
          }
        })
        if(flag == false)//遍历完数据后发现没有该账户
        {
          wx.showToast({
            title: '该用户不存在',
            icon: 'error',
            duration: 1000
          })
        }
      }
    })
  }
})