Component({
    properties: {
        type: String,
        show: Boolean,
        playType: Number,
        groupNub: Number,
        left: Boolean
    }
});