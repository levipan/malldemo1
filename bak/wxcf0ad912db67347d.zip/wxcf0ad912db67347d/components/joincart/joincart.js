function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, u = Array(t.length); a < t.length; a++) u[a] = t[a];
        return u;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), u = getApp();

Component({
    properties: {
        productid: {
            type: Number
        }
    },
    data: {
        chooseSkuHide: !0,
        setTime: "",
        quickClick: !0,
        isgo: !1
    },
    ready: function() {},
    methods: {
        changeCart: function(t, r, e, s, i) {
            var d = this;
            "" === u.globalData.openId && null != s && s(), u.getOpenId(function(s) {
                a.httpGet(u.getUrl("Cart/GetUpdateToCart"), {
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    skuId: t,
                    quantity: r,
                    productDeliveryType: i,
                    openId: s
                }, function(a) {
                    if (a.success) u.globalData.cartData.items[d.data.productid] ? u.globalData.cartData.items[d.data.productid].skus[t] ? u.globalData.cartData.items[d.data.productid].skus[t].Quantity = u.globalData.cartData.items[d.data.productid].skus[t].Quantity + r : u.globalData.cartData.items[d.data.productid].skus[t] = {
                        Quantity: r,
                        ProductId: a.data.ProductId,
                        SkuId: t
                    } : (u.globalData.cartData.items[d.data.productid] = {}, u.globalData.cartData.items[d.data.productid].skus = {}, 
                    u.globalData.cartData.items[d.data.productid].skus[t] = {
                        Quantity: r,
                        ProductId: a.data.ProductId,
                        SkuId: t
                    }), u.getCartTotal(function(t) {
                        u.updateCartTotal(t + parseInt(r));
                    }); else {
                        if (3001 === a.code || 3002 === a.code || 3003 === a.code) {
                            var s = u.globalData.cartData.items[d.data.productid];
                            if (s) {
                                var i = 0;
                                for (var o in s.skus) i += s.skus[o].Quantity;
                                u.getCartTotal(function(t) {
                                    u.updateCartTotal(t - parseInt(i) + parseInt(a.data));
                                }), s.skus[t].Quantity = a.data;
                            }
                        }
                        u.showErrorModal(a.msg);
                    }
                    e(a);
                });
            });
        },
        hideChooseSku: function() {
            this.setData({
                chooseSkuHide: !0,
                delivery: 0
            }), this.triggerEvent("hide");
        },
        chooseSku: function(t) {
            var r = this;
            t && (this.data.delivery = t), a.httpGet(u.getUrl("CommunityStore/GetProductSkus"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                ProductId: this.data.productid,
                openId: u.globalData.openId
            }, function(t) {
                if (t.success) {
                    var a, e = {}, s = [ (t = t.data).ProductId, 0, 0, 0 ], i = "";
                    t.Skus.forEach(function(t) {
                        e[t.SkuId] = t, !a && t.Stock && (a = t);
                    });
                    var d = t.Skus.filter(function(t) {
                        return t.Stock > 0;
                    });
                    if (t.Skus = e, 1 === d.length && (s = d[0].SkuId.split("_"), i = t.Skus[d[0].SkuId]), 
                    t.DefaultSku.Stock || (t.DefaultSku = a), !t.DefaultSku) return void wx.showToast({
                        title: "暂无库存",
                        icon: "none"
                    });
                    r.setData({
                        chooseSkuHide: !1,
                        skuData: t,
                        skuArr: s,
                        curSkuData: i
                    }), r.triggerEvent("hideHomeVideo", {
                        hide: !0
                    }), 0 !== r.data.skuData.SkuItems.length && r.setDisabledSku(), u.getSysSettingData(function(t) {
                        r.setData(t);
                    });
                } else 502 == t.code ? (wx.showToast({
                    title: "请先登录账号",
                    icon: "none"
                }), wx.navigateTo({
                    url: "../login/login"
                })) : u.showErrorModal(t.msg);
            });
        },
        setDisabledSku: function() {
            var a = this.data.skuData.SkuItems, u = this.data.skuData.Skus, r = (a.length, this.data.skuArr);
            a.forEach(function(a) {
                var e = a.AttributeIndex;
                a.AttributeValue.forEach(function(a) {
                    var s = [].concat(t(r));
                    s[e + 1] = a.ValueId, u[s.join("_")] && !u[s.join("_")].Stock ? a.disabled = !0 : a.disabled = !1;
                });
            }), this.setData({
                skuData: this.data.skuData
            });
        },
        swithSku: function(t) {
            var a = t.currentTarget.dataset.index, u = t.currentTarget.dataset.id, r = this.data.skuArr;
            r[a + 1] = parseInt(r[a + 1]) === u ? 0 : u, this.setData({
                skuArr: r,
                curSkuData: this.data.skuData.Skus[this.data.skuArr.join("_")] || null
            }), this.setDisabledSku();
        },
        delete: function(t) {
            var r = this, e = t.currentTarget.dataset.skuid;
            a.httpGet(u.getUrl("Cart/GetdelCartItem"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                openId: u.globalData.openId,
                skuIds: e
            }, function(t) {
                if (!t.success) return u.showErrorModal(t.msg);
                u.globalData.cartData.items[r.data.productid].skus[e].Quantity = 0, u.getCartTotal(function(t) {
                    u.updateCartTotal(t - 1);
                }), r.data.curSkuData.CartQuantity = 0, r.data.skuData.Skus[r.data.curSkuData.SkuId] = r.data.curSkuData, 
                r.setData({
                    curSkuData: r.data.curSkuData,
                    skuData: r.data.skuData
                });
                var a = 0, s = r.data.skuData.Skus;
                for (var i in s) a += s[i].CartQuantity;
                r.triggerEvent("updateproduct", {
                    quantity: a,
                    skus: s
                });
            });
        },
        skuCountChange: function(t) {
            var a = this;
            if (this.data.curSkuData) {
                if (this.data.quickClick) {
                    this.setData({
                        quickClick: !1
                    });
                    var u = t.currentTarget.dataset.type ? 1 : -1;
                    this.data.setTime = setTimeout(function() {
                        a.changeCart(a.data.curSkuData.SkuId, u, function(t) {
                            a.data.curSkuData.CartQuantity += t.success ? u : 0, 3001 !== t.code && 3002 !== t.code && 3003 !== t.code || (a.data.curSkuData.CartQuantity = t.data), 
                            a.data.curSkuData.CartQuantity < 0 && (a.data.curSkuData.CartQuantity = 0), a.data.skuData.Skus[a.data.curSkuData.SkuId] = a.data.curSkuData, 
                            a.setData({
                                curSkuData: a.data.curSkuData,
                                skuData: a.data.skuData,
                                quickClick: !0
                            });
                            var r = 0, e = a.data.skuData.Skus;
                            for (var s in e) r += e[s].CartQuantity;
                            a.triggerEvent("updateproduct", {
                                quantity: r,
                                skus: e
                            });
                        }, function() {
                            a.setData({
                                quickClick: !0
                            });
                        }, a.data.delivery);
                    }, 500);
                }
            } else wx.showToast({
                title: "请选择规格",
                icon: "none"
            });
        }
    }
});