var t = require("../../utils/config.js"), a = getApp();

Component({
    properties: {},
    data: {
        pageLoaded: !1,
        pageEnd: !1,
        empty: !1,
        pageNo: 1,
        typeHeight: "auto",
        searchTop: 0,
        typeTop: "88rpx",
        products: [],
        categoryId: 0,
        keyword: "",
        categoryList: []
    },
    methods: {
        onLoad: function() {
            var t = this;
            a.getSysSettingData(function(e) {
                e.IsShowShopBranchLink = a.globalData.IsShowShopBranchLink, e.ProductSaleCountOnOff = a.globalData.ProductSaleCountOnOff, 
                t.setData(e);
            }, !0), a.getShareConfig(function(a) {
                t.setData({
                    shareTitle: a.shareTitle,
                    shareImage: a.shareImage
                });
            }), this.setData({
                shopBranchId: wx.getStorageSync("shopBranchId")
            }), this.bottomCart = this.selectComponent("#bottomCart"), this.getStoreInfo(), 
            this.getVisitCount(), a.globalData.navData.storeselfsupport ? this.setData({
                isNavs: !0
            }, function() {
                t._getBoxSizes();
            }) : this._getBoxSizes();
        },
        onShow: function() {
            this.data.products.length > 0 && this.bottomCart.getCartData();
        },
        onPullDownRefresh: function() {
            this.setData({
                pageEnd: !1,
                empty: !1,
                pageNo: 1,
                products: [],
                categoryId: 0,
                categoryList: []
            }), this.loadData();
        },
        onShareAppMessage: function() {
            var t = "pages/index/index?id=" + this.data.shopBranchId;
            return a.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + a.globalData.userInfo.UserId), 
            {
                title: this.data.shareTitle.replace(/{shequ}/g, this.data.current.ShopBranchName),
                imageUrl: this.data.shareImage || this.data.current.ShopImages,
                path: t,
                success: function(t) {},
                fail: function(t) {}
            };
        },
        onHide: function() {
            this.setData({
                showVideo: !1
            }), wx.setNavigationBarColor({
                frontColor: "#000000",
                backgroundColor: "#ffffff"
            });
        },
        getVisitCount: function() {
            wx.request({
                url: a.getUrl("Home/GetStatisticShopBranchVisitUserCount"),
                data: {
                    shopBranchId: wx.getStorageSync("shopBranchId")
                },
                success: function(t) {}
            });
        },
        showVideo: function(t) {
            this.setData({
                currentVideo: t.currentTarget.dataset.video,
                showVideo: !0
            });
        },
        _getBoxSizes: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(e) {
                    t.setData({
                        searchTop: (t.data.isNavs ? a.globalData.customheaderHeight : 0) + "px",
                        typeTop: (t.data.isNavs ? 54 + a.globalData.customheaderHeight : 54) + "px",
                        typeHeight: e.windowHeight - 54 - 52 - (t.data.isNavs ? a.globalData.customheaderHeight + 54 : 0) + "px"
                    });
                }
            });
        },
        closeVideo: function() {
            this.setData({
                currentVideo: "",
                showVideo: !1
            });
        },
        getStoreInfo: function() {
            var e = this;
            t.httpGet(a.getUrl("Home/GetStoreInfo"), {
                Id: this.data.shopBranchId
            }, function(t) {
                t.success ? (e.setData({
                    pageNo: 1,
                    current: t.data,
                    pageLoaded: !0
                }), e.loadData()) : wx.showToast({
                    title: t.msg
                });
            });
        },
        loadData: function() {
            this.getCategoryList();
        },
        getCategoryList: function() {
            var e = this;
            t.httpGet(a.getUrl("CommunitySelfProduct/GetProductCategory"), {
                openId: a.globalData.openId,
                shopBranchId: this.data.shopBranchId
            }, function(t) {
                t.success && (t.data ? (t.data.unshift({
                    Id: 0,
                    Name: "全部"
                }), e.setData({
                    categoryList: t.data
                }), e.getProductList()) : e.setData({
                    empty: !0
                }));
            });
        },
        getProductList: function() {
            var e = this;
            this.data.loading || (this.setData({
                loading: !0
            }), t.httpGet(a.getUrl("CommunitySelfProduct/GetProducts"), {
                openId: a.globalData.openId,
                shopBranchId: this.data.shopBranchId,
                pageNo: this.data.pageNo,
                categoryId: this.data.categoryId,
                keyWord: this.data.keyword,
                pageSize: 10
            }, function(t) {
                if (wx.stopPullDownRefresh(), t.success) {
                    var a = t.data.products, o = a.length < 10, s = 1 == e.data.pageNo && 0 == a.length, i = 1 == e.data.pageNo ? [] : e.data.products;
                    i.push.apply(i, a), e.setData({
                        loading: !1,
                        products: i,
                        pageEnd: o,
                        empty: s
                    }), 1 == e.data.pageNo ? e.bottomCart.getCartData() : e.updateproduct();
                } else e.setData({
                    loading: !1
                }), wx.showToast({
                    title: "系统数据异常",
                    icon: "none"
                });
            }));
        },
        onReachBottom: function() {
            this.data.pageEnd || (this.setData({
                pageNo: this.data.pageNo + 1
            }), this.loadData());
        },
        goProduct: function(t) {
            wx.navigateTo({
                url: "../storeProductdetail/storeProductdetail?id=" + t.currentTarget.dataset.id + "&shopBranchId=" + this.data.shopBranchId
            });
        },
        callShopTel: function(t) {
            wx.makePhoneCall({
                phoneNumber: t.currentTarget.dataset.tel
            });
        },
        productNumChange: function(t) {
            this.bottomCart.numChange(t, function(t) {
                if (!t.success) return wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
                wx.showToast({
                    title: "加入购物车成功",
                    icon: "none"
                });
            });
        },
        updateproduct: function() {
            this.data.products.map(function(t) {
                a.globalData.selfCartData[t.Id] ? t.Quantity = a.globalData.selfCartData[t.Id] : t.Quantity = 0;
            }), this.setData({
                products: this.data.products
            });
        },
        onChangeCategory: function(t) {
            var a = t.currentTarget.dataset.id;
            this.setData({
                empty: !1,
                pageEnd: !1,
                categoryId: a,
                pageNo: 1
            }), this.getProductList();
        },
        onInputKeyword: function(t) {
            var a = this, e = t.detail.value;
            a.setData({
                keyword: e
            }), e ? (clearTimeout(this.searchTimer), this.searchTimer = setTimeout(function() {
                a.onConfirmSearch();
            }, 800)) : a.onConfirmSearch();
        },
        clearSearch: function() {
            this.setData({
                keyword: ""
            }), this.onConfirmSearch();
        },
        onConfirmSearch: function() {
            clearTimeout(this.searchTimer), this.setData({
                empty: !1,
                pageEnd: !1,
                categoryId: 0,
                pageNo: 1
            }), this.getProductList();
        }
    }
});