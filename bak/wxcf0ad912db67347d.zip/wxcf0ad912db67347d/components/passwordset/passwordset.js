var t = require("../../utils/config.js"), e = getApp();

Component({
    properties: {
        showPop: {
            type: Boolean,
            value: !1
        },
        focusFlag: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        bindCancel: function() {
            this.setData({
                showPop: !1
            });
        },
        bindSubmitPayPassword: function(s) {
            var o = s.detail.value.password, a = s.detail.value.pw, n = this;
            if (0 != o.length && 0 != a.length && a == o) t.httpPost(e.getUrl("MyDistribution/PostInitPayPassowrd"), {
                openId: e.globalData.openId,
                password: o
            }, function(t) {
                var e = t.msg;
                t.success && (e = "密码设置成功", n.triggerEvent("submitsuccess"), n.setData({
                    showPop: !1
                })), wx.showToast({
                    title: e,
                    icon: "none",
                    image: "",
                    mask: !0
                });
            }); else {
                var i = 0 == o.length ? "请输入交易密码" : 0 == a.length ? "请输入确认密码" : "交易密码输入不一致";
                wx.showToast({
                    title: i,
                    icon: "none",
                    image: "",
                    mask: !0
                });
            }
        }
    }
});