getApp();

Component({
    properties: {},
    data: {},
    methods: {
        onLoad: function() {
            wx.navigateTo({
                url: "../video/video"
            });
        },
        onShow: function() {}
    }
});