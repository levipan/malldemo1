function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), e = require("../../utils/util"), i = getApp(), o = require("../../utils/busEvent"), s = {
    limitType: {
        auto: 0,
        toDay: 1,
        nextDay: 2
    }
}, n = {
    startY: 0,
    endY: 0,
    moveY: 0,
    isBottom: !1,
    isAuto: !1
}, r = {
    getPopupAdvertSetting: function() {
        return JSON.parse(wx.getStorageSync("popupAdvertSetting") || "{}");
    },
    setPopupAdvertSetting: function(t) {
        wx.setStorageSync("popupAdvertSetting", JSON.stringify(t));
    }
};

Component({
    properties: {},
    data: {
        conststant: s,
        pageLoaded: !1,
        statusBarHeight: 0,
        limitType: s.limitType.auto,
        categories: [],
        products: [],
        isLimitEmpty: !1,
        isHasNextCategory: !1,
        timeload: null,
        gotopVal: !0,
        keyword: "",
        existCountDown: !1,
        focus: !1,
        cartHide: !0,
        productLayout: 1,
        animationData: {},
        isEmpty: !1,
        showVideo: !1,
        productImgClass: "height1",
        moduleData: [],
        categoryId: 0,
        collectTip: !1,
        showcoupon: !1,
        showBindPhone: !1,
        showNewBuyIndex: 0,
        shouldSwitch: !1,
        limitLoading: !1,
        limitProductsInit: !1,
        getRequestUrl: i.getRequestUrl,
        openLimit: "",
        openProductId: "",
        translateY: 0,
        transition: "",
        listScrollLeft: 0,
        couponLoading: !1,
        showNext: !1,
        limitProducts: [],
        isPopupAdvert: !1,
        isShowPopupAdvert: !0,
        staticData: {
            scrollTop: 0,
            windowH: 500,
            autoNext: !1,
            listRects: [],
            listLefts: [],
            listKeys: {},
            listInit: !1,
            windowW: 375,
            isIos: !1,
            isReachBottomIng: !1,
            isNeedScroll: !1
        },
        isInit: !1,
        IsShowPickupDate: !0,
        customHeadHeight: 0,
        customHeadDemoHeight: 74,
        navToTop: 0,
        isCustomhead: !1,
        isShowPaging: !1,
        pagingNumber: 1,
        pagingTotal: 1,
        pagingPages: [],
        pagingSize: 100,
        pageInit: !1,
        popupAdvert: {
            imgWidth: 0,
            imgHeight: 0
        },
        tempLoading: !1,
        pageSize: 10,
        nextPage: !0,
        pageNo: 1,
        isShowProduct: !0,
        isNoLimitProduct: !1
    },
    lifetimes: {
        ready: function() {
            var t = this;
            i.getSystemInfo(function(a) {
                t.data.staticData.windowH = a.windowHeight, t.data.staticData.windowW = a.windowWidth, 
                -1 != a.system.toLocaleLowerCase().indexOf("ios") && (t.data.staticData.isIos = !0, 
                t.data.staticData.isNeedScroll = !0), t.setData({
                    statusBarHeight: a.statusBarHeight
                });
            }), this.storeCart = this.selectComponent("#storeCart"), o.off("triggerBindphone"), 
            o.on("triggerBindphone", function() {
                t.setData({
                    showBindPhone: !0
                });
            });
        }
    },
    methods: {
        onLoad: function(t) {
            t.isReload && (this.data.pageloading = !1, this.data.hasGetSysSetting = !1), this._loadDataStart(), 
            this._correctTime(), this._getCartData();
        },
        onShow: function() {
            var t = this;
            this.setData({
                gotopVal: !0
            }), this._correctTime(), this._getCartData(), o.off("triggerBindphone"), o.on("triggerBindphone", function() {
                t.setData({
                    showBindPhone: !0
                });
            });
        },
        _correctTime: function() {
            if (this.data.hideTime) {
                var t = parseInt(+new Date() / 1e3) - this.data.hideTime, a = this.data.productLayout;
                3 === a || 4 === a || 7 === a || 8 === a ? (this.data.products.forEach(function(a) {
                    a.IsLimit && (a.EndSecond = a.EndSecond - t, a.StartSecond = a.StartSecond - t);
                }), this._setTimeProduct()) : (this.data.limitProducts.forEach(function(a) {
                    a.IsLimit && (a.EndSecond = a.EndSecond - t, a.StartSecond = a.StartSecond - t);
                }), this.data.hideTime = 0, this._setTimeLoad());
            }
        },
        onHide: function() {
            (this.data.limitProducts.length > 0 || this.data.products.length > 0) && (this.data.hideTime = parseInt(+new Date() / 1e3), 
            clearInterval(this.timeload));
        },
        onPageScroll: function(t) {
            this.data.staticData.scrollTop = t.scrollTop, this.setData({
                gotopVal: t.scrollTop < 500
            });
        },
        onReachBottom: function() {
            this.data.isShowPaging || this.data.Store.IsClose || !this.data.isShowProduct || this.data.nextPage && !this.data.tempLoading && (this.data.pageNo += 1, 
            this._getTemplateProducts());
        },
        onPullDownRefresh: function() {
            this._initData(), wx.showNavigationBarLoading();
        },
        onShareTimeline: function() {
            var t = "id=" + this.data.Store.Id;
            return i.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + i.globalData.userInfo.UserId), 
            {
                title: this.data.shareTitle.replace(/{shequ}/g, this.data.Store.ShopBranchName),
                imageUrl: this.data.shareImage || this.data.Store.ShopImages,
                query: t
            };
        },
        onShareAppMessage: function() {
            var t = "pages/index/index?id=" + this.data.Store.Id;
            return i.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + i.globalData.userInfo.UserId), 
            {
                title: this.data.shareTitle.replace(/{shequ}/g, this.data.Store.ShopBranchName),
                imageUrl: this.data.shareImage || this.data.Store.ShopImages,
                path: t,
                success: function(t) {},
                fail: function(t) {}
            };
        },
        _initData: function() {
            this.setData({
                pageloading: !1,
                limitProducts: [],
                products: [],
                moduleData: [],
                newbuyorder: [],
                isLimitEmpty: !1,
                isEnd: !1,
                showNext: !1,
                couponsData: [],
                listScrollLeft: 0,
                limitType: s.limitType.auto,
                nextPage: !0,
                isShowPaging: !1,
                pagingNumber: 1,
                pageNo: 1,
                Store: {},
                existCountDown: !1,
                showNewBuyIndex: 0,
                newBuyOrderTop: !1
            }), this.data.staticData.listRects = [], this.data.staticData.listLefts = [], this.data.staticData.listKeys = {}, 
            this.data.staticData.listInit = !1;
        },
        _loadDataStart: function() {
            this.data.pageloading || (this.data.pageloading = !0, this.data.shopId != wx.getStorageSync("shopBranchId") ? (this.data.popupAdvert.init = !1, 
            this.adverting = !1, this._initData(), this.setData({
                shopId: wx.getStorageSync("shopBranchId"),
                popupAdvert: this.data.popupAdvert
            }), i.globalData.storeColse = !1, this._getSystemSetting(!0)) : this.data.hasGetSysSetting || this._getSystemSetting(!0));
        },
        _getSystemSetting: function(t) {
            var a = this;
            i.getSettingData(function(t) {
                var e = Object.assign({}, i.globalData.colorsConfig);
                e.IsShowHishopCopyRight = i.globalData.IsShowHishopCopyRight, e.ProductSaleCountOnOff = i.globalData.ProductSaleCountOnOff, 
                e.SiteName = i.globalData.SiteName, e.PrimaryColorlight7 = i.hex2rgb(i.globalData.PrimaryColor, .7), 
                e.PrimaryColorlight8 = i.hex2rgb(i.globalData.PrimaryColor, .88), e.IsJumpLink = i.globalData.IsJumpLink, 
                e.KeepOnRecordPic = i.globalData.KeepOnRecordPic, e.KeepOnRecordUrl = i.globalData.KeepOnRecordUrl, 
                e.IsShowAll = i.globalData.IsShowAll, e.hasGetSysSetting = !0, e.pageloading = !1, 
                e.IsShowPickupDate = i.globalData.IsShowPickupDate, e.shareTitle = t.share.shareTitle, 
                e.shareImage = t.share.shareImage, e.productImgClass = "height" + t.share.productShowImageSize, 
                a.data = Object.assign(a.data, e), wx.stopPullDownRefresh(), a._setStoreData(t.store), 
                a._getCustomTemplate(t, function() {
                    a._categoryInit(t.store), a.setData(a.data, function() {
                        a._renderRead();
                    }), a.data.isShowProduct && a._getTemplateProducts();
                }), wx.setNavigationBarTitle({
                    title: i.globalData.SiteName
                });
            }, t);
        },
        _renderRead: function() {
            this._getListPositionInfo(), this._getNewOrderList(), this._setCollectionTip(), 
            this._getVisitCount();
        },
        _getCustomTemplate: function(t, a) {
            var e = this;
            wx.request({
                url: t.visualConfig,
                dataType: "json",
                success: function(t) {
                    var o = t.data.page.customheadimgsrc;
                    e.triggerEvent("setcustomhead", {
                        isCustomhead: o
                    }), e.data.isCustomhead = o || !1, e.data.customheadimgsrc = i.getRequestUrl + o, 
                    e.data.isShowProduct = void 0 === t.data.page.isShowProduct || "1" === t.data.page.isShowProduct, 
                    e.data.moduleData = t.data.LModules, a && a();
                },
                fail: function() {
                    e.triggerEvent("setcustomhead", {
                        isCustomhead: ""
                    }), e.data.isCustomhead = !1, a && a();
                }
            });
        },
        _setStoreData: function(t) {
            t.IsClose && !i.globalData.storeColse && (i.globalData.storeColse = !0, this.goStoreClose()), 
            1 == t.Status && wx.showModal({
                title: "提示",
                content: "当前店铺已冻结，请重新选择自提点",
                confirmColor: this.data.PrimaryColor,
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.redirectTo({
                        url: "../stores/stores"
                    });
                }
            }), this.data.Store = t, this.data.shopId = t.Id, this.data.pageLoaded = !0, this.data.productLayout = t.ProductLayout, 
            this.data.isHasCoupon = t.CoupnCount > 0, wx.setStorageSync("shopBranchId", t.Id), 
            wx.setStorageSync("FranchiseeId", t.FranchiseeId), this._getPopupAdvert(t.FranchiseeId);
        },
        _categoryInit: function(t) {
            var a = this;
            !this.data.Store.IsClose && this.data.isShowProduct && (t.Categories.map(function(t, e) {
                t.index = e, a.data.staticData.listKeys[t.Id] = e, a.data.staticData.listRects.push("_list_" + t.Id);
            }), this.data.IsShowAll && this.data.staticData.listRects.push("_list_0"), this.data.categories = t.Categories, 
            this.data.categoryId = this.data.IsShowAll ? 0 : t.Categories[0] ? t.Categories[0].Id : 0);
        },
        _getNewOrderList: function() {
            var t = this;
            this.data.Store.IsClose || (clearTimeout(this.newBuyRequestTimer), this.newBuyRequestTimer = setTimeout(function() {
                a.httpGet(i.getUrl("CommunityStore/GetNewBuyOrder"), {}, function(a) {
                    a.success && a.data.length >= 10 && (a.data.forEach(function(t) {
                        t.UserPhoto || (t.UserPhoto = "../../images/avatar-null.png");
                    }), t._getNewBuyOrderTop(function() {
                        t.data.newbuyorder = a.data, t.setData({
                            newbuyorder: a.data,
                            newBuyOrderTop: t.data.newBuyOrderTop
                        }), t._setNewBuyAnimate();
                    }));
                });
            }, 3e3));
        },
        _getNewBuyOrderTop: function(t) {
            var a = this;
            this.createSelectorQuery().select("#headerBox").boundingClientRect(function(e) {
                a.data.newBuyOrderTop = e.height, t && t();
            }).exec();
        },
        _getCartData: function() {
            this._getCartQuantity(), i.getCartTotal();
        },
        _getCartQuantity: function() {
            var t = this;
            clearTimeout(this.syncCartQuantityTimer), this.syncCartQuantityTimer = setTimeout(function() {
                t.data.limitProducts.length > 0 && t.data.limitProducts.map(function(t) {
                    if (i.globalData.cartData.items[t.Id]) {
                        var a = 0;
                        for (var e in i.globalData.cartData.items[t.Id].skus) a += i.globalData.cartData.items[t.Id].skus[e].Quantity;
                        t.Quantity = a;
                    } else t.Quantity = 0;
                }), t.data.products.length > 0 && t.data.products.map(function(t) {
                    if (i.globalData.cartData.items[t.Id]) {
                        var a = 0;
                        for (var e in i.globalData.cartData.items[t.Id].skus) a += i.globalData.cartData.items[t.Id].skus[e].Quantity;
                        t.Quantity = a;
                    } else t.Quantity = 0;
                }), t.setData({
                    products: t.data.products,
                    limitProducts: t.data.limitProducts
                });
            }, 2500);
        },
        _setCollectionTip: function() {
            var t = this, a = wx.getLaunchOptionsSync();
            1001 != a.scene && 1089 != a.scene && (this.setData({
                collectTip: !0
            }), setTimeout(function() {
                t.setData({
                    collectTip: !1
                });
            }, 3e3));
        },
        _getVisitCount: function() {
            wx.getStorageSync("shopBranchId") && wx.request({
                url: i.getUrl("Home/GetStatisticShopBranchVisitUserCount"),
                data: {
                    shopBranchId: wx.getStorageSync("shopBranchId")
                },
                success: function(t) {}
            });
        },
        _setTimeProduct: function() {
            var t = this;
            clearInterval(this.timeload), this.timeload = setInterval(function() {
                t.data.products.forEach(function(a) {
                    a.IsLimit && (a.IsStarted ? (a.EndSecond -= 1, a.EndSecond >= 0 ? a.time = t.formatDuring(a.EndSecond) : a.overtime = !0) : (a.StartSecond -= 1, 
                    a.StartSecond >= 0 ? (a.EndSecond -= 1, a.time = t.formatDuring(a.StartSecond)) : (a.IsStarted = !0, 
                    a.overtime = !(a.EndSecond > 0))));
                }), t.setData({
                    products: t.data.products
                });
            }, 1e3);
        },
        _setTimeLoad: function() {
            var t = this;
            clearInterval(this.timeload), this.timeload = setInterval(function() {
                t.data.limitProducts.forEach(function(a) {
                    a.IsLimit && (a.IsStarted ? (a.EndSecond -= 1, a.EndSecond >= 0 ? a.time = t.formatDuring(a.EndSecond) : a.overtime = !0) : (a.StartSecond -= 1, 
                    a.StartSecond >= 0 ? (a.EndSecond -= 1, a.time = t.formatDuring(a.StartSecond)) : (a.IsStarted = !0, 
                    a.overtime = !(a.EndSecond > 0))));
                }), t.setData({
                    limitProducts: t.data.limitProducts
                });
            }, 1e3);
        },
        _setProductToTop: function() {
            var t = this;
            clearTimeout(this.setProductTopTimer), this.setProductTopTimer = setTimeout(function() {
                t.createSelectorQuery().select("#products").boundingClientRect(function(a) {
                    a && t.createSelectorQuery().select("#headerBox").boundingClientRect(function(e) {
                        var i = (null != a.top ? a.top : 0) + t.data.staticData.scrollTop - e.height;
                        wx.pageScrollTo({
                            scrollTop: i,
                            duration: 0
                        });
                    }).exec();
                }).exec();
            }, 100);
        },
        getNextData: function() {
            var t = this;
            if (0 === this.data.categoryId || this.data.keyword) return null;
            var a = this.data.categories || [], e = -1;
            if (0 === a.length) return null;
            if (a.some(function(a, i) {
                a.Id !== t.data.categoryId || (e = i);
            }), -1 !== e) {
                var i = a[e + 1];
                if (i) return {
                    id: i.Id,
                    name: i.Name,
                    index: i.index
                };
            }
            return null;
        },
        _getTemplateProducts: function(e) {
            var o = this;
            this.data.tempLoading || (1 == this.data.pageNo && this.setData({
                limitProducts: [],
                products: []
            }), this.setData({
                tempLoading: !0
            }), a.httpGet(i.getUrl("Home/GetTemplateProducts"), {
                type: this.data.limitType,
                openId: wx.getStorageSync("mallAppletOpenId"),
                shopBranchId: wx.getStorageSync("shopBranchId"),
                categoryId: this.data.categoryId,
                pageNo: this.data.pageNo,
                tmplType: this.data.productLayout
            }, function(a) {
                if (o.setData({
                    tempLoading: !1
                }), a.success) {
                    var i = o.data.productLayout, n = 3 === i || 4 === i || 7 === i || 8 === i, r = a.data.ProductList.length == o.data.pageSize;
                    if (r && a.data.TotalCount !== o.data.limitProducts.length + o.data.products.length + a.data.ProductList.length) o.setData({
                        isHasNextCategory: !1
                    }); else if (0 != o.data.categoryId) {
                        var d = o.getNextData();
                        o.setData({
                            showNext: !0,
                            nextData: d || null,
                            isHasNextCategory: !!d
                        });
                    }
                    if (o.setData({
                        nextPage: r
                    }), n) a.data.ProductList.map(function(t) {
                        t.Tags && (t.Tags = t.Tags.split(",")), t.IsStarted ? (t.time = o.formatDuring(Math.round(t.EndSecond)), 
                        t.EndSecond <= 0 && (t.overtime = !0)) : t.time = o.formatDuring(Math.round(t.StartSecond));
                    }), o.setData({
                        limitType: a.data.LimitType,
                        existCountDown: !1,
                        products: o.data.pageNo > 1 ? [].concat(t(o.data.products), t(a.data.ProductList)) : a.data.ProductList
                    }), o._getCartData(), o._setTimeProduct(); else {
                        var c = [], u = [];
                        a.data.ProductList.map(function(t) {
                            t.Tags && (t.Tags = t.Tags.split(",")), t.IsStarted ? (t.time = o.formatDuring(Math.round(t.EndSecond)), 
                            t.EndSecond <= 0 && (t.overtime = !0)) : t.time = o.formatDuring(Math.round(t.StartSecond)), 
                            t.IsLimit ? c.push(t) : u.push(t);
                        });
                        var h = !0;
                        1 == o.data.pageNo ? o.data.limitType === s.limitType.auto && 0 === c.length && (o.data.isNoLimitProduct = !0, 
                        h = !1) : h = o.data.existCountDown;
                        var g = 0 === o.data.limitProducts.length && 0 === c.length;
                        e && e.isClearLimit && (0 == c.length ? (h = !1, 1 !== o.data.pagingNumber || o.data.isNoLimitProduct || (h = !0)) : h = !0), 
                        o.setData({
                            limitType: a.data.LimitType,
                            existCountDown: h,
                            limitProducts: o.data.pageNo > 1 ? [].concat(t(o.data.limitProducts), c) : c,
                            products: o.data.pageNo > 1 ? [].concat(t(o.data.products), u) : u,
                            isLimitEmpty: g
                        }), o._setTimeLoad();
                    }
                    if (1 == o.data.pageNo) {
                        var l = 1, p = [];
                        l = Math.ceil(a.data.TotalCount / o.data.pagingSize);
                        for (var m = 0; m < l; m++) p.push(m + 1);
                        o.setData({
                            pagingNumber: 1,
                            pagingTotal: l,
                            pagingPages: p
                        });
                    }
                    (o.isAnchor && 1 === o.data.pageNo || o.pagingChange) && (o._setProductToTop(), 
                    o.isAnchor = !1, o.pagingChange = !1), o.getPagingStatus(), o._getCartQuantity();
                }
            }));
        },
        _setNewBuyAnimate: function() {
            var t = this;
            if (clearTimeout(this.newBuyTimer), !(this.data.newbuyorder.length <= 0)) {
                var a = wx.createAnimation({
                    timingFunction: "linear"
                });
                this.data.showNewBuyIndex < this.data.newbuyorder.length - 1 ? this.data.showNewBuyIndex = this.data.showNewBuyIndex + 1 : this.data.showNewBuyIndex = 0, 
                a.translateY(-32 * this.data.showNewBuyIndex).step(), this.newBuyTimer = setTimeout(function() {
                    t.setData({
                        animationData: a.export()
                    }), t._setNewBuyAnimate();
                }, 4e3);
            }
        },
        _getListPositionInfo: function() {
            var t = this;
            if (!(this.data.categories.length <= 0) && this.data.isShowProduct && !this.data.staticData.listInit) {
                this.data.staticData.listInit = !0;
                var a = 0;
                this.data.staticData.listRects.forEach(function(e) {
                    t.createSelectorQuery().select("#" + e).boundingClientRect().exec(function(e) {
                        e.map(function(e) {
                            t.data.staticData.listLefts.push(a + (e.width + 28) / 2), a += e.width + 28;
                        });
                    });
                });
            }
        },
        getListPosition: function(t) {
            this.data.staticData.listLefts[t] && this.data.staticData.listLefts[t] > this.data.staticData.windowW / 2 ? this.setData({
                listScrollLeft: this.data.staticData.listLefts[t] - this.data.staticData.windowW / 2
            }) : this.setData({
                listScrollLeft: 0
            });
        },
        formatDuring: function(t) {
            var a = parseInt(t / 3600), e = parseInt(t % 3600 / 60), i = parseInt(t % 60);
            return a < 10 && (a = "0" + a), e < 10 && (e = "0" + e), i < 10 && (i = "0" + i), 
            [ a, e, i ];
        },
        getScrollInfo: function(t) {
            var a = this;
            this.createSelectorQuery().select("#body-container").boundingClientRect(function(e) {
                if (e) {
                    var i = a.data.staticData.windowH + a.data.staticData.scrollTop >= e.height - 5;
                    n.isBottom = !!i, t && t();
                }
            }).exec();
        },
        bindNavScroll: function(t) {
            0 == t.detail.scrollLeft && this.setData({
                listScrollLeft: 0
            });
        },
        getPagingStatus: function() {
            this.setData({
                isShowPaging: !1
            }), this.data.limitProducts.length + this.data.products.length >= this.data.pagingSize && this.setData({
                isShowPaging: !0
            }), this.data.pagingNumber > 1 && !this.data.nextPage && this.setData({
                isShowPaging: !0
            });
        },
        handlePagePre: function() {
            this.data.pagingNumber <= 1 || this.setPagingInit(this.data.pagingNumber - 1);
        },
        handlePageNext: function() {
            this.data.pagingNumber >= this.data.pagingTotal || this.setPagingInit(this.data.pagingNumber + 1);
        },
        bindPickerChange: function(t) {
            var a = t.detail.value, e = this.data.pagingPages[a];
            e != this.data.pagingNumber && this.setPagingInit(parseInt(e));
        },
        setPagingInit: function(t) {
            this.setData({
                pagingNumber: t,
                limitProducts: [],
                products: [],
                pageNo: (t - 1) * (this.data.pagingSize / 10) + 1,
                isShowPaging: !1
            }), this.pagingChange = !0, this._getTemplateProducts({
                isClearLimit: !0
            });
        },
        _getPopupAdvert: function(t, e) {
            var o = this;
            this.adverting || (this.adverting = !0, a.httpGet(i.getUrl("Home/GetAdvertisingData"), {
                franchiseeId: t
            }, function(a) {
                if (a.success) {
                    if (!a.data.IsEnable) return;
                    var i = r.getPopupAdvertSetting(), s = new Date(), n = !1, d = null, c = new Date(), u = !1, h = i[t];
                    h ? (d = h.lastRecord, u = h.isRead, c = d ? new Date(d) : new Date(), h.lastRecord = new Date().getTime()) : i[t] = {
                        lastRecord: new Date().getTime(),
                        isRead: !1
                    }, r.setPopupAdvertSetting(i);
                    var g = !1;
                    s.getFullYear() >= c.getFullYear() && s.getMonth() >= c.getMonth() && s.getDate() - c.getDate() >= 1 && (g = !0, 
                    u = !1), a.data.IsRepeatShow || d && !g || (n = !0), n || !a.data.IsRepeatShow || u || (n = !0), 
                    o.setData({
                        isPopupAdvert: n,
                        popupAdvertInfo: a.data,
                        isShowPopupAdvert: !0
                    });
                }
                e && e();
            }));
        },
        toCategories: function() {
            o.emit("tabUserChange", {
                url: "../categories/categories?focus=true"
            });
        },
        goToStores: function() {
            wx.navigateTo({
                url: "../userpickupstation/userpickupstation"
            });
        },
        changeCategory: function(t) {
            var a = t.currentTarget.dataset.categoryid;
            this.setData({
                showNext: !1,
                existCountDown: !1,
                limitType: s.limitType.auto,
                categoryId: a,
                pageNo: 1
            }), this.getListPosition(t.currentTarget.dataset.index), this.isAnchor = !0, this._getTemplateProducts();
        },
        changeLimitType: function(t) {
            this.setData({
                isLimitEmpty: !1,
                limitType: parseInt(t.currentTarget.dataset.type),
                nextPage: !0,
                pageNo: 1
            }), this._getTemplateProducts();
        },
        onJoinCart: function(t) {
            t.detail.currentTarget.dataset.hassku ? this.chooseSku(t.detail) : this.productNumChange(t.detail);
        },
        productNumChange: function(t) {
            var a = this, e = t.currentTarget.dataset.id, i = t.currentTarget.dataset.index, o = t.currentTarget.dataset.type ? 1 : -1, s = 1 == parseInt(t.currentTarget.dataset.limit), n = t.currentTarget.dataset.delivery, r = void 0 === t.currentTarget.dataset.issync || t.currentTarget.dataset.issync;
            this.setData({
                productIsLimit: s,
                skuProductid: e
            }), this.storeCart.changeCart(e + "_0_0_0", o, function(t) {
                if (r) {
                    var e = a.data.products[i];
                    s && (e = a.data.limitProducts[i]), e.Quantity = e.Quantity ? e.Quantity + o : o, 
                    3001 !== t.code && 3002 !== t.code && 3003 !== t.code || (e.Quantity = t.data), 
                    e.Quantity < 0 && (e.Quantity = 0), s ? a.setData({
                        limitProducts: a.data.limitProducts
                    }) : a.setData({
                        products: a.data.products
                    }), console.log(a.data);
                }
                t.success && wx.showToast({
                    title: "加入购物车成功",
                    icon: "none"
                });
            }, null, n);
        },
        goProduct: function(t) {
            var a = t.currentTarget.dataset.id, e = 1 == parseInt(t.currentTarget.dataset.limit);
            this.setData({
                openLimit: e,
                openProductId: a
            }), wx.navigateTo({
                url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.currentTarget.dataset.id
            });
        },
        bindtouchstart: function(t) {
            n.startY = t.touches[0].pageY;
        },
        bindtouchmove: function(t) {
            n.endY = t.touches[0].pageY, n.moveY = n.endY - n.startY, this.data.showNext && this.data.isHasNextCategory && n.isBottom && !this.data.staticData.isIos && Math.abs(n.moveY) < 200 && (this.data.staticData.startMove || n.endY < n.startY) && (this.data.staticData.startMove = !0, 
            this.getAnimation(50, n.moveY + "px"));
        },
        bindtouchend: function(t) {
            var a = this;
            this.data.staticData.startMove = !1, this.data.categories.length <= 0 || this.data.showNext && this.data.isHasNextCategory && (this.getScrollInfo(function() {
                n.endY < n.startY ? (n.isAuto && n.isBottom && Math.abs(n.moveY) > 140 && (a.touchLoadData(), 
                n.isBottom = !1, n.isAuto = !1, a.data.staticData.isIos || a.getAnimation(300, 0, "ease")), 
                n.isBottom ? n.isAuto = !0 : n.isAuto = !1) : n.isAuto = !1;
            }), this.getAnimation(300, 0, "ease"));
        },
        touchLoadData: function() {
            this.setData({
                limitType: s.limitType.auto,
                categoryId: this.data.nextData.id,
                pageNo: 1,
                nextPage: !0,
                isShowPaging: !1
            }), this.isAnchor = !0, this._getTemplateProducts(), this.getListPosition(this.data.nextData.index + (this.data.IsShowAll ? 1 : 0));
        },
        getAnimation: function(t, a, e) {
            var i = wx.createAnimation({
                duration: t,
                timingFunction: e || "linear"
            });
            i.translateY(a).step(), this.setData({
                elasticAnimation: i.export()
            });
        },
        showCouponToggle: function() {
            var t = this;
            i.getOpenId(function(a) {
                t.data.couponsData.length ? t.setData({
                    showcoupon: !t.data.showcoupon
                }) : t.getCouponList();
            });
        },
        goTop: function(t) {
            wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
        },
        getCoupon: function() {
            var t = this, e = this, o = "";
            e.data.couponsData.forEach(function(t) {
                o += t.Id + ",";
            }), a.httpGet(i.getUrl("Coupon/GetActiveClaimCoupons"), {
                couponIds: o,
                openId: i.globalData.openId,
                franchiseeId: e.data.Store.FranchiseeId
            }, function(o) {
                o.success ? (wx.showToast({
                    title: o.msg,
                    icon: "none"
                }), a.httpGet(i.getUrl("Home/GetShopCoupons"), {
                    openId: i.globalData.openId,
                    franchiseeId: e.data.Store.FranchiseeId
                }, function(a) {
                    a.success ? (a.data.forEach(function(t) {
                        t.StartTime = t.StartTime.slice(0, 10), t.EndTime = t.EndTime.slice(0, 10);
                    }), t.setData({
                        couponsData: a.data,
                        showcoupon: !1
                    })) : wx.showToast({
                        title: a.msg,
                        icon: "none"
                    });
                })) : 502 == o.code ? (wx.showToast({
                    title: "请先登录账号",
                    icon: "none"
                }), wx.navigateTo({
                    url: "../login/login"
                })) : wx.showToast({
                    title: o.msg,
                    icon: "none"
                });
            });
        },
        showVideo: function(t) {
            this.setData({
                currentVideo: t.currentTarget.dataset.video,
                showVideo: !0
            });
        },
        closeVideo: function() {
            this.setData({
                currentVideo: "",
                showVideo: !1
            });
        },
        chooseSku: function(t) {
            var a = this;
            i.getOpenId(function(e) {
                if (e) {
                    a.setData({
                        skuProductid: t.currentTarget.dataset.id
                    });
                    var i = t.currentTarget.dataset.delivery;
                    a.storeCart.chooseSku(i);
                }
            });
        },
        goToCopyright: function() {
            wx.navigateTo({
                url: "../outurl/outurl?url=" + i.getRequestUrl + "hishop/index.html"
            });
        },
        goKeepOnRecordUrl: function() {
            null != this.data.KeepOnRecordUrl && "" != this.data.KeepOnRecordUrl && wx.navigateTo({
                url: "../outurl/outurl?url=" + this.data.KeepOnRecordUrl
            });
        },
        goStoreClose: function() {
            wx.navigateTo({
                url: "../storeclose/storeclose"
            });
        },
        updateproduct: function(t) {
            this._getCartQuantity();
        },
        getCouponList: function() {
            var t = this;
            this.data.isHasCoupon && !this.data.couponLoading && (this.setData({
                couponLoading: !0
            }), wx.showLoading({
                title: "加载中..."
            }), a.httpGet(i.getUrl("Home/GetShopCoupons"), {
                openId: i.globalData.openId,
                franchiseeId: this.data.Store.FranchiseeId,
                couponType: 0
            }, function(a) {
                t.setData({
                    couponLoading: !1
                }), wx.hideLoading(), a.success ? (a.data.forEach(function(t) {
                    t.StartTime = t.StartTime.slice(0, 10), t.EndTime = t.EndTime.slice(0, 10);
                }), a.data.length <= 0 ? (t.setData({
                    showcoupon: !1,
                    isHasCoupon: !1
                }), wx.showToast({
                    title: "优惠券已领完",
                    icon: "none"
                })) : t.setData({
                    couponsData: a.data,
                    showcoupon: !t.data.showcoupon
                })) : wx.showToast({
                    title: a.msg,
                    icon: "none"
                });
            }));
        },
        onHideAdvert: function() {
            this.setData({
                isShowPopupAdvert: !1
            });
        },
        onImgLoad: function(t) {
            var a = t.detail, i = a.width, o = a.height, s = e.drawImage(i, o, 280, 320), n = this.data.popupAdvert;
            n.imgWidth = s.width, n.imgHeight = s.height, n.init = !0, this.setData({
                popupAdvert: n
            });
        },
        onOpenAdvert: function(t) {
            var a = r.getPopupAdvertSetting();
            a[wx.getStorageSync("FranchiseeId")] && (a[wx.getStorageSync("FranchiseeId")].isRead = !0, 
            r.setPopupAdvertSetting(a)), this.onHideAdvert(), i.customTap(t);
        },
        onUpdatephone: function() {
            this.setData({
                showBindPhone: !1
            });
        }
    }
});