var t = getApp();

Component({
    lifetimes: {
        ready: function() {
            var e = this;
            t.getSystemInfo(function(t) {
                e.setData({
                    x: t.windowWidth - 72 - 12,
                    y: t.windowHeight - 90 - 138
                });
            });
        }
    },
    data: {
        x: 1e3,
        y: 1e3
    },
    methods: {
        showCouponToggle: function() {
            this.triggerEvent("showCouponToggle");
        }
    }
});