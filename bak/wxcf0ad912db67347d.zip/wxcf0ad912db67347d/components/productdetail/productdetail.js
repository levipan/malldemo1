var t = require("../../utils/config"), e = getApp();

Component({
    properties: {
        productId: String,
        activeId: String
    },
    data: {
        isInit: !1,
        isShow: !1,
        loading: !0,
        translateY: 0,
        scrollTop: 0,
        moduleData: null
    },
    lifetimes: {
        ready: function() {
            var t = this;
            e.getSysSettingData(function(e) {
                t.setData(e);
            });
        }
    },
    methods: {
        init: function() {
            var a = this;
            e.getOpenId(function(i) {
                t.httpGet(e.getUrl("GroupSolitaire/GetProductDetail"), {
                    productId: a.data.productId,
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    id: a.data.activeId
                }, function(t) {
                    t.success && a.setData({
                        isInit: !0,
                        info: t.data
                    }, function() {
                        a.getModel();
                    });
                });
            }, !0), this.setData({
                isShow: !0
            });
        },
        getModel: function() {
            var a = this;
            this.data.info.MetaDescription || this.data.info.ProductTemplate ? this.getProductTemplate(function(i) {
                if (!a.data.info.MetaDescription && i) return a.setData({
                    moduleData: i
                });
                wx.request({
                    url: a.data.info.MetaDescription + "?r=" + Date.parse(new Date()) / 1e3,
                    dataType: "json",
                    success: function(n) {
                        if (i) {
                            var o = i.findIndex(function(t) {
                                return 98 === t.type;
                            });
                            -1 != o ? (i.splice(o, 1), n.data.LModules.forEach(function(t, e) {
                                i.splice(o + e, 0, t);
                            })) : i = n.data.LModules.concat(i);
                        } else i = n.data.LModules;
                        a.setData({
                            moduleData: i
                        }), null != a.data.moduleData && a.data.moduleData.forEach(function(i) {
                            if (4 == i.type) {
                                var n = "";
                                i.content.goodslist.forEach(function(t, e) {
                                    n = 0 == e ? t.item_id : n + "," + t.item_id;
                                }), t.httpGet(e.getUrl("product/GetProductLastPriceByIds"), {
                                    openId: e.globalData.openId,
                                    productIds: n,
                                    shopBranchId: a.data.shopBranchId,
                                    preview: a.data.preview
                                }, function(t) {
                                    t.success && (i.content.goodslist.forEach(function(a) {
                                        t.data.Data.forEach(function(t) {
                                            a.item_id == t.productId && (a.price = t.price, a.title = null != t.title ? t.title : a.title, 
                                            a.pic = null != t.pic ? -1 == t.pic.indexOf("http://") && -1 == t.pic.indexOf("https://") ? e.getRequestUrl + t.pic : t.pic : a.pic);
                                        });
                                    }), a.setData({
                                        moduleData: a.data.moduleData
                                    }));
                                });
                            }
                        }), wx.hideNavigationBarLoading();
                    }
                });
            }) : this.setData({
                moduleData: null
            });
        },
        getProductTemplate: function(t) {
            if (!this.data.info.ProductTemplate) return t(null);
            wx.request({
                url: this.data.info.ProductTemplate + "?r=" + Date.parse(new Date()) / 1e3,
                dataType: "json",
                success: function(e) {
                    t(e.data.LModules);
                }
            });
        },
        getAngle: function(t, e) {
            return 180 * Math.atan2(e, t) / Math.PI;
        },
        getDirection: function(t, e, a, i) {
            var n = a - t, o = i - e, s = 0;
            if (Math.abs(n) < 2 && Math.abs(o) < 2) return s;
            var r = this.getAngle(n, o);
            return r >= -135 && r <= -45 ? s = 1 : r > 45 && r < 135 ? s = 2 : r >= 135 && r <= 180 || r >= -180 && r < -135 ? s = 3 : r >= -45 && r <= 45 && (s = 4), 
            s;
        },
        bindtouchstart: function(t) {
            this.startY = t.changedTouches[0].clientY, this.startX = t.changedTouches[0].clientX;
        },
        bindtouchmove: function(t) {
            var e = t.changedTouches[0].clientX, a = t.changedTouches[0].clientY;
            if (this.direction || (this.direction = this.getDirection(this.startX, this.startY, e, a)), 
            2 === this.direction && 0 === this.data.scrollTop) {
                var i = a - this.startY;
                this.setData({
                    translateX: 0,
                    translateY: i <= 0 ? 0 : i
                });
            }
            return !1;
        },
        bindtouchend: function(t) {
            this.direction = 0, this.data.translateY > 20 ? this.setHide() : this.setData({
                translateY: 0
            });
        },
        setHide: function() {
            this.triggerEvent("hidePopup", !1), this.setData({
                translateY: 0,
                isShow: !1,
                scrollTop: 0
            });
        },
        onProviewImg: function(t) {
            wx.previewImage({
                current: t.currentTarget.dataset.path,
                urls: this.data.info.ProductImgs
            });
        }
    }
});