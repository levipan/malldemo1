var t = require("../../utils/config.js"), a = getApp(), e = require("../../utils/qqmap-wx-jssdk.min.js"), o = void 0;

require("../../utils/busEvent");

Component({
    properties: {},
    data: {
        location: "正在定位",
        locationName: "",
        showNoLocate: !1,
        isDataEnd: !1,
        loadDataing: !1,
        list: [],
        isLoading: !1,
        pageLoaded: !1,
        categoryId: 0,
        fromLatLng: "",
        KeyWord: "",
        pageIndex: 1,
        pageSize: 10
    },
    methods: {
        onLoad: function() {
            var t = this;
            wx.showNavigationBarLoading(), a.getSysSettingData(function(i) {
                t.setData(i), o = new e({
                    key: a.globalData.QQMapKey
                }), t.getLocation();
            }, !0), this.onShow();
        },
        onShow: function() {},
        onInputKeyword: function(t) {
            var a = this, e = t.detail.value;
            a.setData({
                KeyWord: e
            }), e ? (clearTimeout(this.searchTimer), this.searchTimer = setTimeout(function() {
                a.onConfirmSearch();
            }, 500)) : a.onConfirmSearch();
        },
        onConfirmSearch: function() {
            var t;
            this.data.KeyWord ? t = !0 : (t = !1, this.setData({
                pageIndex: 1
            })), this.setData({
                loadDataing: !1,
                isLoading: !1,
                isDataEnd: !1,
                categoryId: 0,
                isSearch: t
            }), this.getServiceShopList(1);
        },
        toChooseAddr: function() {
            var t = this;
            wx.navigateTo({
                url: "../storelocation/storelocation?fromLatLng=" + t.data.fromLatLng + "&cityname=" + (t.data.cityinfo ? t.data.cityinfo : "") + "&location=" + t.data.location
            });
        },
        getLocation: function() {
            var t = this;
            wx.getLocation({
                type: "gcj02",
                success: function(a) {
                    t.setData({
                        fromLatLng: a.latitude + "," + a.longitude,
                        showNoLocate: !1,
                        isDataEnd: !1,
                        pageIndex: 1,
                        list: []
                    }), t.getStoreList();
                },
                fail: function() {
                    t.setData({
                        location: "未获取定位",
                        showNoLocate: !0,
                        list: []
                    });
                }
            });
        },
        reGetLocation: function() {
            var t = this;
            wx.getLocation({
                type: "gcj02",
                success: function(a) {
                    t.setData({
                        fromLatLng: a.latitude + "," + a.longitude
                    }), t.getStoreList();
                },
                fail: function(e) {
                    a.openSetting(function() {
                        t.getLocation();
                    });
                }
            });
        },
        getStoreList: function() {
            this.getCategorieList();
        },
        getCategorieList: function() {
            var e = this;
            this.setData({
                categoryId: 0,
                isDataEnd: !1,
                categoryList: [],
                list: []
            }), t.httpGet(a.getUrl("ServiceShop/GetShopCategory"), {
                fromLatLng: this.data.fromLatLng,
                provider: "applet",
                shopBranchId: wx.getStorageSync("shopBranchId")
            }, function(t) {
                t.success && (t.data && (t.data.unshift({
                    Id: 0,
                    Name: "全部"
                }), e.setData({
                    categoryList: t.data
                })), e.getServiceShopList(1));
            });
        },
        getServiceShopList: function(e) {
            var i = this;
            if (!i.data.loadDataing) {
                var n = i.data.fromLatLng.split(",");
                i.setData({
                    loadDataing: !0
                });
                var s = {
                    pageNo: e,
                    pageSize: i.data.pageSize,
                    fromLatLng: i.data.fromLatLng,
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    keyWords: i.data.KeyWord,
                    categoryId: i.data.categoryId
                };
                i.data.locationName && t.httpGet(a.getUrl("ServiceShop/List"), s, function(t) {
                    wx.stopPullDownRefresh(), i.setResultData(t);
                }), o.reverseGeocoder({
                    location: {
                        latitude: n[0],
                        longitude: n[1]
                    },
                    get_poi: 1,
                    poi_options: "page_size=10;radius=1000;policy=2",
                    success: function(e) {
                        i.setData({
                            cityinfo: e.result.address_component.city,
                            location: e.result.formatted_addresses.recommend
                        }), i.data.locationName ? i.setData({
                            location: i.data.locationName
                        }) : (s.fromLatLng = e.result.pois[0].location.lat + "," + e.result.pois[0].location.lng, 
                        t.httpGet(a.getUrl("ServiceShop/List"), s, function(t) {
                            wx.stopPullDownRefresh(), i.setResultData(t);
                        })), wx.hideNavigationBarLoading();
                    },
                    fail: function(t) {
                        wx.showToast({
                            title: "获取位置失败"
                        });
                    }
                });
            }
        },
        setResultData: function(t, a) {
            var e = this;
            if (e.setData({
                pageLoaded: !0,
                loadDataing: !1,
                isLoading: !1
            }), t.success) {
                var o = (t = t.data).ServiceShops, i = 1 == e.data.pageIndex || a ? [] : e.data.list;
                (!t.ServiceShops || t.ServiceShops.length < e.data.pageSize) && e.setData({
                    isDataEnd: !0
                }), e.data.isSearch ? e.setData({
                    list: o,
                    showNoLocate: !1,
                    IsShowShopBranchLink: t.IsShowShopBranchLink
                }) : e.setData({
                    list: i.concat(o),
                    showNoLocate: !1,
                    IsShowShopBranchLink: t.IsShowShopBranchLink
                });
            } else e.setData({
                location: "未获取定位",
                showNoLocate: !0
            });
        },
        callShopTel: function(t) {
            wx.makePhoneCall({
                phoneNumber: t.currentTarget.dataset.tel
            });
        },
        reachBottom: function() {
            var t = this.data.pageIndex;
            this.setData({
                pageIndex: t + 1,
                isLoading: !0
            }), this.getServiceShopList(t + 1);
        },
        changeShopBranch: function(t) {
            var a = t.currentTarget.dataset.id;
            wx.navigateTo({
                url: "../serviceStore/serviceStore?id=" + a
            });
        },
        onChangeCategory: function(t) {
            var a = t.currentTarget.dataset.id;
            this.setData({
                categoryId: a
            }), this.getServiceShopList(1);
        }
    }
});