var t = require("../../pages/wxParse/wxParse.js"), a = getApp(), e = require("../../utils/config");

require("../../utils/busEvent");

Component({
    properties: {
        moduleData: {
            type: Array,
            observer: function() {
                this.parseHtml();
            }
        }
    },
    data: {
        hostUrl: a.getRequestUrl,
        primaryColor: a.globalData.PrimaryColor,
        defaultTag: [ "/images/tag1.png", "/images/tag2.png", "/images/tag3.png", "/images/tag4.png" ],
        indicator: {},
        newUserRead: !1,
        isHasNewUserActive: !1
    },
    ready: function() {
        this.addToCart = this.selectComponent("#addToCart");
    },
    pageLifetimes: {
        show: function() {
            this.data.isHasNewUserActive && (a.globalData.isHideNewUserActive && this._hideNewUserActive(), 
            this._getIsNewUserActive());
        }
    },
    methods: {
        parseHtml: function() {
            var e = this;
            if (this.data.moduleData.length > 0) {
                var o = [], i = [], n = [], s = 0, d = !1;
                if (this.data.moduleData.forEach(function(a, c) {
                    3 === a.type && t.wxParse("editors.editor" + a.id, "html", a.content.fulltext, e, a.content.fullScreen ? "0" : "20"), 
                    8 === a.type && a.content.couponType && (i.push({
                        index: c,
                        size: a.content.count
                    }), s = Math.max(s, a.content.count)), 9 === a.type && a.content.goodslist.forEach(function(t) {
                        o.push(t.RoomId);
                    }), 10 === a.type && a.content.goodslist.forEach(function(t) {
                        n.push(t.item_id), t.pic.indexOf("http://") < 0 && t.pic.indexOf("https://") < 0 && (t.pic = e.data.hostUrl + t.pic);
                    }), 11 === a.type && (d = !0, a.content.goodslist.forEach(function(t) {
                        t.pic = e.data.hostUrl + t.pic;
                    }));
                }), this.setData({
                    isHasNewUserActive: d,
                    primaryColor: a.globalData.PrimaryColor,
                    moduleData: this.data.moduleData
                }), i.length && wx.request({
                    url: a.getUrl("Home/GetShopCoupons"),
                    data: {
                        franchiseeId: wx.getStorageSync("FranchiseeId"),
                        openId: a.globalData.openId,
                        size: s,
                        couponType: -1
                    },
                    success: function(t) {
                        var a = t.data.data;
                        i.map(function(t) {
                            e.data.moduleData[t.index].content.coupons = a.length > t.size ? a.slice(0, t.size) : a;
                        }), e.setData({
                            moduleData: e.data.moduleData
                        });
                    }
                }), o.length > 0) {
                    var c = o.join(",");
                    wx.request({
                        url: a.getUrl("Live/GetHomeLiveData"),
                        data: {
                            ids: c
                        },
                        success: function(t) {
                            if (!(t = t.data).success) return wx.showToast({
                                title: t.mes,
                                icon: "none"
                            });
                            var a = [];
                            t.data.forEach(function(t) {
                                a[t.RoomId] = t;
                            }), e.data.moduleData.forEach(function(t) {
                                9 === t.type && t.content.goodslist.forEach(function(e, o) {
                                    t.content.goodslist[o] = a[e.RoomId];
                                });
                            }), e.setData({
                                moduleData: e.data.moduleData
                            });
                        }
                    });
                }
                n.length > 0 && this._getTopPicProduct(n), d && this._getIsNewUserActive();
            }
        },
        customTap: function(t) {
            a.customTap(t);
        },
        handleChangeIndicator: function(t) {
            var a = t.detail.current, e = t.currentTarget.dataset.id;
            this.data.indicator["id_" + e] = a + 1, this.setData({
                indicator: this.data.indicator
            });
        },
        _getTopPicProduct: function(t) {
            var o = this;
            a.getOpenId(function(i) {
                e.httpPost(a.getUrl("Product/TopicProducts"), {
                    ids: t,
                    openId: i || "",
                    shopBranchId: wx.getStorageSync("shopBranchId")
                }, function(t) {
                    var a = {};
                    t.data.forEach(function(t) {
                        a[t.item_id] = t;
                    }), o.data.moduleData.forEach(function(t) {
                        if (10 === t.type) {
                            var e = [];
                            t.content.goodslist.forEach(function(t) {
                                a[t.item_id] && e.push(a[t.item_id]);
                            }), t.content.goodslist = e;
                        }
                    }), o.setData({
                        moduleData: o.data.moduleData
                    });
                });
            }, !0);
        },
        _getIsNewUserActive: function() {
            var t = this;
            a.getOpenId(function(o) {
                e.httpGet(a.getUrl("product/GetNewExclusiveData"), {
                    openId: o || "",
                    shopBranchId: wx.getStorageSync("shopBranchId")
                }, function(a) {
                    if (a.success) {
                        var e = -1;
                        t.data.moduleData.forEach(function(t, o) {
                            11 === t.type && (e = o, t.content.goodslist = a.data || []);
                        }), a.data && a.data.length || !o || -1 == e || t.data.moduleData.splice(e, 1), 
                        t.setData({
                            newUserRead: !0,
                            moduleData: t.data.moduleData
                        });
                    } else t.setData({
                        newUserRead: !1
                    });
                });
            }, !0);
        },
        _hideNewUserActive: function() {
            var t = this.data.moduleData.findIndex(function(t) {
                return 11 === t.type;
            });
            -1 != t && (this.data.moduleData.splice(t, 1), this.setData({
                moduleData: this.data.moduleData
            }));
        },
        onJoinCart: function(t) {
            this.triggerEvent("onJoinCart", t);
        }
    }
});