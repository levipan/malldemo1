require("../../utils/config.js");

var e = getApp();

Component({
    properties: {
        showBindPhone: {
            type: Boolean
        },
        PrimaryColor: {
            type: String
        },
        PrimaryTxtColor: {
            type: String
        }
    },
    data: {
        showBindPhone: !1
    },
    methods: {
        getPhoneNumber: function(t) {
            var o = this;
            "getPhoneNumber:ok" === t.detail.errMsg && e.getPhoneNumber(t.detail, function() {
                o.setData({
                    showBindPhone: !1
                }), o.triggerEvent("updatephone");
            });
        },
        hideBindPhone: function() {
            this.setData({
                showBindPhone: !1
            });
        }
    }
});