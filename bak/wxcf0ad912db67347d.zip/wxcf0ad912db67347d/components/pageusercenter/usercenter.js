var t = require("../../utils/config.js"), e = getApp();

Component({
    properties: {},
    data: {
        headHeight: 8,
        userInfo: {},
        isLogin: !1,
        showTip: !1,
        hasStore: !1,
        hasSupplier: !1,
        hasDriver: !1,
        showCard: !1,
        showBindPhone: !1,
        IsDistribution: e.globalData.IsDistribution || !1,
        IsOpenDistributor: e.globalData.IsOpenDistributor || !1,
        distributionStatus: -1,
        distributionNames: {},
        identity: [],
        statusBarHeight: 20,
        containerHeight: "auto"
    },
    lifetimes: {
        created: function() {
            var t = this;
            wx.getSystemInfo({
                complete: function(e) {
                    t.setData({
                        statusBarHeight: e.statusBarHeight
                    });
                }
            }), e.getDistrbutionName(function(a) {
                t.setData({
                    isOpenSubledger: e.globalData.IsOpenSubledger,
                    distributionNames: a
                });
            });
        },
        ready: function() {
            var t = this;
            e.getSystemInfo(function(e) {
                t.setData({
                    windowH: e.screenHeight,
                    headHeight: 2 * (46 + e.statusBarHeight)
                }), t._getContainerHeight();
            });
        }
    },
    methods: {
        onLoad: function() {
            var t = this;
            wx.getSystemInfo({
                complete: function(e) {
                    t.setData({
                        statusBarHeight: e.statusBarHeight
                    });
                }
            }), e.getDistrbutionName(function(e) {
                t.setData({
                    isOpenSubledger: !1,
                    distributionNames: e
                });
            }), this.onShow();
        },
        onShow: function() {
            var t = this;
            this.setData({
                identity: []
            }), e.getCartTotal(), this.loadData(), this.setData({
                IsDistribution: e.globalData.IsDistribution,
                IsOpenDistributor: e.globalData.IsOpenDistributor
            }), this.getDistrbutionStatus(), this.data.hasGetSysSetting || e.getSysSettingData(function(a) {
                a.IsShowHishopCopyRight = e.globalData.IsShowHishopCopyRight, a.IsOpenSupplier = e.globalData.IsOpenSupplier, 
                a.IsJumpLink = e.globalData.IsJumpLink, a.hasGetSysSetting = !0, t.setData(a);
            }, !0), this.setData({
                CommunityJoinPhone: e.globalData.CommunityJoinPhone,
                ServiceShopJoinPhone: e.globalData.ServiceShopJoinPhone,
                SupplierJoinPhone: e.globalData.SupplierJoinPhone
            }), this.bindPhone = this.selectComponent("#bindPhone"), wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: this.data.PrimaryColor
            }), this._getContainerHeight();
        },
        onHide: function() {
            this.bindPhone && this.bindPhone.hideBindPhone(), wx.setNavigationBarColor({
                frontColor: "#000000",
                backgroundColor: "#ffffff"
            });
        },
        onPullDownRefresh: function() {
            setTimeout(function() {
                wx.stopPullDownRefresh();
            }, 1e3);
        },
        _getContainerHeight: function() {
            this.setData({
                containerHeight: this.data.windowH - e.globalData.customheaderHeight - e.globalData.customTabBarHeight + "px"
            });
        },
        handleOpenSetting: function() {
            wx.navigateTo({
                url: "../setting/setting"
            });
        },
        loadData: function() {
            var a = this;
            e.getOpenId(function(s) {
                s ? t.httpGet(e.getUrl("MemberCenter/GetUser"), {
                    openId: s
                }, function(t) {
                    if (t.success) {
                        t = t.data, e.globalData.Nick = t.Nick;
                        var s = e.globalData.userInfo;
                        a.checkUser(), null != s && (s.CellPhone = t.CellPhone), s.IsDistributor = t.IsDistributor, 
                        t.ShowBalance = "充值赠送", t.ShowBalanceClass = "red", t.IsOpenRechargePresent || (t.ShowBalance = t.Balance + "元", 
                        t.ShowBalanceClass = ""), null != t.CanRecharge && t.CanRecharge || (t.ShowBalance = "", 
                        t.ShowBalanceClass = ""), t.CellPhone ? a.setData({
                            showTip: !1
                        }) : a.setData({
                            showTip: !0
                        }), t.IsBeBindDriver && a.data.identity.push("hasDriver"), a.setData({
                            identity: a.data.identity,
                            isLogin: !0,
                            hasDriver: t.IsBeBindDriver,
                            userInfo: t
                        });
                    } else 504 === t.code && (e.showErrorModal("用户已被冻结"), wx.removeStorageSync("mallAppletOpenId"), 
                    e.globalData.wxUserInfo = null, e.globalData.openId = "", a.setData({
                        isLogin: !1
                    }));
                }) : a.setData({
                    isLogin: !1
                });
            }, !0), this.getUserLastMsg(), this.GetLastShop();
        },
        GetLastShop: function() {
            var a = this;
            t.httpGet(e.getUrl("MemberCenter/GetLastShopBranchInfo"), {
                openId: wx.getStorageSync("mallAppletOpenId"),
                shopBranchId: wx.getStorageSync("shopBranchId")
            }, function(t) {
                t.success ? a.setData({
                    lastShopBranchInfo: t.data
                }) : wx.showToast({
                    title: t.msg
                });
            });
        },
        handleToggle: function() {
            this.setData({
                showCard: !this.data.showCard
            });
        },
        goToCopyright: function() {
            wx.navigateTo({
                url: "../outurl/outurl?url=" + e.getRequestUrl + "hishop/index.html"
            });
        },
        getPhoneNumber: function(t) {
            var a = this;
            "getPhoneNumber:ok" === t.detail.errMsg && e.getPhoneNumber(t.detail, function() {
                a.setData({
                    showTip: !1
                }), a.loadData();
            });
        },
        closeTip: function() {
            this.setData({
                showTip: !1
            });
        },
        getUserLastMsg: function() {
            var a = wx.getStorageSync("mallAppletOpenId");
            t.httpGet(e.getUrl("MemberCenter/GetUserLastMsg"), {
                openid: a
            }, function(t) {
                t.success && wx.showToast({
                    icon: "none",
                    title: t.msg
                });
            });
        },
        callShopTel: function(t) {
            wx.makePhoneCall({
                phoneNumber: t.currentTarget.dataset.tel
            });
        },
        bindUserTap: function(t) {
            var e = t.currentTarget.dataset.url;
            this.data.isLogin || (e = "../login/login"), wx.navigateTo({
                url: e
            });
        },
        distributionHanlde: function() {
            var t = this.data.userInfo.IsDistributor ? "../distributionstore/distributionstore" : -1 === this.data.distributionStatus ? "../distributionapply/distributionapply" : "../distributionauditing/distributionauditing";
            if (this.data.isLogin || (t = "../login/login"), this.data.userInfo.IsRepeled) return wx.showModal({
                content: "您已被商城取消分销员资格，请联系管理员",
                showCancel: !1
            });
            t && wx.navigateTo({
                url: t
            });
        },
        bindTelPhone: function(t) {
            var e = t.currentTarget.dataset.tel;
            wx.makePhoneCall({
                phoneNumber: e
            });
        },
        gostoreH5: function() {
            var t = "../webView/webView?&url=" + encodeURIComponent(e.getRequestUrl + "store/?open_Id=" + e.globalData.openId);
            this.resetNotice(19), wx.navigateTo({
                url: t
            });
        },
        getDistrbutionStatus: function() {
            var a = this;
            e.getOpenId(function(s) {
                s && t.httpGet(e.getUrl("Distribution/GetDistributorStatus"), {
                    openId: s
                }, function(t) {
                    if (!t.success) return a.setData({
                        distributionStatus: -1
                    });
                    a.setData({
                        distributionStatus: t.data.status
                    });
                });
            }, !0);
        },
        updatephone: function() {
            this.loadData();
        },
        showJoin: function() {
            if (!this.data.isLogin) return wx.showToast({
                title: "请先登录账号",
                icon: "none"
            }), void wx.navigateTo({
                url: "../login/login"
            });
            this.data.userInfo.CellPhone ? this.setData({
                joinPopupShow: !0
            }) : this.setData({
                showBindPhone: !0
            });
        },
        hideJoin: function() {
            this.setData({
                joinPopupShow: !1
            });
        },
        checkUser: function() {
            var a = this;
            t.httpGet(e.getUrl("MemberCenter/GetApplyShopbracnStatus"), {
                openId: e.globalData.openId
            }, function(t) {
                t.success && (0 == t.data.Status && a.data.identity.push("hasStore"), a.setData({
                    identity: a.data.identity,
                    storeApplyStatus: t.data.Status,
                    storeApplyRemark: t.data.Remark || "",
                    hasStore: 0 == t.data.Status
                }));
            }), this.data.IsOpenSupplier && t.httpGet(e.getUrl("MemberCenter/GetApplySupplierStatus"), {
                openId: e.globalData.openId
            }, function(t) {
                t.success && (0 == t.data.Status && a.data.identity.push("hasSupplier"), a.setData({
                    identity: a.data.identity,
                    supplierApplyStatus: t.data.Status,
                    supplierApplyRemark: t.data.AuditReason || "",
                    hasSupplier: 0 == t.data.Status
                }));
            }), t.httpGet(e.getUrl("MemberCenter/GetApplyServiceShopStatus"), {
                openId: e.globalData.openId
            }, function(t) {
                t.success && (0 == t.data.Status && a.data.identity.push("hasStore"), a.setData({
                    serviceApplyRemark: t.data.Remark || "",
                    serviceStatus: t.data.Status,
                    hasService: 0 == t.data.Status
                }));
            });
        },
        goStoreApply: function() {
            var a = this;
            -1 == this.data.storeApplyStatus && (t.httpPost(e.getUrl("MemberCenter/BindShopBranch"), {
                openId: e.globalData.openId
            }, function(t) {
                t.success && (0 == t.code || 4 == t.code ? a.gostoreH5() : 2 == t.code ? wx.navigateTo({
                    url: "../userapplystore/userapplystore?cellPhone=" + a.data.userInfo.CellPhone
                }) : wx.showToast({
                    title: t.mes,
                    icon: "none"
                }));
            }), this.setData({
                joinPopupShow: !1
            })), 1 == this.data.storeApplyStatus && wx.showToast({
                title: "团长已冻结",
                icon: "none"
            }), 2 != this.data.storeApplyStatus && 3 != this.data.storeApplyStatus || (wx.navigateTo({
                url: "../userapplyresult/userapplyresult?type=store&status=" + this.data.storeApplyStatus + "&remark=" + this.data.storeApplyRemark
            }), this.setData({
                joinPopupShow: !1
            }));
        },
        goSupplierApply: function() {
            -1 == this.data.supplierApplyStatus && (wx.navigateTo({
                url: "../userapplysupplier/userapplysupplier?contactPhone=" + this.data.userInfo.CellPhone
            }), this.setData({
                joinPopupShow: !1
            })), 0 == this.data.supplierApplyStatus && this.openService(), 1 == this.data.supplierApplyStatus && wx.showToast({
                title: "供应商已冻结",
                icon: "none"
            }), 2 != this.data.supplierApplyStatus && 3 != this.data.supplierApplyStatus || (wx.navigateTo({
                url: "../userapplyresult/userapplyresult?type=supplier&status=" + this.data.supplierApplyStatus + "&remark=" + this.data.supplierApplyRemark
            }), this.setData({
                joinPopupShow: !1
            }));
        },
        onServiceApply: function() {
            -1 == this.data.serviceStatus && (wx.navigateTo({
                url: "/subPages/userapplyService/userapplyService"
            }), this.setData({
                joinPopupShow: !1
            })), 0 == this.data.serviceStatus && wx.showToast({
                title: "您已是入驻商",
                icon: "success"
            }), 1 == this.data.serviceStatus && wx.showToast({
                title: "入驻商已冻结",
                icon: "none"
            }), 2 != this.data.serviceStatus && 3 != this.data.serviceStatus || (wx.navigateTo({
                url: "/pages/userapplyresult/userapplyresult?type=Service&status=" + this.data.serviceStatus + "&remark=" + this.data.serviceApplyRemark
            }), this.setData({
                joinPopupShow: !1
            }));
        },
        oepnDriver: function() {
            wx.navigateTo({
                url: "../drivercenter/drivercenter"
            });
        },
        openSupplier: function() {
            var t = "../webView/webView?&url=" + encodeURIComponent(e.getRequestUrl + "supplier/?open_Id=" + e.globalData.openId);
            this.resetNotice(39), wx.navigateTo({
                url: t
            });
        },
        openService: function() {
            this.resetNotice(29), wx.navigateTo({
                url: "/subPages/serviceHome/serviceHome"
            });
        },
        resetNotice: function(a) {
            e.getOpenId(function(s) {
                s && t.httpGet(e.getUrl("MemberCenter/GetResetNotice"), {
                    field: a,
                    openId: s
                }, function(t) {});
            });
        },
        openSeller: function() {
            wx.navigateTo({
                url: "/subPages/salesman/salesman"
            });
        }
    }
});