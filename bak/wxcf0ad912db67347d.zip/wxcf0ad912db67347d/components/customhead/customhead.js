var t = getApp();

Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        backgroundColor: {
            type: String,
            value: "#ffffff"
        },
        show: Boolean,
        frontColor: {
            type: String,
            value: "#333333"
        }
    },
    data: {
        statusBarHeight: 0
    },
    methods: {},
    lifetimes: {
        ready: function() {
            var e = this;
            t.getSystemInfo(function(t) {
                e.setData({
                    statusBarHeight: t.statusBarHeight
                });
            }), this.createSelectorQuery().select("#customheadDom").boundingClientRect(function(e) {
                e && (t.globalData.customheaderHeight = e.height);
            }).exec();
        }
    }
});