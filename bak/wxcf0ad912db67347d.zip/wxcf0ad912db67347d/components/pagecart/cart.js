require("../../utils/config.js");

var t = getApp();

Component({
    properties: {},
    data: {
        headHeight: 0,
        isEdite: !1,
        TotalPrice: "0.00",
        EditeText: "编辑",
        selectAllStatus: !1,
        SettlementText: "结算",
        isEmpty: !1,
        isgo: !1,
        buttonClicked: !0,
        isShowHeader: !1,
        isBindIphone: !1
    },
    lifetimes: {
        ready: function() {
            var a = this;
            t.getSystemInfo(function(e) {
                t.globalData.navData.cart && a.setData({
                    headHeight: 2 * (42 + e.statusBarHeight)
                });
            });
        }
    },
    methods: {
        onLoad: function() {
            this.setData({
                isNavIn: t.globalData.navData.cart || !1
            }), this.onShow();
        },
        onShow: function() {
            var a = this;
            this.setData({
                isEdite: !1,
                isBindIphone: !1,
                EditeText: "编辑",
                SettlementText: "结算",
                selectAllStatus: !1
            }), t.globalData.IsConBindCellPhone && !t.globalData.userInfo.CellPhone && this.setData({
                isBindIphone: !0
            }), this.loadData(), this.data.hasGetSysSetting || t.getSysSettingData(function(e) {
                e.IsShowHishopCopyRight = t.globalData.IsShowHishopCopyRight, e.hasGetSysSetting = !0, 
                a.setData(e);
            });
        },
        onPullDownRefresh: function() {
            setTimeout(function() {
                wx.stopPullDownRefresh();
            }, 1e3);
        },
        loadData: function() {
            var a = this;
            t.getOpenId(function(e) {
                e ? (a.setData({
                    islogin: !0,
                    isEmpty: !1,
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    isShowHeader: !1
                }), wx.request({
                    url: t.getUrl("Cart/GetDeliveryTypeCartCount"),
                    data: {
                        shopBranchId: a.data.shopBranchId,
                        openId: t.globalData.openId
                    },
                    success: function(e) {
                        if (e.data.success) {
                            var s = e.data.data.edCartCount, o = e.data.data.rqdCartCount, i = e.data.data.timelyCartCount, n = [], d = 1;
                            d = o > 0 ? 1 : s > 0 ? 2 : i > 0 ? 3 : 1, o > 0 && n.push(1), s > 0 && n.push(1), 
                            i > 0 && n.push(1), a.setData({
                                showCommon: o > 0 || !1,
                                showLogistics: s > 0 || !1,
                                showTimely: i > 0 || !1,
                                isShowHeader: n.length > 1,
                                tabtype: d
                            }), t.updateCartTotal(parseInt(s) + parseInt(o) + parseInt(i)), a.GetCartData(d);
                        }
                    }
                })) : a.setData({
                    islogin: !1
                });
            }, !0);
        },
        tabcart: function(t) {
            var a = t.currentTarget.dataset.type;
            this.setData({
                tabtype: a,
                selectAllStatus: !1
            }), this.GetCartData(a);
        },
        selectList: function(t) {
            var a = t.currentTarget.dataset.index, e = this.data.shops;
            e.Items[a].selected = !e.Items[a].selected;
            var s = e.Items.every(function(t) {
                return t.selected;
            });
            this.setData({
                shops: this.data.shops,
                selectAllStatus: s
            }), this.GetTotal();
        },
        GetCartData: function(a) {
            var e = this;
            wx.showLoading({
                title: "加载中"
            }), t.getCartData({
                shopBranchId: this.data.shopBranchId,
                type: a,
                callback: function(a) {
                    wx.hideLoading(), a.success ? (e.setData({
                        isEmpty: e.data.isShowHeader ? e.data.isEmpty : 0 == a.data.list.length,
                        shops: a.data.list[0] ? a.data.list[0] : "",
                        TotalPrice: "0.00",
                        pageLoaded: !0,
                        buttonClicked: !0
                    }), e.data.shops && e.setData({
                        shops: e.data.shops
                    }), e.GetTotal()) : "502" == a.code ? wx.navigateTo({
                        url: "../login/login"
                    }) : t.showErrorModal(a.msg, function(t) {
                        t.confirm && wx.navigateBack({
                            delta: 1
                        });
                    });
                }
            });
        },
        GetTotal: function() {
            var t = parseFloat(0);
            this.data.shops && (this.data.shops.Items.forEach(function(a) {
                a.selected && (t += parseFloat(a.Price * a.Quantity));
            }), this.setData({
                TotalPrice: t.toFixed(2)
            }));
        },
        selectAll: function() {
            var t = !this.data.selectAllStatus, a = this.data.shops;
            a.Items.forEach(function(a) {
                1 === a.ShowStatus && a.IsStarted && (a.selected = t);
            }), this.setData({
                shops: a,
                selectAllStatus: t
            }), this.GetTotal();
        },
        SwitchEdite: function() {
            "编辑" == this.data.EditeText ? this.setData({
                isEdite: !0,
                EditeText: "完成",
                SettlementText: "删除"
            }) : this.setData({
                isEdite: !1,
                EditeText: "编辑",
                SettlementText: "去结算"
            });
        },
        countNum: function(t) {
            if (this.data.buttonClicked) {
                var a = this;
                a.setData({
                    buttonClicked: !1
                });
                var e = t.currentTarget.dataset, s = a.data.shops.Items[e.index], o = parseInt(s.Quantity);
                if (t.currentTarget.dataset.skuid = s.SkuId, setTimeout(function() {
                    a.setData({
                        buttonClicked: !0
                    });
                }, 500), "minus" == e.dotype) {
                    if (o <= 1) return void a.DelCarts(t);
                    a.ChangeQuantiy(-1, s.SkuId);
                } else a.ChangeQuantiy(1, s.SkuId);
            }
        },
        DelCarts: function(a) {
            var e = this, s = a.currentTarget.dataset.skuid;
            wx.showModal({
                title: "",
                confirmColor: this.data.PrimaryColor,
                content: "确认要删除该商品吗？",
                success: function(a) {
                    a.confirm && wx.request({
                        url: t.getUrl("Cart/GetdelCartItem"),
                        data: {
                            shopBranchId: e.data.shopBranchId,
                            openId: t.globalData.openId,
                            SkuIds: s,
                            productDeliveryType: e.data.tabtype
                        },
                        success: function(a) {
                            if ((a = a.data).success) {
                                var o = -1;
                                e.data.shops.Items.some(function(t, a) {
                                    if (t.SkuId === s) return o = a, !0;
                                });
                                var i = e.data.shops.Items[o];
                                t.updateCartData("del", [ i ]), e.data.shops.Items.splice(o, 1), e.setData({
                                    shops: e.data.shops
                                }), e.getIsEmpty();
                            } else "502" == a.code ? wx.navigateTo({
                                url: "../login/login"
                            }) : t.showErrorModal(a.msg);
                        }
                    });
                }
            });
        },
        delInvalidItems: function() {
            var a = this, e = "";
            this.data.shops.InvalidItems.forEach(function(t) {
                e += t.SkuId + ",";
            }), wx.showModal({
                title: "",
                confirmColor: this.data.PrimaryColor,
                content: "确认要清空过期商品吗？",
                success: function(s) {
                    s.confirm && wx.request({
                        url: t.getUrl("Cart/GetdelCartItem"),
                        data: {
                            shopBranchId: a.data.shopBranchId,
                            openId: t.globalData.openId,
                            SkuIds: e,
                            productDeliveryType: a.data.tabtype
                        },
                        success: function(e) {
                            (e = e.data).success ? (t.updateCartData("del", a.data.shops.InvalidItems), a.data.shops.InvalidItems = [], 
                            a.setData({
                                shops: a.data.shops
                            })) : "502" == e.code ? wx.navigateTo({
                                url: "../login/login"
                            }) : t.showErrorModal(e.msg);
                        }
                    });
                }
            });
        },
        SettlementShopCart: function() {
            var a = this;
            if (!this.data.isgo) {
                this.setData({
                    isgo: !0
                });
                var e = [], s = this.data.shops.Items, o = 0, i = [], n = [];
                if (s.forEach(function(t, a) {
                    t.selected && (e.push(t.SkuId), i.push(a), n.push(t), o += t.Quantity);
                }), e = e.join(","), this.data.isEdite) {
                    if (!e) return t.showErrorModal("请选择要删除的商品"), void this.setData({
                        isgo: !1
                    });
                    wx.showModal({
                        title: "",
                        confirmColor: this.data.PrimaryColor,
                        content: "确认要删除这些商品吗？",
                        success: function(s) {
                            s.confirm ? wx.request({
                                url: t.getUrl("Cart/getdelCartItem"),
                                data: {
                                    shopBranchId: a.data.shopBranchId,
                                    openId: t.globalData.openId,
                                    skuids: e,
                                    productDeliveryType: a.data.tabtype
                                },
                                success: function(e) {
                                    if (a.setData({
                                        isgo: !1
                                    }), (e = e.data).success) {
                                        var s = a.data.shops.Items.slice();
                                        n.map(function(t) {
                                            s = s.filter(function(a) {
                                                return a.SkuId !== t.SkuId;
                                            });
                                        }), a.data.shops.Items = s, a.setData({
                                            shops: a.data.shops
                                        }), t.updateCartData("del", n), a.getIsEmpty();
                                    } else "502" == e.code ? wx.navigateTo({
                                        url: "../login/login"
                                    }) : t.showErrorModal(e.msg);
                                }
                            }) : a.setData({
                                isgo: !1
                            });
                        }
                    });
                } else {
                    if (!e) return wx.showToast({
                        title: "请选择要结算的商品",
                        icon: "none"
                    }), void this.setData({
                        isgo: !1
                    });
                    var d = [];
                    s.forEach(function(t) {
                        t.selected && d.push(t.Id);
                    });
                    var r = d.join(",");
                    wx.request({
                        url: t.getUrl("Cart/GetCheckSettlement"),
                        data: {
                            openId: t.globalData.openId,
                            shopBranchId: this.data.shopBranchId,
                            cartItemIds: r,
                            productDeliveryType: this.data.tabtype
                        },
                        success: function(e) {
                            e = e.data, a.setData({
                                isgo: !1
                            }), e.success ? wx.navigateTo({
                                url: "../ordersubmit/ordersubmit?cartItemIds=" + r + "&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&deliver=" + a.data.tabtype
                            }) : (3001 != e.code && 3002 != e.code && 3003 != e.code && 18 != e.code || a.loadData(), 
                            t.showErrorModal(e.msg));
                        }
                    });
                }
            }
        },
        ChangeQuantiy: function(a, e) {
            var s = this;
            wx.request({
                url: t.getUrl("Cart/GetUpdateToCart"),
                data: {
                    openId: t.globalData.openId,
                    shopBranchId: this.data.shopBranchId,
                    skuId: e,
                    quantity: a,
                    productDeliveryType: this.data.tabtype
                },
                success: function(o) {
                    if ((o = o.data).success) {
                        var i = null;
                        s.data.shops.Items.forEach(function(t) {
                            t.SkuId == e && (i = t, t.Quantity = t.Quantity + a);
                        }), t.globalData.cartData.items[i.ProductId].skus[e].Quantity = t.globalData.cartData.items[i.ProductId].skus[e].Quantity + a, 
                        t.getCartTotal(function(e) {
                            t.updateCartTotal(e + parseInt(a));
                        }), s.setData({
                            shops: s.data.shops
                        });
                    } else {
                        if (3001 === o.code || 3002 === o.code || 3003 === o.code) {
                            var n = null;
                            s.data.shops.Items.forEach(function(t) {
                                t.SkuId == e && (n = t, t.Quantity = o.data);
                            }), s.setData({
                                shops: s.data.shops
                            });
                            var d = t.globalData.cartData.items[n.ProductId];
                            if (d) {
                                var r = d.skus[e].Quantity;
                                t.getCartTotal(function(a) {
                                    t.updateCartTotal(a - parseInt(r) + parseInt(o.data));
                                }), d.skus[e].Quantity = o.data;
                            }
                        } else s.loadData();
                        t.showErrorModal(o.msg);
                    }
                    s.GetTotal();
                }
            });
        },
        goToProductDetail: function(t) {
            var a = t.currentTarget.dataset, e = a.productid, s = a.status, o = a.shopid, i = a.activeid;
            1 != s || this.data.isEdite || wx.navigateTo({
                url: "../productdetail/productdetail?shopBranchId=" + o + "&id=" + e + (i ? "&activeid=" + i : "")
            });
        },
        getIsEmpty: function() {
            this.data.shops.Items.length <= 0 && this.data.shops.InvalidItems.length <= 0 && (this.data.isShowHeader || this.setData({
                isEmpty: !0
            }));
        },
        getPhoneNumber: function(a) {
            var e = this;
            "getPhoneNumber:ok" === a.detail.errMsg && t.getPhoneNumber(a.detail, function() {
                e.setData({
                    isBindIphone: !1
                });
            });
        }
    }
});