function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = getApp(), e = require("../../utils/config.js"), i = requirePlugin("live-player-plugin");

Component({
    properties: {},
    data: {
        pageNo: 0,
        pageSize: 10,
        firstScene: {},
        list: [],
        isNav: !1,
        loading: !1,
        isEnd: !1
    },
    methods: {
        onLoad: function() {
            this.onShow();
        },
        onShow: function() {
            this.setData({
                isNav: a.globalData.navData.livelist || !1
            }), this.data.pageLoading || (this.loadFirstScene(), this.loadData(), wx.showLoading({
                title: "加载中"
            }));
        },
        onPullDownRefresh: function() {
            this.setData({
                pageNo: 0,
                isEnd: !1,
                loading: !1
            }), this.loadFirstScene(), this.loadData();
        },
        onReachBottom: function() {
            this.loadData();
        },
        loadFirstScene: function() {
            var t = this;
            e.httpGet(a.getUrl("Live/GetFirstLivingScene"), {
                franchiseeId: wx.getStorageSync("FranchiseeId") || 0
            }, function(a) {
                if (a) {
                    var e = JSON.parse(wx.getStorageSync("localRoom") || "{}"), o = "room_" + a.data.RoomId;
                    e[o] && (a.data.Status = e[o]), i.getLiveStatus({
                        room_id: a.data.RoomId
                    }).then(function(i) {
                        a.data.Status = i.liveStatus, e[o] = i.liveStatus, t.setData({
                            firstScene: a.data
                        });
                    }), wx.setStorageSync("localRoom", JSON.stringify(e)), t.setData({
                        firstScene: a.data
                    });
                } else t.setData({
                    firstScene: {}
                });
            });
        },
        loadData: function() {
            var o = this;
            this.data.loading || this.data.isEnd || (this.setData({
                loading: !0,
                pageNo: this.data.pageNo + 1
            }), e.httpGet(a.getUrl("Live/GetLiveHomeList"), {
                franchiseeId: wx.getStorageSync("FranchiseeId") || 0,
                pageNo: this.data.pageNo,
                pageSize: 10
            }, function(a) {
                if (wx.stopPullDownRefresh(), o.data.pageLoading = !0, a.success) {
                    a.data.length < 10 && o.setData({
                        isEnd: !0
                    });
                    var e = JSON.parse(wx.getStorageSync("localRoom") || "{}");
                    a.data.forEach(function(t) {
                        var a = "room_" + t.RoomId;
                        e[a] && (t.Status = e[a]), i.getLiveStatus({
                            room_id: t.RoomId
                        }).then(function(i) {
                            t.Status = i.liveStatus, e[a] = i.liveStatus;
                        });
                    }), wx.setStorageSync("localRoom", JSON.stringify(e)), setTimeout(function() {
                        o.setData({
                            list: 1 === o.data.pageNo ? a.data : [].concat(t(o.data.list), t(a.data)),
                            loading: !1
                        }), wx.hideLoading();
                    }, 1e3);
                }
            }));
        },
        handleOpen: function(t) {
            var a = t.currentTarget.dataset.id, e = "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=" + a;
            101 !== t.currentTarget.dataset.status && (e = "../livedetail/livedetail?roomId=" + a), 
            wx.navigateTo({
                url: e
            });
        }
    }
});