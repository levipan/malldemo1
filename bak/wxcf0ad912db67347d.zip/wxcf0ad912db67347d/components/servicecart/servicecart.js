var t = require("../../utils/config.js"), a = getApp();

Component({
    properties: {
        serviceId: {
            type: Number
        },
        serviceName: String,
        productid: {
            type: Number
        },
        cartHide: {
            type: Boolean,
            value: !0
        },
        detail: Boolean
    },
    data: {
        quickClick: !0,
        setTime: "",
        isBindIphone: !1,
        isNavs: !1,
        cartData: [],
        invalidItems: []
    },
    ready: function() {
        var t = this;
        a.getSysSettingData(function(a) {
            t.setData(a);
        });
    },
    pageLifetimes: {
        show: function() {
            var t = this;
            a.getSysSettingData(function(a) {
                a.quickClick = !0, t.setData(a);
            });
        }
    },
    methods: {
        getCartData: function() {
            var t = this;
            a.getOpenId(function(a) {
                a && (t.data.openId = a, t.checkPhone(function() {
                    t.getCartProducts();
                }));
            }, !0);
        },
        checkPhone: function(e) {
            var c = this;
            !a.globalData.IsConBindCellPhone || a.globalData.userInfo && a.globalData.userInfo.CellPhone ? e && e() : t.httpGet(a.getUrl("MemberCenter/GetUser"), {
                openId: this.data.openId
            }, function(t) {
                t.success ? (c.setData({
                    isBindIphone: !t.data.CellPhone
                }), e && e()) : 504 === t.code && (a.showErrorModal("用户已被冻结"), wx.removeStorageSync("mallAppletOpenId"), 
                a.globalData.openId = "");
            });
        },
        getCartProducts: function() {
            var e = this;
            t.httpGet(a.getUrl("ServiceShopCart/GetCart"), {
                serviceShopId: this.data.serviceId,
                openId: this.data.openId
            }, function(t) {
                if (t.success) {
                    var c = {
                        Items: t.data.Carts
                    }, s = 0, o = {}, i = [];
                    if (!c) return e.setData({
                        cartData: [],
                        choosePrice: 0,
                        cartHide: !0,
                        quickClick: !0,
                        totalCount: 0
                    }), a.globalData.serviceCartData = {}, void e.triggerEvent("updateproduct");
                    c.selectedAll = !0, e.data.cartData.Items && e.data.cartData.Items.forEach(function(t) {
                        t.selected || i.push(t.ProductId);
                    }), c.Items.forEach(function(t) {
                        i.indexOf(t.ProductId) > -1 ? (t.selected = !1, c.selectedAll = !1) : t.selected = !0, 
                        t.selected && (s += t.Quantity * t.Price), o[t.ProductId] = t.Quantity;
                    }), a.globalData.serviceCartData = o, e.setData({
                        invalidItems: t.data.InvalidCarts,
                        totalCount: t.data.Count,
                        cartData: c,
                        quickClick: !0,
                        choosePrice: parseFloat(s.toFixed(2))
                    }), e.triggerEvent("updateproduct");
                } else e.setData({
                    quickClick: !0
                }), wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        },
        numChange: function(e, c) {
            var s = this;
            if (this.data.quickClick) {
                this.setData({
                    quickClick: !1
                });
                var o = e.currentTarget.dataset.id, i = e.currentTarget.dataset.type ? 1 : -1;
                this.data.setTime = setTimeout(function() {
                    a.getOpenId(function(e) {
                        t.httpPost(a.getUrl("ServiceShopCart/Add"), {
                            ServiceShopId: s.data.serviceId,
                            openId: s.data.openId,
                            quantity: i,
                            name: s.data.serviceName,
                            productId: o
                        }, function(e) {
                            e.success ? s.getCartData() : (s.setData({
                                quickClick: !0
                            }), wx.showToast({
                                title: e.msg,
                                icon: "none"
                            }), 3001 !== e.code && 3002 !== e.code && 3003 !== e.code || s.data.cartData.Items.forEach(function(c) {
                                c.ProductId == o && (i = e.data - c.Quantity), 0 != i && t.httpGet(a.getUrl("ShopBranch/GetUpdateToCart"), {
                                    shopBranchId: wx.getStorageSync("shopBranchId"),
                                    openId: a.globalData.openId,
                                    quantity: i,
                                    productId: o
                                }, function(t) {
                                    t.success ? s.getCartData() : wx.showToast({
                                        title: t.msg,
                                        icon: "none"
                                    });
                                });
                            })), c && c(e);
                        });
                    });
                }, 500);
            }
        },
        delete: function(e) {
            var c = this, s = e.currentTarget.dataset.cartid;
            t.httpPost(a.getUrl("ServiceShopCart/Del"), {
                openId: this.data.openId,
                id: s
            }, function(t) {
                t.success ? c.getCartData() : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        },
        cartShowHide: function() {
            this.setData({
                cartHide: !this.data.cartHide
            });
        },
        selectAllChange: function() {
            var t = this;
            this.data.cartData.Items && this.data.cartData.Items.length > 0 && (this.data.cartData.selectedAll = !this.data.cartData.selectedAll, 
            this.data.cartData.Items.forEach(function(a) {
                a.selected = t.data.cartData.selectedAll;
            }), this.setData({
                cartData: this.data.cartData
            }), this.caleCartTotal());
        },
        selectList: function(t) {
            var a = !0, e = t.currentTarget.dataset.index;
            this.data.cartData.Items[e].selected = !this.data.cartData.Items[e].selected, this.data.cartData.Items.forEach(function(t) {
                t.selected || (a = !1);
            }), this.data.cartData.selectedAll = a, this.setData({
                cartData: this.data.cartData
            }), this.caleCartTotal();
        },
        caleCartTotal: function() {
            var t = 0;
            this.data.cartData.Items.forEach(function(a) {
                a.selected && (t += a.Quantity * a.Price);
            }), this.setData({
                choosePrice: parseFloat(t.toFixed(2))
            });
        },
        clearCartProduct: function() {
            var e = this;
            wx.showModal({
                title: "",
                content: "您确定清空购物车吗?",
                success: function(c) {
                    c.confirm && t.httpPost(a.getUrl("ServiceShopCart/Clear"), {
                        serviceShopId: e.data.serviceId,
                        openId: e.data.openId
                    }, function(t) {
                        t.success && (e.setData({
                            cartData: [],
                            cartHide: !0,
                            choosePrice: 0,
                            totalCount: 0
                        }), a.globalData.serviceCartData = {}, e.triggerEvent("updateproduct"));
                    });
                }
            });
        },
        clearLoseProduct: function() {
            var e = this;
            wx.showModal({
                title: "",
                content: "您确定清空失效商品吗?",
                success: function(c) {
                    c.confirm && t.httpPost(a.getUrl("ServiceShopCart/ClearInvalid"), {
                        serviceShopId: e.data.serviceId,
                        openId: e.data.openId
                    }, function(t) {
                        t.success && e.setData({
                            invalidItems: []
                        });
                    });
                }
            });
        },
        submitCart: function(e) {
            var c = this;
            if (!e.currentTarget.dataset.disabled) {
                var s = [];
                this.data.cartData.Items.forEach(function(t) {
                    t.selected && t.Quantity > 0 && s.push(t.Id);
                }), t.httpPost(a.getUrl("ServiceShopCart/CheckSettlement"), {
                    serviceShopId: this.data.serviceId,
                    ids: s,
                    openId: a.globalData.openId
                }, function(t) {
                    t.success ? wx.navigateTo({
                        url: "../ordersubmit/ordersubmit?deliver=1&isServiceShop=1&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&cartItemIds=" + s.join(",")
                    }) : (3001 != t.code && 3002 != t.code && 3003 != t.code && 18 != t.code || c.getCartData(), 
                    a.showErrorModal(t.msg));
                });
            }
        },
        stopMove: function() {},
        getPhoneNumber: function(t) {
            var e = this;
            "getPhoneNumber:ok" === t.detail.errMsg && a.getPhoneNumber(t.detail, function() {
                e.setData({
                    isBindIphone: !1
                });
            });
        }
    }
});