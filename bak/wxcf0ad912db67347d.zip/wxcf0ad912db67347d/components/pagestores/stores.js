var t = require("../../utils/config.js"), a = getApp(), o = require("../../utils/qqmap-wx-jssdk.min.js"), e = void 0, i = require("../../utils/busEvent");

Component({
    properties: {},
    data: {
        scrolltoview: "v0",
        pageIndex: 1,
        pageSize: 10,
        KeyWord: "",
        location: "正在定位",
        locationName: "",
        fromLatLng: "",
        showNoLocate: !1,
        isDataEnd: !1,
        loadDataing: !1,
        storeList: [],
        isLoading: !1,
        pageLoaded: !1
    },
    methods: {
        onLoad: function(t) {
            var i = this;
            this.setData({
                options: t
            }), wx.showNavigationBarLoading(), a.getSysSettingData(function(t) {
                i.setData(t), e = new o({
                    key: a.globalData.QQMapKey
                }), i.getLocation();
            }, !0), this.onShow();
        },
        onHide: function() {
            wx.setNavigationBarColor({
                backgroundColor: "#fff",
                frontColor: "#000000"
            });
        },
        onShow: function() {
            var t = this;
            this.data.fromLatLng && this.data.storeList.length > 0 && wx.request({
                url: a.getUrl("Home/GetStoreList"),
                data: {
                    pageNo: 1,
                    pageSize: this.data.pageSize * this.data.pageIndex,
                    fromLatLng: this.data.fromLatLng,
                    openId: a.globalData.openId,
                    keyWords: this.data.KeyWord,
                    giftId: this.data.options ? this.data.options.giftId : 0,
                    quantity: this.data.options ? this.data.options.quantity : 0,
                    type: this.data.options && "integralPro" === this.data.options.giftType ? 0 : 1
                },
                success: function(a) {
                    (a = a.data).success && t.getStoreListData(a, !0);
                }
            });
        },
        onInputKeyword: function(t) {
            var a = this, o = t.detail.value;
            a.setData({
                KeyWord: o
            }), o ? (clearTimeout(this.searchTimer), this.searchTimer = setTimeout(function() {
                a.onConfirmSearch();
            }, 500)) : a.onConfirmSearch();
        },
        onConfirmSearch: function() {
            var t;
            this.data.KeyWord ? t = !0 : (t = !1, this.setData({
                pageIndex: 1
            })), this.setData({
                loadDataing: !1,
                isLoading: !1,
                isDataEnd: !1,
                isSearch: t
            }), this.getStoreList(1);
        },
        toChooseAddr: function() {
            var t = this;
            wx.navigateTo({
                url: "../storelocation/storelocation?fromLatLng=" + t.data.fromLatLng + "&cityname=" + (t.data.cityinfo ? t.data.cityinfo : "") + "&location=" + t.data.location
            });
        },
        getLocation: function() {
            var t = this;
            wx.getLocation({
                type: "gcj02",
                success: function(a) {
                    t.setData({
                        fromLatLng: a.latitude + "," + a.longitude,
                        showNoLocate: !1,
                        isDataEnd: !1,
                        pageIndex: 1,
                        storeList: []
                    }), t.getStoreList(1);
                },
                fail: function() {
                    t.setData({
                        location: "未获取定位",
                        showNoLocate: !0,
                        storeList: []
                    });
                }
            });
        },
        reGetLocation: function() {
            var t = this;
            wx.getLocation({
                type: "gcj02",
                success: function(a) {
                    t.setData({
                        fromLatLng: a.latitude + "," + a.longitude
                    }), t.getStoreList(1);
                },
                fail: function(o) {
                    a.openSetting(function() {
                        t.getLocation();
                    });
                }
            });
        },
        getStoreList: function(o) {
            var i = this;
            if (!i.data.loadDataing) {
                var n = i.data.fromLatLng.split(",");
                if (e.reverseGeocoder({
                    location: {
                        latitude: n[0],
                        longitude: n[1]
                    },
                    success: function(t) {
                        i.setData({
                            cityinfo: t.result.address_component.city,
                            location: t.result.formatted_addresses.recommend
                        }), i.data.locationName && i.setData({
                            location: i.data.locationName
                        }), wx.hideNavigationBarLoading();
                    },
                    fail: function(t) {
                        wx.showToast({
                            title: "获取位置失败"
                        });
                    }
                }), i.data.isDataEnd) i.setData({
                    loadDataing: !1,
                    isLoading: !1
                }); else {
                    i.setData({
                        loadDataing: !0
                    });
                    var s = {
                        pageNo: o,
                        pageSize: i.data.pageSize,
                        fromLatLng: i.data.fromLatLng,
                        keyWords: i.data.KeyWord,
                        giftId: this.data.options ? this.data.options.giftId : 0,
                        quantity: this.data.options ? this.data.options.quantity : 0,
                        type: this.data.options && "integralPro" === this.data.options.giftType ? 0 : 1
                    };
                    t.httpGet(a.getUrl("Home/GetStoreList"), s, function(t) {
                        i.getStoreListData(t);
                    });
                }
            }
        },
        getStoreListData: function(t, a) {
            var o = this;
            if (o.setData({
                pageLoaded: !0,
                loadDataing: !1,
                isLoading: !1
            }), t.success) {
                var e = (t = t.data).Stores, i = 1 == o.data.pageIndex || a ? [] : o.data.storeList;
                (!t.Stores || t.Stores.length < o.data.pageSize) && o.setData({
                    isDataEnd: !0
                }), o.data.isSearch ? o.setData({
                    storeList: e,
                    showNoLocate: !1,
                    IsShowShopBranchLink: t.IsShowShopBranchLink
                }) : o.setData({
                    storeList: i.concat(e),
                    showNoLocate: !1,
                    IsShowShopBranchLink: t.IsShowShopBranchLink
                });
            } else o.setData({
                location: "未获取定位",
                showNoLocate: !0
            });
        },
        callShopTel: function(t) {
            wx.makePhoneCall({
                phoneNumber: t.currentTarget.dataset.tel
            });
        },
        onReachBottom: function() {
            var t = this.data.pageIndex;
            this.setData({
                pageIndex: t + 1,
                isLoading: !0
            }), this.getStoreList(t + 1);
        },
        changeShopBranch: function(t) {
            var o = t.currentTarget.dataset, e = o.latitude + "," + o.longitude, n = getCurrentPages()[getCurrentPages().length - 2];
            if (n && "pages/ordersubmit/ordersubmit" === n.route) {
                var s = this.data.storeList.filter(function(t) {
                    return t.Id === o.id;
                })[0];
                return n.setGiftStore(s), void wx.navigateBack({
                    delta: 1
                });
            }
            wx.setStorage({
                key: "o2oFromLatLng",
                data: e
            }), a.updateCartTotal(0), a.globalData.cartData.items = {}, a.getCartAllData({
                shopBranchId: o.id
            }), wx.setStorageSync("shopBranchId", o.id), i.emit("tabUserChange", {
                url: "../index/index",
                reload: !0
            });
        }
    }
});