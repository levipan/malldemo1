var e = getApp();

Component({
    options: {
        multipleSlots: !0,
        pureDataPattern: /^_/
    },
    properties: {
        type: {
            type: String,
            optionalTypes: [ Number, Object ],
            value: "productList"
        },
        leftSecond: {
            type: Number,
            value: 0
        },
        isProcessing: Boolean,
        leftTimeDesc: String,
        salePrice: String,
        delPrice: String,
        productTag: String,
        needNumber: Number,
        needRefresh: Boolean,
        mini: Boolean
    },
    data: {
        _timer: null,
        _leftSecond: 0,
        countdown: {
            day: "00",
            hour: "00",
            minute: "00",
            second: "00"
        },
        isIphone: wx.getSystemInfoSync().model.includes("iPhone"),
        isEnd: !1,
        bargainBg: e.getRequestUrl + "/Images/product_detail_bargain_bg.png"
    },
    observers: {
        _leftSecond: function() {
            this.formatLeftSecond();
        },
        leftSecond: function(e) {
            this._initCountdown();
        }
    },
    behaviors: {},
    lifetimes: {
        detached: function() {
            this._clearTimer();
        }
    },
    externalClasses: [ "external-class" ],
    methods: {
        formatLeftSecond: function() {
            var e = this.data._leftSecond, t = {
                day: this.fixZero(parseInt(e / 86400)),
                hour: this.fixZero(parseInt(e / 3600 % 24)),
                minute: this.fixZero(parseInt(e / 60 % 60)),
                second: this.fixZero(parseInt(e % 60))
            };
            this.setData({
                countdown: t
            });
        },
        fixZero: function(e) {
            return e < 10 ? "0" + e : e;
        },
        _clearTimer: function() {
            clearInterval(this.data._timer), this.setData({
                isEnd: !0
            });
        },
        _excuteCountdown: function() {
            var e = this.data, t = e._leftSecond, n = e.type;
            if (t <= 0) return this.triggerEvent("done", {
                type: n
            }, {
                bubbles: !1,
                composed: !1,
                capturePhase: !1
            }), void this._clearTimer();
            var i = t - 1;
            this.setData({
                _leftSecond: i
            });
        },
        _initCountdown: function() {
            var e = this, t = this.data.leftSecond;
            t <= 0 || this.setData({
                _leftSecond: t
            }, function() {
                clearInterval(e.data._timer), e.data._timer = setInterval(function() {
                    e._excuteCountdown();
                }, 1e3), e.setData({
                    isEnd: !1
                });
            });
        }
    }
});