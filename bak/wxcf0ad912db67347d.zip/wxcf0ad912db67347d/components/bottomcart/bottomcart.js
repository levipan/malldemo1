var t = require("../../utils/config.js"), a = getApp();

Component({
    properties: {
        shopBranchId: {
            type: Number
        },
        productid: {
            type: Number
        },
        cartHide: {
            type: Boolean,
            value: !0
        },
        detail: Boolean
    },
    data: {
        quickClick: !0,
        setTime: "",
        isBindIphone: !1,
        isNavs: !1,
        cartData: []
    },
    ready: function() {
        var t = this;
        a.globalData.navData.storeselfsupport && this.setData({
            isNavs: !0
        }), a.getSysSettingData(function(a) {
            t.setData(a);
        });
    },
    pageLifetimes: {
        show: function() {
            var t = this;
            a.getSysSettingData(function(a) {
                a.quickClick = !0, t.setData(a);
            });
        }
    },
    methods: {
        getCartData: function() {
            var e = this;
            (a.globalData.openId || wx.getStorageSync("mallAppletOpenId")) && (a.globalData.openId = a.globalData.openId || wx.getStorageSync("mallAppletOpenId"), 
            this.checkPhone(), t.httpGet(a.getUrl("ShopBranch/GetCartCount"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                openId: a.globalData.openId
            }, function(t) {
                t.success ? (e.setData({
                    totalCount: t.data
                }), e.getCartProducts()) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }));
        },
        checkPhone: function() {
            var e = this;
            !a.globalData.IsConBindCellPhone || a.globalData.userInfo && a.globalData.userInfo.CellPhone || t.httpGet(a.getUrl("MemberCenter/GetUser"), {
                openId: a.globalData.openId
            }, function(t) {
                t.success ? e.setData({
                    isBindIphone: !t.data.CellPhone
                }) : 504 === t.code && (a.showErrorModal("用户已被冻结"), wx.removeStorageSync("mallAppletOpenId"), 
                a.globalData.openId = "");
            });
        },
        getCartProducts: function() {
            var e = this;
            t.httpGet(a.getUrl("ShopBranch/GetCartProducts"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                openId: a.globalData.openId
            }, function(t) {
                if (t.success) {
                    var o = t.data.list[0], c = 0, n = {}, s = [];
                    if (!o) return e.setData({
                        cartData: [],
                        choosePrice: 0,
                        cartHide: !0,
                        quickClick: !0,
                        totalCount: 0
                    }), a.globalData.selfCartData = {}, void e.triggerEvent("updateproduct");
                    o.selectedAll = !0, e.data.cartData.Items && e.data.cartData.Items.forEach(function(t) {
                        t.selected || s.push(t.ProductId);
                    }), o.Items.forEach(function(t) {
                        s.indexOf(t.ProductId) > -1 ? (t.selected = !1, o.selectedAll = !1) : t.selected = !0, 
                        t.selected && (c += t.Quantity * t.Price), n[t.ProductId] = t.Quantity;
                    }), a.globalData.selfCartData = n, e.setData({
                        cartData: o,
                        quickClick: !0,
                        choosePrice: parseFloat(c.toFixed(2))
                    }), e.triggerEvent("updateproduct");
                } else e.setData({
                    quickClick: !0
                }), wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        },
        numChange: function(e, o) {
            var c = this;
            if (this.data.quickClick) {
                this.setData({
                    quickClick: !1
                });
                var n = e.currentTarget.dataset.id, s = e.currentTarget.dataset.type ? 1 : -1;
                this.data.setTime = setTimeout(function() {
                    a.getOpenId(function(e) {
                        t.httpGet(a.getUrl("ShopBranch/GetUpdateToCart"), {
                            shopBranchId: wx.getStorageSync("shopBranchId"),
                            openId: a.globalData.openId,
                            quantity: s,
                            productId: n
                        }, function(e) {
                            e.success ? c.getCartData() : (c.setData({
                                quickClick: !0
                            }), wx.showToast({
                                title: e.msg,
                                icon: "none"
                            }), 3001 !== e.code && 3002 !== e.code && 3003 !== e.code || c.data.cartData.Items.forEach(function(o) {
                                o.ProductId == n && (s = e.data - o.Quantity), 0 != s && t.httpGet(a.getUrl("ShopBranch/GetUpdateToCart"), {
                                    shopBranchId: wx.getStorageSync("shopBranchId"),
                                    openId: a.globalData.openId,
                                    quantity: s,
                                    productId: n
                                }, function(t) {
                                    t.success ? c.getCartData() : wx.showToast({
                                        title: t.msg,
                                        icon: "none"
                                    });
                                });
                            })), o && o(e);
                        });
                    });
                }, 500);
            }
        },
        delete: function(e) {
            var o = this, c = e.currentTarget.dataset.id;
            t.httpGet(a.getUrl("ShopBranch/GetDelCartItem"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                openId: a.globalData.openId,
                productIds: c
            }, function(t) {
                t.success ? o.getCartData() : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        },
        cartShowHide: function() {
            this.setData({
                cartHide: !this.data.cartHide
            });
        },
        selectAllChange: function() {
            var t = this;
            this.data.cartData.Items && this.data.cartData.Items.length > 0 && (this.data.cartData.selectedAll = !this.data.cartData.selectedAll, 
            this.data.cartData.Items.forEach(function(a) {
                a.selected = t.data.cartData.selectedAll;
            }), this.setData({
                cartData: this.data.cartData
            }), this.caleCartTotal());
        },
        selectList: function(t) {
            var a = !0, e = t.currentTarget.dataset.index;
            this.data.cartData.Items[e].selected = !this.data.cartData.Items[e].selected, this.data.cartData.Items.forEach(function(t) {
                t.selected || (a = !1);
            }), this.data.cartData.selectedAll = a, this.setData({
                cartData: this.data.cartData
            }), this.caleCartTotal();
        },
        caleCartTotal: function() {
            var t = 0;
            this.data.cartData.Items.forEach(function(a) {
                a.selected && (t += a.Quantity * a.Price);
            }), this.setData({
                choosePrice: parseFloat(t.toFixed(2))
            });
        },
        clearCartProduct: function() {
            var e = this;
            wx.showModal({
                title: "",
                content: "您确定清空购物车吗?",
                success: function(o) {
                    o.confirm && t.httpGet(a.getUrl("ShopBranch/GetClear"), {
                        shopBranchId: wx.getStorageSync("shopBranchId"),
                        openId: a.globalData.openId
                    }, function(t) {
                        t.success && (e.setData({
                            cartData: [],
                            cartHide: !0,
                            choosePrice: 0,
                            totalCount: 0
                        }), a.globalData.selfCartData = {}, e.triggerEvent("updateproduct"));
                    });
                }
            });
        },
        clearLoseProduct: function() {
            var e = this;
            wx.showModal({
                title: "",
                content: "您确定清空失效商品吗?",
                success: function(o) {
                    o.confirm && t.httpGet(a.getUrl("ShopBranch/GetClearInvalid"), {
                        shopBranchId: wx.getStorageSync("shopBranchId"),
                        openId: a.globalData.openId
                    }, function(t) {
                        t.success && (e.data.cartData.InvalidItems = [], e.setData({
                            cartData: e.data.cartData
                        }));
                    });
                }
            });
        },
        submitCart: function(e) {
            var o = this;
            if (!e.currentTarget.dataset.disabled) {
                c = [];
                this.data.cartData.Items.forEach(function(t) {
                    t.selected && t.Quantity > 0 && c.push(t.Id);
                });
                var c = c.join(",");
                t.httpGet(a.getUrl("ShopBranch/GetCheckSettlement"), {
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    cartItemIds: c,
                    openId: a.globalData.openId
                }, function(t) {
                    t.success ? wx.navigateTo({
                        url: "../ordersubmit/ordersubmit?isSelfSupport=1&deliver=1&cartItemIds=" + c + "&shopBranchId=" + wx.getStorageSync("shopBranchId")
                    }) : (3001 != t.code && 3002 != t.code && 3003 != t.code && 18 != t.code || o.getCartData(), 
                    a.showErrorModal(t.msg));
                });
            }
        },
        stopMove: function() {},
        getPhoneNumber: function(t) {
            var e = this;
            "getPhoneNumber:ok" === t.detail.errMsg && a.getPhoneNumber(t.detail, function() {
                e.setData({
                    isBindIphone: !1
                });
            });
        }
    }
});