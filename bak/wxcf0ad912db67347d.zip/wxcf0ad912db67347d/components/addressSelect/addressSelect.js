var t = require("../../utils/config.js"), a = getApp();

Component({
    properties: {
        defaultId: String,
        activeList: Array
    },
    data: {
        show: !1,
        selectList: [ {
            default: "请选择",
            hasSub: !0,
            name: ""
        } ],
        list: [],
        activeId: 0,
        tabIndex: 0,
        nowIndex: 0,
        lastIndex: 0
    },
    methods: {
        handleShow: function() {
            this.setData({
                show: !0
            }), this.setInit(), this.getCitys(this.data.defaultId);
        },
        handleHide: function() {
            this.setData({
                show: !1
            });
        },
        getCitys: function(e) {
            var s = this;
            t.httpGet(a.getUrl("Common/GetSubRegion"), {
                parent: e
            }, function(t) {
                if (t.success) {
                    var a = s.data.selectList[s.data.tabIndex];
                    a && t.data.forEach(function(t) {
                        t.Id === a.id && (t.select = !0);
                    }), s.setData({
                        list: t.data
                    });
                }
            });
        },
        handleTabChange: function(t) {
            var a = t.currentTarget.dataset.index;
            this.setData({
                tabIndex: a,
                nowIndex: a
            });
            var e = this.data.selectList[a].parentId;
            this.getCitys(e);
        },
        handleGetChild: function(t) {
            this.setSelectList({
                id: t.currentTarget.dataset.id,
                name: t.currentTarget.dataset.name,
                hasSub: t.currentTarget.dataset.hassub
            }), t.currentTarget.dataset.hassub && this.getCitys(t.currentTarget.dataset.id);
        },
        setSelectList: function(t) {
            var a = t.id, e = t.name, s = t.hasSub, i = (t.index, e.length > 5 ? e.substr(0, 5) + "..." : e);
            this.data.nowIndex += 1;
            var n = this.data.selectList[this.data.nowIndex - 1];
            if (s && (this.data.tabIndex = this.data.nowIndex), this.setData({
                tabIndex: this.data.tabIndex
            }), n && (n.id = a, n.text = e, n.name = s ? i : "", n.hasSub = s, n.parentId || (n.parentId = 0)), 
            this.data.selectList.splice(this.data.nowIndex, this.data.selectList.length - this.data.nowIndex), 
            s && !this.data.selectList[this.data.nowIndex] && this.data.selectList.push({
                parentId: a,
                default: "请选择"
            }), this.setData({
                selectList: this.data.selectList
            }), !s) {
                this.setData({
                    show: !1
                });
                var d = [];
                this.data.selectList.map(function(t) {
                    d.push({
                        parentId: t.parentId,
                        text: t.text,
                        id: t.id
                    });
                }), this.triggerEvent("ok", d);
            }
        },
        setInit: function() {
            var t = this, a = [ {
                name: "请选择",
                parentId: 0
            } ], e = 0, s = 0;
            this.data.activeList.length > 0 && (a.length = 0, this.data.activeList.map(function(e, s) {
                var i = !(s < t.data.activeList.length - 1), n = e.text.length > 5 ? e.text.substr(0, 5) + "..." : e.text;
                a.push({
                    parentId: e.parentId,
                    id: e.id,
                    name: i ? "" : n,
                    hasSub: !i,
                    text: e.text,
                    default: "请选择"
                });
            }), e = this.data.activeList.length - 1, s = this.data.activeList[e].parentId), 
            this.setData({
                selectList: a,
                nowIndex: e,
                tabIndex: e,
                defaultId: s
            });
        }
    }
});