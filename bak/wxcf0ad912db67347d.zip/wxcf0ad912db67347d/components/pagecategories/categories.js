function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, i = Array(t.length); a < t.length; a++) i[a] = t[a];
        return i;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), i = getApp(), e = {
    startY: 0,
    endY: 0,
    moveY: 0,
    isBottom: !1,
    isAuto: !1
};

Component({
    properties: {},
    data: {
        pageInit: !1,
        pageno: 1,
        Products: [],
        isEnd: !1,
        keyword: "",
        timeload: null,
        oldShopBranchId: 0,
        scrollTop: 0,
        listScrollLeft: 0,
        listScrollTop: 0,
        anchoring: !0,
        intoView: 0,
        staticData: {
            scrollTop: 0,
            windowH: 500,
            bodyW: 295,
            navHeight: 500,
            listRects: [],
            listKeys: {},
            listSubLefts: [],
            listSubRects: [],
            listInit: !1,
            isIos: !1,
            IsLargerCategoryTemplate: !1,
            count: 0,
            isNavIn: !0
        },
        containerHeight: "auto",
        isShowPaging: !1,
        pagingNumber: 1,
        pagingTotal: 1,
        pagingPages: [],
        pagingSize: 100
    },
    lifetimes: {
        ready: function() {
            var t = this;
            i.getSystemInfo(function(a) {
                -1 != a.system.toLocaleLowerCase().indexOf("ios") && (t.data.staticData.isIos = !0), 
                t.data.staticData.statusBarHeight = a.statusBarHeight, t.data.staticData.windowH = a.screenHeight, 
                t._getContainerHeight();
            }), this.storeCart = this.selectComponent("#storeCart");
        }
    },
    methods: {
        onLoad: function(t) {
            t.isReload && (this.data.pageInit = !1, this.data.hasGetSysSetting = !1), this.setData({
                isNavIn: i.globalData.navData.categories || !1
            }), t.focus && this.setData({
                focus: !!t.focus
            }), this.onShow(t);
        },
        onShow: function(t) {
            i.getCartTotal(), t && t.id && this.setData({
                categoryId: parseInt(t.id),
                categorySubId: parseInt(t.id)
            }), this.loadData(), this._getContainerHeight();
        },
        onPullDownRefresh: function() {
            this.data.staticData.listRects = [], this.data.staticData.listKeys = {}, this.data.staticData.listInit = !1, 
            this.data.staticData.listSubLefts = [], this.data.staticData.listSubRects = [], 
            this.setData({
                listScrollLeft: 0,
                listScrollTop: 0,
                isEnd: !1,
                pageInit: !1,
                pageno: 0
            }), this.loadData(!0);
        },
        _getContainerHeight: function() {
            i.globalData.navData.categories ? this.setData({
                containerHeight: this.data.staticData.windowH - i.globalData.customheaderHeight - i.globalData.customTabBarHeight + "px"
            }) : this.setData({
                containerHeight: "100vh"
            });
        },
        onHide: function() {
            this.storeCart && this.storeCart.hideChooseSku();
        },
        loadRead: function() {
            var t = this;
            this.createSelectorQuery().select("#page-navs").boundingClientRect(function(a) {
                t.data.staticData.navHeight = a.height;
            }).exec(), this.createSelectorQuery().select("#page-body").boundingClientRect(function(a) {
                t.data.staticData.bodyW = a.width;
            }).exec();
        },
        loadData: function(t) {
            var e = this;
            this.data.hasGetSysSetting && !t || i.getSysSettingData(function(t) {
                t.ProductSaleCountOnOff = i.globalData.ProductSaleCountOnOff, t.hasGetSysSetting = !0, 
                e.setData(t);
            }, !1, t);
            var s = wx.getStorageSync("shopBranchId");
            s ? (this.data.oldShopBranchId != s ? (this.setData({
                isEnd: !1,
                pageInit: !0,
                oldShopBranchId: s
            }), a.httpGet(i.getUrl("Home/GetAllCategories"), {
                shopBranchId: s
            }, function(t) {
                if (t.success) {
                    var a = {};
                    if (e.data.staticData.listRects = [], e.data.staticData.listKeys = {}, e.data.staticData.listInit = !1, 
                    t.data.forEach(function(t, i) {
                        t.subs && t.subs.forEach(function(t, a) {
                            t.index = a;
                        }), a[t.Id + "_"] = t, e.data.staticData.listKeys[t.Id] = i, e.data.staticData.listRects.push("_list_" + t.Id);
                    }), e.data.categorySubId) {
                        var i = 0, s = 0;
                        t.data.map(function(t) {
                            t.Id === e.data.categoryId && (i = t.Id), t.subs && t.subs.map(function(a) {
                                a.Id === e.data.categoryId && (i = t.Id), a.Id === e.data.categorySubId && (s = a.Id);
                            });
                        }), i && !s && (s = i), e.setData({
                            categoryId: i,
                            categorySubId: s,
                            intoView: "nav_" + i,
                            keyword: "",
                            categoryArr: t.data,
                            categoryData: a
                        }), e.data.categoryId && e.getSubNavInfo(e.data.categoryId);
                    } else e.setData({
                        categoryId: 0,
                        categorySubId: 0,
                        keyword: "",
                        intoView: "nav_0",
                        categoryArr: t.data,
                        categoryData: a
                    });
                    e.getProductData(!0);
                } else e.setData({
                    categoryId: 0,
                    categorySubId: 0,
                    categoryData: [],
                    intoView: "nav_0",
                    categoryArr: [],
                    keyword: "",
                    pageInit: !1,
                    Products: []
                }), wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            })) : (a.httpGet(i.getUrl("Home/GetAllCategories"), {
                shopBranchId: s
            }, function(t) {
                if (t.success) {
                    var a = {};
                    e.data.staticData.listRects = [], e.data.staticData.listKeys = {}, t.data.forEach(function(t, i) {
                        t.subs && t.subs.forEach(function(t, a) {
                            t.index = a;
                        }), a[t.Id + "_"] = t, e.data.staticData.listKeys[t.Id] = i, e.data.staticData.listRects.push("_list_" + t.Id);
                    });
                    var i = e.data.categoryId, s = e.data.categorySubId;
                    e.data.categorySubId && t.data.map(function(t) {
                        t.Id === e.data.categorySubId && (i = t.Id), t.subs && t.subs.map(function(a) {
                            a.Id === e.data.categoryId && (i = t.Id), a.Id === e.data.categorySubId && (s = a.Id);
                        });
                    }), i && !s && (s = i), e.setData({
                        categoryId: i,
                        categorySubId: s,
                        intoView: "nav_" + i,
                        categoryArr: t.data,
                        categoryData: a
                    }), e.data.categoryId && e.getSubNavInfo(e.data.categoryId);
                } else e.setData({
                    categoryId: 0,
                    categorySubId: 0,
                    categoryArr: t.data,
                    categoryData: [],
                    Products: []
                }), wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }), this.data.pageInit || (this.setData({
                pageInit: !0,
                isEnd: !1
            }), this.getProductData(!0, 1))), this.getCartQuantity(), this.loadRead()) : wx.navigateTo({
                url: "/pages/position/position"
            });
        },
        goProduct: function(t) {
            wx.navigateTo({
                url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.currentTarget.dataset.id
            });
        },
        productNumChange: function(t) {
            var a = this, i = t.currentTarget.dataset.id, e = t.currentTarget.dataset.index, s = t.currentTarget.dataset.type ? 1 : -1, o = this.data.Products[e], n = t.currentTarget.dataset.delivery;
            this.setData({
                skuProductid: t.currentTarget.dataset.id
            }), this.storeCart.changeCart(i + "_0_0_0", s, function(t) {
                o.Quantity += t.success ? s : 0, 3001 !== t.code && 3002 !== t.code && 3003 !== t.code || (o.Quantity = t.data), 
                o.Quantity < 0 && (o.Quantity = 0), a.setData({
                    Products: a.data.Products
                }), t.success && wx.showToast({
                    title: "加入购物车成功",
                    icon: "none"
                });
            }, null, n);
        },
        chooseSku: function(t) {
            this.setData({
                skuProductid: t.currentTarget.dataset.id,
                productIndex: t.currentTarget.dataset.index
            });
            var a = t.currentTarget.dataset.delivery;
            this.storeCart.chooseSku(a);
        },
        updateProduct: function(t) {
            t.detail ? (this.data.Products[this.data.productIndex].Quantity = t.detail.quantity, 
            this.setData({
                Products: this.data.Products
            })) : this.getProductData(!1, 1);
        },
        searchFocus: function() {
            this.setData({
                focus: !0
            });
        },
        searchBlur: function() {
            this.setData({
                focus: !1
            });
        },
        clearSearch: function() {
            wx.hideKeyboard(), this.setData({
                keyword: "",
                focus: !1
            }), this.onConfirmSearch();
        },
        searchInput: function(t) {
            var a = t.detail.value;
            this.setData({
                keyword: a
            }), a || this.onConfirmSearch();
        },
        onConfirmSearch: function() {
            this.setData({
                categoryId: 0,
                categorySubId: 0,
                focus: !1
            }), this.getProductData(!0);
        },
        changeCategoryId: function(t) {
            var a = t.currentTarget.dataset.id;
            this.setData({
                categoryId: a,
                scrollTop: 0,
                isEnd: !1,
                isOver: !1,
                isShowPaging: !1,
                categorySubId: a
            }), this.getListPosition(), this.getProductData(!0, 1), this.getSubNavInfo(a);
        },
        changeSubId: function(t) {
            var a = t.currentTarget.dataset.id;
            this.setData({
                categorySubId: a,
                isEnd: !1,
                isOver: !1,
                scrollTop: 0
            }), this.getProductData(!0, 1), this.getSubListPosition(t.currentTarget.dataset.index);
        },
        getProductData: function(e, s) {
            var o = this;
            e && this.setData({
                pageno: 1,
                isEnd: !1,
                Products: []
            });
            var n = s || this.data.pageno;
            a.httpGet(i.getUrl("Home/GetProducts"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                pageNo: n,
                openId: i.globalData.openId,
                categoryId: this.data.categorySubId,
                type: "category",
                key: this.data.keyword
            }, function(a) {
                if (wx.stopPullDownRefresh(), a.success) {
                    var i = a.data.ProductList;
                    if (1 == n) {
                        var e = 1, s = [];
                        e = Math.ceil(a.data.TotalCount / o.data.pagingSize);
                        for (var r = 0; r < e; r++) s.push(r + 1);
                        o.setData({
                            pagingNumber: 1,
                            pagingTotal: e,
                            pagingPages: s
                        });
                    }
                    if (i.length < 10 || a.data.TotalCount === o.data.Products.length + i.length) {
                        var d = o.getNextData();
                        d ? o.setData({
                            nextData: d
                        }) : o.setData({
                            isOver: !0
                        });
                    }
                    i.forEach(function(t) {
                        t.IsLimit && (t.IsStarted ? (t.time = o.formatDuring(Math.round(t.EndSecond)), t.EndSecond <= 0 && (t.overtime = !0)) : t.time = o.formatDuring(Math.round(t.StartSecond)));
                    });
                    var c = 1 == n ? i : [].concat(t(o.data.Products), t(i));
                    o.setData({
                        isEnd: i.length < 10 || a.data.TotalCount === o.data.Products.length + i.length,
                        isShowPaging: !1,
                        Products: c,
                        isEmpty: 0 == c.length
                    }), o.setTimeLoad(), o.getPagingStatus(), o.getCartQuantity();
                } else wx.showToast({
                    title: "系统数据异常",
                    icon: "none"
                });
            });
        },
        setTimeLoad: function() {
            var t = this;
            clearInterval(this.timeload), this.timeload = setInterval(function() {
                t.data.Products.forEach(function(a) {
                    a.IsLimit && (a.IsStarted ? (a.EndSecond -= 1, a.EndSecond >= 0 ? a.time = t.formatDuring(a.EndSecond) : a.overtime = !0) : (a.StartSecond -= 1, 
                    a.StartSecond >= 0 ? (a.EndSecond -= 1, a.time = t.formatDuring(a.StartSecond)) : (a.IsStarted = !0, 
                    a.overtime = !(a.EndSecond > 0))));
                }), t.setData({
                    Products: t.data.Products
                });
            }, 1e3);
        },
        formatDuring: function(t) {
            var a = parseInt(t / 3600), i = parseInt(t % 3600 / 60), e = parseInt(t % 60);
            return a < 10 && (a = "0" + a), i < 10 && (i = "0" + i), e < 10 && (e = "0" + e), 
            [ a, i, e ];
        },
        getScrollInfo: function(t) {
            var a = this;
            this.createSelectorQuery().select("#scroll-container").boundingClientRect(function(i) {
                i && a.createSelectorQuery().select("#page-body-list").boundingClientRect(function(s) {
                    var o = parseFloat(s.height + a.data.staticData.scrollTop) >= i.height - 20;
                    e.isBottom = !!o, t && t();
                }).exec();
            }).exec();
        },
        reachBottom: function() {
            this.data.isShowPaging || this.data.isEnd || (this.setData({
                pageno: this.data.pageno + 1
            }), this.getProductData());
        },
        getCartQuantity: function() {
            this.data.Products.length > 0 && this.data.Products.map(function(t) {
                if (i.globalData.cartData.items[t.Id]) {
                    var a = 0;
                    for (var e in i.globalData.cartData.items[t.Id].skus) a += i.globalData.cartData.items[t.Id].skus[e].Quantity;
                    t.Quantity = a;
                } else t.Quantity = 0;
            }), this.setData({
                Products: this.data.Products
            });
        },
        getNextData: function() {
            var t = this;
            if (0 === this.data.categoryId || this.data.keyword) return null;
            var a = -1, i = -1, e = !1;
            if (this.data.categoryArr.some(function(s, o) {
                if (s.Id === t.data.categorySubId) return e = !0, void (a = o);
                s.subs && s.subs.some(function(s, n) {
                    if (s.Id === t.data.categorySubId) return e = !1, a = o, void (i = n);
                });
            }), e && -1 !== a) {
                var s = this.data.categoryArr[a + 1];
                if (s) return {
                    id: s.Id,
                    isP: !0,
                    name: s.Name
                };
            }
            if (-1 !== a && -1 !== i) {
                var o = this.data.categoryArr[a].subs[i + 1];
                if (o) return {
                    id: o.Id,
                    isP: !1,
                    index: o.index,
                    name: o.Name
                };
                if (o = this.data.categoryArr[a + 1]) return {
                    id: o.Id,
                    isP: !0,
                    name: o.Name
                };
            }
            return null;
        },
        bindtouchstart: function(t) {
            e.startY = t.touches[0].pageY;
        },
        bindtouchmove: function(t) {
            e.endY = t.touches[0].pageY, e.moveY = e.endY - e.startY, this.data.isEnd && !this.data.isOver && e.isBottom && !this.data.staticData.isIos && Math.abs(e.moveY) < 200 && (this.data.staticData.startMove || e.endY < e.startY) && (this.data.staticData.startMove = !0, 
            this.getAnimation(100, e.moveY + "px"));
        },
        bindtouchend: function(t) {
            var a = this;
            this.data.staticData.startMove = !1, this.data.isEnd && (this.getScrollInfo(function() {
                e.endY < e.startY ? (e.isAuto && e.isBottom && Math.abs(e.moveY) > 140 && a.data.nextData && !a.data.isOver && (a.touchLoadData(), 
                e.isBottom = !1, e.isAuto = !1, a.data.staticData.isIos || a.getAnimation(300, 0, "ease")), 
                e.isBottom ? e.isAuto = !0 : e.isAuto = !1) : e.isAuto = !1;
            }), this.getAnimation(300, 0, "ease"));
        },
        touchLoadData: function() {
            var t = this.data.nextData;
            this.setData({
                categoryId: t.isP ? t.id : this.data.categoryId,
                scrollTop: 0,
                isEnd: !1,
                isShowPaging: !1,
                intoView: "nav_" + t.id,
                categorySubId: t.id
            }), this.data.categoryId === this.data.categorySubId ? (this.getSubNavInfo(t.id), 
            this.getListPosition()) : this.getSubListPosition(t.index + 1), this.getProductData(!0, 1);
        },
        getAnimation: function(t, a, i) {
            var e = wx.createAnimation({
                duration: t,
                timingFunction: i || "linear"
            });
            e.translateY(a).step(), this.setData({
                animationData: e.export()
            });
        },
        bindNavScroll: function(t) {
            0 == t.detail.scrollTop && this.setData({
                listScrollTop: 0
            });
        },
        bindListscroll: function(t) {
            this.data.staticData.scrollTop = t.detail.scrollTop;
        },
        getListPosition: function() {
            var t = this, a = 0, i = this.data.staticData.listKeys[this.data.categoryId] || 0;
            this.data.staticData.listRects.forEach(function(e) {
                t.createSelectorQuery().select("#" + e).boundingClientRect().exec(function(e) {
                    a = e[0].height, t.data.staticData.maxIndex || (t.data.staticData.maxIndex = Math.floor((t.data.staticData.navHeight - 42) / 2 / a)), 
                    i > t.data.staticData.maxIndex ? t.setData({
                        listScrollTop: (i - t.data.staticData.maxIndex) * a
                    }) : t.setData({
                        listScrollTop: 0
                    });
                });
            });
        },
        bindSubNavScroll: function(t) {
            0 == t.detail.scrollLeft && this.setData({
                listScrollLeft: 0
            });
        },
        getSubListPosition: function(t) {
            this.data.staticData.listSubLefts[t] && this.data.staticData.listSubLefts[t] > this.data.staticData.bodyW / 2 ? this.setData({
                listScrollLeft: this.data.staticData.listSubLefts[t] - this.data.staticData.bodyW / 2
            }) : this.setData({
                listScrollLeft: 0
            });
        },
        getSubPositionInfo: function() {
            var t = this, a = 0;
            this.data.staticData.listSubRects.forEach(function(i) {
                t.createSelectorQuery().select("#" + i).boundingClientRect().exec(function(i) {
                    i.map(function(i) {
                        t.data.staticData.listSubLefts.push(a + i.width / 2), a += i.width;
                    });
                });
            });
        },
        getSubNavInfo: function(t) {
            var a = this, i = this.data.categoryData[t + "_"];
            i && i.subs && i.subs.length > 0 && (this.data.staticData.listSubRects = [], this.data.staticData.listSubRects.push("sub_list_" + t), 
            this.data.staticData.listSubLefts = [], i.subs.map(function(t, i) {
                a.data.staticData.listSubRects.push("sub_list_" + t.Id);
            }), this.getSubPositionInfo());
        },
        getPagingStatus: function() {
            this.setData({
                isShowPaging: !1
            }), this.data.pagingNumber > 1 && this.data.isEnd ? this.setData({
                isShowPaging: !0
            }) : this.data.Products.length >= this.data.pagingSize && this.setData({
                isShowPaging: !0
            });
        },
        handlePagePre: function() {
            this.data.pagingNumber <= 1 || this.setPagingInit(this.data.pagingNumber - 1);
        },
        handlePageNext: function() {
            this.data.pagingNumber >= this.data.pagingTotal || this.setPagingInit(this.data.pagingNumber + 1);
        },
        bindPickerChange: function(t) {
            var a = t.detail.value, i = this.data.pagingPages[a];
            i != this.data.pagingNumber && this.setPagingInit(parseInt(i));
        },
        setPagingInit: function(t) {
            this.setData({
                pagingNumber: t,
                Products: [],
                pageno: (t - 1) * (this.data.pagingSize / 10) + 1,
                isShowPaging: !1
            }), this.getProductData();
        }
    }
});