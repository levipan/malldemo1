function t(t) {
    try {
        t = t.replace(/-/g, "/");
    } catch (t) {}
    var i = (t = new Date(t)).getFullYear(), e = t.getMonth() + 1, n = t.getDate(), s = t.getHours(), r = t.getMinutes(), d = t.getSeconds();
    return {
        str: [ i, e, n ].map(a).join("-") + " " + [ s, r, d ].map(a).join(":"),
        arr: [ i, e, n, s, r, d ]
    };
}

function a(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

Component({
    properties: {
        pickerShow: {
            type: Boolean,
            observices: function(t) {
                var a = this;
                if (t) {
                    var i = wx.createAnimation({
                        duration: 500,
                        timingFunction: "ease"
                    }), e = wx.createAnimation({
                        duration: 500,
                        timingFunction: "ease"
                    });
                    setTimeout(function() {
                        i.bottom(0).step(), e.opacity(.7).step(), a.setData({
                            animationOpacity: e.export(),
                            animationData: i.export()
                        });
                    }, 0);
                } else {
                    var n = wx.createAnimation({
                        duration: 100,
                        timingFunction: "ease"
                    }), s = wx.createAnimation({
                        duration: 500,
                        timingFunction: "ease"
                    });
                    n.bottom(-320).step(), s.opacity(0).step(), this.setData({
                        animationOpacity: s.export(),
                        animationData: n.export()
                    });
                }
                if (this.data.startValue && this.data.endValue) {
                    var r = 0, d = 0, o = this.data.config;
                    this.data.startValue.map(function(t) {
                        0 == t && r++;
                    }), this.data.endValue.map(function(t) {
                        0 == t && d++;
                    });
                    var h = {
                        hour: 4,
                        minute: 5,
                        second: 6
                    }[o.column];
                    (r >= h || d >= h) && (this.initPick(), this.setData({
                        startValue: this.data.startValue,
                        endValue: this.data.endValue
                    }));
                }
            }
        },
        config: Object
    },
    data: {},
    detached: function() {},
    attached: function() {},
    ready: function() {
        this.readConfig(), this.initPick(this.data.config || null), this.setData({
            startValue: this.data.startValue,
            endValue: this.data.endValue
        });
    },
    methods: {
        readConfig: function() {
            var a = new Date().getTime(), i = new Date().getTime() - 2592e6;
            if (this.data.config) {
                var e = this.data.config;
                "number" == typeof e.dateLimit && (i = new Date().getTime() - 864e5 * e.dateLimit), 
                e.limitStartTime && (i = new Date(e.limitStartTime.replace(/-/g, "/")).getTime()), 
                e.limitEndTime && (a = new Date(e.limitEndTime.replace(/-/g, "/")).getTime()), this.setData({
                    yearStart: e.yearStart || 2e3,
                    yearEnd: e.yearEnd || 2100,
                    endDate: e.endDate || !1,
                    dateLimit: e.dateLimit || !1,
                    hourColumn: "hour" == e.column || "minute" == e.column || "second" == e.column,
                    minColumn: "minute" == e.column || "second" == e.column,
                    secColumn: "second" == e.column
                });
            }
            var n = t(i), s = t(a);
            this.setData({
                limitStartTime: i,
                limitStartTimeArr: n,
                limitEndTime: a,
                limitEndTimeArr: s
            });
        },
        preventD: function() {},
        handlePickStart: function(t) {
            this.setData({
                isPicking: !0
            });
        },
        handlePickEnd: function(t) {
            this.setData({
                isPicking: !1
            });
        },
        onConfirm: function() {
            if (!this.data.isPicking) {
                var a = new Date(this.data.startPickTime.replace(/-/g, "/")), i = new Date(this.data.endPickTime.replace(/-/g, "/"));
                if (a <= i || !this.data.endDate) {
                    this.setData({
                        startTime: a,
                        endTime: i
                    });
                    var e = t(a).arr, n = t(i).arr, s = function(t) {
                        return t < 10 ? "0" + t : t;
                    }, r = {
                        startTime: e[0] + "-" + s(e[1]) + "-" + s(e[2]) + " " + (this.data.hourColumn ? s(e[3]) : "00") + ":" + (this.data.minColumn ? s(e[4]) : "00") + ":" + (this.data.secColumn ? s(e[5]) : "00"),
                        endTime: n[0] + "-" + s(n[1]) + "-" + s(n[2]) + " " + (this.data.hourColumn ? s(n[3]) : "00") + ":" + (this.data.minColumn ? s(n[4]) : "00") + ":" + (this.data.secColumn ? s(n[5]) : "00")
                    };
                    this.triggerEvent("setPickerTime", r), this.triggerEvent("hidePicker", {});
                } else wx.showToast({
                    icon: "none",
                    title: "时间不合理"
                });
            }
        },
        showModal: function() {
            this.triggerEvent("showPicker", {});
        },
        hideModal: function() {
            this.triggerEvent("hidePicker", {});
        },
        changeStartDateTime: function(t) {
            var a = t.detail.value;
            this.compareTime(a, "start");
        },
        changeEndDateTime: function(t) {
            var a = t.detail.value;
            this.compareTime(a, "end");
        },
        compareTime: function(a, i) {
            var e = a[3] ? this.data.HourList[a[3]] : "00", n = a[4] ? this.data.MinuteList[a[4]] : "00", s = a[5] ? this.data.SecondList[a[5]] : "00", r = this.data.YearList[a[0]] + "-" + this.data.MonthList[a[1]] + "-" + this.data.DayList[a[2]] + " " + e + ":" + n + ":" + s, d = this.data.limitStartTime, o = this.data.limitEndTime, h = new Date(r.replace(/-/g, "/")).getTime(), u = void 0, c = void 0, m = void 0, l = void 0, L = void 0, g = void 0, D = void 0;
            u = (D = this.data.dateLimit ? "start" == i && h > new Date(this.data.endPickTime.replace(/-/g, "/")) && this.data.config.endDate ? t(this.data.endPickTime).arr : "end" == i && h < new Date(this.data.startPickTime.replace(/-/g, "/")) ? t(this.data.startPickTime).arr : h < d ? this.data.limitStartTimeArr.arr : h > o ? this.data.limitEndTimeArr.arr : [ this.data.YearList[a[0]], this.data.MonthList[a[1]], this.data.DayList[a[2]], this.data.HourList[a[3]], this.data.MinuteList[a[4]], this.data.SecondList[a[5]] ] : [ this.data.YearList[a[0]], this.data.MonthList[a[1]], this.data.DayList[a[2]], this.data.HourList[a[3]], this.data.MinuteList[a[4]], this.data.SecondList[a[5]] ])[0], 
            c = D[1], m = D[2], l = D[3], L = D[4], g = D[5], "start" == i ? this.setStartDate(u, c, m, l, L, g) : "end" == i && this.setEndDate(u, c, m, l, L, g);
        },
        getDays: function(t, a) {
            var i = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
            return 2 === a ? t % 4 == 0 && t % 100 != 0 || t % 400 == 0 ? 29 : 28 : i[a - 1];
        },
        initPick: function(t) {
            for (var a = t.initStartTime ? new Date(t.initStartTime.replace(/-/g, "/")) : new Date(), i = t.initEndTime ? new Date(t.initEndTime.replace(/-/g, "/")) : new Date(), e = a.getFullYear(), n = a.getMonth() + 1, s = a.getDate(), r = a.getHours(), d = a.getMinutes(), o = a.getSeconds(), h = i.getFullYear(), u = i.getMonth() + 1, c = i.getDate(), m = i.getHours(), l = i.getMinutes(), L = i.getSeconds(), g = [], D = [], p = [], f = [], T = [], v = [], x = this.data.yearStart; x <= this.data.yearEnd; x++) g.push(x);
            for (var I = 1; I <= 12; I++) D.push(I);
            for (var y = 1; y <= 31; y++) p.push(y);
            for (var S = 0; S <= 23; S++) 0 <= S && S < 10 && (S = "0" + S), f.push(S);
            for (var M = 0; M <= 59; M++) 0 <= M && M < 10 && (M = "0" + M), T.push(M), v.push(M);
            this.setData({
                YearList: g,
                MonthList: D,
                DayList: p,
                HourList: f,
                MinuteList: T,
                SecondList: v
            }), this.setStartDate(e, n, s, r, d, o), this.setEndDate(h, u, c, m, l, L);
        },
        setPickerDateArr: function(t, a, i, e, n, s, r) {
            var d = 0, o = 0, h = 0, u = 0, c = 0, m = 0;
            this.data.YearList.map(function(t, i) {
                parseInt(t) === a && (d = i);
            }), this.data.MonthList.map(function(t, a) {
                parseInt(t) === i && (o = a);
            });
            for (var l = [], L = 1; L <= this.getDays(a, i); L++) l.push(L);
            return l.map(function(t, a) {
                parseInt(t) === e && (h = a);
            }), "start" == t ? this.setData({
                startDayList: l
            }) : "end" == t && this.setData({
                endDayList: l
            }), this.data.HourList.map(function(t, a) {
                parseInt(t) === parseInt(n) && (u = a);
            }), this.data.MinuteList.map(function(t, a) {
                parseInt(t) === parseInt(s) && (c = a);
            }), this.data.SecondList.map(function(t, a) {
                parseInt(t) === parseInt(r) && (m = a);
            }), {
                yearIdx: d,
                monthIdx: o,
                dayIdx: h,
                hourIdx: u,
                minuteIdx: c,
                secondIdx: m
            };
        },
        setStartDate: function(t, a, i, e, n, s) {
            var r = this.setPickerDateArr("start", t, a, i, e, n, s);
            this.setData({
                startYearList: this.data.YearList,
                startMonthList: this.data.MonthList,
                startHourList: this.data.HourList,
                startMinuteList: this.data.MinuteList,
                startSecondList: this.data.SecondList,
                startValue: [ r.yearIdx, r.monthIdx, r.dayIdx, r.hourIdx, r.minuteIdx, r.secondIdx ],
                startPickTime: this.data.YearList[r.yearIdx] + "-" + this.data.MonthList[r.monthIdx] + "-" + this.data.DayList[r.dayIdx] + " " + this.data.HourList[r.hourIdx] + ":" + this.data.MinuteList[r.minuteIdx] + ":" + this.data.SecondList[r.secondIdx]
            });
        },
        setEndDate: function(t, a, i, e, n, s) {
            var r = this.setPickerDateArr("end", t, a, i, e, n, s);
            this.setData({
                endYearList: this.data.YearList,
                endMonthList: this.data.MonthList,
                endHourList: this.data.HourList,
                endMinuteList: this.data.MinuteList,
                endSecondList: this.data.SecondList,
                endValue: [ r.yearIdx, r.monthIdx, r.dayIdx, r.hourIdx, r.minuteIdx, r.secondIdx ],
                endPickTime: this.data.YearList[r.yearIdx] + "-" + this.data.MonthList[r.monthIdx] + "-" + this.data.DayList[r.dayIdx] + " " + this.data.HourList[r.hourIdx] + ":" + this.data.MinuteList[r.minuteIdx] + ":" + this.data.SecondList[r.secondIdx]
            });
        }
    }
});