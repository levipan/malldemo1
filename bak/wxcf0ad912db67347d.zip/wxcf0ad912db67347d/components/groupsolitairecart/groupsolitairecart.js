function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, i = Array(t.length); a < t.length; a++) i[a] = t[a];
        return i;
    }
    return Array.from(t);
}

var a = require("../../utils/config"), i = getApp();

Component({
    properties: {
        productId: Number,
        activeId: Number,
        isInit: Boolean,
        delivery: String,
        maxNumber: Number
    },
    data: {
        isShowList: !1,
        totalMoney: 0,
        totalNumber: 0,
        list: [],
        skusList: [],
        chooseSkuHide: !0,
        isShowCart: !1
    },
    observers: {
        isInit: function(t) {
            t && (this.setData({
                isShowCart: !0
            }), this._updateCart());
        }
    },
    lifetimes: {
        ready: function() {
            var t = this;
            this._initData(), i.getSysSettingData(function(a) {
                t.setData(a);
            });
        }
    },
    pageLifetimes: {
        show: function() {
            this.data.isInit && (this._initData(), this._update());
        }
    },
    methods: {
        _initData: function() {
            var t = this._getStorageCart(), a = wx.getStorageSync("shopBranchId");
            t[a] && t[a][this.data.activeId] ? (this.data.skusList = t[a][this.data.activeId], 
            this._loadData()) : this.setData({
                list: [],
                skusList: []
            });
        },
        _getStorageCart: function() {
            return JSON.parse(wx.getStorageSync("solitaireCartData") || "{}");
        },
        _loadData: function(t) {
            var s = this;
            if (this.data.skusList.length && !this.processing) {
                this.processing = !0;
                var u = JSON.stringify(this.data.skusList);
                a.httpPost(i.getUrl("GroupSolitaire/LoadProduct"), {
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    Id: this.data.activeId,
                    Products: u
                }, function(a) {
                    if (s.processing = !1, !a.success) return wx.showToast({
                        title: a.msg
                    });
                    var i = [];
                    a.data.Products.map(function(t) {
                        var a = t.SkuId ? t.SkuId : t.ProductId + "_0_0_0";
                        i.push({
                            ProductId: t.ProductId,
                            SkuId: a,
                            Quantity: t.Quantity,
                            LimitCount: t.LimitCount
                        });
                    }), s.setData({
                        list: a.data.Products,
                        skusList: i
                    }, function() {
                        s._update();
                    }), t && t(a);
                });
            }
        },
        _getMoneys: function() {
            var t = 0, a = 0;
            this.data.list.map(function(s) {
                a += s.Quantity, t = i.add(t, i.multiply(s.Quantity, s.SalePrice));
            }), this.setData({
                totalMoney: t,
                totalNumber: a
            });
        },
        _updateCart: function() {
            this.triggerEvent("syncCartData", this.data.list);
        },
        _delCartItem: function(t) {
            this.data.skusList[t];
            this.data.skusList.splice(t, 1), -1 !== t && (this.data.list.splice(t, 1), this.setData({
                list: this.data.list
            })), this._update();
        },
        _saveTo: function() {
            var t = this._getStorageCart(), a = wx.getStorageSync("shopBranchId");
            t[a] ? t[a][this.data.activeId] = this.data.skusList : (t[a] = {}, t[a][this.data.activeId] = this.data.skusList), 
            wx.setStorageSync("solitaireCartData", JSON.stringify(t));
        },
        _update: function() {
            this._updateCart(), this._getMoneys(), this._saveTo();
        },
        _setDisabledSku: function() {
            var a = this.data.skuData.SkuItems, i = this.data.skuData.Skus, s = (a.length, this.data.skuArr);
            a.forEach(function(a) {
                var u = a.AttributeIndex;
                a.AttributeValue.forEach(function(a) {
                    var n = [].concat(t(s));
                    n[u + 1] = a.ValueId, i[n.join("_")] && !i[n.join("_")].Stock ? a.disabled = !0 : a.disabled = !1;
                });
            }), this.setData({
                skuData: this.data.skuData
            });
        },
        changeCart: function(t) {
            var a = this.data.skusList.findIndex(function(a) {
                return a.SkuId == t.skuId;
            }), i = this.data.maxNumber;
            if (-1 != a) {
                var s = this.data.skusList[a], u = this.data.list[a];
                if (t.quantity > 0 && u.Stock <= 0 || s.Quantity + t.quantity > u.Stock) return void wx.showToast({
                    title: "库存不足,当前库存" + u.Stock,
                    icon: "none"
                });
                if (i && t.quantity > 0 && s.Quantity + t.quantity > i) return void wx.showToast({
                    title: "您购买的数量已达到上限",
                    icon: "none"
                });
                if (s.Quantity = s.Quantity + t.quantity, s.Quantity <= 0) return void this._delCartItem(a);
            } else {
                var n = {
                    ProductId: t.pid,
                    SkuId: t.skuId,
                    Quantity: t.quantity,
                    LimitCount: this.data.maxNumber
                };
                this.data.skusList.push(n);
            }
            this._loadData();
        },
        chooseSku: function() {
            var t = this;
            i.getOpenId(function(s) {
                a.httpGet(i.getUrl("GroupSolitaire/GetProductSkus"), {
                    productId: t.data.productId,
                    shopBranchId: wx.getStorageSync("shopBranchId"),
                    openId: s,
                    id: t.data.activeId
                }, function(a) {
                    if (a.success) {
                        var s, u = {}, n = [ (a = a.data).ProductId, 0, 0, 0 ], e = "";
                        a.Skus.forEach(function(a) {
                            u[a.SkuId] = a, !s && a.Stock && (s = a);
                            var i = t.data.skusList.find(function(t) {
                                return a.SkuId === t.SkuId;
                            });
                            i && (a.CartQuantity = i.Quantity);
                        });
                        var r = a.Skus.filter(function(t) {
                            return t.Stock > 0;
                        });
                        if (a.Skus = u, 1 === r.length && (n = r[0].SkuId.split("_"), e = a.Skus[r[0].SkuId]), 
                        a.DefaultSku.Stock || (a.DefaultSku = s), !a.DefaultSku) return void wx.showToast({
                            title: "暂无库存",
                            icon: "none"
                        });
                        t.setData({
                            chooseSkuHide: !1,
                            skuData: a,
                            skuArr: n,
                            curSkuData: e
                        }), 0 !== t.data.skuData.SkuItems.length && t._setDisabledSku(), i.getSysSettingData(function(a) {
                            t.setData(a);
                        });
                    } else 502 == a.code ? (wx.showToast({
                        title: "请先登录账号",
                        icon: "none"
                    }), wx.navigateTo({
                        url: "../login/login"
                    })) : i.showErrorModal(a.msg);
                });
            });
        },
        _getCartProductsItem: function(t) {
            var a = {};
            return this.data.list.map(function(t) {
                a[t.ProductId] ? a[t.ProductId].quantity = a[t.ProductId].quantity + t.Quantity : a[t.ProductId] = {
                    quantity: t.Quantity
                };
            }), a[t.productId] ? a[t.productId] : null;
        },
        onSwithSku: function(t) {
            var a = t.currentTarget.dataset.index, i = t.currentTarget.dataset.id, s = this.data.skuArr;
            s[a + 1] = parseInt(s[a + 1]) === i ? 0 : i, this.setData({
                skuArr: s,
                curSkuData: this.data.skuData.Skus[this.data.skuArr.join("_")] || null
            }), this._setDisabledSku();
        },
        onSkuCountChange: function(t) {
            if (this.data.curSkuData) {
                var a = t.currentTarget.dataset.type, i = this.data.curSkuData, s = a ? 1 : -1, u = this.data.maxNumber;
                if (u) {
                    if (s > 0 && (i.Stock <= 0 || i.CartQuantity + s > i.Stock)) return void wx.showToast({
                        title: "库存不足,当前库存" + i.Stock,
                        icon: "none"
                    });
                    if (s > 0 && i.CartQuantity + s > u) return void wx.showToast({
                        title: "您购买的数量已达到上限",
                        icon: "none"
                    });
                }
                i.CartQuantity = i.CartQuantity + s, this.setData({
                    curSkuData: this.data.curSkuData
                }), this.changeCart({
                    skuId: this.data.curSkuData.SkuId,
                    pid: this.data.productId,
                    quantity: s
                });
            } else wx.showToast({
                title: "请选择规格",
                icon: "none"
            });
        },
        onCartItemCountChange: function(t) {
            var a = t.currentTarget.dataset, i = a.type, s = a.index, u = this.data.list[s], n = i ? 1 : -1, e = this.data.skusList[s];
            this.data.maxNumber = e.LimitCount, this.changeCart({
                skuId: u.SkuId,
                pid: u.ProductId,
                quantity: n
            });
        },
        onClearCart: function() {
            var t = this;
            wx.showModal({
                title: "",
                content: "您确定清空购物车吗?",
                success: function(a) {
                    a.confirm && (t.setData({
                        list: [],
                        skusList: [],
                        isShowList: !1
                    }), t._update(), t.triggerEvent("hidePopup", !1));
                }
            });
        },
        onHideChooseSku: function() {
            this.setData({
                chooseSkuHide: !0
            }), this.triggerEvent("hidePopup", !1);
        },
        onShowList: function() {
            this.triggerEvent("hidePopup", !this.data.isShowList), this.setData({
                isShowList: !this.data.isShowList
            });
        },
        onConfirmOrder: function() {
            var t = this;
            this.data.list.length <= 0 || this.processing || i.getOpenId(function(a) {
                a && t._loadData(function() {
                    wx.navigateTo({
                        url: "../ordersubmit/ordersubmit?products=" + JSON.stringify(t.data.skusList) + "&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&deliver=" + t.data.delivery + "&groupSolitaireId=" + t.data.activeId
                    });
                });
            }, !0);
        }
    }
});