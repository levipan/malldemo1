var t = require("../../utils/config.js"), a = getApp(), e = require("../../utils/busEvent");

Page({
    data: {
        hasload: !1
    },
    onLoad: function(t) {
        var e = this;
        a.getSysSettingData(function(t) {
            t.IsShowShopBranchLink = a.globalData.IsShowShopBranchLink, e.setData(t);
        }, !0);
    },
    onReady: function() {},
    onShow: function() {
        this.getMemberHistoryShopBranchs(), this.GetLastShop();
    },
    callShopTel: function(t) {
        wx.makePhoneCall({
            phoneNumber: t.currentTarget.dataset.tel
        });
    },
    GetLastShop: function() {
        var e = this;
        t.httpGet(a.getUrl("MemberCenter/GetLastShopBranchInfo"), {
            openId: a.globalData.openId || "of5UJ49DE7H5jNb7Pwty79E-rWnc",
            shopBranchId: wx.getStorageSync("shopBranchId")
        }, function(t) {
            t.success ? (t.data.Id = wx.getStorageSync("shopBranchId"), e.setData({
                current: t.data,
                hasload: !0
            })) : wx.showToast({
                title: t.msg
            });
        });
    },
    changeStore: function(t) {
        var o = t.currentTarget.dataset;
        wx.setStorageSync("shopBranchId", o.id), a.updateCartTotal(0), a.globalData.cartData.items = {}, 
        a.getCartAllData({
            shopBranchId: o.id
        }), e.emit("tabUserChange", {
            url: "../index/index",
            reload: !0
        });
    },
    showFreezeToast: function(t) {
        wx.showToast({
            title: "店铺已冻结",
            icon: "none",
            duration: 1e3,
            mask: !0
        });
    },
    getMemberHistoryShopBranchs: function() {
        var t = this;
        wx.request({
            url: a.getUrl("Common/GetMemberHistoryShopBranchs"),
            data: {
                openId: a.globalData.openId || "of5UJ49DE7H5jNb7Pwty79E-rWnc",
                shopBranchId: wx.getStorageSync("shopBranchId")
            },
            success: function(a) {
                a = a.data, t.setData({
                    history: a.data
                });
            }
        });
    }
});