function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = requirePlugin("live-player-plugin"), e = getApp(), o = require("../../utils/config.js");

Page({
    data: {
        roomId: 0,
        pageInit: !0,
        room: {},
        productList: [],
        pageNo: 0,
        loading: !1,
        isEnd: !1,
        timer: null,
        countdown: [ "00", "00", "00" ],
        isTimeOut: !1,
        liveTimer: null
    },
    onLoad: function(t) {
        var a = this;
        e.getSysSettingData(function(t) {
            a.setData(t);
        }), this.setData({
            roomId: t.roomId
        }), this.loadData(), this.loadProduct(), wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        });
    },
    loadData: function() {
        var t = this;
        o.httpGet(e.getUrl("Live/GetLiveDetail"), {
            roomId: this.data.roomId
        }, function(e) {
            if (wx.stopPullDownRefresh(), e.success) {
                var o = JSON.parse(wx.getStorageSync("localRoom") || "{}"), i = "room_" + e.data.RoomId;
                o[i] && (e.data.Status = o[i]), a.getLiveStatus({
                    room_id: e.data.RoomId
                }).then(function(a) {
                    e.data.Status = a.liveStatus, o[i] = a.liveStatus, t.setData({
                        room: e.data
                    });
                }), wx.setStorageSync("localRoom", JSON.stringify(o)), t.setData({
                    room: e.data
                }), 102 === e.data.Status && (t.setCountdown(), t.getLiveStatus()), wx.setNavigationBarTitle({
                    title: e.data.Name
                });
            }
        });
    },
    loadProduct: function() {
        var a = this;
        this.data.loading || this.data.isEnd || (this.setData({
            loading: !0,
            pageNo: this.data.pageNo + 1
        }), o.httpGet(e.getUrl("Live/GetLiveProducts"), {
            roomId: this.data.roomId,
            pageNo: this.data.pageNo,
            pageSize: 10
        }, function(e) {
            e.success && (e.data.length < 10 && a.setData({
                isEnd: !0
            }), a.setData({
                productList: 1 === a.data.pageNo ? e.data : [].concat(t(a.data.productList), t(e.data)),
                loading: !1
            }));
        }));
    },
    getLiveStatus: function() {
        var t = this;
        this.liveTimer = setInterval(function() {
            a.getLiveStatus({
                room_id: t.data.roomId
            }).then(function(a) {
                101 === a.liveStatus && (t.data.room.Status = 101, t.setData({
                    room: t.data.room
                }), clearInterval(t.liveTimer), clearInterval(t.timer));
            });
        }, 6e4);
    },
    setCountdown: function() {
        var t = this, a = +new Date(), e = +new Date(this.data.room.StartTime.replace("T", " ").replace(/-/g, "/"));
        if (e > a) return this.setData({
            isTimeOut: !0
        });
        var o = (e - a) / 1e3;
        this.timer = setInterval(function() {
            (o -= 1) < 0 && (o = 0, t.setData({
                isTimeOut: !0
            })), t.setData({
                countdown: t.formatDuring(o)
            }), o < 0 && clearInterval(t.timer);
        }, 1e3);
    },
    formatDuring: function(t) {
        var a, e, o;
        return a = parseInt(t / 3600), e = parseInt(t % 3600 / 60), o = parseInt(t % 60), 
        a < 10 && (a = "0" + a), e < 10 && (e = "0" + e), o < 10 && (o = "0" + o), [ a, e, o ];
    },
    openProduct: function(t) {
        wx.navigateTo({
            url: "../productdetail/productdetail?id=" + t.currentTarget.dataset.id + "&room_id=" + this.data.roomId
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        wx.setNavigationBarTitle({
            title: e.globalData.SiteName
        });
    },
    onPullDownRefresh: function() {
        this.setData({
            pageNo: 0,
            isEnd: !1,
            loading: !1
        }), this.loadData(), this.loadProduct();
    },
    onReachBottom: function() {
        this.loadProduct();
    },
    onShareAppMessage: function() {
        return {
            title: this.data.room.Name + "——" + this.data.room.AnchorName,
            imageUrl: this.data.room.CoverImg,
            path: "pages/livedetail/livedetail?roomId=" + this.data.roomId
        };
    }
});