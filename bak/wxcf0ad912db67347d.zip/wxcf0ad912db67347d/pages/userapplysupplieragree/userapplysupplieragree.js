var e = getApp(), r = require("../wxParse/wxParse.js"), t = require("../../utils/config.js");

Page({
    data: {
        Agreement: "",
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(a) {
        var o = this;
        this.setData({
            PrimaryColor: e.globalData.PrimaryColor,
            PrimaryTxtColor: e.globalData.PrimaryTxtColor
        }), e.getOpenId(function(a) {
            a && (wx.showLoading({
                title: "加载中"
            }), t.httpGet(e.getUrl("Home/GetSupplierAgreement"), {
                openId: a
            }, function(e) {
                wx.hideLoading();
                var t = e.data.SupplierAgreement;
                r.wxParse("Agreement", "html", t, o);
            }));
        });
    },
    goback: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            checked: !0
        }), wx.navigateBack();
    }
});