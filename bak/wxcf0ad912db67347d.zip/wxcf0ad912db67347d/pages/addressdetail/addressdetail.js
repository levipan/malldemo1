var a = require("../../utils/config.js"), t = getApp();

Page({
    data: {
        show: !0,
        options: null,
        showDistpicker: !1,
        type: 1,
        form: {
            id: 0,
            shipTo: "",
            cellPhone: "",
            regionId: 0,
            address: "",
            addressDetail: "",
            isDefault: !1
        },
        returnFrom: {
            address: "",
            shipTo: "",
            cellPhone: "",
            id: ""
        },
        addressData: []
    },
    onLoad: function(a) {
        var e = this;
        a.id && this.load(a.id), a.type && this.setData({
            type: a.type
        }), t.getSysSettingData(function(a) {
            e.setData(a);
        });
    },
    onReady: function() {
        this.addressSelect = this.selectComponent("#addressSelect");
    },
    switchChange: function(a) {
        this.data.form.isDefault = a.detail.value;
    },
    handleAddressOk: function(a) {
        var t = a.detail, e = [];
        t.map(function(a) {
            e.push(a.text);
        }), this.data.form.regionId = t[t.length - 1].id, this.data.form.address = e.join(" "), 
        this.setData({
            form: this.data.form,
            addressData: t
        });
    },
    load: function(e) {
        var d = this;
        wx.showLoading(), a.httpGet(t.getUrl("Address/GetAddress"), {
            openId: t.globalData.openId,
            addressId: e
        }, function(a) {
            if (wx.hideLoading(), !a.success) return wx.showToast({
                title: a.msg || "获取失败",
                icon: "none"
            });
            var t = a.data.data, e = [];
            t.Path.forEach(function(a, t) {
                e.push({
                    id: a.Id,
                    name: a.Name,
                    text: a.Name,
                    parentId: a.ParentId
                });
            });
            var s = d.data.form;
            s.id = t.Id, s.address = t.Address, s.addressDetail = t.AddressDetail, s.cellPhone = t.CellPhone, 
            s.isDefault = t.IsDefault, s.shipTo = t.ShipTo, s.regionId = t.RegionId, d.setData({
                form: s,
                show: t.IsDefault,
                addressData: e
            });
        });
    },
    handleShowAddressSelect: function() {
        this.addressSelect.handleShow();
    },
    handleInput: function(a) {
        var t = a.detail.value, e = a.currentTarget.dataset.name;
        this.data.form[e] = t;
    },
    addAddress: function() {
        var e = this, d = !1, s = "";
        if (this.data.form.shipTo.trim() || (d = !0, s = "收货人姓名不能为空"), !d && this.data.form.cellPhone.trim().length < 11 && (d = !0, 
        s = "收货人手机号不正确"), d || this.data.form.address || (d = !0, s = "请选择地区"), d || this.data.form.addressDetail || (d = !0, 
        s = "请输入详细地址"), d) return wx.showToast({
            title: s,
            icon: "none"
        });
        this.data.form.openId = t.globalData.openId, wx.showLoading(), a.httpPost(t.getUrl("Address/Save"), this.data.form, function(a) {
            if (wx.hideLoading(), !a.success) return wx.showToast({
                title: a.msg,
                icon: "none"
            });
            "2" === e.data.type ? (t.setCacheAddressAction({
                name: e.data.form.shipTo,
                addressId: a.data.data,
                phone: e.data.form.cellPhone,
                address: e.data.form.address,
                addressDetail: e.data.form.addressDetail
            }), wx.navigateBack({
                delta: 2
            })) : wx.navigateBack({
                delta: 1
            });
        });
    },
    delAddress: function() {
        wx.showLoading(), a.httpGet(t.getUrl("Address/Remove"), {
            openId: t.globalData.openId,
            id: this.data.form.id
        }, function(a) {
            wx.hideLoading(), a.success ? wx.navigateBack() : wx.showToast({
                title: "删除失败",
                icon: "none"
            });
        });
    }
});