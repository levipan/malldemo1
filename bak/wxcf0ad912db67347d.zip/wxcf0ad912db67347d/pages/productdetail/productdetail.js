function t(t) {
    if (Array.isArray(t)) {
        for (var e = 0, a = Array(t.length); e < t.length; e++) a[e] = t[e];
        return a;
    }
    return Array.from(t);
}

function e(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

function a(t) {
    function e(t) {
        for (var e = 32; e--; ) t.push("0");
    }
    function o(t, e) {
        switch (e) {
          case "N":
            return t.toString().replace(/,/g, "");

          case "D":
            return i = (i = t.slice(0, 8) + "-" + t.slice(8, 12) + "-" + t.slice(12, 16) + "-" + t.slice(16, 20) + "-" + t.slice(20, 32)).replace(/,/g, "");

          case "B":
            return i = "{" + (i = o(t, "D")) + "}";

          case "P":
            var i = o(t, "D");
            return i = "(" + i + ")";

          default:
            return new a();
        }
    }
    var i = new Array();
    "string" == typeof t ? function(t, a) {
        if (a = a.replace(/\{|\(|\)|\}|-/g, ""), 32 != (a = a.toLowerCase()).length || -1 != a.search(/[^0-9,a-f]/i)) e(t); else for (var o = 0; o < a.length; o++) t.push(a[o]);
    }(i, t) : e(i), this.Equals = function(t) {
        return !(!t || !t.IsGuid) && this.ToString() == t.ToString();
    }, this.IsGuid = function() {}, this.ToString = function(t) {
        return "string" == typeof t && ("N" == t || "D" == t || "B" == t || "P" == t) ? o(i, t) : o(i, "D");
    };
}

var o = getApp(), i = require("../../utils/config.js"), r = require("../../utils/busEvent"), s = (require("../../utils/config.js").httpGet, 
o.add, o.subtract), n = o.multiply;

Page({
    data: {
        isNewMember: !1,
        backShow: "none",
        SkuShow: "none",
        couponShow: "none",
        promoteShow: "none",
        skuPrice: 0,
        skuStock: 0,
        choosetype: "",
        ReviewCount: 0,
        gotopVal: !0,
        hasLoaded: !1,
        pageLoaded: !1,
        shopBuyHide: !1,
        EstimateCommission: "",
        timeload: "",
        showDetailBuy: 0,
        moduleData: null,
        serviceShow: !1,
        showPoster: !1,
        shopName: "",
        shopContact: "",
        posterData: [],
        hasPoster: !1,
        showVideo: !1,
        swiperIndex: 0,
        swiperItemNum: 1,
        actionsheetShow: !1,
        preview: !1,
        time: [],
        disabled: !1,
        roomId: 0,
        liveIng: !1,
        liveRoomId: "",
        isBindIphone: !1,
        vipCard: {
            minSalePrice: 1,
            sourceMinSalePrice: 1
        },
        isNewExclusive: !1,
        deliveryFeeTip: "",
        showBindPhone: !1,
        isVideoTakeGoods: !1,
        showGroupRule: !1,
        showGroupList: !1,
        groupRule: [ {
            img: o.getRequestUrl + "/Images/Applet/step1.png",
            text: "选中商品点击【去开团】 \n确认商品规格"
        }, {
            img: o.getRequestUrl + "/Images/Applet/step2.png",
            text: "提交订单完成付款 \n即可开团"
        }, {
            img: o.getRequestUrl + "/Images/Applet/step3.png",
            text: "分享好友 \n等待好友参团"
        }, {
            img: o.getRequestUrl + "/Images/Applet/step4.png",
            text: "好友点击【去参团】 \n完成付款后 \n成功参团"
        }, {
            img: o.getRequestUrl + "/Images/Applet/step5.png",
            text: "有效期内达到人数 \n组团成功 \n等待发货/自提"
        } ],
        groupId: 0,
        buyType: "ordinary",
        productType: 1,
        timer: null
    },
    changerSwiperIndex: function(t) {
        this.setData({
            swiperIndex: t.detail.current
        });
    },
    onImgOK: function(t) {
        this.setData({
            posterImagePath: t.detail.path,
            hasPoster: !0
        }), wx.previewImage({
            current: 0,
            urls: [ t.detail.path ]
        });
    },
    savePoster: function() {
        var t = this;
        wx.saveImageToPhotosAlbum({
            filePath: t.data.posterImagePath,
            success: function() {
                wx.showToast({
                    title: "保存成功"
                }), t.setData({
                    backShow: "none",
                    showPoster: !1
                });
            }
        });
    },
    createShareImg: function(t) {
        this.setData({
            shareImagePath: t.detail.path
        });
    },
    showVideo: function() {
        this.setData({
            showVideo: !0
        });
    },
    closeVideo: function() {
        this.setData({
            showVideo: !1
        });
    },
    onPullDownRefresh: function() {
        this.getProductDetail();
    },
    onReady: function() {
        var t = this;
        this.storeCart = this.selectComponent("#storeCart"), wx.setNavigationBarColor({
            frontColor: this.data.PrimaryTxtColor,
            backgroundColor: this.data.PrimaryColor
        }), wx.createSelectorQuery().select(".product-detail").boundingClientRect(function(e) {
            if (e.top < wx.getSystemInfoSync().windowHeight) {
                var a = wx.getSystemInfoSync().windowHeight - e.top;
                t.setData({
                    productMinHeight: a + "px"
                });
            }
        }).exec(), r.off("triggerBindphone"), r.on("triggerBindphone", function() {
            t.setData({
                showBindPhone: !0
            });
        });
    },
    goToCopyright: function() {
        wx.navigateTo({
            url: "../outurl/outurl?url=" + o.getRequestUrl + "hishop/index.html"
        });
    },
    showSharePoster: function() {
        this.setData({
            backShow: "none",
            actionsheetShow: !1
        }), this.data.hasPoster ? wx.previewImage({
            current: 0,
            urls: [ this.data.posterImagePath ]
        }) : (wx.showLoading({
            title: "生成中"
        }), this.getProductCodeimg());
    },
    showVideoNumber: function() {
        var t = this.data.productId, e = this.data.shopBranchId;
        wx.navigateTo({
            url: "/subPages/videoNumber/videoNumber?productId=" + t + "&shopBranchId=" + e
        });
    },
    closeShowSharePoster: function() {
        this.setData({
            showPoster: !1
        });
    },
    setCartCount: function() {
        var t = wx.getStorageSync("cartCount");
        if (t > 0) {
            e = !0;
            t > 99 && (t = "...", this.setData({
                dot: !0
            }));
        } else var e = !1;
        this.setData({
            cartCount: t,
            showCartNum: e
        });
    },
    onLoad: function(t) {
        var e = t.id, a = t.shopBranchId;
        this.setData({
            roomId: t.room_id || 0,
            productId: e,
            isNewExclusive: t.isNewExclusive || !1,
            shopBranchId: a
        }), t.referralUserId && o.setRefferUserId(t.referralUserId), t.preview && this.setData({
            preview: t.preview
        }), wx.getStorageSync("shopBranchId") || a ? wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }) : wx.navigateTo({
            url: "../position/position?isBack=1"
        });
    },
    onShow: function() {
        o.globalData.IsConBindCellPhone && !o.globalData.userInfo.CellPhone && this.setData({
            isBindIphone: !0
        }), !this.data.producttype && this.data.pageLoaded && this.updateProduct(), wx.getStorageSync("mallAppletOpenId") ? (this.setCartCount(), 
        this.setData({
            isVideoTakeGoods: !0
        })) : this.setData({
            isVideoTakeGoods: !1
        }), this.loadData();
    },
    init: function() {
        this.loadData();
    },
    loadData: function() {
        var t = this, e = wx.getStorageSync("shopBranchId");
        e && this.data.shopBranchId && e != this.data.shopBranchId ? wx.redirectTo({
            url: "../storeswitch/storeswitch?formPage=productdetail&currentBranchId=" + e + "&newBranchId=" + this.data.shopBranchId + "&productId=" + this.data.productId
        }) : (t.setData({
            shopBranchId: t.data.shopBranchId || e
        }, function() {
            wx.setStorageSync("shopBranchId", t.data.shopBranchId);
        }), t.getProductDetail(), t.getVisitCount(), o.getSysSettingData(function(e) {
            e.IsShowHishopCopyRight = o.globalData.IsShowHishopCopyRight, e.ProductSaleCountOnOff = o.globalData.ProductSaleCountOnOff, 
            e.IsJumpLink = o.globalData.IsJumpLink, e.IsShowPickupDate = o.globalData.IsShowPickupDate, 
            t.setData(e);
        }, !1, !0));
    },
    handleBargainLaunch: function() {
        var t = this;
        o.getOpenId(function(a) {
            i.httpGet(o.getUrl("Bargain/GetLaunch"), {
                bargainId: t.data.bargainInfo.Id,
                shopBranchId: t.data.shopBranchId,
                openId: a
            }, function(a) {
                if (!a.success) {
                    if (18 == a.code) {
                        var o = Object.assign({}, t.data.bargainInfo.Team, {
                            Surplus: 0,
                            Status: 3,
                            StatusDesc: "已购买"
                        });
                        t.setData(e({}, "bargainInfo.Team", o));
                    }
                    return wx.showToast({
                        title: a.msg,
                        icon: "none"
                    });
                }
                wx.showToast({
                    title: "发起成功"
                }), setTimeout(function() {
                    wx.navigateTo({
                        url: "/subPages/bargainDetail/bargainDetail?teamId=" + a.data.TeamId
                    });
                }, 1e3);
            });
        });
    },
    handleOpenBargain: function() {
        wx.navigateTo({
            url: "/subPages/bargainDetail/bargainDetail?teamId=" + this.data.bargainInfo.Team.Id
        });
    },
    handleOpenActivityCourse: function() {
        wx.navigateTo({
            url: "/subPages/bargainCourse/bargainCourse"
        });
    },
    handleSubscribe: function() {
        var t = this;
        this.data.seckillInfo.IsNodify || o.getOpenId(function(e) {
            i.httpGet(o.getUrl("Common/GetWeiXinMsgTemplateListByApplet"), {
                openId: e
            }, function(a) {
                var r = a.data.find(function(t) {
                    return 27 === t.MessageType;
                }).TemplateId;
                wx.requestSubscribeMessage({
                    tmplIds: [ r ],
                    success: function(a) {
                        "requestSubscribeMessage:ok" == a.errMsg && i.httpGet(o.getUrl("FlashSale/GetCreateNotify"), {
                            flashSaleId: t.data.seckillInfo.Id,
                            openId: e
                        }, function() {
                            wx.showToast({
                                title: "预约成功"
                            }), t.data.seckillInfo.IsNodify = !0, t.setData({
                                seckillInfo: t.data.seckillInfo
                            });
                        });
                    }
                });
            });
        });
    },
    getVisitCount: function() {
        var t = wx.getStorageSync("userGuid");
        t || (t = a.NewGuid().ToString("hishop"), wx.setStorageSync("userGuid", t)), wx.request({
            url: o.getUrl("CommunityStore/GetStatisticProductVisitCount"),
            data: {
                pid: this.data.productId,
                shopBranchId: this.data.shopBranchId,
                guid: t
            },
            success: function(t) {}
        });
    },
    getProductDetail: function() {
        var t = this;
        wx.showNavigationBarLoading(), wx.request({
            url: o.getUrl("CommunityStore/GetProductDetail"),
            data: {
                roomId: this.data.roomId,
                openId: o.globalData.openId,
                productId: this.data.productId,
                shopBranchId: this.data.shopBranchId,
                preview: this.data.preview,
                isNewExclusive: this.data.isNewExclusive
            },
            success: function(a) {
                if (wx.hideLoading(), (a = a.data).success) {
                    var i = a.data, r = t.data.skuArr || [ i.ProductId, 0, 0, 0 ], u = t.data.selectTextArr || [], c = t.data.selectedSkuContent || "", d = t.data.curSkuData ? t.data.curSkuData.SalePrice : i.FlashSale ? i.FlashSale.MinPrice : i.MinSalePrice, h = t.data.curSkuData ? t.data.curSkuData.Stock : 0, p = t.data.curSkuData ? t.data.curSkuData : null;
                    if (t.setData({
                        deliver: i.IsFrontWareHouse ? 3 : i.DeliveryType,
                        DeliveryFeeTip: i.DeliveryFeeTip
                    }), 0 == i.SkuItemList.length) h = i.Stock, p = i.Skus[0]; else {
                        var l = {}, g = i.Skus.filter(function(t) {
                            return t.Stock > 0;
                        });
                        if (i.Skus.forEach(function(t) {
                            l[t.SkuId] = t;
                        }), i.Skus = l, 1 === g.length) {
                            r = g[0].SkuId.split("_");
                            var f = i.Skus[g[0].SkuId], x = [];
                            i.SkuItemList.map(function(t, e) {
                                t.AttributeValue.map(function(t) {
                                    t.ValueId == r[e + 1] && (x.push(t.Value), u.push(t.Value));
                                });
                            }), c = x.join("，"), d = f.SalePrice, h = f.Stock, p = f;
                        }
                    }
                    var m = [];
                    i.Promotes && i.Promotes.FullDiscount && m.push(i.Promotes.FullDiscount.Active.ActiveName), 
                    i.Promotes && i.Promotes.ShopBonus && m.push("代金红包"), wx.setNavigationBarTitle({
                        title: i.ProductName
                    }), i.CommendCard && (i.CommendCard.Price = s(i.MinSalePrice, n(i.SourceMinSalePrice, i.CommendCard.Discount)).toFixed(2), 
                    i.CommendCard.diffPrice = s(i.SourceMinSalePrice, i.MinSalePrice).toFixed(2) || 0), 
                    i.SourceMinSalePrice !== i.MinSalePrice && (i.MarketPrice = i.SourceMinSalePrice);
                    var I = i.MinSalePrice, S = i.FightGroupInfo ? i.FightGroupInfo.Price : i.FlashSaleInfo ? i.FlashSaleInfo.Price : i.MinSalePrice;
                    if (i.FightGroupInfo) {
                        var w = i.FightGroupInfo, D = w.PlayType, v = w.Price, b = t.data.groupRule;
                        2 === D && (b[2].text = "分享好友 \n等待新人参团", b[3].text = "新人点击【去参团】 \n完成付款后 \n成功参团", 
                        t.setData({
                            groupRule: b
                        })), d = t.data.curSkuData ? t.data.curSkuData.ActivityPrice : v, i.FightGroupInfo.GroupList && i.FightGroupInfo.GroupList.slice(0, 2), 
                        i.IsNewExclusive = !1;
                    }
                    if (i.BargainInfo && (o.globalData.bargainId = i.BargainInfo.Id, console.log("bargainId:" + i.BargainInfo.Id), 
                    i.BargainInfo.Team && (i.BargainInfo.Team.Surplus = o.subtract(o.subtract(i.BargainInfo.SalePrice, i.BargainInfo.MinPrice), i.BargainInfo.Team.Amount)), 
                    i.IsNewExclusive = !1), i.FlashSale && (i.LimitCount = i.FlashSale.Limit, i.ShowSaleCounts = i.FlashSale.Sales), 
                    t.setData({
                        groupId: 0,
                        skuStock: h,
                        curSkuData: p,
                        liveIng: i.IsLiving,
                        liveRoomId: i.LiveRoomId,
                        productId: i.ProductId,
                        ProductName: i.ProductName,
                        shopName: i.ShopBranchName,
                        EstimateCommission: i.EstimateCommission,
                        shopContact: i.IsShowShopBranchLink ? i.ContactPhone : "",
                        limitCount: i.LimitCount,
                        defaultLimitCount: i.LimitCount,
                        ShortDescription: i.ShortDescription ? i.ShortDescription : "",
                        ShowSaleCounts: i.ShowSaleCounts,
                        IsUnSale: i.IsUnSale || !1,
                        MarketPrice: parseFloat(i.MarketPrice || 0),
                        MaxSalePrice: i.MaxSalePrice,
                        MinSalePrice: i.MinSalePrice,
                        ProductImgs: i.ProductImgs,
                        swiperItemNum: i.ProductImgs.length + (i.VideoPath ? 1 : 0),
                        videoPath: i.VideoPath,
                        skuArr: r,
                        SkuItemList: i.SkuItemList,
                        Skus: i.Skus,
                        Coupons: i.Coupons,
                        Promotes: i.Promotes || {},
                        ShowPromotesText: m.join("，"),
                        ShowPrice: I,
                        sharePrice: S,
                        SourcePrice: i.SourceMinSalePrice,
                        skuImg: i.ThumbnailUrl60,
                        defaultImg: i.ThumbnailUrl60,
                        skuPrice: d,
                        allStock: i.Stock > 0 ? i.Stock : 0,
                        selectTextArr: u,
                        selectedSkuContent: c,
                        ReviewCount: void 0 !== i.ReviewCount ? i.ReviewCount : i.CommentsNumber,
                        buyAmount: 1,
                        CartCount: i.CartCount || 0,
                        MetaDescription: i.MetaDescription,
                        ProductTemplate: i.ProductTemplate,
                        notDetail: !i.MetaDescription && !i.ProductTemplate,
                        limitStatus: i.Status || 1,
                        CanBuy: i.CanBuy || !1,
                        ShowStatus: i.ShowStatus || "",
                        MeasureUnit: i.MeasureUnit,
                        pageLoaded: !0,
                        BonusCount: i.BonusCount || 0,
                        BonusGrantPrice: i.BonusGrantPrice || 0,
                        BonusRandomAmountStart: i.BonusRandomAmountStart || "",
                        BonusRandomAmountEnd: i.BonusRandomAmountEnd || "",
                        IsShowBuyRecords: i.IsShowBuyRecords,
                        IsSaleCountOnOff: i.IsSaleCountOnOff,
                        isFlashSale: i.IsFlashSale,
                        isStarted: i.IsStarted,
                        franchiseeId: i.FranchiseeId,
                        second: i.HasSecond ? Math.round(i.HasSecond) : "",
                        pickupDateTip: i.PickupDateTip,
                        vipCard: i.CommendCard,
                        isFrontWareHouse: i.IsFrontWareHouse,
                        deliveryFeeTip: i.DeliveryFeeTip,
                        isNewExclusive: i.IsNewExclusive,
                        productType: i.ProductType,
                        fightGroupInfo: i.FightGroupInfo || !1,
                        bargainInfo: i.BargainInfo || !1,
                        seckillInfo: i.FlashSale || !1
                    }), i.PickupDateTip && 11 == i.PickupDateTip.length && i.PickupDateTip.indexOf("月") > 0 && i.PickupDateTip.indexOf("号") > 0 && i.PickupDateTip.indexOf("周") > 0 && parseFloat(i.PickupDateTip.split("月")[0]) > 0 && t.setData({
                        fakePickupDateTip: parseFloat(i.PickupDateTip.split("月")[0]) + "月" + i.PickupDateTip.split("月")[1]
                    }), t.getServicePromises(), o.getShareConfig(function(e) {
                        var a = e.productShareTitle.replace(/{shequ}/g, t.data.shopName);
                        a = (a = a.replace(/{productname}/g, t.data.ProductName)).replace(/{price}/g, t.data.SourcePrice), 
                        t.setData({
                            shareTitle: a
                        });
                    }), t.shareCanvas(), t.data.isFlashSale) {
                        clearInterval(t.data.timeload);
                        t.formatDuring(Math.round(t.data.second));
                        t.data.second >= 0 ? t.setTimeLoad() : t.setData({
                            isOvertime: !0
                        });
                    }
                    0 != t.data.SkuItemList.length && t.setDisabledSku(), i.FightGroupInfo && (clearInterval(t.data.timeload), 
                    t.data.second = i.FightGroupInfo.LeftSecond, t.data.second >= 0 ? t.setTimeLoad() : t.setData({
                        isOvertime: !0
                    })), i.BargainInfo && i.BargainInfo.Team && i.BargainInfo.Team.ExpireSec > 0 && (t.data.bargainInfo.Team.time = t.formatDuring(t.data.bargainInfo.Team.ExpireSec, !0), 
                    t.setData({
                        bargainInfo: t.data.bargainInfo
                    }), clearInterval(t.data.timer), t.data.timer = setInterval(function() {
                        t.data.bargainInfo.Team.ExpireSec -= 1, t.data.bargainInfo.Team.time = t.formatDuring(t.data.bargainInfo.Team.ExpireSec, !0), 
                        t.data.bargainInfo.Team.ExpireSec < 0 && clearInterval(timer), t.setData(e({}, "bargainInfo.Team", t.data.bargainInfo.Team));
                    }, 1e3));
                } else "502" == a.code ? wx.navigateTo({
                    url: "../login/login"
                }) : o.showErrorModal(a.msg, function(t) {
                    t.confirm && wx.navigateBack({
                        delta: 1
                    });
                });
            },
            complete: function() {
                wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), t.setData({
                    hasLoaded: !0
                });
            }
        });
    },
    setTimeLoad: function() {
        var t = this;
        t.data.timeload = setInterval(function() {
            if (t.data.second -= 1, t.data.second > 0) t.data.isOvertime = !1, t.data.time = t.formatDuring(t.data.second); else {
                if (0 != t.data.second) return void (t.data.isOvertime = !0);
                t.getProductDetail();
            }
            t.setData({
                second: t.data.second,
                time: t.data.time,
                isOvertime: t.data.isOvertime
            });
        }, 1e3);
    },
    formatDuring: function(t, e) {
        var a = parseInt(t / 86400), o = parseInt(t % 86400 / 3600), i = parseInt(t % 3600 / 60), r = parseInt(t % 3600 % 60);
        if (o < 10 && (o = "0" + o), i < 10 && (i = "0" + i), r < 10 && (r = "0" + r), !e) return [ a, o, i, r ];
        var s = "";
        return a > 0 && (s += a + "天"), s += o + ":" + i + ":" + r;
    },
    posterCanvas: function() {
        var t = this.data.fightGroupInfo ? this.data.fightGroupInfo.Price + "" : this.data.SourcePrice, e = this.data.fightGroupInfo ? "拼团价" : this.data.isNewExclusive ? "新人专享" : "抢购价";
        this.data.bargainInfo && (e = this.data.bargainInfo.MinPrice > 0 ? this.data.bargainInfo.MinPrice + "元砍价" : "0元免费拿"), 
        this.data.seckillInfo && (e = this.data.seckillInfo.Tag, t = this.data.seckillInfo.MinPrice + ""), 
        this.setData({
            showPoster: !0,
            posterData: {
                background: "#fff",
                width: "640rpx",
                height: "1000rpx",
                views: [ {
                    type: "image",
                    url: this.data.defaultImg,
                    css: {
                        top: "0rpx",
                        left: "0rpx",
                        width: "640rpx",
                        height: "640rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.ProductName,
                    css: {
                        top: "672rpx",
                        width: "416rpx",
                        fontSize: "32rpx",
                        lineHeight: "48rpx",
                        color: "#212121",
                        maxLines: "1",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.ShortDescription,
                    css: {
                        top: "720rpx",
                        width: "416rpx",
                        fontSize: "28rpx",
                        lineHeight: "40rpx",
                        color: "#BDBDBD",
                        maxLines: "1",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: "￥",
                    css: {
                        top: "789rpx",
                        left: "24rpx",
                        color: "#FB1438",
                        lineHeight: "40rpx",
                        fontSize: "28rpx"
                    }
                }, {
                    type: "text",
                    text: t,
                    css: {
                        top: "772rpx",
                        left: "52rpx",
                        color: "#FB1438",
                        fontWeight: "bold",
                        fontSize: "48rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#FB1438",
                        width: o.calcTextLength(e, 20) + 16 + "rpx",
                        height: "32rpx",
                        lineHeight: "32rpx",
                        borderRadius: "16rpx",
                        top: "788rpx",
                        left: o.calcTextLength(t, 48) + 72 + "rpx"
                    }
                }, {
                    type: "text",
                    text: e,
                    css: {
                        color: "#fff",
                        height: "32rpx",
                        lineHeight: "32rpx",
                        fontSize: "20rpx",
                        top: "790rpx",
                        left: o.calcTextLength(t, 48) + 72 + 8 + "rpx"
                    }
                }, {
                    type: "image",
                    url: this.data.productCodeimg,
                    css: {
                        top: "672rpx",
                        right: "24rpx",
                        width: "160rpx",
                        height: "160rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#eee",
                        width: "592rpx",
                        height: "1rpx",
                        top: "864rpx",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.shopName,
                    css: {
                        top: "888rpx",
                        left: "344rpx",
                        width: "592rpx",
                        lineHeight: "40rpx",
                        color: "#212121",
                        maxLines: "1",
                        fontSize: "28rpx",
                        align: "center"
                    }
                }, {
                    type: "text",
                    text: "长按识别小程序码",
                    css: {
                        top: "938rpx",
                        left: "318rpx",
                        width: "592rpx",
                        lineHeight: "40rpx",
                        color: "#bdbdbd",
                        maxLines: "1",
                        fontSize: "28rpx",
                        align: "center"
                    }
                }, {
                    type: "image",
                    url: "../../images/icon-store.png",
                    css: {
                        top: "886rpx",
                        left: 320 - o.calcTextLength(this.data.shopName) / 2 - 22 + "rpx",
                        width: "40rpx",
                        height: "40rpx"
                    }
                } ]
            }
        });
    },
    shareCanvas: function() {
        var t = o.calcTextLength(this.data.SourcePrice, 80) + 80, e = o.calcTextLength(this.data.ShowSaleCounts + "" + this.data.allStock, 10) + 112;
        this.data.pickupDateTip && 11 == this.data.pickupDateTip.length && this.data.pickupDateTip.indexOf("月") > 0 && this.data.pickupDateTip.indexOf("号") > 0 && this.data.pickupDateTip.indexOf("周") > 0 ? 1 == this.data.deliver ? this.setData({
            shareData: {
                background: "#fff",
                width: "750rpx",
                height: "600rpx",
                views: [ {
                    type: "image",
                    url: this.data.defaultImg,
                    css: {
                        top: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "750rpx"
                    }
                }, {
                    type: "image",
                    url: "../../images/share-bg.png",
                    css: {
                        bottom: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "128rpx"
                    }
                }, {
                    type: "text",
                    text: "￥",
                    css: {
                        bottom: "16rpx",
                        left: "24rpx",
                        color: "#fff",
                        lineHeight: "60rpx",
                        fontSize: "44rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.SourcePrice,
                    css: {
                        bottom: "16rpx",
                        left: "64rpx",
                        lineHeight: "96rpx",
                        color: "#fff",
                        fontSize: "80rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.MarketPrice ? "￥" + this.data.MarketPrice : "",
                    css: {
                        color: "#fff",
                        bottom: "70rpx",
                        lineHeight: "24rpx",
                        fontSize: "20rpx",
                        textDecoration: "line-through",
                        left: t + "rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#fff",
                        width: e + 32 + "rpx",
                        height: "32rpx",
                        borderRadius: "16rpx",
                        bottom: "32rpx",
                        left: t + "rpx"
                    }
                }, {
                    type: "text",
                    text: "售" + this.data.ShowSaleCounts + (this.data.MeasureUnit || "份") + " / 剩" + this.data.allStock + (this.data.MeasureUnit || "份"),
                    css: {
                        color: "#FB1438",
                        bottom: "28rpx",
                        lineHeight: "32rpx",
                        fontSize: "20rpx",
                        left: t + 8 + "rpx"
                    }
                }, {
                    type: "text",
                    text: "到货时间",
                    css: {
                        color: "rgba(255,255,255,0.6)",
                        bottom: "64rpx",
                        lineHeight: "32rpx",
                        fontSize: "24rpx",
                        right: "60rpx"
                    }
                }, {
                    type: "text",
                    text: "月",
                    css: {
                        bottom: "20rpx",
                        right: "112rpx",
                        lineHeight: "32rpx",
                        color: "#fff",
                        fontSize: "24rpx"
                    }
                }, {
                    type: "text",
                    text: "日",
                    css: {
                        bottom: "20rpx",
                        right: "24rpx",
                        lineHeight: "32rpx",
                        color: "#fff",
                        fontSize: "24rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#fff",
                        width: "48rpx",
                        height: "40rpx",
                        borderRadius: "4rpx",
                        bottom: "18rpx",
                        right: "144rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#fff",
                        width: "48rpx",
                        height: "40rpx",
                        borderRadius: "4rpx",
                        bottom: "18rpx",
                        right: "56rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.pickupDateTip.substring(0, 2),
                    css: {
                        bottom: "22rpx",
                        right: "152rpx",
                        lineHeight: "32rpx",
                        color: "#FB1438",
                        fontSize: "28rpx",
                        fontWeight: "bold"
                    }
                }, {
                    type: "text",
                    text: this.data.pickupDateTip.substring(3, 5),
                    css: {
                        bottom: "22rpx",
                        right: "64rpx",
                        lineHeight: "32rpx",
                        color: "#FB1438",
                        fontSize: "28rpx",
                        fontWeight: "bold"
                    }
                } ]
            }
        }) : this.setData({
            shareData: {
                background: "#fff",
                width: "750rpx",
                height: "600rpx",
                views: [ {
                    type: "image",
                    url: this.data.defaultImg,
                    css: {
                        top: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "750rpx"
                    }
                }, {
                    type: "image",
                    url: "../../images/share-bg.png",
                    css: {
                        bottom: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "128rpx"
                    }
                }, {
                    type: "text",
                    text: "￥",
                    css: {
                        bottom: "16rpx",
                        left: "24rpx",
                        color: "#fff",
                        lineHeight: "60rpx",
                        fontSize: "44rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.SourcePrice,
                    css: {
                        bottom: "16rpx",
                        left: "64rpx",
                        lineHeight: "96rpx",
                        color: "#fff",
                        fontSize: "80rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.MarketPrice ? "￥" + this.data.MarketPrice : "",
                    css: {
                        color: "#fff",
                        bottom: "70rpx",
                        lineHeight: "24rpx",
                        fontSize: "20rpx",
                        textDecoration: "line-through",
                        left: t + "rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#fff",
                        width: e + 32 + "rpx",
                        height: "32rpx",
                        borderRadius: "16rpx",
                        bottom: "32rpx",
                        left: t + "rpx"
                    }
                }, {
                    type: "text",
                    text: "售" + this.data.ShowSaleCounts + (this.data.MeasureUnit || "份") + " / 剩" + this.data.allStock + (this.data.MeasureUnit || "份"),
                    css: {
                        color: "#FB1438",
                        bottom: "28rpx",
                        lineHeight: "32rpx",
                        fontSize: "20rpx",
                        left: t + 8 + "rpx"
                    }
                }, {
                    type: "text",
                    text: "快递到家",
                    css: {
                        color: "rgba(255,255,255,0.6)",
                        bottom: "48rpx",
                        lineHeight: "32rpx",
                        fontSize: "36rpx",
                        right: "50rpx"
                    }
                } ]
            }
        }) : this.setData({
            shareData: {
                background: "#fff",
                width: "750rpx",
                height: "600rpx",
                views: [ {
                    type: "image",
                    url: this.data.defaultImg,
                    css: {
                        top: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "750rpx"
                    }
                }, {
                    type: "image",
                    url: "../../images/share-bg.png",
                    css: {
                        bottom: "0rpx",
                        left: "0rpx",
                        width: "750rpx",
                        height: "128rpx"
                    }
                }, {
                    type: "text",
                    text: "￥",
                    css: {
                        bottom: "16rpx",
                        left: "24rpx",
                        color: "#fff",
                        lineHeight: "60rpx",
                        fontSize: "44rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.SourcePrice,
                    css: {
                        bottom: "16rpx",
                        left: "64rpx",
                        lineHeight: "96rpx",
                        color: "#fff",
                        fontSize: "80rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.MarketPrice ? "￥" + this.data.MarketPrice : "",
                    css: {
                        color: "#fff",
                        bottom: "70rpx",
                        lineHeight: "24rpx",
                        fontSize: "20rpx",
                        textDecoration: "line-through",
                        left: t + "rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#fff",
                        width: e + 32 + "rpx",
                        height: "32rpx",
                        borderRadius: "16rpx",
                        bottom: "32rpx",
                        left: t + "rpx"
                    }
                }, {
                    type: "text",
                    text: "售" + this.data.ShowSaleCounts + (this.data.MeasureUnit || "份") + " / 剩" + this.data.allStock + (this.data.MeasureUnit || "份"),
                    css: {
                        color: "#FB1438",
                        bottom: "28rpx",
                        lineHeight: "32rpx",
                        fontSize: "20rpx",
                        left: t + 16 + "rpx"
                    }
                }, {
                    type: "text",
                    text: "到货时间",
                    css: {
                        color: "rgba(255,255,255,0.6)",
                        bottom: "64rpx",
                        lineHeight: "32rpx",
                        fontSize: "24rpx",
                        right: "60rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.pickupDateTip,
                    css: {
                        bottom: "22rpx",
                        left: "630rpx",
                        lineHeight: "32rpx",
                        color: "#ffffff",
                        fontSize: "28rpx",
                        maxLines: "1",
                        align: "center",
                        fontWeight: "bold",
                        width: "180rpx"
                    }
                } ]
            }
        });
    },
    updateProduct: function() {
        var t = this;
        i.httpGet(o.getUrl("CommunityStore/GetProductDetail"), {
            shopBranchId: this.data.shopBranchId,
            productId: this.data.productId,
            openId: o.globalData.openId
        }, function(e) {
            t.setData({
                CartCount: e.data.CartCount
            });
        });
    },
    getProductCodeimg: function() {
        var t = this;
        wx.request({
            url: o.getUrl("CommunityStore/GetProductDetailAppletCode"),
            data: {
                pid: this.data.productId,
                uid: o.globalData.userInfo.IsDistributor ? o.globalData.userInfo.UserId : 0,
                isNewExclusive: this.data.isNewExclusive,
                shopBranchId: this.data.shopBranchId
            },
            success: function(e) {
                e.data.success && (t.setData({
                    productCodeimg: o.getUrl(e.data.data.url).replace("/mobileshopapi/", "")
                }), wx.hideLoading());
            },
            complete: function() {
                t.posterCanvas();
            }
        });
    },
    onShareAppMessage: function(t) {
        if ("button" === t.from && "group" === t.target.dataset.type) {
            var e = t.target.dataset, a = e.groupId, i = e.orderId, r = e.needNumber, s = this.data, n = s.ProductName, u = s.fightGroupInfo, c = u.Price, d = u.ShopBranchId, h = s.defaultImg, p = o.globalData.FightGroupShareTitle, l = o.globalData.FightGroupShareImage || h, g = p.replace(/{count}/g, r);
            return {
                title: g = (g = g.replace(/{price}/g, c)).replace(/{product}/g, n),
                path: "subPages/groupDetail/groupDetail?groupId=" + a + "&orderId=" + i + "&shopBranchId=" + d,
                imageUrl: l
            };
        }
        var f = "pages/productdetail/productdetail?id=" + this.data.productId + "&shopBranchId=" + this.data.shopBranchId;
        return o.globalData.userInfo.IsDistributor && (f += "&referralUserId=" + o.globalData.userInfo.UserId), 
        this.data.isNewExclusive && (f += "&isNewExclusive=" + this.data.isNewExclusive), 
        {
            title: this.data.shareTitle,
            path: f,
            imageUrl: this.data.shareImagePath,
            success: function(t) {},
            fail: function(t) {}
        };
    },
    reachBottom: function() {
        var t = this;
        if ((this.data.MetaDescription || this.data.ProductTemplate) && !this.data.moduleData) {
            var e = Date.parse(new Date());
            e /= 1e3, wx.showNavigationBarLoading(), this.getProductTemplate(function(a) {
                if (!t.data.MetaDescription && a) return t.setData({
                    moduleData: a
                });
                wx.request({
                    url: t.data.MetaDescription + "?r=" + e,
                    dataType: "json",
                    success: function(e) {
                        if (a) {
                            var r = a.findIndex(function(t) {
                                return 98 === t.type;
                            });
                            -1 != r ? (a.splice(r, 1), e.data.LModules.forEach(function(t, e) {
                                a.splice(r + e, 0, t);
                            })) : a = e.data.LModules.concat(a);
                        } else a = e.data.LModules;
                        t.setData({
                            moduleData: a
                        }), null != t.data.moduleData && t.data.moduleData.forEach(function(e) {
                            if (4 == e.type) {
                                var a = "";
                                e.content.goodslist.forEach(function(t, e) {
                                    a = 0 == e ? t.item_id : a + "," + t.item_id;
                                }), i.httpGet(o.getUrl("product/GetProductLastPriceByIds"), {
                                    openId: o.globalData.openId,
                                    productIds: a,
                                    shopBranchId: t.data.shopBranchId,
                                    preview: t.data.preview
                                }, function(a) {
                                    a.success && (e.content.goodslist.forEach(function(t) {
                                        a.data.Data.forEach(function(e) {
                                            t.item_id == e.productId && (t.price = e.price, t.title = null != e.title ? e.title : t.title, 
                                            t.pic = null != e.pic ? -1 == e.pic.indexOf("http://") && -1 == e.pic.indexOf("https://") ? o.getRequestUrl + e.pic : e.pic : t.pic);
                                        });
                                    }), t.setData({
                                        moduleData: t.data.moduleData
                                    }));
                                });
                            }
                        }), wx.hideNavigationBarLoading();
                    }
                });
            });
        }
    },
    getProductTemplate: function(t) {
        if (!this.data.ProductTemplate) return t(null);
        wx.request({
            url: this.data.ProductTemplate + "?r=" + Date.parse(new Date()) / 1e3,
            dataType: "json",
            success: function(e) {
                t(e.data.LModules);
            }
        });
    },
    getServicePromises: function() {
        var t = this;
        o.getServicePromises(this.data.franchiseeId, function(e) {
            t.setData({
                service: e
            });
        });
    },
    showServiceToggle: function() {
        this.setData({
            serviceShow: !this.data.serviceShow,
            backShow: this.data.backShow ? "" : "none"
        });
    },
    actionsheetToggle: function() {
        this.setData({
            actionsheetShow: !this.data.actionsheetShow,
            backShow: this.data.backShow ? "" : "none"
        });
    },
    changeDetailBuy: function(t) {
        var e = parseInt(t.currentTarget.dataset.type);
        !this.data.BuyRecords && e && this.getBuyRecords(), this.setData({
            showDetailBuy: e
        });
    },
    getBuyRecords: function() {
        var t = this;
        i.httpGet(o.getUrl("product/GetBuyRecords"), {
            productId: this.data.productId
        }, function(e) {
            e.success && (e.data.forEach(function(t) {
                var e = t.Nick, a = [], o = !0, i = !1, r = void 0;
                try {
                    for (var s, n = e[Symbol.iterator](); !(o = (s = n.next()).done); o = !0) {
                        var u = s.value;
                        a.push(u);
                    }
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    i = !0, r = t;
                } finally {
                    try {
                        !o && n.return && n.return();
                    } finally {
                        if (i) throw r;
                    }
                }
                2 === a.length ? e = a[0] + "*" : e.length > 2 && (e = a[0] + "***" + a[a.length - 1]), 
                t.Nick = e;
            }), t.setData({
                BuyRecords: e.data
            }));
        });
    },
    getCoupon: function(t) {
        var e = t.currentTarget.dataset.id;
        o.getOpenId(function(t) {
            wx.request({
                url: o.getUrl("Coupon/GetUserCoupon"),
                data: {
                    openId: t,
                    couponId: e
                },
                success: function(t) {
                    (t = t.data).success ? wx.showToast({
                        title: "领取成功"
                    }) : "502" == t.code ? wx.navigateTo({
                        url: "../login/login"
                    }) : wx.showToast({
                        title: t.msg,
                        icon: "none"
                    });
                }
            });
        });
    },
    clickCouponList: function(t) {
        var e = this;
        e.data.Coupons && e.data.Coupons.length > 0 ? this.setData({
            backShow: "",
            couponShow: "",
            promoteShow: "none"
        }) : wx.showToast({
            title: "暂时没有可以领取的优惠券",
            icon: "loading"
        });
    },
    clickPromoteList: function(t) {
        this.data.ShowPromotesText ? this.setData({
            backShow: "",
            promoteShow: "",
            couponShow: "none"
        }) : wx.showToast({
            title: "暂时没有进行中的满额优惠活动",
            icon: "loading"
        });
    },
    clickSku: function(t) {
        var e = this, a = t.currentTarget.dataset.type;
        this.setData({
            buyType: a
        }), o.getOpenId(function(t) {
            var a = e.data.skuPrice, o = e.data.defaultLimitCount;
            e.data.fightGroupInfo && (o = e.data.fightGroupInfo.LimitQuantity, a = e.data.curSkuData ? e.data.curSkuData.ActivityPrice : e.data.fightGroupInfo.Price), 
            e.setData({
                limitCount: o,
                skuPrice: a,
                backShow: "",
                SkuShow: "",
                choosetype: "buy"
            });
        });
    },
    setDisabledSku: function() {
        var e = this.data.SkuItemList, a = this.data.Skus, o = e.length, i = this.data.skuArr, r = 0;
        i.forEach(function(t) {
            0 !== t && (r += 1);
        }), r >= o && (e.forEach(function(e) {
            var o = e.AttributeIndex;
            e.AttributeValue.forEach(function(e) {
                var r = [].concat(t(i));
                r[o + 1] = e.ValueId, a[r.join("_")] && !a[r.join("_")].Stock ? e.disabled = !0 : e.disabled = !1;
            });
        }), this.setData({
            SkuItemList: this.data.SkuItemList
        }));
    },
    swithSku: function(t) {
        var e = t.currentTarget.dataset.index, a = t.currentTarget.dataset.skuvalue, o = t.currentTarget.dataset.imgurl, i = t.currentTarget.dataset.id, r = this.data.skuArr;
        0 === e && o != this.data.skuImg && (o = o || this.data.defaultImg, this.setData({
            skuImg: o
        })), r[e + 1] = parseInt(r[e + 1]) === i ? 0 : i, this.data.selectTextArr[e] = r[e + 1] ? a : "";
        var s = this.data.Skus[this.data.skuArr.join("_")], n = "";
        this.data.selectTextArr.forEach(function(t, e) {
            t && (e > 0 && n && (n += "，"), n += t);
        }), this.setData({
            skuArr: r,
            selectTextArr: this.data.selectTextArr,
            selectedSkuContent: n,
            curSkuData: s || null
        }), s && (this.data.IsOpenLadder ? this.setData({
            skuStock: s.Stock
        }) : this.setData({
            skuPrice: "group" === this.data.buyType ? s.ActivityPrice : s.SalePrice,
            skuStock: s.Stock
        })), this.setDisabledSku();
    },
    addShopCart: function(t) {
        var e = this;
        o.getOpenId(function(a) {
            var o = e.data.skuPrice;
            e.data.fightGroupInfo && (o = e.data.curSkuData ? e.data.curSkuData.SalePrice : e.data.ShowPrice);
            var i = t.currentTarget.dataset.type;
            e.setData({
                limitCount: e.data.defaultLimitCount,
                buyType: i,
                skuPrice: o,
                backShow: "",
                SkuShow: "",
                choosetype: "add"
            });
        });
    },
    clickback: function(t) {
        this.setData({
            backShow: "none",
            SkuShow: "none",
            couponShow: "none",
            promoteShow: "none",
            serviceShow: !1,
            showPoster: !1,
            showGroupRule: !1,
            actionsheetShow: !1,
            showGroupList: !1
        });
    },
    onCouponHide: function(t) {
        this.setData({
            backShow: "none",
            couponShow: "none"
        });
    },
    onPromoteHide: function(t) {
        this.setData({
            backShow: "none",
            promoteShow: "none"
        });
    },
    onSkuHide: function(t) {
        this.setData({
            backShow: "none",
            SkuShow: "none"
        });
    },
    handleToggleGroupRule: function() {
        this.setData({
            showGroupRule: !this.data.showGroupRule,
            backShow: this.data.showGroupRule ? "none" : ""
        });
    },
    handleToggleGroupList: function() {
        this.setData({
            showGroupList: !this.data.showGroupList,
            backShow: this.data.showGroupList ? "none" : ""
        });
    },
    handleGoGroupDetail: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/subPages/groupDetail/groupDetail?orderId=" + e
        });
    },
    handleJoinGroup: function(t) {
        var e = this, a = t.currentTarget.dataset.groupId, r = wx.getStorageSync("shopBranchId");
        o.getOpenId(function(t) {
            i.httpGet(o.getUrl("FightGroup/CanJoin"), {
                openId: t,
                groupId: a,
                shopBranchId: r
            }, function(t) {
                var o = {
                    currentTarget: {
                        dataset: {
                            type: "group"
                        }
                    }
                };
                if (e.setData({
                    showGroupList: !1
                }), !t.success) return 999 === t.code ? wx.showModal({
                    title: "参团失败",
                    content: "你是我们的老客户了，可以去开个新团，立享优惠哦",
                    showCancel: !0,
                    cancelText: "知道了",
                    cancelColor: "#000000",
                    confirmText: "开新团",
                    confirmColor: "#FB1438",
                    success: function(t) {
                        t.confirm && (e.setData({
                            isNewMember: !0
                        }), e.clickSku(o));
                    }
                }) : wx.showToast({
                    title: t.msg,
                    icon: "none",
                    duration: 1500,
                    mask: !0
                });
                e.setData({
                    groupId: a
                }, function() {
                    e.clickSku(o);
                });
            });
        });
    },
    reduceAmount: function(t) {
        var e = this.data.buyAmount;
        (e -= 1) <= 0 || this.setData({
            buyAmount: e
        });
    },
    addAmount: function() {
        if (this.data.skuStock) {
            var t = this.data.buyAmount, e = this.data.skuStock, a = this.data.limitCount;
            if (t += 1, 0 == a) {
                if (t > e) return void wx.showToast({
                    title: "超过最大可购买数",
                    icon: "none"
                });
                this.setData({
                    buyAmount: t
                });
            } else {
                if (t > e || t > a) return void wx.showToast({
                    title: "超过最大可购买数",
                    icon: "none"
                });
                this.setData({
                    buyAmount: t
                });
            }
        } else o.showErrorModal("请选择规格");
    },
    changeAmount: function(t) {
        var e = parseInt(t.detail.value), a = this.data.skuStock, i = this.data.limitCount;
        if (0 == i) {
            if (isNaN(e) || e > a || e <= 0) return o.showErrorModal("请输入正确的数量,不能大于库存或者小于等于0"), 
            void this.setData({
                buyAmount: e <= 0 ? 1 : a
            });
            this.setData({
                buyAmount: e
            });
        } else {
            if (isNaN(e) || e > a || e <= 0 || e > i) return o.showErrorModal("请输入正确的数量,不能大于最大可购买或者小于等于0"), 
            void this.setData({
                buyAmount: 1
            });
            this.setData({
                buyAmount: e
            });
        }
    },
    doCommit: function(t) {
        var e = this, a = t.currentTarget.dataset.option;
        if (this.data.curSkuData) if (this.data.curSkuData.Stock) if (this.data.buyAmount <= 0) o.showErrorModal("请输入要购买的数量"); else {
            var i = this.data.buyAmount, r = this.data.skuArr.join("_");
            "buy" == a ? ("bargain" === this.data.buyType && (i = 1), o.getOpenId(function(t) {
                var a = "skuid=" + r + "&count=" + i + "&shopBranchId=" + e.data.shopBranchId + "&deliver=" + e.data.deliver + "&roomId=" + e.data.roomId + "&isNewExclusive=" + e.data.isNewExclusive, o = e.data, s = o.productType, n = o.buyType, u = o.groupId, c = o.isNewMember;
                if (3 === s && "group" === n) {
                    if (e.data.fightGroupInfo.HasWaitPayOrder) return wx.showToast({
                        title: "你已有一个待付款的拼团订单了",
                        icon: "none"
                    });
                    a += "&type=groupSubmit&fightGroupActiveId=" + e.data.fightGroupInfo.Id + "&fightGroupId=" + (c ? 0 : u);
                }
                "bargain" === n && (a += "&bargainId=" + e.data.bargainInfo.Id + "&bargainTeamId=" + e.data.bargainInfo.Team.Id), 
                e.data.seckillInfo && (a += "&flashSaleId=" + e.data.seckillInfo.Id), e.onSkuHide(), 
                wx.navigateTo({
                    url: "../ordersubmit/ordersubmit?" + a
                });
            })) : (this.setData({
                disabled: !0
            }), o.getOpenId(function(t) {
                wx.request({
                    url: o.getUrl("Cart/getaddToCart"),
                    data: {
                        openId: t,
                        shopBranchId: e.data.shopBranchId,
                        SkuID: r,
                        Quantity: i,
                        roomId: e.data.roomId,
                        productDeliveryType: e.data.deliver
                    },
                    success: function(t) {
                        (t = t.data).success ? (e.setData({
                            backShow: "none",
                            SkuShow: "none",
                            disabled: !1
                        }), wx.showToast({
                            title: "加入购物车成功",
                            icon: "none"
                        }), o.globalData.cartData.items[e.data.productId] ? o.globalData.cartData.items[e.data.productId].skus[r] ? o.globalData.cartData.items[e.data.productId].skus[r].Quantity = o.globalData.cartData.items[e.data.productId].skus[r].Quantity + i : o.globalData.cartData.items[e.data.productId].skus[r] = {
                            Quantity: i,
                            ProductId: e.data.productId,
                            SkuId: r
                        } : (o.globalData.cartData.items[e.data.productId] = {}, o.globalData.cartData.items[e.data.productId].skus = {}, 
                        o.globalData.cartData.items[e.data.productId].skus[r] = {
                            Quantity: i,
                            ProductId: e.data.productId,
                            SkuId: r
                        }), o.getCartTotal(function(t) {
                            o.updateCartTotal(t + parseInt(i)), e.setCartCount();
                        })) : "502" == t.code ? wx.navigateTo({
                            url: "../login/login"
                        }) : (o.showErrorModal(t.msg), e.setData({
                            disabled: !1
                        }));
                    }
                });
            }));
        } else o.showErrorModal("库存不足"); else o.showErrorModal("请选择规格");
    },
    goTop: function(t) {
        this.setData({
            scrollTop: 0
        });
    },
    scroll: function(t) {
        this.setData({
            gotopVal: t.detail.scrollTop < 350
        });
    },
    previewImage: function(t) {
        var e = t.target.dataset.src;
        wx.previewImage({
            current: e,
            urls: this.data.ProductImgs
        });
    },
    getPhoneNumber: function(t) {
        var e = this;
        "getPhoneNumber:ok" === t.detail.errMsg && o.getPhoneNumber(t.detail, function() {
            e.setData({
                isBindIphone: !1
            });
        });
    },
    openLive: function() {
        var t = "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=" + this.data.liveRoomId;
        wx.navigateTo({
            url: t
        });
    },
    joinVip: function() {
        var t = this.data.vipCard.Id;
        wx.navigateTo({
            url: "/pages/card/cardDetail/cardDetail?id=" + t + "&type=member"
        });
    },
    handleToCart: function() {
        r.emit("tabUserChange", {
            url: "../cart/cart"
        });
    },
    handleToIndex: function() {
        r.emit("tabUserChange", {
            url: "../index/index"
        });
    },
    onUpdatephone: function() {
        this.setData({
            showBindPhone: !1
        });
    },
    onJoinCart: function(t) {
        t.detail.currentTarget.dataset.hassku ? this.chooseSku(t.detail) : this.productNumChange(t.detail);
    },
    productNumChange: function(t) {
        var e = this, a = t.currentTarget.dataset.id, o = t.currentTarget.dataset.type ? 1 : -1, i = t.currentTarget.dataset.delivery;
        this.setData({
            skuProductid: a
        }), this.storeCart.changeCart(a + "_0_0_0", o, function(t) {
            t.success && (e.setCartCount(), wx.showToast({
                title: "加入购物车成功",
                icon: "none"
            }));
        }, null, i);
    },
    chooseSku: function(t) {
        var e = this;
        o.getOpenId(function(a) {
            if (a) {
                e.setData({
                    skuProductid: t.currentTarget.dataset.id
                });
                var o = t.currentTarget.dataset.delivery;
                e.storeCart.chooseSku(o);
            }
        });
    },
    handleCountdownEnd: function(t) {
        var a = t.currentTarget.dataset, o = a.type, i = a.id;
        if ("groupItem" !== o) this.onShow(); else {
            var r = this.data.fightGroupInfo.GroupList;
            this.setData(e({}, "fightGroupInfo.GroupList", r.map(function(t) {
                return t.Id === i && (t.isEnd = !0), t;
            })));
        }
    },
    handleGetSwell: function(t) {
        var e = t.currentTarget.dataset.id;
        o.getOpenId(function() {
            wx.navigateTo({
                url: "/subPages/swellActivityDeatil/swellActivityDeatil?couponId=" + e
            });
        });
    }
}), a.Empty = new a(), a.NewGuid = function() {
    for (var t = "", e = 32; e--; ) t += Math.floor(16 * Math.random()).toString(16);
    return new a(t);
};