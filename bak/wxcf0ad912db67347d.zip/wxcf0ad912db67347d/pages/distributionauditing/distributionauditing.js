var t = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        status: 0,
        isLoad: !0,
        remark: ""
    },
    onLoad: function() {
        var i = this;
        a.getOpenId(function(e) {
            e && (wx.showLoading({
                title: "加载中"
            }), t.httpGet(a.getUrl("Distribution/GetDistributorStatus"), {
                openId: e
            }, function(t) {
                wx.hideLoading(), i.setData({
                    isLoad: !1,
                    status: t.data.status,
                    remark: t.data.remark || ""
                });
            }));
        });
    },
    openHandle: function() {
        wx.redirectTo({
            url: "../distributionapply/distributionapply?restart=true"
        });
    }
});