var t = require("../../utils/config.js"), e = require("../../utils/busEvent.js"), o = getApp();

Page({
    data: {
        couponType: 0,
        couponList: [],
        counpimgClass: [ "coupon", "coupon-use", "coupon-over" ],
        couponStyle: [ "coupon", "coupon-use", "coupon-over" ],
        showEmpty: !1
    },
    onLoad: function(e) {
        var a = this;
        wx.showLoading({
            title: "加载中"
        });
        var n = this, s = {
            openId: o.globalData.openId,
            shopBranchId: wx.getStorageSync("shopBranchId") || 0
        };
        wx.showNavigationBarLoading(), t.httpGet(o.getUrl("Coupon/GetLoadCoupon"), s, n.getCouponsData), 
        o.getSysSettingData(function(t) {
            a.setData(t);
        }, !0);
    },
    showEmpty: function() {
        var t = 0 == this.data.couponList[this.data.couponType].length;
        this.setData({
            showEmpty: t
        });
    },
    getCouponsData: function(t) {
        wx.hideLoading();
        var e = this;
        if ("502" == t.code) wx.navigateTo({
            url: "../login/login"
        }); else if (t.success) {
            var o, a = [], n = [], s = [], u = Date.parse(new Date());
            if (t.data.Coupon.length > 0) for (p = 0; p < t.data.Coupon.length; p++) {
                var r = t.data.Coupon[p];
                o = r.EndTime;
                var i = "";
                i = 1 == r.UseArea ? "部分商品可用" : "全店通用";
                h = "";
                h = r.OrderAmount > 0 ? "订单满" + r.OrderAmount.toFixed(2) + "元可用" : "订单金额无限制", r.IsShow || (i = "当前店铺不可用");
                g = {
                    couponsDate: r.StartTime.split(" ")[0].replace(/\//g, "-") + "至" + r.EndTime.split(" ")[0].replace(/\//g, "-"),
                    couponsPrice: r.Price,
                    couponsCanUseProductse: i,
                    LimitText: h,
                    AreaContent: r.AreaContent,
                    useArea: r.UseArea,
                    couponId: r.CouponId,
                    Remark: null == r.Remark ? "" : r.Remark,
                    IsShow: r.IsShow
                };
                1 == r.UseStatus ? n.push(g) : 2 == r.UseStatus ? s.push(g) : a.push(g);
            }
            if (t.data.Bonus.length > 0) for (var p = 0; p < t.data.Bonus.length; p++) {
                var c = t.data.Bonus[p].Bonus, d = t.data.Bonus[p].Receive, h = "订单满" + (c.UsrStatePrice || d.Price).toFixed(2) + "元可用";
                o = c.BonusDateEnd;
                var g = {
                    couponsDate: c.BonusDateStart.split(" ")[0].replace(/\//g, "-") + "至" + c.BonusDateEnd.split(" ")[0].replace(/\//g, "-"),
                    couponsPrice: d.Price,
                    couponsCanUseProductse: c.IsShow ? "全店通用" : "当前店铺不可用",
                    LimitText: h,
                    useArea: 0,
                    couponId: c.Id,
                    AreaContent: c.AreaContent,
                    IsShow: c.IsShow,
                    Remark: ""
                };
                2 == d.State ? n.push(g) : 3 == d.State ? s.push(g) : u > Date.parse(o) ? s.push(g) : a.push(g);
            }
            e.setData({
                couponList: [ a, n, s ]
            }), e.showEmpty(), wx.hideNavigationBarLoading();
        } else wx.hideNavigationBarLoading();
    },
    couponTypeChange: function(t) {
        this.setData({
            couponType: t.currentTarget.dataset.type
        }), this.showEmpty();
    },
    handleToList: function(t) {
        var o = t.currentTarget.dataset, a = o.type, n = o.id;
        void 0 != a && n && (0 != a ? wx.navigateTo({
            url: "../searchProduct/searchProduct?couponId=" + n
        }) : e.emit("tabUserChange", {
            url: "../index/index"
        }));
    }
});