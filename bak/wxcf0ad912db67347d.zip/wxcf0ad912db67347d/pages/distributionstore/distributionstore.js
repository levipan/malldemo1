var t = getApp(), i = require("../../utils/config.js");

Page({
    data: {
        uname: "",
        uPic: "",
        money: 0,
        totalMoney: 0,
        pageload: !0,
        distributionName: {},
        unsettled: 0,
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(a) {
        var e = this;
        t.getDistrbutionName(function(t) {
            t.MyDistributionName && wx.setNavigationBarTitle({
                title: t.MyDistributionName
            }), e.setData({
                distributionName: t
            });
        }), t.getSysSettingData(function(t) {
            e.setData(t);
        }, !0), t.getOpenId(function(a) {
            a && (wx.showLoading({
                title: "加载中"
            }), i.httpGet(t.getUrl("Distribution/GetDistributionHome"), {
                openId: a
            }, function(t) {
                wx.hideLoading(), t.success ? e.setData({
                    pageload: !1,
                    uname: t.data.RealName || "",
                    upic: t.data.Photo,
                    money: t.data.Withdrawable,
                    totalMoney: t.data.History,
                    unsettled: t.data.Unsettled
                }) : e.setData({
                    pageload: !1
                });
            }));
        });
    },
    onReady: function() {},
    onShow: function() {},
    openHandle: function(t) {
        var i = t.currentTarget.dataset.opentype;
        "money" === i && wx.navigateTo({
            url: "../distributioncommision/distributioncommision"
        }), "sub" === i && wx.navigateTo({
            url: "../distributionsub/distributionsub"
        }), "card" === i && wx.navigateTo({
            url: "../distributionshare/distributionshare"
        });
    }
});