var e = require("../../utils/config.js"), t = getApp();

Page({
    data: {
        nickName: "",
        RefferImg: ""
    },
    onLoad: function(s) {
        var n = this;
        t.getDistrbutionName(function(e) {
            e.BusinessCard && wx.setNavigationBarTitle({
                title: e.BusinessCard
            }), n.setData({
                distributionName: e
            });
        });
        var a = this;
        s.ReferralUserId && t.setRefferUserId(s.ReferralUserId), t.getSysSettingData(function(e) {
            n.setData(e);
        }, !0), t.getOpenId(function(s) {
            s && (wx.showLoading({
                title: "加载中"
            }), e.httpGet(t.getUrl("Distribution/GetBusinessCard"), {
                openId: s
            }, function(e) {
                wx.hideLoading(), a.setData({
                    RefferImg: e.data.ReferralPosterUrl
                });
            }));
        }), t.getOpenId(function(s) {
            s && e.httpGet(t.getUrl("MemberCenter/GetUser"), {
                openId: s
            }, function(e) {
                e.success && a.setData({
                    nickName: e.data.Nick
                });
            });
        });
    },
    onShareAppMessage: function() {
        var e = "pages/index/index?id=" + wx.getStorageSync("shopBranchId");
        return t.globalData.userInfo.IsDistributor && (e += "&referralUserId=" + t.globalData.userInfo.UserId), 
        {
            title: this.data.nickName,
            imageUrl: "",
            path: e,
            success: function(e) {
                wx.showToast({
                    title: "分享成功",
                    icon: "none"
                });
            },
            fail: function(e) {
                wx.showToast({
                    title: "分享失败",
                    icon: "none"
                });
            }
        };
    },
    saveImg: function(e) {
        var t = this;
        wx.showModal({
            title: "提示",
            content: "是否保存图片",
            success: function(e) {
                e.confirm ? wx.getSetting({
                    success: function(e) {
                        wx.authorize({
                            scope: "scope.writePhotosAlbum",
                            success: function(e) {
                                var s = t.data.RefferImg;
                                wx.downloadFile({
                                    url: s,
                                    success: function(e) {
                                        wx.saveImageToPhotosAlbum({
                                            filePath: e.tempFilePath,
                                            success: function(e) {
                                                wx.showToast({
                                                    title: "成功保存到相册",
                                                    icon: "success"
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                }) : e.cancel;
            }
        });
    }
});