var a = require("../../utils/config.js"), t = getApp();

Page({
    data: {
        name: "",
        phone: "",
        userInfo: {},
        PrimaryColor: "",
        PrimaryTxtColor: "",
        showDistpicker: !1,
        procitydata: [],
        procitydataValue: [ 0, 0 ],
        provinceSelIndex: 0,
        citySelIndex: 0,
        banks: [],
        bankName: "",
        bankIndex: -1,
        bankAddressId: "",
        bankAddress: "",
        bankUserName: "",
        bankCardNumber: "",
        IdCard: ""
    },
    onLoad: function(e) {
        var i = this;
        t.getSysSettingData(function(a) {
            i.setData(a);
        }, !1), t.getOpenId(function(e) {
            e && (a.httpGet(t.getUrl("MemberCenter/GetUser"), {
                openId: e
            }, function(a) {
                a.success && i.setData({
                    userInfo: a.data
                });
            }), wx.showLoading({
                title: "加载中"
            }), a.httpPost(t.getUrl("Distribution/RequetDistributor"), {
                openId: e
            }, function(a) {
                wx.hideLoading(), a.success && i.setData({
                    name: a.data.realName || "",
                    phone: a.data.cellPhone,
                    bankUserName: a.data.bankUserName || "",
                    bankCardNumber: a.data.bankCardNumber || "",
                    IdCard: a.data.idCard || "",
                    bankName: a.data.bankName || "",
                    bankAddressId: a.data.bankAddressId || ""
                });
            }));
        });
    },
    getVerification: function() {
        var a = this.data, t = a.name, e = a.phone;
        a.IdCard, a.bankName, a.bankAddressId, a.bankCardNumber, a.bankUserName;
        return t ? !(!e || !/^1[3456789]\d{9}$/.test(e)) || (wx.showToast({
            title: "手机号码不正确",
            icon: "none"
        }), !1) : (wx.showToast({
            title: "真实姓名不能为空",
            icon: "none"
        }), !1);
    },
    getBanks: function() {
        var e = this;
        a.httpGet(t.getUrl("Common/GetBanks"), {}, function(a) {
            a.success && e.setData({
                banks: a.data,
                bankIndex: e.data.bankName ? a.data.findIndex(function(a) {
                    return a.id == e.data.bankName;
                }) : -1
            });
        });
    },
    bindBankChange: function(a) {
        this.setData({
            bankIndex: a.detail.value,
            bankName: this.data.banks[a.detail.value].id
        });
    },
    bindAddressTap: function() {
        this.setData({
            showDistpicker: !0
        });
    },
    setAreaData: function() {
        var a = this;
        wx.request({
            url: t.getUrl("Common/GetAdaPayRegions"),
            async: !1,
            success: function(t) {
                if (t.data.success) {
                    var e = t.data.data;
                    if (a.setData({
                        procitydata: e
                    }), a.data.bankAddressId && !a.data.bankAddress) {
                        var i = a.data.bankAddressId.split(",")[0], n = a.data.bankAddressId.split(",")[1], d = e.findIndex(function(a) {
                            return a.id == i;
                        }), s = e[d].name, r = e[d].cities.findIndex(function(a) {
                            return a.id == n;
                        }), o = [ d, r ], c = s + e[d].cities[r].name;
                        a.setData({
                            bankAddress: c,
                            provinceSelIndex: d,
                            citySelIndex: r,
                            procitydataValue: o
                        });
                    }
                    a.setProvinceCityData();
                }
            }
        });
    },
    setProvinceCityData: function() {
        var a = this.data.procitydata, t = [], e = [];
        for (var i in a) {
            var n = a[i].name, d = a[i].id;
            t.push(n), e.push(d);
        }
        this.setData({
            provinceName: t,
            provinceCode: e
        }), this.setSubCityData(this.data.provinceSelIndex);
    },
    setSubCityData: function(a) {
        var t = this.data.procitydata[a].cities, e = [], i = [];
        for (var n in t) {
            var d = t[n].name, s = t[n].id;
            e.push(d), i.push(s);
        }
        this.setData({
            cityName: e,
            cityCode: i
        });
    },
    changeArea: function(a) {
        a.detail.value[0] != this.data.provinceSelIndex && (this.setData({
            provinceSelIndex: a.detail.value[0],
            procitydataValue: [ a.detail.value[0], 0 ]
        }), this.setSubCityData(a.detail.value[0])), a.detail.value[1] != this.data.citySelIndex && this.setData({
            citySelIndex: a.detail.value[1],
            procitydataValue: [ a.detail.value[0], a.detail.value[1] ]
        });
    },
    distpickerCancel: function() {
        this.setData({
            showDistpicker: !1
        });
    },
    distpickerSure: function() {
        this.setData({
            bankAddressId: this.data.provinceCode[this.data.provinceSelIndex] + "," + this.data.cityCode[this.data.citySelIndex],
            bankAddress: this.data.provinceName[this.data.provinceSelIndex] + this.data.cityName[this.data.citySelIndex],
            showDistpicker: !1
        });
    },
    okHandle: function() {
        var e = this;
        this.getVerification() && t.getOpenId(function(i) {
            i && a.httpPost(t.getUrl("Distribution/SubDistributor"), {
                openId: i,
                realName: e.data.name,
                cellPhone: e.data.phone,
                IdCard: e.data.IdCard,
                bankName: e.data.bankName,
                bankAddressId: e.data.bankAddressId,
                bankCardNumber: e.data.bankCardNumber,
                bankUserName: e.data.bankUserName
            }, function(a) {
                if (a.success) return a.data.isRegister ? wx.redirectTo({
                    url: "../distributionstore/distributionstore"
                }) : wx.redirectTo({
                    url: "../distributionauditing/distributionauditing"
                });
                if (2 === a.code) return wx.showModal({
                    title: "提示",
                    content: "需要累计消费金额达到" + a.msg + "元才可申请哦",
                    showCancel: !1,
                    confirmColor: "#ff221a"
                });
                if (3 === a.code) return wx.showModal({
                    title: "提示",
                    content: "需要购买指定商品后才可申请哦",
                    confirmText: "现在购买",
                    success: function(t) {
                        t.confirm && (a.msg.indexOf(",") > -1 ? wx.redirectTo({
                            url: "../productList/productList?ids=" + a.msg
                        }) : wx.redirectTo({
                            url: "../productdetail/productdetail?storeid=0&id=" + a.msg
                        }));
                    }
                });
                if (4 === a.code) {
                    var i = t.subtract(a.msg, e.data.userInfo.Balance), n = "需要充值到" + a.msg + "元才可申请哦,还需要充值" + i + "元";
                    return wx.showModal({
                        title: "提示",
                        content: n,
                        confirmText: "去充值",
                        success: function(a) {
                            a.confirm && wx.redirectTo({
                                url: "../userasset/userasset"
                            });
                        }
                    });
                }
                wx.showToast({
                    title: a.msg,
                    icon: "none"
                });
            });
        });
    },
    bindKeyInput: function(a) {
        var t = a.detail.value, e = a.target.dataset.type;
        this.data[e] = t;
    }
});