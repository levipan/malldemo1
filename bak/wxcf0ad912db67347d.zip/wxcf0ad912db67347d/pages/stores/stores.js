Page({
    data: {},
    onShow: function(o) {
        this.stores.onShow();
    },
    onLoad: function(o) {
        this.stores = this.selectComponent("#stores"), this.stores.onLoad(o);
    },
    onReachBottom: function() {
        this.stores.onReachBottom && this.stores.onReachBottom();
    }
});