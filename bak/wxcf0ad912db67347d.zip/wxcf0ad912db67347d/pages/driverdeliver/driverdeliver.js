function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, i = Array(t.length); a < t.length; a++) i[a] = t[a];
        return i;
    }
    return Array.from(t);
}

var a = getApp(), i = require("../../utils/config.js");

Page({
    data: {
        id: "",
        status: "",
        noMore: !1,
        list: [],
        pageLoading: !0
    },
    staticData: {
        loading: !1,
        pageNumber: 0
    },
    onLoad: function(t) {
        this.setData({
            id: t.id,
            status: parseInt(t.status)
        }), this.getInitConfig(), this.getList();
    },
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getInitConfig: function() {
        var t = this;
        a.getSettingData(function() {
            var i = Object.assign({}, a.globalData.colorsConfig);
            t.setData(i);
        });
    },
    getList: function() {
        var e = this;
        this.data.loading || (this.setData({
            loading: !0
        }), this.staticData.pageNumber += 1, 1 === this.staticData.pageNumber && wx.showLoading(), 
        a.getOpenId(function(s) {
            s && i.httpGet(a.getAdminUrl("Delivery/GetCommunityBatchItems"), {
                openId: s,
                shopBranchId: e.data.id,
                status: e.data.status,
                pageNo: e.staticData.pageNumber,
                pageSize: 10
            }, function(a) {
                if (wx.hideLoading(), e.setData({
                    loading: !1
                }), !a.success) return wx.showToast({
                    title: a.msg,
                    duration: 3e3,
                    icon: "none"
                });
                var i = a.data.BatchList, s = !1;
                a.data.BatchList.length < 10 && (s = !0), e.staticData.pageNumber > 1 && (i = [].concat(t(e.data.list), t(i))), 
                i.map(function(t) {
                    t.more = !1, t.status = e.data.status;
                }), e.setData({
                    pageLoading: !0,
                    noMore: s,
                    list: i
                });
            });
        }));
    },
    handleMore: function(t) {
        var a = t.currentTarget.dataset.item;
        this.data.list.some(function(t) {
            if (a.Id === t.Id) return t.more = !t.more;
        }), this.setData({
            list: this.data.list
        });
    },
    handleSendOk: function(t) {
        var e = this, s = t.currentTarget.dataset.item;
        2 !== s.status && (wx.showLoading(), a.getOpenId(function(t) {
            t && i.httpPost(a.getAdminUrl("Delivery/PostCommunityBatchSigned"), {
                openId: t,
                id: s.Id
            }, function(t) {
                if (wx.hideLoading(), !t.success) return wx.showToast({
                    title: t.msg,
                    duration: 3e3,
                    icon: "none"
                });
                e.data.list.some(function(t) {
                    if (t.Id === s.Id) return t.status = 2;
                }), e.setData({
                    list: e.data.list
                });
            });
        }));
    }
});