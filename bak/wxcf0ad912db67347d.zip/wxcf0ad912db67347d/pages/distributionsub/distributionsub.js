function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = getApp(), e = require("../../utils/config.js");

Page({
    data: {
        distributionName: {},
        isNext: !0,
        list: [],
        pageNumber: 0,
        pageSize: 10,
        pageLoad: !0,
        noList: !0,
        active: "0",
        isOpenSecondLevel: !1
    },
    onLoad: function(t) {
        var e = this;
        a.getDistrbutionName(function(t) {
            e.setData({
                distributionName: t
            }), t.MyLowerLevelName && wx.setNavigationBarTitle({
                title: t.MyLowerLevelName
            });
        }), a.getSysSettingData(function(t) {
            e.setData(t);
        }, !0), this.loadData();
    },
    onReady: function() {},
    onShow: function() {},
    navClick: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            active: a
        }), this.data.pageNumber = 0, this.data.isNext = !0, this.loadData();
    },
    loadData: function() {
        var i = this;
        this.loading || (this.loading = !0, this.data.pageNumber += 1, wx.showLoading({
            title: "加载中"
        }), a.getOpenId(function(n) {
            n && e.httpGet(a.getUrl("Distribution/GetMySubordinateList"), {
                openId: n,
                pageNo: i.data.pageNumber,
                pageSize: i.data.pageSize,
                isSubordinate: "0" !== i.data.active
            }, function(a) {
                if (wx.hideLoading(), i.loading = !1, a.success) {
                    1 === i.data.pageNumber && (i.data.list = []);
                    var e = [].concat(t(i.data.list), t(a.data.subordinatelist));
                    i.setData({
                        pageLoad: !1,
                        noList: !(1 === i.data.pageNumber && 0 === e.length),
                        isOpenSecondLevel: a.data.isOpenSecondLevel,
                        list: e,
                        isNext: a.data.subordinatelist.length === i.data.pageSize
                    });
                } else i.setData({
                    pageLoad: i.data.list.length > 0 && i.data.pageLoad
                });
            });
        }));
    },
    onReachBottom: function() {
        this.data.isNext && this.loadData();
    }
});