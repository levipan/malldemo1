var a = getApp(), r = require("../../utils/config.js");

Page({
    data: {
        OrderId: "",
        ProductList: [],
        scoreArr: new Array(5),
        ScoreGrade: [],
        packMark: 5,
        deliveryMark: 5,
        serviceMark: 5,
        TxtareaName: [],
        isSubmit: !1,
        getRequestUrl: a.getRequestUrl
    },
    onLoad: function(e) {
        var t = this, o = e.id, d = {
            openId: a.globalData.openId,
            orderId: o
        };
        r.httpGet(a.getUrl("MyComment/GetComment"), d, t.getProductData), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: a.globalData.PrimaryColor
        }), t.setData({
            OrderId: o,
            PrimaryColor: a.globalData.PrimaryColor,
            PrimaryTxtColor: a.globalData.PrimaryTxtColor
        });
    },
    getProductData: function(r) {
        var e = this;
        if (r.success) {
            var t = [], o = [], d = r.data.orderItemIds;
            r.data.Product.forEach(function(a, r, e) {
                var i = {
                    mark: parseInt(5),
                    content: "",
                    orderItemId: d[r],
                    Images: [],
                    WXmediaId: []
                };
                t.push(i), o.push("txt_" + d[r]), a.OrderItemId = d[r];
            }), e.setData({
                ProductList: r.data.Product,
                ScoreGrade: t,
                TxtareaName: o
            });
        } else 502 == r.code ? wx.navigateTo({
            url: "../login/login"
        }) : a.showErrorModal(r.msg, function(a) {
            a.confirm && wx.navigateBack({
                delta: 1
            });
        });
    },
    ScoreGrade: function(a) {
        var r = a.currentTarget.dataset.grade, e = a.currentTarget.dataset.index, t = this.data.ScoreGrade;
        t[e].mark = parseInt(r), this.setData({
            ScoreGrade: t
        });
    },
    packGrade: function(a) {
        var r = a.currentTarget.dataset.grade;
        this.setData({
            packMark: r
        });
    },
    deliveryGrade: function(a) {
        var r = a.currentTarget.dataset.grade;
        this.setData({
            deliveryMark: r
        });
    },
    serviceGrade: function(a) {
        var r = a.currentTarget.dataset.grade;
        this.setData({
            serviceMark: r
        });
    },
    uploadImg: function(r) {
        var e = this, t = r.currentTarget.dataset.index, o = e.data.ScoreGrade, d = o[t], i = r.currentTarget.dataset.imgindex;
        wx.chooseImage({
            count: 1,
            success: function(r) {
                var t = r.tempFilePaths;
                wx.uploadFile({
                    url: a.getUrl("MyOrderRefund/PostUploadAppletImage"),
                    filePath: t[0],
                    name: "file",
                    formData: {
                        openId: a.globalData.openId
                    },
                    success: function(a) {
                        if ((a = JSON.parse(a.data)).success) {
                            var r = a.data.Data[0].ImageUrl;
                            void 0 != i ? d.Images[parseInt(i)] = r : d.Images.push(r), e.setData({
                                ScoreGrade: o
                            });
                        }
                    }
                });
            }
        });
    },
    delImg: function(a) {
        var r = a.currentTarget.dataset.index, e = a.currentTarget.dataset.imgindex;
        this.data.ScoreGrade[r].Images.splice(e, 1), this.setData({
            ScoreGrade: this.data.ScoreGrade
        });
    },
    formSubmit: function(e) {
        var t = this;
        if (t.data.isSubmit) return !1;
        e.detail.formId;
        var o = t.data.ScoreGrade, d = t.data.TxtareaName;
        if (d.length <= 0) return a.showErrorModal("文本框不存在"), !1;
        var i = !1;
        if (d.forEach(function(a, r, d) {
            t.ToTrim(e.detail.value[a]).length <= 0 ? i = !0 : o[r].content = t.ToTrim(e.detail.value[a]);
        }), i) return a.showErrorModal("请输入评价内容"), !1;
        t.setData({
            ScoreGrade: o,
            isSubmit: !0
        });
        var s = {
            orderId: t.data.OrderId,
            serviceMark: t.data.serviceMark,
            deliveryMark: t.data.deliveryMark,
            packMark: t.data.packMark,
            productComments: t.data.ScoreGrade
        };
        r.httpPost(a.getUrl("MyComment/PostAddComment"), {
            openId: a.globalData.openId,
            Jsonstr: JSON.stringify(s)
        }, function(r) {
            r.success ? a.showErrorModal("评论已提交", function(a) {
                a.confirm && wx.redirectTo({
                    url: "../orderlist/orderlist"
                });
            }) : a.showErrorModal("评论提交失败", function(a) {
                a.confirm && wx.navigateBack({
                    delta: 1
                });
            });
        });
    },
    ToTrim: function(a) {
        return a.replace(/(^\s*)|(\s*$)/g, "");
    }
});