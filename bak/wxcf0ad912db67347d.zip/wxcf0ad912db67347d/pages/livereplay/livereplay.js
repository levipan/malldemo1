function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, o = Array(t.length); a < t.length; a++) o[a] = t[a];
        return o;
    }
    return Array.from(t);
}

var a = getApp(), o = require("../../utils/config.js");

Page({
    data: {
        statusBarHeight: 20,
        roomId: 0,
        room: {},
        productList: [],
        pageNo: 0,
        loading: !1,
        isEnd: !1,
        videoUrl: "",
        videoIndex: 0,
        isPlay: !1,
        showProduct: !1
    },
    onLoad: function(t) {
        var e = this;
        wx.showLoading({
            title: "加载中"
        }), this.setData({
            roomId: t.roomId
        }), wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    statusBarHeight: t.statusBarHeight
                });
            }
        }), o.httpGet(a.getUrl("Live/GetLiveDetail"), {
            roomId: this.data.roomId
        }, function(t) {
            t.success && (e.setData({
                room: t.data,
                videoUrl: t.data.RecordingUrlList[0]
            }), e.data.videoUrl || (wx.hideLoading(), wx.showToast({
                title: "回放暂未生成，请稍候",
                icon: "none",
                duration: 6e4
            })), e.loadProduct());
        }), wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        });
    },
    loadProduct: function() {
        var e = this;
        this.data.loading || this.data.isEnd || (this.setData({
            loading: !0,
            pageNo: this.data.pageNo + 1
        }), o.httpGet(a.getUrl("Live/GetLiveProducts"), {
            roomId: this.data.roomId,
            pageNo: this.data.pageNo,
            pageSize: 10
        }, function(a) {
            a.success && (a.data.length < 10 && e.setData({
                isEnd: !0
            }), e.setData({
                productList: [].concat(t(e.data.productList), t(a.data)),
                loading: !1
            }));
        }));
    },
    scrolltolower: function() {
        this.loadProduct();
    },
    back: function() {
        getCurrentPages().length > 1 ? wx.navigateBack() : wx.redirectTo({
            url: "../livelist/livelist"
        });
    },
    videoPlay: function() {
        this.setData({
            isPlay: !0
        }), wx.hideLoading();
    },
    videoEnd: function() {
        this.data.videoIndex < this.data.room.RecordingUrlList.length - 1 && this.setData({
            videoIndex: this.data.videoIndex + 1,
            videoUrl: this.data.room.RecordingUrlList[this.data.videoIndex + 1]
        });
    },
    toggleProduct: function() {
        this.setData({
            showProduct: !this.data.showProduct
        });
    },
    switchVideo: function(t) {
        var a = parseInt(t.currentTarget.dataset.index);
        this.data.videoIndex !== a && (wx.showLoading({
            title: "切换中..."
        }), this.setData({
            isPlay: !1,
            videoUrl: t.currentTarget.dataset.url,
            videoIndex: a
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.room.Name + "——" + this.data.room.AnchorName,
            imageUrl: this.data.room.CoverImg,
            path: "pages/livedetail/livedetail?roomId=" + this.data.roomId
        };
    }
});