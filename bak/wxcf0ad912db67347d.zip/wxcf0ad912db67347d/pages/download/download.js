var e = getApp();

Page({
    data: {
        pageLoaded: !1
    },
    onLoad: function(a) {
        this.setData({
            PrimaryColor: e.globalData.PrimaryColor,
            fileName: (a.fileName || new Date().getTime()) + ".xls",
            url: decodeURIComponent(a.url)
        }), this.down();
    },
    down: function() {
        var e = this;
        wx.downloadFile({
            url: this.data.url,
            filePath: wx.env.USER_DATA_PATH + "/" + this.data.fileName,
            success: function(a) {
                200 === a.statusCode ? (e.setData({
                    pageLoaded: !0,
                    filePath: a.filePath
                }), e.open()) : wx.showToast({
                    title: "下载失败",
                    icon: "none"
                });
            }
        });
    },
    open: function() {
        wx.openDocument({
            filePath: this.data.filePath,
            showMenu: !0,
            success: function(e) {}
        });
    }
});