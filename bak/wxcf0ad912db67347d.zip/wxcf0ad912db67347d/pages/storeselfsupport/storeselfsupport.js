require("../../utils/config.js");

var s = getApp();

Page({
    data: {},
    onShareAppMessage: function() {
        var t = "pages/storeselfsupport/storeselfsupport?shopBranchId=" + this.storeselfsupport.data.shopBranchId;
        return s.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + s.globalData.userInfo.UserId), 
        {
            title: this.data.shareTitle.replace(/{shequ}/g, this.storeselfsupport.data.current.ShopBranchName),
            imageUrl: this.data.shareImage || this.storeselfsupport.data.current.ShopImages,
            path: t,
            success: function(s) {},
            fail: function(s) {}
        };
    },
    onLoad: function(t) {
        var e = this;
        s.shopBranchChange(t.shopBranchId, "formPage=storeSelfSupport") || (s.getShareConfig(function(s) {
            e.setData({
                shareTitle: s.shareTitle,
                shareImage: s.shareImage
            });
        }), this.storeselfsupport = this.selectComponent("#storeselfsupport"), this.storeselfsupport.onLoad());
    },
    onPullDownRefresh: function() {
        this.storeselfsupport && this.storeselfsupport.onPullDownRefresh && this.storeselfsupport.onPullDownRefresh();
    },
    onShow: function() {
        this.storeselfsupport && this.storeselfsupport.onShow();
    },
    onReachBottom: function() {
        this.storeselfsupport && this.storeselfsupport.onReachBottom && this.storeselfsupport.onReachBottom();
    }
});