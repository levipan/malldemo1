function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), e = getApp(), i = require("../../utils/busEvent");

Page({
    data: {
        list: [],
        pageNo: 1,
        pageSize: 10,
        isEnd: !1,
        isLoad: !1,
        chooseSkuHide: !0
    },
    onLoad: function() {
        var t = this;
        e.getSysSettingData(function(a) {
            t.setData(a);
        });
    },
    hideCode: function() {
        this.setData({
            codeHide: !0
        });
    },
    handleTap: function(t) {
        var s = this, r = t.currentTarget.dataset, d = r.id, o = r.type, u = r.orderid, n = r.status, c = r.productid, h = r.deliver;
        if ("back" === o) return i.emit("tabUserChange", {
            url: "../usercenter/usercenter"
        });
        1 === n && "btn" === o && a.httpGet(e.getUrl("CommunityStore/GetProductSkus"), {
            shopBranchId: wx.getStorageSync("shopBranchId"),
            productid: c,
            openId: e.globalData.openId
        }, function(t) {
            if (t.success) {
                if (!t.data.Stock) return e.showErrorModal("库存不足，请联系客服");
                if (1 === t.data.Skus.length) wx.navigateTo({
                    url: "/pages/ordersubmit/ordersubmit?isGiftOrder=true&skuid=" + t.data.Skus[0].SkuId + "&count=1&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&deliver=" + h + "&giftid=" + d
                }); else {
                    var a, i = {};
                    t.data.Skus.forEach(function(t) {
                        i[t.SkuId] = t, !a && t.Stock && (a = t);
                    }), t.data.Skus = i, s.setData({
                        chooseSkuHide: !1,
                        skuData: t.data,
                        skuArr: [ t.data.ProductId, 0, 0, 0 ],
                        curSkuData: "",
                        deliver: h,
                        giftid: d
                    }), 1 == s.data.skuData.SkuItems.length && s.setDisabledSku();
                }
            } else e.showErrorModal(t.msg);
        }), (3 === n || 2 === n || 6 === n && "item" === o) && wx.navigateTo({
            url: "/pages/orderdetails/orderdetails?orderid=" + u
        });
    },
    loadMyGift: function() {
        var i = this, s = this.data, r = s.pageNo, d = s.pageSize, o = s.list;
        a.httpGet(e.getUrl("Gifts/GetList"), {
            pageNo: r,
            pageSize: d,
            openId: e.globalData.openId
        }, function(a) {
            i.setData({
                list: 1 === r ? a.data.List : [].concat(t(o), t(a.data.List)),
                isEnd: a.data.List.length < d,
                isLoad: !0
            });
        });
    },
    onShow: function() {
        this.setData({
            pageNo: 1,
            isEnd: !1
        }), this.loadMyGift();
    },
    goProduct: function(t) {
        wx.navigateTo({
            url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.currentTarget.dataset.id
        });
    },
    setDisabledSku: function() {
        var a = this.data.skuData.SkuItems, e = this.data.skuData.Skus, i = (a.length, this.data.skuArr);
        a.forEach(function(a) {
            var s = a.AttributeIndex;
            a.AttributeValue.forEach(function(a) {
                var r = [].concat(t(i));
                r[s + 1] = a.ValueId, e[r.join("_")] && !e[r.join("_")].Stock ? a.disabled = !0 : a.disabled = !1;
            });
        }), this.setData({
            skuData: this.data.skuData
        });
    },
    swithSku: function(t) {
        var a = t.currentTarget.dataset.index, e = t.currentTarget.dataset.id, i = this.data.skuArr;
        i[a + 1] = parseInt(i[a + 1]) === e ? 0 : e, this.setData({
            skuArr: i,
            curSkuData: this.data.skuData.Skus[this.data.skuArr.join("_")] || null
        }), this.setDisabledSku();
    },
    confirmGift: function() {
        this.data.curSkuData.SkuId ? (this.hideChooseSku(), wx.navigateTo({
            url: "/pages/ordersubmit/ordersubmit?isGiftOrder=true&skuid=" + this.data.curSkuData.SkuId + "&count=1&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&deliver=" + this.data.deliver + "&giftid=" + this.data.giftid
        })) : wx.showToast({
            title: "请选择规格",
            icon: "none"
        });
    },
    hideChooseSku: function() {
        this.setData({
            chooseSkuHide: !0
        });
    },
    onReachBottom: function() {
        var t = this, a = this.data, e = a.isEnd, i = a.pageNo;
        e || this.setData({
            pageNo: i + 1
        }, function() {
            t.loadMyGift();
        });
    }
});