var e = getApp(), t = require("../wxParse/wxParse.js"), a = require("../../utils/config.js");

Page({
    data: {
        Agreement: "",
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(r) {
        var n = this;
        e.getSysSettingData(function(e) {
            n.setData(e);
        }, !1), e.getOpenId(function(r) {
            r && (wx.showLoading({
                title: "加载中"
            }), a.httpGet(e.getUrl("Distribution/GetRecruitmentAgreement"), {
                openId: r
            }, function(e) {
                wx.hideLoading();
                var a = e.data.RecruitmentAgreement;
                t.wxParse("Agreement", "html", a, n);
            }));
        });
    },
    goback: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            checked: !0
        }), wx.navigateBack();
    }
});