var t = require("../../utils/config.js"), i = require("../wxParse/wxParse.js"), e = require("../../utils/busEvent.js"), s = getApp();

Page({
    data: {
        checked: !1,
        introduction: null,
        openAgree: !0,
        distributorName: "",
        value: "",
        isReady: !1,
        userInfo: null,
        PrimaryColor: "",
        restart: !1,
        PrimaryTxtColor: "",
        init: !1
    },
    onLoad: function(t) {
        var i = this;
        this.data.restart = Boolean(t.restart) || !1;
        s.getSysSettingData(function(t) {
            i.setData(t);
        }, !1), s.getDistrbutionName(function(t) {
            t.DistributorName && (wx.setNavigationBarTitle({
                title: t.DistributorName + "招募简介"
            }), i.setData({
                distributorName: t.DistributorName
            }));
        });
    },
    onShow: function() {
        this.getIntroduction();
    },
    getStatus: function() {
        var i = this;
        if (!this.data.isDistribution) return wx.showModal({
            showCancel: !1,
            content: "活动尚未开启",
            confirmText: "好的",
            success: function() {
                e.emit("tabUserChange", {
                    url: "../index/index"
                });
            }
        });
        s.getOpenId(function(e) {
            e && t.httpGet(s.getUrl("MemberCenter/GetUser"), {
                openId: e
            }, function(t) {
                t.success && (i.setData({
                    userInfo: t.data
                }), !i.data.restart || t.data.IsDistributor ? i.getDistrbutionStatus() : i.setData({
                    isReady: !0
                }));
            });
        }, !0);
    },
    getIntroduction: function() {
        var e = this;
        this.data.init ? this.getStatus() : (wx.showLoading({
            title: "加载中"
        }), t.httpGet(s.getUrl("Distribution/GetDistributorIntroduction"), {
            openId: s.globalData.openId || ""
        }, function(t) {
            wx.hideLoading();
            var s = t.data.DistributorIntroduction;
            e.data.openAgree = t.data.OpenRecruitmentAgreement, e.data.isDistribution = t.data.IsDistribution, 
            e.data.init = !0, i.wxParse("introduction", "html", s, e), e.getStatus();
        }), s.globalData.openId || this.setData({
            isReady: !0
        }));
    },
    checkboxChange: function(t) {
        this.setData({
            checked: t.detail.value[0] || !1
        });
    },
    applyHandle: function() {
        var i = this;
        if (!this.data.checked && this.data.openAgree) return wx.showToast({
            title: "请阅读并同意招募协议",
            icon: "none"
        });
        s.getOpenId(function(e) {
            e && t.httpPost(s.getUrl("Distribution/RequetDistributor"), {
                openId: e
            }, function(t) {
                if (t.success) return wx.navigateTo({
                    url: "../distributioninfoset/distributioninfoset"
                });
                if (2 === t.code) return wx.showModal({
                    title: "提示",
                    content: "需要累计消费金额达到" + t.msg + "元才可申请哦",
                    showCancel: !1,
                    confirmColor: "#ff221a"
                });
                if (3 === t.code) return wx.showModal({
                    title: "提示",
                    content: "需要购买指定商品后才可申请哦",
                    confirmText: "现在购买",
                    success: function(i) {
                        i.confirm && (t.msg.indexOf(",") > -1 ? wx.redirectTo({
                            url: "../productList/productList?ids=" + t.msg
                        }) : wx.redirectTo({
                            url: "../productdetail/productdetail?storeid=0&id=" + t.msg
                        }));
                    }
                });
                if (4 === t.code) {
                    var e = s.subtract(t.msg, i.data.userInfo.Balance), n = "需要充值到" + t.msg + "元才可申请哦,还需要充值" + e + "元";
                    return wx.showModal({
                        title: "提示",
                        content: n,
                        confirmText: "去充值",
                        success: function(t) {
                            t.confirm && wx.redirectTo({
                                url: "../userasset/userasset"
                            });
                        }
                    });
                }
                wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        });
    },
    _isDistributor: function() {
        this.data.userInfo.IsDistributor;
    },
    getDistrbutionStatus: function() {
        var i = this;
        s.getOpenId(function(e) {
            e && t.httpGet(s.getUrl("Distribution/GetDistributorStatus"), {
                openId: e
            }, function(t) {
                if (t.success) {
                    if (i.data.userInfo.IsRepeled) return wx.showModal({
                        content: "您已被商城取消分销员资格，请联系管理员",
                        showCancel: !1
                    });
                    i.data.userInfo.IsDistributor ? wx.redirectTo({
                        url: "../distributionstore/distributionstore"
                    }) : 1 !== t.data.status && wx.redirectTo({
                        url: "../distributionauditing/distributionauditing"
                    });
                } else i.setData({
                    isReady: !0
                });
            });
        }, !0);
    }
});