function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = getApp(), e = require("../../utils/config.js");

Page({
    data: {
        list: [],
        pageLoading: !0,
        noMore: !1,
        loading: !1,
        status: 1
    },
    staticData: {
        loading: !1,
        pageNumber: 0
    },
    onLoad: function(t) {
        var e = this;
        a.getOpenIdToUserKeyDriver(function(t) {
            t.success && (e.getInitConfig(), e.getList());
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.noMore || this.getList();
    },
    getInitConfig: function() {
        var t = this;
        a.getSettingData(function() {
            var e = Object.assign({}, a.globalData.colorsConfig);
            t.setData(e);
        });
    },
    getList: function() {
        var i = this;
        this.data.loading || (this.setData({
            loading: !0
        }), this.staticData.pageNumber += 1, 1 === this.staticData.pageNumber && wx.showLoading(), 
        a.getOpenId(function(n) {
            n && e.httpGet(a.getAdminUrl("Delivery/GetShopBranchList"), {
                status: i.data.status,
                pageNo: i.staticData.pageNumber,
                pageSize: 10
            }, function(a) {
                if (wx.hideLoading(), i.setData({
                    loading: !1
                }), !a.success) return wx.showToast({
                    title: a.msg,
                    duration: 3e3,
                    icon: "none"
                });
                var e = a.data.ShopBranchList;
                i.staticData.pageNumber > 1 && (e = [].concat(t(i.data.list), t(e)));
                var n = !1;
                a.data.ShopBranchList.length < 10 && (n = !0), i.setData({
                    pageLoading: !1,
                    noMore: n,
                    list: e
                });
            });
        }));
    },
    handleCall: function(t) {
        var a = t.currentTarget.dataset.item;
        a.Phone && wx.makePhoneCall({
            phoneNumber: a.Phone
        });
    },
    handleNav: function(t) {
        var a = t.currentTarget.dataset.item;
        a && wx.openLocation({
            latitude: a.Latitude,
            longitude: a.Longitude
        });
    },
    handleOpen: function(t) {
        var a = t.currentTarget.dataset.item;
        a && wx.navigateTo({
            url: "../driverdeliver/driverdeliver?id=" + a.Id + "&status=" + this.data.status
        });
    },
    handleStatus: function(t) {
        var a = parseInt(t.currentTarget.dataset.status);
        a !== this.data.status && (this.staticData.pageNumber = 0, this.setData({
            noMore: !1,
            status: a
        }), this.setInit(), this.getList());
    },
    setInit: function() {
        this.staticData.pageNumber = 0;
    },
    handleLocation: function() {
        wx.navigateTo({
            url: "../driverposition/driverposition"
        });
    }
});