var t = require("../../utils/qqmap-wx-jssdk.1.2.min.js"), i = null, e = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        status: 1
    },
    onLoad: function(t) {},
    onShow: function() {
        var e = this;
        a.getSysSettingData(function() {
            i = new t({
                key: a.globalData.QQMapKey
            }), e.setData({
                subkey: a.globalData.QQMapKey
            }), e.getPosition();
        });
    },
    getList: function(t) {
        var i = this;
        wx.showLoading(), a.getOpenId(function(n) {
            n && e.httpGet(a.getAdminUrl("Delivery/GetShopBranchLocation"), {
                openId: n
            }, function(e) {
                if (wx.hideLoading(), !e.success) return wx.showToast({
                    title: e.msg,
                    duration: 3e3,
                    icon: "none"
                });
                i.setData({
                    list: e.data.ShopBranchList
                });
                var a = [], n = [];
                e.data.ShopBranchList.map(function(t) {
                    var i = "../../images/position_store_disibale.png";
                    t.HasUnSignedBatch && (i = "../../images/position_store_default.png", n.push({
                        id: t.Id,
                        latitude: t.Latitude,
                        longitude: t.Longitude,
                        iconPath: i,
                        width: 50,
                        height: 50,
                        hasUnSignedBatch: t.HasUnSignedBatch,
                        callout: {
                            content: t.Name,
                            display: "ALWAYS",
                            padding: 5,
                            bgColor: "#ffffff",
                            fontSize: 14
                        }
                    })), a.push({
                        id: t.Id,
                        latitude: t.Latitude,
                        longitude: t.Longitude,
                        iconPath: i,
                        width: 50,
                        height: 50,
                        hasUnSignedBatch: t.HasUnSignedBatch,
                        callout: {
                            content: t.Name,
                            display: "ALWAYS",
                            padding: 5,
                            bgColor: "#ffffff",
                            fontSize: 14
                        }
                    });
                }), i.setMap({
                    longitude: t.longitude,
                    latitude: t.latitude,
                    currentLongitude: t.longitude,
                    currentLatitude: t.latitude,
                    AllMarkers: a,
                    noSendMarkers: n,
                    markers: n
                });
            });
        });
    },
    getPosition: function() {
        var t = this;
        wx.getSetting({
            complete: function(t) {
                t.authSetting["scope.userLocation"] || wx.showModal({
                    title: "提示",
                    content: "获取地址授权失败，请重新开启授权！",
                    confirmText: "确认",
                    confirmColor: "#FB1438",
                    success: function(t) {
                        t.confirm && wx.openSetting();
                    }
                });
            }
        }), wx.getLocation({
            type: "gcj02",
            isHighAccuracy: !0,
            success: function(i) {
                t.getList(i);
            }
        });
    },
    setMap: function(t) {
        t.circles = [ {
            latitude: t.latitude,
            longitude: t.longitude,
            fillColor: "#FB143814",
            strokeWidth: 0,
            color: "#FB143814",
            radius: 160
        } ], t.showMap = !0, this.setData(t);
    },
    bindmarkertap: function(t) {
        var i = this, e = t.markerId, a = this.data.markers, n = null;
        a.map(function(t) {
            t.id === e ? (n = t, t.iconPath = "../../images/position_store_active.png") : t.iconPath = t.hasUnSignedBatch ? "../../images/position_store_default.png" : "../../images/position_store_disibale.png";
        }), this.setData({
            markers: a
        }), wx.showActionSheet({
            itemList: [ "路线", "导航" ],
            success: function(t) {
                0 === t.tapIndex ? i.polyline(e) : wx.openLocation({
                    latitude: n.latitude,
                    longitude: n.longitude
                });
            }
        });
    },
    polyline: function(t) {
        var e = this, a = null;
        this.data.markers.map(function(i) {
            i.id === t && (a = i);
        }), i.direction({
            mode: "driving",
            from: {
                latitude: this.data.currentLatitude,
                longitude: this.data.currentLongitude
            },
            to: {
                latitude: a.latitude,
                longitude: a.longitude
            },
            success: function(t) {
                for (var i = t.result.routes[0].polyline, n = [], o = 2; o < i.length; o++) i[o] = Number(i[o - 2]) + Number(i[o]) / 1e6;
                for (o = 0; o < i.length; o += 2) n.push({
                    latitude: i[o],
                    longitude: i[o + 1]
                });
                e.setData({
                    latitude: a.latitude,
                    longitude: a.longitude,
                    polyline: [ {
                        points: n,
                        color: "#07c160",
                        width: 4
                    } ]
                });
            }
        });
    },
    handleStatus: function(t) {
        var i = parseInt(t.currentTarget.dataset.status);
        if (this.data.status !== i) {
            var e = null;
            e = 0 === i ? this.data.AllMarkers : this.data.noSendMarkers, this.setData({
                status: i,
                markers: e
            });
        }
    },
    currentPostion: function() {
        this.setData({
            latitude: this.data.currentLatitude,
            longitude: this.data.currentLongitude
        });
    }
});