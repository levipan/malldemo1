var t = require("../../utils/config.js"), e = getApp();

Page({
    data: {
        pageInit: !0,
        list: [],
        type: 1,
        form: {
            pageNo: 1,
            pageSize: 10
        }
    },
    onLoad: function(t) {
        var a = this;
        t.type && (this.setData({
            type: parseInt(t.type)
        }), 2 === parseInt(t.type) && wx.setNavigationBarTitle({
            title: "选择地址"
        })), e.getSysSettingData(function(t) {
            a.setData(t);
        });
    },
    onReady: function() {},
    onShow: function() {
        this.loadData();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    loadData: function() {
        var a = this;
        wx.showLoading(), t.httpGet(e.getUrl("Address/GetAddressList"), {
            openId: e.globalData.openId
        }, function(t) {
            wx.hideLoading();
            var e = t.data;
            if (!e.success) return wx.showToast({
                title: e.msg || "获取失败！"
            });
            a.setData({
                pageInit: !0,
                list: e.data
            });
        });
    },
    hanldeChoice: function(t) {
        var a = t.currentTarget.dataset.item;
        2 === this.data.type && (e.setCacheAddressAction({
            name: a.ShipTo,
            addressId: a.Id,
            phone: a.CellPhone,
            address: a.Address,
            addressDetail: a.AddressDetail
        }), wx.navigateBack({
            delta: 1
        }));
    },
    addAddress: function() {
        wx.navigateTo({
            url: "../addressdetail/addressdetail?type=" + this.data.type
        });
    },
    updateAddress: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../addressdetail/addressdetail?id=" + e + "&type=" + this.data.type
        });
    },
    getChooseAddress: function() {
        var a = this;
        this.needLoad = !1, wx.getSetting({
            success: function(t) {
                void 0 == t.authSetting["scope.address"] || t.authSetting["scope.address"] || wx.showModal({
                    content: "授权失败，请手动授权",
                    showCancel: !1
                });
            }
        }), wx.chooseAddress({
            success: function(s) {
                "chooseAddress:ok" === s.errMsg && t.httpPost(e.getUrl("Address/Save"), {
                    openId: e.globalData.openId,
                    ShipTo: s.userName,
                    CellPhone: s.telNumber,
                    Address: s.provinceName + " " + s.cityName + " " + s.countyName,
                    AddressDetail: s.detailInfo,
                    IsDefault: !1
                }, function(t) {
                    if (!t.success) return wx.showToast({
                        title: t.msg || "添加失败"
                    });
                    a.loadData();
                });
            }
        });
    }
});