var t = getApp(), e = require("../../utils/busEvent");

Page({
    data: {
        showBindPhone: !1
    },
    onLoad: function(e) {
        var a = this;
        wx.showLoading({
            title: "加载中"
        });
        var n = t.getRequestUrl + "Areas/Admin/Templates/Topic/" + e.id + "/data/default.json?r=" + new Date().getTime();
        0 != e.franchiseeId && (n = t.getRequestUrl + "Areas/fAdmin/Templates/Topic/franchisee" + e.franchiseeId + "/" + e.id + "/data/default.json?r=" + new Date().getTime()), 
        wx.request({
            url: n,
            dataType: "json",
            success: function(t) {
                t.data.title && wx.setNavigationBarTitle({
                    title: t.data.title
                }), a.setData({
                    moduleData: t.data.LModules,
                    pageLoaded: !0
                }), wx.hideLoading();
            }
        });
    },
    onShareAppMessage: function() {},
    onReady: function() {
        var t = this;
        this.storeCart = this.selectComponent("#storeCart"), e.off("triggerBindphone"), 
        e.on("triggerBindphone", function() {
            t.setData({
                showBindPhone: !0
            });
        });
    },
    onUpdatephone: function() {
        this.setData({
            showBindPhone: !1
        });
    },
    onJoinCart: function(t) {
        t.detail.currentTarget.dataset.hassku ? this.chooseSku(t.detail) : this.productNumChange(t.detail);
    },
    productNumChange: function(t) {
        var e = t.currentTarget.dataset.id, a = t.currentTarget.dataset.type ? 1 : -1, n = t.currentTarget.dataset.delivery;
        this.setData({
            skuProductid: e
        }), this.storeCart.changeCart(e + "_0_0_0", a, function(t) {
            t.success && wx.showToast({
                title: "加入购物车成功",
                icon: "none"
            });
        }, null, n);
    },
    chooseSku: function(e) {
        var a = this;
        t.getOpenId(function(t) {
            if (t) {
                a.setData({
                    skuProductid: e.currentTarget.dataset.id
                });
                var n = e.currentTarget.dataset.delivery;
                a.storeCart.chooseSku(n);
            }
        });
    }
});