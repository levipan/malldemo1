function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

function e(t) {
    function a(t) {
        for (var e = 32; e--; ) t.push("0");
    }
    function o(t, a) {
        switch (a) {
          case "N":
            return t.toString().replace(/,/g, "");

          case "D":
            return r = (r = t.slice(0, 8) + "-" + t.slice(8, 12) + "-" + t.slice(12, 16) + "-" + t.slice(16, 20) + "-" + t.slice(20, 32)).replace(/,/g, "");

          case "B":
            return r = "{" + (r = o(t, "D")) + "}";

          case "P":
            var r = o(t, "D");
            return r = "(" + r + ")";

          default:
            return new e();
        }
    }
    var r = new Array();
    "string" == typeof t ? function(t, e) {
        if (e = e.replace(/\{|\(|\)|\}|-/g, ""), 32 != (e = e.toLowerCase()).length || -1 != e.search(/[^0-9,a-f]/i)) a(t); else for (var o = 0; o < e.length; o++) t.push(e[o]);
    }(r, t) : a(r), this.Equals = function(t) {
        return !(!t || !t.IsGuid) && this.ToString() == t.ToString();
    }, this.IsGuid = function() {}, this.ToString = function(t) {
        return "string" == typeof t && ("N" == t || "D" == t || "B" == t || "P" == t) ? o(r, t) : o(r, "D");
    };
}

var a, o = require("../../utils/config.js"), r = getApp();

Page((a = {
    data: {
        pageLoaded: !1,
        curQuantity: 0,
        gotopVal: !0,
        showDetailBuy: 0,
        actionsheetShow: !1,
        showPoster: !1,
        backShow: "none"
    },
    onReady: function() {},
    onLoad: function(t) {
        var e = this;
        t.referralUserId && r.setRefferUserId(t.referralUserId);
        var a = t.id, o = wx.getStorageSync("shopBranchId"), i = t.shopBranchId;
        this.setData({
            productId: a,
            shopBranchId: i
        }), o || wx.setStorageSync("shopBranchId", t.shopBranchId), r.getSysSettingData(function(t) {
            t.IsShowHishopCopyRight = r.globalData.IsShowHishopCopyRight, t.ProductSaleCountOnOff = r.globalData.ProductSaleCountOnOff, 
            t.IsJumpLink = r.globalData.IsJumpLink, e.setData(t);
        }), o && this.data.shopBranchId && o != this.data.shopBranchId ? wx.redirectTo({
            url: "../storeswitch/storeswitch?formPage=storeProductdetail&currentBranchId=" + o + "&newBranchId=" + this.data.shopBranchId + "&productId=" + this.data.productId
        }) : (this.bottomCart = this.selectComponent("#bottomCart"), this.getVisitCount(), 
        this.getProductDetail());
    },
    getVisitCount: function() {},
    onShareAppMessage: function() {
        var t = "pages/storeProductdetail/storeProductdetail?id=" + this.data.productId + "&shopBranchId=" + this.data.shopBranchId;
        return r.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + r.globalData.userInfo.UserId), 
        {
            title: this.data.shareTitle,
            path: t,
            imageUrl: this.data.detailInfo.Image
        };
    }
}, t(a, "onReady", function() {
    var t = this;
    wx.createSelectorQuery().select(".product-detail").boundingClientRect(function(e) {
        if (e.top < wx.getSystemInfoSync().windowHeight) {
            var a = wx.getSystemInfoSync().windowHeight - e.top;
            t.setData({
                productMinHeight: a + "px"
            });
        }
    }).exec();
}), t(a, "goToCopyright", function() {
    wx.navigateTo({
        url: "../outurl/outurl?url=" + r.getRequestUrl + "hishop/index.html"
    });
}), t(a, "getProductDetail", function() {
    var t = this;
    wx.showLoading({
        title: "加载中"
    }), wx.showNavigationBarLoading(), o.httpGet(r.getUrl("CommunitySelfProduct/GetProductDetail"), {
        productId: this.data.productId,
        shopBranchId: this.data.shopBranchId
    }, function(e) {
        e.success ? (t.setData({
            detailInfo: e.data,
            pageLoaded: !0
        }), wx.setNavigationBarTitle({
            title: e.data.ProductName
        }), r.getShareConfig(function(e) {
            var a = e.productShareTitle.replace(/{shequ}/g, t.data.detailInfo.ShopBranchName);
            a = (a = a.replace(/{productname}/g, t.data.detailInfo.ProductName)).replace(/{price}/g, t.data.detailInfo.SalePrice), 
            t.setData({
                shareTitle: a
            });
        }), t.bottomCart.getCartData()) : r.showErrorModal(e.msg, function(t) {
            t.confirm && wx.navigateBack({
                delta: 1
            });
        }), wx.hideLoading(), wx.hideNavigationBarLoading();
    });
}), t(a, "showVideo", function() {
    this.setData({
        showVideo: !0
    });
}), t(a, "closeVideo", function() {
    this.setData({
        showVideo: !1
    });
}), t(a, "changeDetailBuy", function(t) {
    var e = parseInt(t.currentTarget.dataset.type);
    !this.data.BuyRecords && e && this.getBuyRecords(), this.setData({
        showDetailBuy: e
    });
}), t(a, "getBuyRecords", function() {
    var t = this;
    o.httpGet(r.getUrl("CommunitySelfProduct/GetBuyRecords"), {
        productId: this.data.productId
    }, function(e) {
        e.success && (e.data.forEach(function(t) {
            var e = t.Nick, a = [], o = !0, r = !1, i = void 0;
            try {
                for (var n, s = e[Symbol.iterator](); !(o = (n = s.next()).done); o = !0) {
                    var c = n.value;
                    a.push(c);
                }
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                r = !0, i = t;
            } finally {
                try {
                    !o && s.return && s.return();
                } finally {
                    if (r) throw i;
                }
            }
            2 === a.length ? e = a[0] + "*" : e.length > 2 && (e = a[0] + "***" + a[a.length - 1]), 
            t.Nick = e;
        }), t.setData({
            BuyRecords: e.data
        }));
    });
}), t(a, "goTop", function(t) {
    wx.pageScrollTo({
        scrollTop: 0,
        duration: 300
    });
}), t(a, "onPageScroll", function(t) {
    this.setData({
        gotopVal: t.scrollTop < 500
    });
}), t(a, "updateproduct", function() {
    r.globalData.selfCartData[this.data.productId] ? this.setData({
        curQuantity: r.globalData.selfCartData[this.data.productId]
    }) : this.setData({
        curQuantity: 0
    });
}), t(a, "productNumChange", function(t) {
    this.bottomCart.numChange(t, function(t) {
        if (!t.success) return wx.showToast({
            title: t.msg,
            icon: "none"
        });
        wx.showToast({
            title: "加入购物车成功",
            icon: "none"
        });
    });
}), t(a, "actionsheetToggle", function() {
    this.setData({
        actionsheetShow: !this.data.actionsheetShow,
        backShow: this.data.backShow ? "" : "none"
    });
}), t(a, "showSharePoster", function() {
    this.setData({
        backShow: "none",
        actionsheetShow: !1
    }), this.data.hasPoster ? wx.previewImage({
        current: 0,
        urls: [ this.data.posterImagePath ]
    }) : (wx.showLoading({
        title: "生成中"
    }), this.getProductCodeimg());
}), t(a, "getProductCodeimg", function() {
    var t = this;
    wx.request({
        url: r.getUrl("CommunityStore/GetSelfProductDetailAppletCode"),
        data: {
            pid: this.data.productId,
            uid: r.globalData.userInfo.IsDistributor ? r.globalData.userInfo.UserId : 0,
            shopBranchId: this.data.shopBranchId
        },
        success: function(e) {
            e.data.success && (t.setData({
                productCodeimg: r.getUrl(e.data.data.url).replace(/mobileshopapi/, "")
            }), wx.hideLoading());
        },
        complete: function() {
            t.posterCanvas();
        }
    });
}), t(a, "posterCanvas", function() {
    var t = 28 * this.data.detailInfo.ShopBranchName.length, e = 28 * (this.data.detailInfo.SalePrice + "").length + 64;
    this.setData({
        showPoster: !0,
        posterData: {
            background: "#fff",
            width: "640rpx",
            height: "1000rpx",
            views: [ {
                type: "image",
                url: this.data.detailInfo.Image,
                css: {
                    top: "0rpx",
                    left: "0rpx",
                    width: "640rpx",
                    height: "640rpx"
                }
            }, {
                type: "text",
                text: this.data.detailInfo.ProductName,
                css: {
                    top: "672rpx",
                    width: "416rpx",
                    fontSize: "32rpx",
                    lineHeight: "48rpx",
                    color: "#212121",
                    maxLines: "1",
                    left: "24rpx"
                }
            }, {
                type: "text",
                text: this.data.detailInfo.ShortDescription,
                css: {
                    top: "720rpx",
                    width: "416rpx",
                    fontSize: "28rpx",
                    lineHeight: "40rpx",
                    color: "#BDBDBD",
                    maxLines: "1",
                    left: "24rpx"
                }
            }, {
                type: "text",
                text: "￥",
                css: {
                    top: "789rpx",
                    left: "24rpx",
                    color: "#FB1438",
                    lineHeight: "40rpx",
                    fontSize: "28rpx"
                }
            }, {
                type: "text",
                text: this.data.detailInfo.SalePrice + "",
                css: {
                    top: "772rpx",
                    left: "52rpx",
                    color: "#FB1438",
                    fontWeight: "bold",
                    fontSize: "48rpx"
                }
            }, {
                type: "rect",
                css: {
                    color: "#FB1438",
                    width: "76rpx",
                    height: "32rpx",
                    borderRadius: "16rpx",
                    top: "788rpx",
                    left: e + "rpx"
                }
            }, {
                type: "text",
                text: "抢购价",
                css: {
                    color: "#fff",
                    lineHeight: "32rpx",
                    fontSize: "20rpx",
                    top: "790rpx",
                    left: e + 8 + "rpx"
                }
            }, {
                type: "image",
                url: this.data.productCodeimg,
                css: {
                    top: "672rpx",
                    right: "24rpx",
                    width: "160rpx",
                    height: "160rpx"
                }
            }, {
                type: "rect",
                css: {
                    color: "#eee",
                    width: "592rpx",
                    height: "1rpx",
                    top: "864rpx",
                    left: "24rpx"
                }
            }, {
                type: "text",
                text: this.data.detailInfo.ShopBranchName,
                css: {
                    top: "888rpx",
                    left: "344rpx",
                    width: "592rpx",
                    lineHeight: "40rpx",
                    color: "#212121",
                    maxLines: "1",
                    fontSize: "28rpx",
                    align: "center"
                }
            }, {
                type: "text",
                text: "长按识别小程序码",
                css: {
                    top: "938rpx",
                    left: "318rpx",
                    width: "592rpx",
                    lineHeight: "40rpx",
                    color: "#bdbdbd",
                    maxLines: "1",
                    fontSize: "28rpx",
                    align: "center"
                }
            }, {
                type: "image",
                url: "../../images/icon-store.png",
                css: {
                    top: "886rpx",
                    left: 320 - t / 2 - 22 + "rpx",
                    width: "40rpx",
                    height: "40rpx"
                }
            } ]
        }
    });
}), t(a, "onImgOK", function(t) {
    this.setData({
        posterImagePath: t.detail.path,
        hasPoster: !0
    }), wx.previewImage({
        current: 0,
        urls: [ t.detail.path ]
    });
}), t(a, "onProviewImg", function(t) {
    wx.previewImage({
        current: t.currentTarget.dataset.path,
        urls: this.data.detailInfo.DescriptionImage
    });
}), t(a, "onProviewSwiper", function() {
    wx.previewImage({
        urls: [ this.data.detailInfo.Image ]
    });
}), a)), e.Empty = new e(), e.NewGuid = function() {
    for (var t = "", a = 32; a--; ) t += Math.floor(16 * Math.random()).toString(16);
    return new e(t);
};