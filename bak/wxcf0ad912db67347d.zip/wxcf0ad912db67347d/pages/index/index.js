require("../../utils/config.js");

var a = getApp(), t = require("../../utils/busEvent");

Page({
    data: {
        showTab: !1,
        selected: 0,
        color: "#000",
        selectdName: "index",
        tabComponent: {},
        tabList: [],
        tableLoad: {},
        hasCartNav: null,
        currentIndex: 0,
        oldIndex: 0,
        tabTitle: "",
        customHeadColor: {
            usercenter: 1,
            services: 1,
            storeselfsupport: 1,
            stores: 1
        },
        noScrolls: {
            categories: 1
        },
        currentComponent: null,
        hasCustHead: !1,
        backgroundColor: "#ffffff",
        frontColor: "#000000",
        viewHeight: "auto"
    },
    onLoad: function(t) {
        var e = this;
        if (a.globalData.indexInit = !0, this._getNavs(), t.referralUserId && a.setRefferUserId(t.referralUserId), 
        a.globalData.switchTabData && (t = Object.assign(t, a.globalData.switchTabData), 
        a.globalData.switchTabData = null), t.id || a.globalData.newStoreId) {
            var n = t.id || a.globalData.newStoreId, o = wx.getStorageSync("shopBranchId");
            o && o != n && (this.setData({
                shouldSwitch: !0
            }), wx.redirectTo({
                url: "../storeswitch/storeswitch?formPage=storehome&currentBranchId=" + o + "&newBranchId=" + n
            })), o || wx.setStorageSync("shopBranchId", n);
        }
        isNaN(t.tabIndex) || this.setData({
            currentIndex: parseInt(t.tabIndex),
            oldIndex: parseInt(t.tabIndex)
        }), isNaN(a.globalData.tabIndex) || (this.setData({
            currentIndex: parseInt(a.globalData.tabIndex),
            oldIndex: parseInt(a.globalData.tabIndex)
        }), a.globalData.tabIndex = void 0), a.getSysSettingData(function(t) {
            t.tabTitle = a.globalData.SiteName, e.setData(t);
        }, !1), a.getOpenId(function() {}, !0), wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }), a.getSystemInfo(function(a) {
            e.data.windowH = a.windowHeight;
        });
    },
    onReady: function() {
        var e = this;
        this.createSelectorQuery().select("#tabbar").boundingClientRect(function(t) {
            t && (a.globalData.customTabBarHeight = t.height);
        }).exec(), a.globalData.indexBusEventInit || (a.globalData.indexBusEventInit = !0, 
        t.on("setTabBarBadge", function() {
            e._setCartMark();
        }), t.on("tabUserChange", function(a) {
            e.handleTabUserChange(a.url, a.reload);
        }));
    },
    onShow: function() {
        if (wx.getStorageSync("shopBranchId")) {
            if (this.data.currentComponent) if ("choice" === this.data.currentComponent.id) {
                var a = 0;
                this.data.tabList.some(function(t, e) {
                    if ("choice" != t.name) return a = e, !0;
                }), this.setTab(a);
            } else if (this.data.currentComponent.onShow) {
                var t = {};
                this.data.currentComponent.onShow(t);
            }
            this._setHeaderColor();
        } else wx.navigateTo({
            url: "/pages/position/position"
        });
    },
    onHide: function() {
        this.data.currentComponent && this.data.currentComponent.onHide && this.data.currentComponent.onHide();
    },
    onPullDownRefresh: function() {
        this.data.currentComponent && (this._getNavs(!0), this.data.currentComponent.onPullDownRefresh ? this.data.currentComponent.onPullDownRefresh() : setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1500));
    },
    onReachBottom: function() {
        this.data.currentComponent.onReachBottom && this.data.currentComponent.onReachBottom();
    },
    onShareAppMessage: function() {
        var t = {};
        this.data.currentComponent.onShareAppMessage ? t = this.data.currentComponent.onShareAppMessage() : (t.title = a.globalData.initConfig.share.shareTitle.replace(/{shequ}/g, a.globalData.initConfig.store.ShopBranchName), 
        t.imageUrl = a.globalData.initConfig.share.shareImage || a.globalData.initConfig.store.ShopImages, 
        t.path = "/pages/index/index?id=" + wx.getStorageSync("shopBranchId"));
        var e = this.data.currentComponent.tabName;
        return a.globalData.navData[e] && (-1 != t.path.indexOf("?") ? t.path += "&tabIndex=" + (a.globalData.navData[e] - 1) : t.path += "?tabIndex=" + (a.globalData.navData[e] - 1)), 
        a.globalData.userInfo.IsDistributor && (t.path += "&referralUserId=" + a.globalData.userInfo.UserId), 
        t;
    },
    onShareTimeline: function() {
        var t = {};
        this.data.currentComponent.onShareTimeline ? t = this.data.currentComponent.onShareTimeline() : t.query = "id=" + wx.getStorageSync("shopBranchId");
        var e = this.data.currentComponent.tabName;
        return a.globalData.navData[e] && (t.query ? t.query += "&tabIndex=" + (a.globalData.navData[e] - 1) : t.query = "tabIndex=" + (a.globalData.navData[e] - 1)), 
        t;
    },
    onPageScroll: function(a) {
        this.data.currentComponent && this.data.currentComponent.onPageScroll && this.data.currentComponent.onPageScroll(a);
    },
    _setCartMark: function() {
        if (null != this.data.hasCartNav) {
            var t = this.data.tabList.slice();
            t[this.data.hasCartNav].mark = a.globalData.cartData.total > 0 ? a.globalData.cartData.total : "", 
            this.setData({
                tabList: t
            });
        }
    },
    _getNavs: function(t) {
        var e = this;
        a._getNavs(function() {
            a.globalData.navList.length > 0 && e.setData({
                showTab: !0,
                tableLoad: a.globalData.navData,
                hasCartNav: a.globalData.hasCartNav,
                tabList: a.globalData.navList
            }, function() {
                t && (e.data.hasTabComponent = !1), e.getTabComponent(), e.data.currentIndex > a.globalData.navList.length - 1 && (e.data.currentIndex = 0), 
                e.setTab(e.data.currentIndex, !0);
            });
        }, t || !1);
    },
    handleTabChange: function(a) {
        var t = a.currentTarget.dataset;
        this.setTab(t.index);
    },
    handleTabUserChange: function(a, t) {
        var e = a.split("?"), n = e[0].split("/"), o = n[n.length - 1];
        this.data.tableLoad[o] && (wx.switchTab({
            url: "/pages/index/index"
        }), this.setTab(this.data.tableLoad[o] - 1, t, e[1]));
    },
    getTabComponent: function() {
        if (!this.data.hasTabComponent) {
            this.data.hasTabComponent = !0;
            var a = {};
            for (var t in this.data.tableLoad) a[t] = this.selectComponent("#" + t), a[t].tabName = t;
            this.setData({
                tabComponent: a
            });
        }
    },
    setTab: function(a, t, e) {
        var n = this.data.currentIndex, o = a, r = this.data.tabList[a].name;
        this.setData({
            oldIndex: n,
            selectdName: r,
            currentIndex: o
        }), wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        });
        var s = {
            isReload: t
        };
        (e || this.data.tabList[o].query) && e.split("&").map(function(a) {
            var t = a.split("=");
            s[t[0]] = t[1];
        });
        var i = this.data.tabList[n].name;
        this.data.tabComponent[i] && this.data.tabComponent[i].onHide && i != r && this.data.tabComponent[i].onHide(), 
        this.data.tabComponent[r].onLoad(s), this.data.currentComponent = this.data.tabComponent[r], 
        this.data.currentComponent && "index" !== this.data.currentComponent.tabName ? wx.hideShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }) : wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        }), this._setHeaderColor();
    },
    onUnload: function() {
        a.globalData.indexInit = !1, a.globalData.indexBusEventInit = !1;
    },
    setcustomhead: function(a) {
        this.setData({
            hasCustHead: a.detail.isCustomhead || !1
        }), this._setHeaderColor();
    },
    _setHeaderColor: function() {
        if (!this.data.hasCustHead && this.data.currentComponent && "index" === this.data.currentComponent.tabName) {
            return this.setData({
                frontColor: "#000000",
                backgroundColor: "#ffffff"
            }), void wx.setNavigationBarColor({
                backgroundColor: "#ffffff",
                frontColor: "#000000"
            });
        }
        var a = this.data.currentComponent ? this.data.currentComponent.tabName : "", t = "index" === a ? "#ffffff" : this.data.customHeadColor[a] ? "#ffffff" : "#000000", e = "index" === a ? "#ffffff" : this.data.customHeadColor[a] ? this.data.PrimaryColor : "#ffffff";
        this.setData({
            frontColor: t,
            backgroundColor: e
        }), wx.setNavigationBarColor({
            backgroundColor: e,
            frontColor: t
        });
    }
});