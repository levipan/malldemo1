var t = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        pageInit: !1,
        tempdata: {},
        drawIndex: -1,
        drawtype: -1,
        drawTypeList: [],
        drawMoney: "",
        password: "",
        active: "0",
        historyList: [],
        pageNo: 0,
        pageSize: 10,
        isNext: !0,
        noList: !1,
        disabled: !1,
        showPopup: !1,
        hasSetPayPwd: !1,
        passwordHide: !0,
        pwd: "",
        againPwd: "",
        remark: "",
        drawInfo: {
            MinLimit: 1,
            MaxLimit: 0
        },
        showDistpicker: !1,
        procitydata: [],
        procitydataValue: [ 0, 0 ],
        provinceSelIndex: 0,
        citySelIndex: 0,
        banks: [],
        bankName: "",
        bankIndex: -1,
        bankAddressId: "",
        bankAddress: "",
        bankUserName: "",
        bankCardNumber: "",
        IdCard: ""
    },
    onLoad: function(t) {
        var e = this;
        a.getDistrbutionName(function(t) {
            t.DistributionName && wx.setNavigationBarTitle({
                title: t.CommissionName + "提现"
            });
        }), a.getSysSettingData(function(t) {
            e.setData(t);
        }, !0), this.loadData(), this.getHasSetPayPwd();
    },
    getBanks: function() {
        var e = this;
        t.httpGet(a.getUrl("Common/GetBanks"), {}, function(t) {
            t.success && e.setData({
                banks: t.data,
                bankIndex: e.data.bankName ? t.data.findIndex(function(t) {
                    return t.id == e.data.bankName;
                }) : -1
            });
        });
    },
    bindBankChange: function(t) {
        this.setData({
            bankIndex: t.detail.value,
            bankName: this.data.banks[t.detail.value].id
        });
    },
    bindAddressTap: function() {
        this.setData({
            showDistpicker: !0
        });
    },
    setAreaData: function() {
        var t = this;
        wx.request({
            url: a.getUrl("Common/GetAdaPayRegions"),
            async: !1,
            success: function(a) {
                if (a.data.success) {
                    var e = a.data.data;
                    if (t.setData({
                        procitydata: e
                    }), t.data.bankAddressId && !t.data.bankAddress) {
                        var i = t.data.bankAddressId.split(",")[0], s = t.data.bankAddressId.split(",")[1], n = e.findIndex(function(t) {
                            return t.id == i;
                        }), d = e[n].name, o = e[n].cities.findIndex(function(t) {
                            return t.id == s;
                        }), r = [ n, o ], c = d + e[n].cities[o].name;
                        t.setData({
                            bankAddress: c,
                            provinceSelIndex: n,
                            citySelIndex: o,
                            procitydataValue: r
                        });
                    }
                    t.setProvinceCityData();
                }
            }
        });
    },
    setProvinceCityData: function() {
        var t = this.data.procitydata, a = [], e = [];
        for (var i in t) {
            var s = t[i].name, n = t[i].id;
            a.push(s), e.push(n);
        }
        this.setData({
            provinceName: a,
            provinceCode: e
        }), this.setSubCityData(this.data.provinceSelIndex);
    },
    setSubCityData: function(t) {
        var a = this.data.procitydata[t].cities, e = [], i = [];
        for (var s in a) {
            var n = a[s].name, d = a[s].id;
            e.push(n), i.push(d);
        }
        this.setData({
            cityName: e,
            cityCode: i
        });
    },
    changeArea: function(t) {
        t.detail.value[0] != this.data.provinceSelIndex && (this.setData({
            provinceSelIndex: t.detail.value[0],
            procitydataValue: [ t.detail.value[0], 0 ]
        }), this.setSubCityData(t.detail.value[0])), t.detail.value[1] != this.data.citySelIndex && this.setData({
            citySelIndex: t.detail.value[1],
            procitydataValue: [ t.detail.value[0], t.detail.value[1] ]
        });
    },
    distpickerCancel: function() {
        this.setData({
            showDistpicker: !1
        });
    },
    distpickerSure: function() {
        this.setData({
            bankAddressId: this.data.provinceCode[this.data.provinceSelIndex] + "," + this.data.cityCode[this.data.citySelIndex],
            bankAddress: this.data.provinceName[this.data.provinceSelIndex] + this.data.cityName[this.data.citySelIndex],
            showDistpicker: !1
        });
    },
    onReachBottom: function() {
        "1" === this.data.active && this.data.isNext && this.getHistoryList();
    },
    InputValue: function(t) {
        var a = t.currentTarget.dataset.key, e = this.data, i = t.detail.value;
        if ("drawMoney" === a) return i = this.checkInputText(t.detail.value), this.setData({
            drawMoney: i
        }), i > this.data.drawInfo.MaxLimit ? (e[a] = this.data.drawInfo.MaxLimit, this.setData({
            drawMoney: this.data.drawInfo.MaxLimit
        }), this.data.drawInfo.MaxLimit) : i;
        e[a] = i;
    },
    checkInputText: function(t) {
        var a = /^(\.*)(\d+)(\.?)(\d{0,2}).*$/g;
        return t = a.test(t) ? t.replace(a, "$2$3$4") : "";
    },
    loadData: function() {
        var e = this;
        a.getOpenId(function(i) {
            i && (wx.showLoading({
                title: "加载中"
            }), t.httpGet(a.getUrl("Distribution/GetApplyWithdraw"), {
                openId: i
            }, function(t) {
                if (wx.hideLoading(), t.success) {
                    var a = [];
                    t.data.enableWeChat && a.push("提现到微信"), t.data.enableCapital && a.push("提现到预付款账户"), 
                    e.setData({
                        drawTypeList: a,
                        drawInfo: t.data,
                        bankUserName: t.data.BankUserName || "",
                        bankCardNumber: t.data.BankCardNumber || "",
                        IdCard: t.data.IdCard || "",
                        bankName: t.data.BankName || "",
                        bankAddressId: t.data.BankAddressId || "",
                        settleAccountId: t.data.SettleAccountId || 0,
                        pageInit: !0
                    });
                }
            }));
        });
    },
    getDrawTypeId: function(t) {
        return "提现到微信" === t ? 2 : "提现到预付款账户" === t ? 1 : void 0;
    },
    ShowType: function(t) {
        var a = this;
        wx.showActionSheet({
            itemList: a.data.drawTypeList,
            success: function(t) {
                if (!t.cancel) {
                    var e = a.data.drawTypeList[t.tapIndex], i = a.getDrawTypeId(e);
                    a.setData({
                        drawIndex: t.tapIndex,
                        drawtype: i
                    });
                }
            }
        });
    },
    handleSubmit: function() {
        var e = this, i = this.data;
        return -1 === i.drawtype ? wx.showToast({
            title: "请选择提现方式",
            icon: "none"
        }) : 3 !== i.drawtype || i.settleAccountId ? !i.drawMoney || i.drawMoney <= 0 ? wx.showToast({
            title: "请输入提现金额",
            icon: "none"
        }) : !i.password || i.password.length < 6 ? wx.showToast({
            title: "请输入交易密码",
            icon: "none"
        }) : (this.setData({
            disabled: !0
        }), void a.getOpenId(function(s) {
            s && t.httpPost(a.getUrl("Distribution/PostDistributionApplyWithdraw"), {
                openId: s,
                Amount: i.drawMoney,
                Type: i.drawtype,
                Password: i.password,
                Remark: i.remark
            }, function(t) {
                if (!t.success) return e.setData({
                    disabled: !1
                }), wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
                e.setData({
                    pageNo: 0,
                    password: "",
                    remark: "",
                    drawMoney: "",
                    drawIndex: -1,
                    drawtype: -1,
                    isNext: !0,
                    disabled: !1,
                    active: "1"
                }), e.getHistoryList();
            });
        })) : wx.showToast({
            title: "请完善提现账户信息",
            icon: "none"
        });
    },
    handleResetPassword: function() {
        wx.navigateTo({
            url: "../userbindphone/userbindphone?formPage=changePwd"
        });
    },
    navClick: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            active: a
        }), "1" === a && (this.setData({
            isNext: !0,
            pageNo: 0
        }), this.getHistoryList());
    },
    getHistoryList: function() {
        var e = this;
        this.loading || (this.loading = !0, this.data.pageNo++, a.getOpenId(function(i) {
            i && t.httpGet(a.getUrl("Distribution/GetWithdraws"), {
                openId: i,
                pageNo: e.data.pageNo,
                pageSize: e.data.pageSize
            }, function(t) {
                if (e.loading = !1, !t.success) return wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
                var a = e.data.isNext, i = !1;
                t.data.length < e.data.pageSize && (a = !1);
                var s = e.data.historyList.slice();
                e.data.pageNo <= 1 ? (s = t.data, 0 === t.data.length && (i = !0)) : s = s.concat(t.data), 
                e.setData({
                    noList: i,
                    pageNo: e.data.pageNo,
                    isNext: a,
                    historyList: s
                });
            });
        }));
    },
    toggleHide: function() {
        this.setData({
            passwordHide: !this.data.passwordHide
        });
    },
    togglePopup: function() {
        this.setData({
            showPopup: !this.data.showPopup
        });
    },
    confirmPwd: function() {
        var e = this, i = this.data.pwd, s = this.data.againPwd;
        i.length < 6 ? a.showErrorModal("支付密码不能少于6位") : "" != s ? i == s ? t.httpPost(a.getUrl("Payment/PostSetPayPwd"), {
            openId: a.globalData.openId,
            pwd: i
        }, function(t) {
            t.success ? e.setData({
                passwordHide: !0,
                hasSetPayPwd: !0,
                password: i
            }) : a.showErrorModal("设置密码失败");
        }) : a.showErrorModal("两次密码输入不一致") : a.showErrorModal("请确认密码");
    },
    saveBankMes: function() {
        var e = this, i = this.data, s = i.IdCard, n = i.bankName, d = i.bankAddressId, o = i.bankCardNumber, r = i.bankUserName, c = i.settleAccountId;
        return !s || s.length < 18 ? wx.showToast({
            title: "请填写18位身份证号码",
            icon: "none"
        }) : n ? d ? o ? r ? (wx.showLoading(), void t.httpPost(a.getUrl("Distribution/SaveDistributorBank"), {
            openId: a.globalData.openId,
            IdCard: s,
            bankName: n,
            bankAddressId: d,
            bankCardNumber: o,
            bankUserName: r,
            settleAccountId: c
        }, function(t) {
            wx.hideLoading(), t.success ? (e.setData({
                showPopup: !1
            }), e.loadData(), wx.showToast({
                title: "保存成功",
                icon: "none"
            })) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        })) : wx.showToast({
            title: "请填写银行卡户名",
            icon: "none"
        }) : wx.showToast({
            title: "请填写银行卡号码",
            icon: "none"
        }) : wx.showToast({
            title: "请选择开户行地区",
            icon: "none"
        }) : wx.showToast({
            title: "请选择银行卡种类",
            icon: "none"
        });
    },
    getHasSetPayPwd: function() {
        var e = this;
        t.httpGet(a.getUrl("Payment/GetHasSetPayPwd"), {
            openId: a.globalData.openId
        }, function(t) {
            t.success && e.setData({
                hasSetPayPwd: !0
            });
        });
    }
});