require("../../utils/config.js"), getApp();

Page({
    data: {},
    onShareAppMessage: function() {
        return this.storehome.onShareAppMessage() || {};
    },
    onHide: function() {
        this.storehome.onHide && this.storehome.onHide();
    },
    onPageScroll: function(o) {
        this.storehome.onPageScroll && this.storehome.onPageScroll(o);
    },
    onShow: function() {
        this.storehome.onShow && this.storehome.onShow();
    },
    onLoad: function(o) {
        this.storehome = this.selectComponent("#storehome"), this.storehome.onLoad({}), 
        wx.showShareMenu({
            menus: [ "shareAppMessage", "shareTimeline" ]
        });
    },
    onPullDownRefresh: function() {
        this.storehome.onPullDownRefresh && this.storehome.onPullDownRefresh();
    },
    onReachBottom: function() {
        this.storehome.onReachBottom && this.storehome.onReachBottom();
    }
});