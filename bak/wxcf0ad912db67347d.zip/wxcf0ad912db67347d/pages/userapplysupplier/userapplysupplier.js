function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var e = getApp(), a = require("../../utils/config.js");

Page({
    data: {
        name: "",
        contactPhone: "",
        contactPerson: "",
        password: "",
        remark: "",
        checked: !1,
        headBg: e.getRequestUrl + "/Images/supplierapply.jpg"
    },
    onLoad: function(t) {
        var a = this;
        e.getSysSettingData(function(n) {
            n.contactPhone = t.contactPhone, n.supplierJoinPhone = e.globalData.SupplierJoinPhone, 
            a.setData(n);
        }), t.source && this.setData({
            checked: !0
        }), t.again && wx.request({
            url: e.getUrl("MemberCenter/GetApplySupplierStatus"),
            data: {
                openId: e.globalData.openId
            },
            success: function(t) {
                (t = t.data).success && (t = t.data, a.setData({
                    contactPerson: t.ContactPerson || "",
                    contactPhone: t.ContactPhone || "",
                    remark: t.Remark || "",
                    name: t.Name || ""
                }));
            }
        });
    },
    changeVal: function(e) {
        var a = e.currentTarget.dataset.field;
        this.setData(t({}, a, e.detail.value));
    },
    callTel: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.supplierJoinPhone
        });
    },
    postApply: function() {
        var t = this;
        this.data.contactPerson ? 11 === this.data.contactPhone.length ? this.data.password.length < 6 ? wx.showToast({
            title: "请输入至少6位密码",
            icon: "none"
        }) : this.data.name ? this.data.returnAddress ? this.data.checked ? (wx.showLoading({
            title: "提交中..."
        }), e.getOpenId(function(n) {
            a.httpPost(e.getUrl("MemberCenter/PostApplySupplier"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                openId: n,
                contactPerson: t.data.contactPerson,
                contactPhone: t.data.contactPhone,
                password: t.data.password,
                name: t.data.name,
                returnAddress: t.data.returnAddress,
                remark: t.data.remark
            }, function(t) {
                wx.hideLoading(), t.success ? (wx.showToast({
                    title: "提交成功"
                }), setTimeout(function() {
                    wx.redirectTo({
                        url: "../userapplyresult/userapplyresult?type=supplier&status=2"
                    });
                }, 1500)) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        })) : wx.showToast({
            title: "请阅读并同意加盟协议",
            icon: "none"
        }) : wx.showToast({
            title: "请输入退货地址",
            icon: "none"
        }) : wx.showToast({
            title: "请输入你的供应商名称",
            icon: "none"
        }) : wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }) : wx.showToast({
            title: "请输入你的姓名",
            icon: "none"
        });
    },
    checkboxChange: function(t) {
        this.setData({
            checked: t.detail.value[0] || !1
        });
    }
});