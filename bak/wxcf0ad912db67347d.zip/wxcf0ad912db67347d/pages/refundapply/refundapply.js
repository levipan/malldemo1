var e = require("../../utils/config.js"), t = getApp();

Page({
    data: {
        ApplyReturnNum: 1,
        ReturnNum: 1,
        OrderId: "",
        SkuId: "",
        getRequestUrl: t.getRequestUrl,
        Images: [],
        RefundType: 0,
        RefundTypeText: "请选择退款方式",
        RefundMoney: 0,
        MaxRefundMoney: 0,
        RefundReason: 0,
        RefundReasonText: "请选择退款原因",
        Remark: "",
        ShowReason: !0,
        ShowType: !0,
        ShowReasonList: [ "拍错/多拍/不想要", "缺货", "未按约定时间发货" ],
        ShowReasonIndex: -1,
        RefundTextList: [ "原路返回", "", "退到预存款" ],
        ShowRefundIndex: -1,
        ShowRefundModeList: [],
        ShowRefundModeIndex: -1,
        ShowRefundReturnList: [],
        ShowRefundReturnIndex: 0,
        ReasonDetail: "",
        ContactPerson: "",
        ContactCellPhone: "",
        AllowEdit: !1,
        quickClick: !0,
        DeliveryType: 1,
        appletTemplate: [],
        templateList: []
    },
    onLoad: function(e) {
        var a = this, n = e.orderid, o = e.itemid;
        a.setData({
            OrderId: n,
            itemId: o || 0,
            PrimaryColor: t.globalData.PrimaryColor,
            PrimaryTxtColor: t.globalData.PrimaryTxtColor
        }), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: t.globalData.PrimaryColor
        }), wx.request({
            url: t.getUrl("MyOrderRefund/GetOrderRefundModel"),
            data: {
                openId: t.globalData.openId,
                orderId: n,
                itemId: o || 0
            },
            success: function(e) {
                a.GetCheckData(e);
            }
        }), wx.request({
            url: t.getUrl("Common/GetWeiXinMsgTemplateListByApplet"),
            data: {
                openId: t.globalData.openId
            },
            success: function(e) {
                if ((e = e.data).success) {
                    a.setData({
                        templateList: e.data
                    });
                    for (var t = [], n = 0; n < a.data.templateList.length; n++) if (1 == a.data.DeliveryType && 5 == a.data.templateList[n].MessageType) {
                        t.push(a.data.templateList[n].TemplateId);
                        break;
                    }
                    a.setData({
                        appletTemplate: t
                    });
                } else wx.showToast({
                    title: e.msg
                });
            }
        });
    },
    GetCheckData: function(e) {
        var a = e.data, n = this;
        if ("502" == a.code) wx.navigateTo({
            url: "../login/login"
        }); else if (a.success) {
            var o = [];
            (a = a.data).AllowPayTypes.forEach(function(e, t) {
                switch (e) {
                  case 1:
                    o.push("原路返回");
                    break;

                  case 2:
                    o.push("退到预存款");
                }
            });
            var s = [];
            a.Reasons.forEach(function(e, t) {
                t < 6 && s.push(e.AfterSalesText);
            });
            var d = [];
            a.AllowReturn.forEach(function(e, t) {
                switch (e) {
                  case 0:
                    d.push("无需退货");
                    break;

                  case 1:
                    d.push("快递寄回");
                    break;

                  case 2:
                    d.push("送货到店");
                    break;

                  case 3:
                    d.push("商家弃货");
                }
            });
            var r = [];
            a.AllowModes.forEach(function(e, t) {
                switch (e) {
                  case 1:
                    r.push("订单退款");
                    break;

                  case 2:
                    r.push("仅退款");
                    break;

                  case 3:
                    r.push("退货退款");
                }
            }), n.data.ValidityType = 0, n.data.StartDate = "", n.data.EndDate = "", this.setData({
                RefundMoney: a.MaxRefund,
                MaxRefundMoney: a.MaxRefund,
                Total: a.MaxRefund,
                RefundTextList: o,
                ShowReasonList: s,
                ShowRefundModeList: r,
                AllowModes: a.AllowModes,
                ShowRefundReturnList: d,
                AllowReturn: a.AllowReturn,
                ContactPerson: a.Person,
                ContactCellPhone: a.Contact || "",
                count: 0,
                OrderItemId: a.OrderItemId,
                ReturnNum: a.MaxQuantity,
                ApplyReturnNum: a.MaxQuantity,
                OneReundAmount: a.RefundPrice,
                AllowEdit: a.AllowEdit,
                DeliveryType: 1
            });
        } else t.showErrorModal(a.msg, function(e) {
            e.confirm && wx.navigateBack({
                delta: 1
            });
        });
    },
    changeNum: function(e) {
        var a = this.data.ApplyReturnNum, n = parseInt(this.data.ReturnNum), o = parseInt(e.currentTarget.dataset.num);
        if (a <= 1 && o < 0) t.showErrorModal("最少退1件商品"); else if (a >= n && o > 0) t.showErrorModal("最多退" + n + "件商品"); else {
            a += o;
            var s = 1e3 * this.data.OneReundAmount * a / 1e3;
            a >= n && (s = this.data.Total), this.setData({
                ApplyReturnNum: a,
                RefundMoney: s,
                MaxRefundMoney: s
            });
        }
    },
    changeSelect: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.OrderVerificationCode, n = a[t], o = (this.data.Total, 
        0);
        n.checked = !n.checked, a.forEach(function(e) {
            e.checked && (o += 1);
        });
        var s = 1e3 * this.data.OneReundAmount * o / 1e3;
        o >= this.data.ReturnNum && (s = this.data.Total), this.setData({
            OrderVerificationCode: a,
            RefundMoney: s,
            MaxRefundMoney: s,
            ApplyReturnNum: o
        });
    },
    ShowRefundReturn: function(e) {
        var t = this;
        wx.showActionSheet({
            itemList: this.data.ShowRefundReturnList,
            success: function(e) {
                e.cancel || t.setData({
                    ShowRefundReturnIndex: e.tapIndex
                });
            },
            fail: function(e) {}
        });
    },
    ShowRefundMode: function(e) {
        var t = this;
        wx.showActionSheet({
            itemList: this.data.ShowRefundModeList,
            success: function(e) {
                e.cancel || t.setData({
                    ShowRefundModeIndex: e.tapIndex
                });
            },
            fail: function(e) {}
        });
    },
    ShowReason: function(e) {
        var t = this;
        wx.showActionSheet({
            itemList: t.data.ShowReasonList,
            success: function(e) {
                t.setData({
                    ShowReasonIndex: e.tapIndex
                });
            },
            fail: function(e) {}
        });
    },
    ShowType: function(e) {
        var t = this;
        wx.showActionSheet({
            itemList: t.data.RefundTextList,
            success: function(e) {
                if (!e.cancel) {
                    var a = t.data.RefundTextList[e.tapIndex], n = t.GetRefundTypeId(a);
                    t.setData({
                        ShowRefundIndex: e.tapIndex,
                        RefundTypeText: a,
                        RefundType: n
                    });
                }
            },
            fail: function(e) {}
        });
    },
    ChooseReason: function(e) {
        var t = e.currentTarget.dataset.name;
        this.setData({
            RefundReasonText: t,
            ShowType: !0,
            ShowReason: !0
        });
    },
    ChooseType: function(e) {
        var t = this.RefundTextList[e.currentTarget.dataset.id], a = GetRefundTypeId(t);
        this.setData({
            RefundType: a,
            RefundTypeText: t,
            ShowType: !0,
            ShowReason: !0
        });
    },
    GetRefundTypeId: function(e) {
        return "退到预存款" == e ? 2 : "原路返回" == e ? 1 : void 0;
    },
    uploadImg: function(e) {
        var a = this, n = e.currentTarget.dataset.index, o = a.data.Images;
        wx.chooseImage({
            count: 1,
            success: function(e) {
                var s = e.tempFilePaths;
                wx.uploadFile({
                    url: t.getUrl("MyOrderRefund/PostUploadAppletImage"),
                    filePath: s[0],
                    name: "file",
                    formData: {
                        openId: t.globalData.openId
                    },
                    success: function(e) {
                        if ((e = JSON.parse(e.data)).success) {
                            var t = e.data.Data[0].ImageUrl;
                            void 0 != n ? o[parseInt(n)] = t : o.push(t), a.setData({
                                Images: o
                            });
                        }
                    }
                });
            }
        });
    },
    delImg: function(e) {
        var t = this, a = e.currentTarget.dataset.index, n = t.data.Images;
        n.splice(a, 1), t.setData({
            Images: n
        });
    },
    formSubmit: function(a) {
        var n = this, o = parseFloat(n.data.RefundMoney), s = parseInt(n.data.ShowReasonIndex), d = n.data.ReasonDetail, r = n.data.ContactPerson, i = n.data.ContactCellPhone, u = n.data.RefundType, l = [];
        if (n.data.ShowRefundModeIndex < 0) t.showErrorModal("请选择售后类型！"); else if (u <= 0) t.showErrorModal("请选择要退款的方式"); else {
            var c = n.data.AllowModes[n.data.ShowRefundModeIndex];
            if (n.data.ShowRefundReturnIndex < 0 && n.data.ShowRefundReturnList.length > 0 && 3 == c) t.showErrorModal("请选择要退货的方式"); else if (s < 0) t.showErrorModal("请选择要退款的原因"); else if (n.data.OrderId.length <= 0) t.showErrorModal("请选择要退款的订单"); else if (r.length <= 0) t.showErrorModal("请输入联系人"); else if (i.length <= 0) t.showErrorModal("请输入联系方式"); else {
                var f = /^1\d{10}$/;
                if (i.length > 0 && !f.test(i)) t.showErrorModal("请输入有效的手机号码"); else {
                    var h = {
                        openId: t.globalData.openId,
                        orderId: n.data.OrderId,
                        formId: "",
                        OrderItemId: n.data.itemId || 0,
                        VerificationCodeIds: l.join(","),
                        RefundType: u,
                        Reason: n.data.ShowReasonList[s],
                        RefundAmount: o,
                        RefundMode: c,
                        RefundQuantity: n.data.ApplyReturnNum,
                        ContactPerson: r,
                        ContactCellPhone: i,
                        ReasonDetail: d,
                        CertPic1: n.data.Images.length > 0 ? n.data.Images[0] : "",
                        CertPic2: n.data.Images.length > 1 ? n.data.Images[1] : "",
                        CertPic3: n.data.Images.length > 2 ? n.data.Images[2] : ""
                    };
                    3 == n.data.AllowModes[n.data.ShowRefundModeIndex] && (h.RefundReturn = n.data.AllowReturn[n.data.ShowRefundReturnIndex]), 
                    n.data.quickClick && (n.setData({
                        quickClick: !1
                    }), wx.showLoading({
                        title: "加载中"
                    }), e.httpPost(t.getUrl("MyOrderRefund/PostApplyRefund"), h, function(e) {
                        if (e.success) {
                            wx.hideLoading();
                            var a = e.data;
                            t.showErrorModal(e.msg, function(e) {
                                wx.requestSubscribeMessage({
                                    tmplIds: n.data.appletTemplate,
                                    success: function(e) {
                                        if ("requestSubscribeMessage:ok" == e.errMsg) {
                                            var n = Object.keys(e).filter(function(t) {
                                                return "accept" === e[t];
                                            });
                                            if (n.length > 0) {
                                                var o = n[0];
                                                wx.request({
                                                    url: t.getUrl("Common/GetAuthorizedSubscribeMessage"),
                                                    data: {
                                                        templateIds: o,
                                                        orderId: a,
                                                        openId: t.globalData.openId
                                                    },
                                                    success: function(e) {}
                                                });
                                            }
                                        }
                                    },
                                    fail: function(e) {
                                        20004 == e.errCode && wx.showModal({
                                            title: "提示",
                                            content: "建议开启订阅消息，接收商城发送的消息通知",
                                            cancelText: "取消",
                                            confirmText: "去开启",
                                            showCancel: !0,
                                            success: function(e) {
                                                wx.openSetting({});
                                            }
                                        });
                                    },
                                    complete: function(e) {
                                        wx.redirectTo({
                                            url: "../refundlist/refundlist"
                                        });
                                    }
                                });
                            });
                        } else wx.hideLoading(), "502" == e.code ? wx.navigateTo({
                            url: "../login/login"
                        }) : t.showErrorModal(e.msg, function(e) {
                            e.confirm && wx.navigateBack({
                                delta: 1
                            });
                        });
                    }), setTimeout(function() {
                        n.setData({
                            quickClick: !0
                        });
                    }, 1500));
                }
            }
        }
    },
    ToTrim: function(e) {
        return e.replace(/(^\s*)|(\s*$)/g, "");
    },
    bindRefundMoneyInput: function(e) {
        var t = this.checkInputText(e.detail.value);
        if (parseFloat(t) > parseFloat(this.data.MaxRefundMoney)) return this.setData({
            RefundMoney: this.data.MaxRefundMoney
        }), this.data.MaxRefundMoney;
        this.setData({
            RefundMoney: t
        });
    },
    checkInputText: function(e) {
        var t = /^(\.*)(\d+)(\.?)(\d{0,2}).*$/g;
        return e = t.test(e) ? e.replace(t, "$2$3$4") : "";
    },
    bindReasonDetailInput: function(e) {
        this.data.ReasonDetail = e.detail.value;
    },
    bindContactPersonInput: function(e) {
        this.data.ContactPerson = e.detail.value;
    },
    bindContactCellPhoneInput: function(e) {
        this.data.ContactCellPhone = e.detail.value;
    }
});