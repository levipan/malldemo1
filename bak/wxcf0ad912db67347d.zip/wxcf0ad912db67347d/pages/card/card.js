var t = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        list: [],
        isLoad: !1
    },
    handleSetDefault: function(e) {
        var i = this, d = e.currentTarget.dataset, r = d.id;
        d.isdefault || t.httpPost(a.getUrl("MemberCard/DefaultCard"), {
            cardId: r,
            openId: a.globalData.openId
        }, function(t) {
            t.success ? (wx.showToast({
                title: "设置成功"
            }), i.init()) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        });
    },
    handleSkip: function(t) {
        var a = t.currentTarget.dataset, e = (a.id, a.cardid), i = a.type, d = "";
        d = "buyCard" === i ? "/pages/card/buyCard/buyCard" : "/pages/card/cardDetail/cardDetail?id=" + e + "&type=" + i, 
        wx.navigateTo({
            url: d
        });
    },
    init: function() {
        var e = this;
        t.httpGet(a.getUrl("MemberCard/GetMemberCard"), {
            openId: a.globalData.openId
        }, function(t) {
            e.setData({
                list: t.data,
                isLoad: !0
            });
        });
    },
    onLoad: function() {
        this.init();
    }
});