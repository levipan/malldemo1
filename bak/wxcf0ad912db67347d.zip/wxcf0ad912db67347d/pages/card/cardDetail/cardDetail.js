var t = require("../../../utils/config.js"), e = require("../../../utils/adaPay.js"), a = getApp();

Page({
    data: {
        info: {},
        isAgree: !0,
        id: 0,
        isLoad: !1
    },
    handleSkip: function(t) {
        var e = t.currentTarget.dataset.url;
        wx.navigateTo({
            url: e
        });
    },
    handleToggle: function() {
        this.setData({
            isAgree: !this.data.isAgree
        });
    },
    handleBuyCard: function() {
        var i = this.data, n = i.id, o = i.isAgree, s = i.info;
        if (!o) return wx.showToast({
            title: "请勾选同意协议",
            icon: "none"
        });
        var r = a.globalData.IsOpenSubledger ? "Himall.Plugin.Payment.Adapay" : "Himall.Plugin.Payment.WeiXinPay_SmallProg";
        t.httpPost(a.getUrl("MemberCard/Purchase"), {
            cardId: n,
            typeId: r,
            openId: a.globalData.openId
        }, function(t) {
            if (!t.success) return wx.showToast({
                title: t.msg,
                icon: "none"
            });
            if (a.globalData.IsOpenSubledger) {
                var i = t.data;
                i.expend.open_id = a.globalData.openId, e.doPay(i, function(t) {
                    "succeeded" === t.result_status ? wx.showToast({
                        title: (s.IsHave ? "续费" : "购买") + "成功",
                        mask: !0,
                        complete: function() {
                            setTimeout(function() {
                                var t = getCurrentPages()[getCurrentPages().length - 2], e = "pages/card/card" === t.route || "pages/productdetail/productdetail" === t.route;
                                t.init && t.init(), wx.navigateBack({
                                    delta: e ? 1 : 2
                                });
                            }, 1e3);
                        }
                    }) : wx.showToast({
                        title: "支付失败",
                        icon: "none"
                    });
                });
            } else wx.requestPayment({
                timeStamp: t.data.timeStamp,
                nonceStr: t.data.nonceStr,
                package: "prepay_id=" + t.data.prepayId,
                signType: "MD5",
                paySign: t.data.sign,
                success: function() {
                    wx.showToast({
                        title: (s.IsHave ? "续费" : "购买") + "成功",
                        mask: !0,
                        complete: function() {
                            setTimeout(function() {
                                var t = getCurrentPages()[getCurrentPages().length - 2], e = "pages/card/card" === t.route || "pages/productdetail/productdetail" === t.route;
                                t.init && t.init(), wx.navigateBack({
                                    delta: e ? 1 : 2
                                });
                            }, 1e3);
                        }
                    });
                },
                fail: function() {
                    wx.showToast({
                        title: "支付失败",
                        icon: "none"
                    });
                }
            });
        });
    },
    init: function() {
        var e = this;
        t.httpGet(a.getUrl("MemberCard/GetCardDetail"), {
            openId: a.globalData.openId,
            cardId: this.data.id
        }, function(t) {
            e.setData({
                info: t.data,
                isLoad: !0
            });
        });
    },
    onLoad: function(t) {
        var e = this;
        this.setData({
            id: t.id
        }, function() {
            e.init();
        });
    }
});