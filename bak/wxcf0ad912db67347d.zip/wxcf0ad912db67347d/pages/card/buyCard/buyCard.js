var t = getApp(), a = require("../../../utils/config.js");

Page({
    data: {
        list: [],
        banner: "",
        isLoad: !1
    },
    handleSkip: function(t) {
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/card/cardDetail/cardDetail?id=" + a + "&type=member"
        });
    },
    init: function() {
        var e = this;
        t.getOpenId(function(i) {
            a.httpGet(t.getUrl("MemberCard/GetCardList"), {
                openId: i
            }, function(t) {
                e.setData({
                    list: t.data.Card,
                    banner: t.data.Banner ? t.data.Banner + "?timestamp=" + new Date().getTime() : "",
                    isLoad: !0
                });
            });
        });
    },
    onShow: function() {
        this.init();
    }
});