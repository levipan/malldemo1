function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), e = getApp(), i = require("../../utils/busEvent");

Page({
    data: {
        videoIndex: 0,
        pageNo: 1,
        list: null,
        isEnd: !1,
        statusBarHeight: 20,
        productid: 0,
        cartCount: wx.getStorageSync("cartCount"),
        isAnimation: !1
    },
    onReady: function() {
        this.storeCart = this.selectComponent("#storeCart");
    },
    onLoad: function(t) {
        var a = this;
        t.referralUserId && e.setRefferUserId(t.referralUserId), wx.getSystemInfo({
            success: function(t) {
                a.setData({
                    statusBarHeight: t.statusBarHeight
                });
            }
        });
        var i = wx.getStorageSync("shopBranchId"), o = t.shopBranchId || "", d = parseInt(t.productid || 0);
        if (this.setData({
            productid: d,
            isLoad: !0
        }), i && i != o && o) return this.setData({
            switching: !0
        }), void wx.redirectTo({
            url: "../storeswitch/storeswitch?formPage=video&currentBranchId=" + i + "&newBranchId=" + o + "&productId=" + d
        });
        o && wx.setStorage({
            key: "shopBranchId",
            data: o
        }), wx.getStorageSync("shopBranchId") ? (this.loadData(), this.loadShareVideo(), 
        this.loadShare()) : wx.navigateTo({
            url: "../position/position?isBack=1"
        });
    },
    loadData: function() {
        var i = this;
        this.data.isEnd || a.httpGet(e.getUrl("Product/GetStoreVideoList"), {
            pageNo: this.data.pageNo,
            pageSize: 10,
            shopBranchId: wx.getStorageSync("shopBranchId"),
            openId: e.globalData.openId
        }, function(a) {
            if (a.success) {
                var e = i.data.list || [];
                i.setData({
                    list: [].concat(t(e), t(a.data.Data)),
                    isEnd: a.data.Data.length < 10,
                    pageNo: i.data.pageNo + 1
                }), e.length || wx.createVideoContext("video" + i.data.videoIndex).play();
            }
        });
    },
    loadShareVideo: function() {
        var t = this;
        this.data.productid && a.httpGet(e.getUrl("Product/GetProductVideoInfo"), {
            productid: this.data.productid,
            shopBranchId: wx.getStorageSync("shopBranchId"),
            openId: e.globalData.openId
        }, function(a) {
            if (a.success) {
                var e = null != t.data.list ? t.data.list.unshift(a.data) : [].unshift(a.data);
                t.setData({
                    list: t.data.list
                }), null != e && wx.createVideoContext("video" + t.data.videoIndex).play();
            } else wx.showToast({
                title: a.msg,
                icon: "none"
            }), wx.createVideoContext("video" + t.data.videoIndex).pause(), setTimeout(function() {
                wx.navigateTo({
                    url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.data.productid
                });
            }, 1500);
        });
    },
    loadShare: function() {
        var t = this;
        e.getShareConfig(function(a) {
            t.setData({
                shareTitle: a.videoShareTitle,
                shareImage: a.videoShareImage
            });
        });
    },
    onShow: function(t) {
        if (!this.data.switching) {
            !this.data.isLoad && wx.getStorageSync("shopBranchId") && (this.loadShareVideo(), 
            this.loadData(), this.loadShare());
            var a = wx.createVideoContext("video" + this.data.videoIndex);
            a && a.play(), this.setData({
                cartCount: wx.getStorageSync("cartCount")
            });
        }
    },
    changeVideo: function(t) {
        var a = this.data.videoIndex;
        this.setData({
            videoIndex: t.detail.current
        }), wx.createVideoContext("video" + a).pause(), wx.createVideoContext("video" + this.data.videoIndex).play(), 
        this.data.videoIndex === this.data.list.length - 2 && this.loadData();
    },
    handleStartTouch: function() {
        this.setData({
            isAnimation: !0
        });
    },
    handleEndTouch: function() {
        this.setData({
            isAnimation: !1
        });
    },
    handleVideoEnd: function() {
        this.data.videoIndex < this.data.list.length - 1 && this.setData({
            videoIndex: this.data.videoIndex + 1
        });
    },
    handleAddCart: function(t) {
        var a = this, e = t.currentTarget.dataset.hassku, i = t.currentTarget.dataset.id, o = t.currentTarget.dataset.delivery;
        this.setData({
            productid: i
        }), e ? (this.storeCart.chooseSku(o), wx.createVideoContext("video" + this.data.videoIndex).pause()) : this.storeCart.changeCart(i + "_0_0_0", 1, function(t) {
            t.success ? (wx.showToast({
                title: "加入成功"
            }), setTimeout(function() {
                a.setData({
                    cartCount: wx.getStorageSync("cartCount")
                });
            }, 1e3)) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }, null, o);
    },
    handleHideSku: function() {
        wx.createVideoContext("video" + this.data.videoIndex).play(), this.setData({
            cartCount: wx.getStorageSync("cartCount")
        });
    },
    goBack: function() {
        getCurrentPages().length > 2 ? wx.navigateBack() : i.emit("tabUserChange", {
            url: "../index/index"
        });
    },
    goCart: function() {
        i.emit("tabUserChange", {
            url: "../cart/cart"
        });
    },
    goProductDetail: function(t) {
        wx.createVideoContext("video" + this.data.videoIndex).pause();
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + a
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = "pages/video/video?productid=" + this.data.list[this.data.videoIndex].ProductId + "&shopBranchId=" + wx.getStorageSync("shopBranchId"), a = this.data.shareTitle.replace(/{productname}/g, this.data.list[this.data.videoIndex].ProductName);
        return a = a.replace(/{price}/g, this.data.list[this.data.videoIndex].MinSalePrice), 
        e.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + e.globalData.userInfo.UserId), 
        {
            title: a,
            path: t,
            imageUrl: this.data.shareImage || this.data.list[this.data.videoIndex].ShowImage,
            success: function(t) {}
        };
    }
});