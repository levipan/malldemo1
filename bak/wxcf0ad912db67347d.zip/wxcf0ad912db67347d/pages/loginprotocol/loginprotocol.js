var e = getApp(), t = require("../wxParse/wxParse.js");

Page({
    data: {},
    onLoad: function(r) {
        var a = this, s = "cardProtocol" === r.type;
        wx.setNavigationBarTitle({
            title: s ? "会员卡服务协议" : "注册协议"
        }), s ? wx.request({
            url: e.getUrl("MemberCard/GetCardAgreement"),
            data: {},
            success: function(e) {
                t.wxParse("MemberAgreement", "html", e.data.data.MemberCardAgreement, a, 24);
            }
        }) : wx.request({
            url: e.getUrl("Home/GetMemberAgreement"),
            data: {},
            success: function(e) {
                (e = e.data).success && t.wxParse("MemberAgreement", "html", e.data.MemberAgreement, a, 24);
            }
        });
    }
});