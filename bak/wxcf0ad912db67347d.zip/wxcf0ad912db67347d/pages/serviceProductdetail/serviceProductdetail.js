var t = require("../../utils/config.js"), e = getApp(), a = require("../../utils/constant").SERVICE;

Page({
    data: {
        pageLoaded: !1,
        gotopVal: !0,
        showDetailBuy: 0,
        actionsheetShow: !1,
        showPoster: !1,
        backShow: "none",
        form: {
            productId: "",
            serviceShopId: ""
        },
        SERVICE: a
    },
    onLoad: function(t) {
        var o = this;
        t.referralUserId && e.setRefferUserId(t.referralUserId), e.shopBranchChange(t.shopBranchId, "formPage=serviceProductdetail&productId=" + t.id + "&serviceShopId=" + t.serviceShopId + "&serviceType=" + t.serviceType) || (this.data.form.productId = t.id, 
        this.data.form.shopBranchId = wx.getStorageSync("shopBranchId"), this.data.form.serviceShopId = t.serviceShopId, 
        this.setData({
            form: this.data.form
        }), e.getSysSettingData(function(r) {
            r.IsShowHishopCopyRight = e.globalData.IsShowHishopCopyRight, r.ProductSaleCountOnOff = e.globalData.ProductSaleCountOnOff, 
            r.IsJumpLink = e.globalData.IsJumpLink, r.IsShowBuyRecords = e.globalData.IsShowBuyRecords, 
            r.serviceType = parseInt(t.serviceType) || a.type.unreal, r.serviceName = t.serviceName || "", 
            o.setData(r);
        }), parseInt(t.serviceType) === a.type.real && (this.serviceCart = this.selectComponent("#serviceCart")));
    },
    onShow: function() {
        this.getProductDetail();
    },
    onShareAppMessage: function() {
        var t = "pages/serviceProductdetail/serviceProductdetail?id=" + this.data.form.productId + "&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&serviceShopId=" + this.data.form.serviceShopId;
        return t += "&serviceType=" + this.data.serviceType, e.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + e.globalData.userInfo.UserId), 
        console.log("path:" + t), {
            title: this.data.shareTitle,
            path: t,
            imageUrl: this.data.detailInfo.Image
        };
    },
    goToCopyright: function() {
        wx.navigateTo({
            url: "../outurl/outurl?url=" + e.getRequestUrl + "hishop/index.html"
        });
    },
    getProductDetail: function() {
        var a = this;
        wx.showLoading({
            title: "加载中"
        }), wx.showNavigationBarLoading(), t.httpGet(e.getUrl("ServiceShop/ProductDetail"), this.data.form, function(t) {
            return wx.hideLoading(), wx.hideNavigationBarLoading(), t.success ? (a.setData({
                detailInfo: t.data,
                pageLoaded: !0
            }), wx.setNavigationBarTitle({
                title: t.data.ProductName
            }), e.getShareConfig(function(t) {
                var e = t.productShareTitle.replace(/{shequ}/g, a.data.detailInfo.ServiceShop.Name);
                e = (e = e.replace(/{productname}/g, a.data.detailInfo.ProductName)).replace(/{price}/g, a.data.detailInfo.SalePrice), 
                a.setData({
                    shareTitle: e
                });
            }), void (a.serviceCart && a.serviceCart.getCartData())) : 600 === t.code ? wx.showModal({
                content: t.msg,
                showCancel: !1,
                success: function(t) {
                    t.confirm && e.busEmit("services", "../services/services");
                }
            }) : void e.showErrorModal(t.msg, function(t) {
                t.confirm && wx.navigateBack({
                    delta: 1
                });
            });
        });
    },
    showVideo: function() {
        this.setData({
            showVideo: !0
        });
    },
    closeVideo: function() {
        this.setData({
            showVideo: !1
        });
    },
    changeDetailBuy: function(t) {
        var e = parseInt(t.currentTarget.dataset.type);
        !this.data.BuyRecords && e && this.getBuyRecords(), this.setData({
            showDetailBuy: e
        });
    },
    getBuyRecords: function() {
        var a = this;
        t.httpGet(e.getUrl("ServiceShop/BuyRecords"), {
            productId: this.data.form.productId
        }, function(t) {
            t.success && (t.data.forEach(function(t) {
                var e = t.Nick, a = [], o = !0, r = !1, i = void 0;
                try {
                    for (var s, n = e[Symbol.iterator](); !(o = (s = n.next()).done); o = !0) {
                        var c = s.value;
                        a.push(c);
                    }
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    r = !0, i = t;
                } finally {
                    try {
                        !o && n.return && n.return();
                    } finally {
                        if (r) throw i;
                    }
                }
                2 === a.length ? e = a[0] + "*" : e.length > 2 && (e = a[0] + "***" + a[a.length - 1]), 
                t.Nick = e;
            }), a.setData({
                BuyRecords: t.data
            }));
        });
    },
    goTop: function(t) {
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    onPageScroll: function(t) {
        this.setData({
            gotopVal: t.scrollTop < 500
        });
    },
    updateproduct: function() {
        e.globalData.serviceCartData[this.data.form.productId] ? this.setData({
            curQuantity: e.globalData.serviceCartData[this.data.form.productId]
        }) : this.setData({
            curQuantity: 0
        });
    },
    productNumChange: function(t) {
        this.serviceCart.numChange(t, function(t) {
            if (!t.success) return wx.showToast({
                title: t.msg,
                icon: "none"
            });
            wx.showToast({
                title: "加入购物车成功",
                icon: "none"
            });
        });
    },
    onBuy: function(t) {
        wx.navigateTo({
            url: "../ordersubmit/ordersubmit?count=1&&deliver=1&isServiceShop=1&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&productId=" + this.data.form.productId
        });
    },
    actionsheetToggle: function() {
        this.setData({
            actionsheetShow: !this.data.actionsheetShow,
            backShow: this.data.backShow ? "" : "none"
        });
    },
    showSharePoster: function() {
        this.setData({
            backShow: "none",
            actionsheetShow: !1
        }), this.data.hasPoster ? wx.previewImage({
            current: 0,
            urls: [ this.data.posterImagePath ]
        }) : (wx.showLoading({
            title: "生成中"
        }), this.getProductCodeimg());
    },
    getProductCodeimg: function() {
        var t = this;
        wx.request({
            url: e.getUrl("ServiceShop/ProductAppletCode"),
            data: {
                pid: this.data.form.productId,
                uid: e.globalData.userInfo.IsDistributor ? e.globalData.userInfo.UserId : 0,
                shopBranchId: wx.getStorageSync("shopBranchId"),
                serviceShopId: this.data.form.serviceShopId
            },
            success: function(a) {
                a.data.success && t.setData({
                    productCodeimg: e.getUrl(a.data.data.url).replace(/mobileshopapi/, "")
                });
            },
            complete: function() {
                t.posterCanvas();
            }
        });
    },
    posterCanvas: function() {
        var t = 28 * this.data.detailInfo.ServiceShop.Name.length, e = 28 * (this.data.detailInfo.SalePrice + "").length + 64;
        this.setData({
            showPoster: !0,
            posterData: {
                background: "#fff",
                width: "640rpx",
                height: "1000rpx",
                views: [ {
                    type: "image",
                    url: this.data.detailInfo.Image,
                    css: {
                        top: "0rpx",
                        left: "0rpx",
                        width: "640rpx",
                        height: "640rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.detailInfo.ProductName,
                    css: {
                        top: "672rpx",
                        width: "416rpx",
                        fontSize: "32rpx",
                        lineHeight: "48rpx",
                        color: "#212121",
                        maxLines: "1",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.detailInfo.ShortDescription,
                    css: {
                        top: "720rpx",
                        width: "416rpx",
                        fontSize: "28rpx",
                        lineHeight: "40rpx",
                        color: "#BDBDBD",
                        maxLines: "1",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: "￥",
                    css: {
                        top: "789rpx",
                        left: "24rpx",
                        color: "#FB1438",
                        lineHeight: "40rpx",
                        fontSize: "28rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.detailInfo.SalePrice + "",
                    css: {
                        top: "772rpx",
                        left: "52rpx",
                        color: "#FB1438",
                        fontWeight: "bold",
                        fontSize: "48rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#FB1438",
                        width: "76rpx",
                        height: "32rpx",
                        borderRadius: "16rpx",
                        top: "788rpx",
                        left: e + "rpx"
                    }
                }, {
                    type: "text",
                    text: "抢购价",
                    css: {
                        color: "#fff",
                        lineHeight: "32rpx",
                        fontSize: "20rpx",
                        top: "790rpx",
                        left: e + 8 + "rpx"
                    }
                }, {
                    type: "image",
                    url: this.data.productCodeimg,
                    css: {
                        top: "672rpx",
                        right: "24rpx",
                        width: "160rpx",
                        height: "160rpx"
                    }
                }, {
                    type: "rect",
                    css: {
                        color: "#eee",
                        width: "592rpx",
                        height: "1rpx",
                        top: "864rpx",
                        left: "24rpx"
                    }
                }, {
                    type: "text",
                    text: this.data.detailInfo.ServiceShop.Name,
                    css: {
                        top: "888rpx",
                        left: "344rpx",
                        width: "592rpx",
                        lineHeight: "40rpx",
                        color: "#212121",
                        maxLines: "1",
                        fontSize: "28rpx",
                        align: "center"
                    }
                }, {
                    type: "text",
                    text: "长按识别小程序码",
                    css: {
                        top: "938rpx",
                        left: "318rpx",
                        width: "592rpx",
                        lineHeight: "40rpx",
                        color: "#bdbdbd",
                        maxLines: "1",
                        fontSize: "28rpx",
                        align: "center"
                    }
                }, {
                    type: "image",
                    url: "../../images/icon-store.png",
                    css: {
                        top: "886rpx",
                        left: 320 - t / 2 - 22 + "rpx",
                        width: "40rpx",
                        height: "40rpx"
                    }
                } ]
            }
        }, function() {
            wx.hideLoading();
        });
    },
    onImgOK: function(t) {
        this.setData({
            posterImagePath: t.detail.path,
            hasPoster: !0
        }), wx.previewImage({
            current: 0,
            urls: [ t.detail.path ]
        });
    },
    onCallPhone: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.detailInfo.ServiceShop.Phone,
            fail: function(t) {}
        });
    },
    onOpenMap: function() {
        wx.openLocation({
            latitude: this.data.detailInfo.ServiceShop.Latitude,
            longitude: this.data.detailInfo.ServiceShop.Longitude
        });
    },
    onOpenStore: function() {
        wx.navigateTo({
            url: "/pages/serviceStore/serviceStore?id=" + this.data.form.serviceShopId
        });
    },
    onProviewImg: function(t) {
        wx.previewImage({
            current: t.currentTarget.dataset.path,
            urls: this.data.detailInfo.descriptionImage
        });
    },
    onProviewSwiper: function() {
        wx.previewImage({
            urls: [ this.data.detailInfo.Image ]
        });
    }
});