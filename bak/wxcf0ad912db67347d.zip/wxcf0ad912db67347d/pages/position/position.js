var t, a = getApp(), e = require("../../utils/qqmap-wx-jssdk.min.js"), o = require("../../utils/busEvent");

Page({
    data: {
        pageType: 0,
        fromLatLng: "",
        cityinfo: "",
        location: ""
    },
    onLoad: function(t) {
        this.setData({
            isBack: t.isBack
        }), t.shopBranchId && this.setData({
            shopBranchId: t.shopBranchId
        });
    },
    onShow: function() {
        var o = this;
        this.data.shopBranchId ? wx.setStorageSync({
            key: "shopBranchId",
            data: this.data.shopBranchId,
            success: function() {
                wx.switchTab({
                    url: "../index/index"
                });
            }
        }) : (this.setData({
            pageType: 0
        }), a.getSysSettingData(function() {
            t = new e({
                key: a.globalData.QQMapKey
            }), wx.getStorageSync("o2oFromLatLng") ? (o.setData({
                fromLatLng: wx.getStorageSync("o2oFromLatLng")
            }), o.getShopBranch()) : o.getLocation();
        }));
    },
    getLocation: function() {
        var t = this;
        wx.getLocation({
            type: "gcj02",
            success: function(a) {
                wx.setStorage({
                    key: "o2oFromLatLng",
                    data: a.latitude + "," + a.longitude
                }), t.setData({
                    fromLatLng: a.latitude + "," + a.longitude
                }), t.getShopBranch();
            },
            fail: function() {
                t.setData({
                    pageType: 1
                });
            }
        });
    },
    getShopBranch: function() {
        var t = this, e = this;
        wx.request({
            url: a.getUrl("Home/GetNearestShopBranchId"),
            data: {
                fromLatLng: e.data.fromLatLng
            },
            success: function(a) {
                if ((a = a.data).success) if (a.data.shopBranchId > 0) if (wx.setStorageSync("shopBranchId", a.data.shopBranchId), 
                t.data.isBack) {
                    var n = getCurrentPages();
                    n[n.length - 2].loadData(), wx.navigateBack();
                } else o.emit("tabUserChange", {
                    url: "../index/index",
                    reload: !0
                }); else e.setData({
                    pageType: 2,
                    cityinfo: a.data.CityInfo.Name,
                    location: a.data.CurrentAddress
                }); else e.setData({
                    pageType: 1
                });
            }
        });
    },
    toChooseAddr: function() {
        var t = this;
        wx.navigateTo({
            url: "../storelocation/storelocation?fromLatLng=" + t.data.fromLatLng + "&cityname=" + (t.data.cityinfo ? t.data.cityinfo : "") + "&location=" + t.data.location + "&ptype=1&page=position"
        });
    }
});