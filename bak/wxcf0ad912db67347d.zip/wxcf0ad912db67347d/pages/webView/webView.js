var e = getApp(), t = require("../../utils/adaPay.js");

Page({
    data: {
        webUrl: "",
        isShow: !0
    },
    onLoad: function(t) {
        t.referralUserId && e.setRefferUserId(t.referralUserId);
        var r = decodeURIComponent(t.url);
        r = r.indexOf("/?") > -1 ? (r = r.replace("/store/?", "/store/?r=" + new Date().getTime() + "&")).replace("/supplier/?", "/supplier/?r=" + new Date().getTime() + "&") : (r = r.replace("/store/", "/store/?r=" + new Date().getTime())).replace("/supplier/", "/supplier/?r=" + new Date().getTime()), 
        this.setData({
            webUrl: r
        }), t.title && wx.setNavigationBarTitle({
            title: t.title
        }), this.bindmessage(t);
    },
    changeCart: function() {
        var e = this.data.webUrl + "#/agentproduct";
        this.setData({
            webUrl: e
        });
    },
    bindmessage: function(r) {
        if (r.orderId) {
            var a = r.orderId, s = encodeURIComponent(r.successUrl + "?orderId=&orderid=" + a), i = encodeURIComponent(r.errorUrl);
            e.getOpenId(function(r) {
                r && (e.globalData.IsOpenSubledger ? wx.request({
                    url: e.getUrl("Payment/GetAdapayPaymentList"),
                    data: {
                        openId: r,
                        orderId: a
                    },
                    success: function(e) {
                        if (e.data.success) {
                            var a = e.data.data;
                            a.expend.open_id = r, t.doPay(a, function(e) {
                                "succeeded" === e.result_status ? wx.redirectTo({
                                    url: "../webView/webView?url=" + s
                                }) : wx.redirectTo({
                                    url: "../webView/webView?url=" + i
                                });
                            });
                        } else wx.showModal({
                            title: "提示",
                            content: e.data.msg,
                            showCancel: !1,
                            success: function(e) {
                                wx.redirectTo({
                                    url: "../webView/webView?url=" + i
                                });
                            }
                        });
                    }
                }) : wx.request({
                    url: e.getUrl("Payment/GetPaymentList"),
                    data: {
                        openId: r,
                        orderId: a
                    },
                    success: function(e) {
                        if ((e = e.data).success) {
                            var t = e.data;
                            wx.requestPayment({
                                timeStamp: t.timeStamp,
                                nonceStr: t.nonceStr,
                                package: "prepay_id=" + t.prepayId,
                                signType: "MD5",
                                paySign: t.sign,
                                success: function(e) {
                                    wx.redirectTo({
                                        url: "../webView/webView?url=" + s
                                    });
                                },
                                fail: function(e) {
                                    wx.redirectTo({
                                        url: "../webView/webView?url=" + i
                                    });
                                }
                            });
                        } else wx.showModal({
                            title: "提示",
                            content: e.msg,
                            showCancel: !1,
                            success: function(e) {
                                wx.redirectTo({
                                    url: "../webView/webView?url=" + i
                                });
                            }
                        });
                    }
                }));
            });
        }
    }
});