function t(t) {
    if (Array.isArray(t)) {
        for (var e = 0, a = Array(t.length); e < t.length; e++) a[e] = t[e];
        return a;
    }
    return Array.from(t);
}

var e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/config")), a = require("../../utils/constant"), i = getApp();

Page({
    data: {
        isShowVideo: !1,
        videoPoster: "",
        videoSrc: "",
        pageSize: 10,
        isEmpty: !0,
        isInit: !1,
        pageNo: 1,
        GROUPSOLITAIRE: a.GROUPSOLITAIRE
    },
    onLoad: function(t) {
        t.referralUserId && i.setRefferUserId(t.referralUserId), i.shopBranchChange(t.shopBranchId, "formPage=groupsolitairedetail") || this.loadData();
    },
    onPullDownRefresh: function() {
        this.data.pageNo = 1, this.loadData();
    },
    onReachBottom: function() {
        this.data.isNoNext || this._loading || (this.data.pageNo += 1, this.loadData());
    },
    loadData: function() {
        var a = this;
        this._loading = !0, i.getOpenId(function(o) {
            e.default.httpGet(i.getUrl("GroupSolitaire/GetActivityList"), {
                shopBranchId: wx.getStorageSync("shopBranchId"),
                pageNo: a.data.pageNo,
                pageSize: a.data.pageSize,
                openId: o || ""
            }, function(e) {
                if (a._loading = !1, wx.stopPullDownRefresh(), e.success) {
                    var i = 1 === a.data.pageNo ? e.data : [].concat(t(a.data.list), t(e.data));
                    a.setData({
                        list: i,
                        isInit: !0,
                        isEmpty: 0 === i.length,
                        isNoNext: e.data.length < a.data.pageSize
                    });
                }
            });
        }, !0);
    },
    onHideVideo: function(t) {
        this.setData({
            isShowVideo: !1,
            videoPoster: "",
            videoSrc: ""
        });
    },
    onShowVideo: function(t) {
        var e = t.currentTarget.dataset, a = e.video, i = e.poster;
        this.setData({
            isShowVideo: !0,
            videoPoster: i || "",
            videoSrc: a
        });
    },
    onOpenDetail: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/groupsolitairedetail/groupsolitairedetail?activeId=" + e + "&shopBranchId=" + wx.getStorageSync("shopBranchId")
        });
    },
    onPreviewImg: function(t) {
        var e = t.currentTarget.dataset, a = e.index, i = e.current, o = this.data.list[a].Images;
        wx.previewImage({
            urls: o,
            current: o[i]
        });
    }
});