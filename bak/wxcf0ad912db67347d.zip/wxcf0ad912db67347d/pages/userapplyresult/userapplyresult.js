var e = getApp(), t = require("../../utils/busEvent");

Page({
    data: {
        hasload: !1
    },
    onLoad: function(t) {
        var a = this;
        wx.showLoading({
            title: "加载中"
        }), this.setData({
            remark: t.remark || "",
            status: t.status || 2,
            type: t.type
        }), setTimeout(function() {
            a.setData({
                hasload: !0
            }), wx.hideLoading();
        }, 500), e.getSysSettingData(function(e) {
            a.setData(e);
        }, !0);
    },
    backCenter: function() {
        t.emit("tabUserChange", {
            url: "../usercenter/usercenter"
        });
    },
    reapply: function() {
        var t = this.data.type;
        "Service" === t ? wx.redirectTo({
            url: "/subPages/userapply" + t + "/userapply" + t + "?again=1&sellerId=" + e.globalData.sellerId
        }) : (console.log(e.globalData.sellerId), wx.redirectTo({
            url: "/pages/userapply" + t + "/userapply" + t + "?again=1&sellerId=" + e.globalData.sellerId
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});