function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

function a(e) {
    var t = this, a = e.target.dataset.src, i = e.target.dataset.from;
    void 0 !== i && i.length > 0 && null != t.data[i] ? wx.previewImage({
        current: a,
        urls: null == t.data[i].imageUrls ? "" : t.data[i].imageUrls
    }) : wx.previewImage({
        current: a,
        urls: [ a ]
    });
}

function i(e) {
    var t = this, a = e.target.dataset.from, i = e.target.dataset.idx;
    void 0 !== a && a.length > 0 && r(e, i, t, a);
}

function r(e, a, i, r) {
    var o, s = d(r, i.data);
    if (s && 0 != s.images.length) {
        var l = s.images, g = n(e.detail.width, e.detail.height, i, r), u = l[a].index, h = "" + r, m = !0, v = !1, f = void 0;
        try {
            for (var w, c = u.split(".")[Symbol.iterator](); !(m = (w = c.next()).done); m = !0) h += ".nodes[" + w.value + "]";
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            v = !0, f = e;
        } finally {
            try {
                !m && c.return && c.return();
            } finally {
                if (v) throw f;
            }
        }
        var x = h + ".width", j = h + ".height";
        i.setData((o = {}, t(o, x, g.imageWidth), t(o, j, g.imageheight), o));
    }
}

function n(e, t, a, i) {
    var r = 0, n = 0, o = 0, s = {}, u = d(i, a.data).view.imagePadding;
    return r = l - 2 * u / 750 * l, g, e > r ? (o = (n = r) * t / e, s.imageWidth = n, 
    s.imageheight = o) : (s.imageWidth = e, s.imageheight = t), s;
}

function d(e, t) {
    t || console.error("obj is invalid:", t);
    var a = e.split(/\./), i = a.shift(), r = /^([a-zA-Z0-9_-]+)\[([0-9]+)\]$/;
    if (r.test(i)) {
        var n = i.match(r);
        i = n[1];
        var o = n[2];
        a.unshift(o);
    }
    return a.length < 1 ? t[i] : (t = t[i], d(a.join("."), t));
}

var o = e(require("./showdown.js")), s = e(require("./html2json.js")), l = 0, g = 0;

wx.getSystemInfo({
    success: function(e) {
        l = e.windowWidth, g = e.windowHeight;
    }
}), module.exports = {
    wxParse: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "wxParseData", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "html", r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '<div class="color:red;">数据不能为空</div>', n = arguments[3], d = arguments[4], l = n, g = {};
        if ("html" == t) g = s.default.html2json(r, e); else if ("md" == t || "markdown" == t) {
            var u = new o.default.Converter().makeHtml(r);
            g = s.default.html2json(u, e);
        }
        g.view = {}, g.view.imagePadding = 0, void 0 !== d && (g.view.imagePadding = d);
        var h = {};
        h[e] = g, l.setData(h), l.wxParseImgLoad = i, l.wxParseImgTap = a;
    },
    wxParseTemArray: function(e, t, a, i) {
        for (var r = [], n = i.data, d = null, o = 0; o < a; o++) {
            var s = n[t + o].nodes;
            r.push(s);
        }
        e = e || "wxParseTemArray", (d = JSON.parse('{"' + e + '":""}'))[e] = r, i.setData(d);
    },
    emojisInit: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/wxParse/emojis/", a = arguments[2];
        s.default.emojisInit(e, t, a);
    }
};