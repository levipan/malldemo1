var e = getApp(), t = require("../../utils/config.js"), i = require("../../utils/busEvent");

Page({
    data: {
        url: ""
    },
    onLoad: function(n) {
        wx.showLoading({
            title: "加载中"
        }), n.scene ? t.httpGet(e.getUrl("CommunityStore/GetSweepCodeUrl"), {
            key: n.scene
        }, function(e) {
            e.success && (wx.hideLoading(), i.emit("tabUserChange", {
                url: "/" + e.data.url
            }));
        }) : wx.switchTab({
            url: "../index/index"
        });
    }
});