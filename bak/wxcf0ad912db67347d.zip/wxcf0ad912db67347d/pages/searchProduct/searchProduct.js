function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

function a(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var e = require("../../utils/config"), r = require("../../utils/busEvent"), o = getApp();

Page({
    data: {
        loading: !1,
        products: [],
        isOver: !1,
        skuProductid: 0,
        cartCount: 0,
        form: {
            shopBranchId: "",
            openId: "",
            pageno: 1,
            pagesize: 10,
            keyword: "",
            couponId: "",
            provider: "applet",
            productsearchType: 4
        }
    },
    onLoad: function(t) {
        var a = this;
        o.getSysSettingData(function(t) {
            a.setData(t);
        }), wx.setNavigationBarColor({
            frontColor: "#000000",
            backgroundColor: "#ffffff"
        }), o.getOpenId(function(e) {
            e && (a.data.form.openId = e, a.data.form.shopBranchId = wx.getStorageSync("shopBranchId"), 
            a.data.form.couponId = t.couponId || "", a._loadData());
        });
    },
    onReady: function() {
        this.storeCart = this.selectComponent("#storeCart");
    },
    onShow: function() {},
    onReachBottom: function() {
        this.data.loading || this.data.isOver || (this.data.form.pageno += 1, this._loadData());
    },
    onUnload: function() {
        clearInterval(this.timeload);
    },
    onShareAppMessage: function() {},
    getProductData: function() {
        this.data.form.pageno = 1, this.setData({
            isOver: !1
        }), this._loadData();
    },
    _loadData: function() {
        var t = this;
        this.data.loading || (this.setData({
            loading: !0
        }), e.httpGet(o.getUrl("Home/GetStoreProductList"), this.data.form, function(e) {
            if (e.success) {
                var r = e.data.Data;
                r.forEach(function(a) {
                    a.HasSecond < 0 && (a.HasSecond = 0), a.IsFlashSale && a.HasSecond && (a.time = t.formatDuring(a.HasSecond));
                });
                var o = [];
                o = t.data.form.pageno > 1 ? [].concat(a(r), a(t.data.products)) : r, t.setData({
                    products: o,
                    loading: !1,
                    isOver: r.length < t.data.form.pagesize
                }), t.setTimeLoad(), t.getCartNumber(), t.getCartQuantity();
            } else wx.showToast({
                title: e.msg
            });
        }));
    },
    setTimeLoad: function() {
        var a = this;
        clearInterval(this.timeload), this.timeload = setInterval(function() {
            a.data.products.forEach(function(e) {
                e.HasSecond > 0 && (e.HasSecond -= 1, e.HasSecond < 0 && (e.HasSecond = 0), e.IsFlashSale && (e.HasSecond > 0 ? (e.time = a.formatDuring(e.HasSecond), 
                a.setData(t({}, "products", a.data.products))) : 0 === e.HasSecond && a.getProductData()));
            });
        }, 1e3);
    },
    formatDuring: function(t) {
        var a = parseInt(t / 3600), e = parseInt(t % 3600 / 60), r = parseInt(t % 60);
        return a < 10 && (a = "0" + a), e < 10 && (e = "0" + e), r < 10 && (r = "0" + r), 
        [ a, e, r ];
    },
    productNumChange: function(t) {
        var a = this, e = t.currentTarget.dataset.id, r = t.currentTarget.dataset.index, o = t.currentTarget.dataset.type ? 1 : -1, n = this.data.products[r], s = t.currentTarget.dataset.delivery;
        this.setData({
            skuProductid: t.currentTarget.dataset.id
        }), this.storeCart.changeCart(e + "_0_0_0", o, function(t) {
            n.Quantity += t.success ? o : 0, 3001 !== t.code && 3002 !== t.code && 3003 !== t.code || (n.Quantity = t.data), 
            n.Quantity < 0 && (n.Quantity = 0), a.setData({
                products: a.data.products
            }), a.getCartNumber(), t.success && wx.showToast({
                title: "加入购物车成功",
                icon: "none"
            });
        }, null, s);
    },
    updateProduct: function(t) {
        t.detail ? (this.data.products[this.data.productIndex].Quantity = t.detail.quantity, 
        this.setData({
            products: this.data.products
        })) : this.getProductData();
    },
    chooseSku: function(t) {
        this.setData({
            skuProductid: t.currentTarget.dataset.id,
            productIndex: t.currentTarget.dataset.index
        });
        var a = t.currentTarget.dataset.delivery;
        this.storeCart.chooseSku(a);
    },
    getCartNumber: function() {
        this.setData({
            cartCount: o.getCartTotal() || 0
        });
    },
    goCart: function() {
        r.emit("tabUserChange", {
            url: "../cart/cart"
        });
    },
    goProduct: function(t) {
        wx.navigateTo({
            url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.currentTarget.dataset.id
        });
    },
    searchFocus: function() {
        this.setData({
            focus: !0
        });
    },
    searchBlur: function() {
        this.setData({
            focus: !1
        });
    },
    clearSearch: function() {
        wx.hideKeyboard(), this.data.form.keyword = "", this.setData({
            focus: !1
        }), this.onConfirmSearch();
    },
    searchInput: function(t) {
        var a = t.detail.value;
        this.data.form.keyword = a, a || this.onConfirmSearch();
    },
    onConfirmSearch: function() {
        this.getProductData();
    },
    getCartQuantity: function() {
        this.data.products.length > 0 && this.data.products.map(function(t) {
            if (o.globalData.cartData.items[t.ProductId]) {
                var a = 0;
                for (var e in o.globalData.cartData.items[t.ProductId].skus) a += o.globalData.cartData.items[t.ProductId].skus[e].Quantity;
                t.Quantity = a;
            } else t.Quantity = 0;
        }), this.setData({
            products: this.data.products
        });
    }
});