var t = require("../../utils/config.js"), e = getApp(), a = require("../../utils/constant").SERVICE;

Page({
    data: {
        pageLoaded: !1,
        pageEnd: !1,
        empty: !1,
        pageNo: 1,
        pageSize: 10,
        serviceShopId: "",
        loadingList: !1,
        products: [],
        categoryId: 0,
        keyWord: "",
        typeHeight: "auto",
        SERVICE: a,
        categoryList: []
    },
    onLoad: function(t) {
        var a = this;
        this.setData({
            serviceShopId: t.id || ""
        }), t.referralUserId && e.setRefferUserId(t.referralUserId), e.shopBranchChange(t.shopBranchId, "formPage=serviceStore&serviceShopId=" + t.id) || (e.getSysSettingData(function(t) {
            t.ProductSaleCountOnOff = e.globalData.ProductSaleCountOnOff, a.setData(t);
        }, !0), this.getStoreInfo());
    },
    onReady: function() {
        this._getBoxSizes();
    },
    onPullDownRefresh: function() {
        this.setData({
            pageEnd: !1,
            empty: !1,
            pageNo: 1,
            categoryList: [],
            categoryId: 0,
            products: []
        }), this.loadData();
    },
    onShow: function() {
        this.data.products.length > 0 && this.serviceCart && this.serviceCart.getCartData();
    },
    onHide: function() {
        this.setData({
            showVideo: !1
        }), wx.setNavigationBarColor({
            frontColor: "#000000",
            backgroundColor: "#ffffff"
        });
    },
    onShareAppMessage: function() {
        var t = "pages/serviceStore/serviceStore?id=" + this.data.serviceShopId + "&shopBranchId=" + wx.getStorageSync("shopBranchId");
        return e.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + e.globalData.userInfo.UserId), 
        {
            title: this.data.shareTitle,
            path: t
        };
    },
    showVideo: function(t) {
        this.setData({
            currentVideo: t.currentTarget.dataset.video,
            showVideo: !0
        });
    },
    closeVideo: function() {
        this.setData({
            currentVideo: "",
            showVideo: !1
        });
    },
    _getBoxSizes: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    typeHeight: e.windowHeight - 54 - 60 + "px"
                });
            }
        });
    },
    getCategory: function() {
        var a = this;
        t.httpGet(e.getUrl("ServiceShop/GetProductCategory"), {
            serviceShopId: this.data.serviceShopId
        }, function(t) {
            t.success && (t.data && (t.data.unshift({
                Id: 0,
                Name: "全部"
            }), a.setData({
                categoryList: t.data
            })), a.getProductList());
        });
    },
    getStoreInfo: function() {
        var o = this;
        wx.showLoading(), t.httpGet(e.getUrl("ServiceShop/Detail"), {
            shopBranchId: wx.getStorageSync("shopBranchId"),
            serviceShopId: this.data.serviceShopId
        }, function(t) {
            return wx.hideLoading(), t.success ? (o.setData({
                current: t.data,
                pageLoaded: !0
            }, function() {
                t.data.ServiceType === a.type.real && (o.serviceCart = o.selectComponent("#serviceCart")), 
                o.loadData();
            }), wx.setNavigationBarTitle({
                title: t.data.Name
            }), void e.getShareConfig(function(t) {
                var e = t.productShareTitle.replace(/{shequ}/g, o.data.current.Name);
                e = (e = e.replace(/{productname}/g, "")).replace(/{price}/g, ""), o.setData({
                    shareTitle: e
                });
            })) : 600 === t.code ? wx.showModal({
                content: t.msg,
                showCancel: !1,
                success: function(t) {
                    t.confirm && e.busEmit("services", "../services/services");
                }
            }) : void wx.showToast({
                title: t.msg
            });
        });
    },
    loadData: function() {
        this.getCategory();
    },
    getProductList: function() {
        var a = this;
        this.data.loadingList || (this.setData({
            loadingList: !0
        }), t.httpGet(e.getUrl("ServiceShop/ProductList"), {
            openId: e.globalData.openId,
            serviceShopId: this.data.serviceShopId,
            pageNo: this.data.pageNo,
            categoryId: this.data.categoryId,
            pageSize: this.data.pageSize,
            keyWords: this.data.keyWord
        }, function(t) {
            if (wx.stopPullDownRefresh(), a.setData({
                loadingList: !1
            }), t.success) {
                var e = t.data.products, o = e.length < a.data.pageSize, i = 1 == a.data.pageNo && 0 == e.length, r = 1 == a.data.pageNo ? [] : a.data.products;
                r.push.apply(r, e), a.setData({
                    products: r,
                    pageEnd: o,
                    empty: i
                }), a.serviceCart && (1 == a.data.pageNo ? a.serviceCart.getCartData() : a.updateproduct());
            } else wx.showToast({
                title: "系统数据异常",
                icon: "none"
            });
        }));
    },
    onReachBottom: function() {
        this.data.pageEnd || (this.setData({
            pageNo: this.data.pageNo + 1
        }), this.getProductList());
    },
    productNumChange: function(t) {
        this.serviceCart.numChange(t, function(t) {
            if (!t.success) return wx.showToast({
                title: t.msg,
                icon: "none"
            });
            wx.showToast({
                title: "加入购物车成功",
                icon: "none"
            });
        });
    },
    updateproduct: function() {
        this.data.products.map(function(t) {
            e.globalData.serviceCartData[t.Id] ? t.Quantity = e.globalData.serviceCartData[t.Id] : t.Quantity = 0;
        }), this.setData({
            products: this.data.products
        });
    },
    goProduct: function(t) {
        wx.navigateTo({
            url: "/pages/serviceProductdetail/serviceProductdetail?id=" + t.currentTarget.dataset.id + "&serviceShopId=" + this.data.serviceShopId + "&serviceType=" + this.data.current.ServiceType + "&serviceName=" + this.data.current.Name
        });
    },
    callShopTel: function(t) {
        wx.makePhoneCall({
            phoneNumber: t.currentTarget.dataset.tel,
            fail: function(t) {}
        });
    },
    openMap: function() {
        wx.openLocation({
            latitude: this.data.current.Latitude,
            longitude: this.data.current.Longitude
        });
    },
    onBuy: function(t) {
        var a = t.currentTarget.dataset.id;
        e.getOpenId(function(t) {
            wx.navigateTo({
                url: "../ordersubmit/ordersubmit?count=1&&deliver=1&isServiceShop=1&shopBranchId=" + wx.getStorageSync("shopBranchId") + "&productId=" + a
            });
        });
    },
    onChangeCategory: function(t) {
        var e = t.currentTarget.dataset.id;
        this.setData({
            categoryId: e,
            products: [],
            pageNo: 1
        }), this.getProductList();
    },
    onInputKeyword: function(t) {
        var e = this, a = t.detail.value;
        e.setData({
            keyWord: a
        }), a ? (clearTimeout(this.searchTimer), this.searchTimer = setTimeout(function() {
            e.onConfirmSearch();
        }, 500)) : e.onConfirmSearch();
    },
    onConfirmSearch: function() {
        this.setData({
            pageEnd: !1,
            empty: !1,
            categoryId: 0,
            pageNo: 1
        }), this.getProductList();
    }
});