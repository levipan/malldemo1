var t = require("../../utils/config.js"), a = getApp(), o = require("../../utils/busEvent");

Page({
    data: {
        ShopBranchName: "",
        start: "",
        end: ""
    },
    onLoad: function() {
        this.loadData();
    },
    onReady: function() {
        setTimeout(function() {
            wx.setNavigationBarColor({
                backgroundColor: "#ffffff",
                frontColor: "#000000"
            });
        }, 1e3);
    },
    loadData: function() {
        var e = this;
        this.data.loading || (this.setData({
            loading: !0
        }), t.httpGet(a.getUrl("Home/GetStoreInfo"), {
            Id: wx.getStorageSync("shopBranchId"),
            fromLatLng: wx.getStorageSync("o2oFromLatLng"),
            openId: a.globalData.openId
        }, function(t) {
            e.setData({
                loading: !1
            }), t.success && (e.setData({
                ShopBranchName: t.data.ShopBranchName,
                start: t.data.WorkingBeginTime || "",
                end: t.data.WorkingEndTime || ""
            }), wx.stopPullDownRefresh(), t.data.IsClose || o.emit("tabUserChange", {
                url: "../index/index",
                reload: !0
            }));
        }));
    },
    onPullDownRefresh: function() {
        this.loadData();
    },
    goToStores: function() {
        wx.navigateTo({
            url: "../userpickupstation/userpickupstation"
        });
    }
});