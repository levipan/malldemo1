var a = getApp();

Page({
    data: {
        isEmpty: !1,
        pageIndex: 1,
        pageSize: 10,
        AfterList: null,
        isEnd: !1
    },
    onLoad: function(t) {
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: a.globalData.PrimaryColor
        });
    },
    loadData: function(t, e) {
        var n = this;
        n.data.isEnd && e || (wx.showLoading({
            title: "加载中"
        }), wx.request({
            url: a.getUrl("MyOrderRefund/GetList"),
            data: {
                openId: a.globalData.openId,
                pageIndex: n.data.pageIndex,
                pageSize: n.data.pageSize
            },
            success: function(e) {
                if (wx.hideLoading(), (e = e.data).success) {
                    var o = e.data.Data;
                    if (o.length < n.data.pageSize && n.setData({
                        isEnd: !0
                    }), t) {
                        var i = n.data.AfterList;
                        i.push.apply(i, o), n.setData({
                            AfterList: i
                        });
                    } else {
                        var d = o.length <= 0;
                        n.setData({
                            AfterList: o,
                            isEmpty: d
                        });
                    }
                } else "502" == e.code ? wx.navigateTo({
                    url: "../login/login"
                }) : wx.showModal({
                    title: "提示",
                    content: e.msg,
                    confirmColor: a.globalData.PrimaryColor,
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        }));
    },
    applydetail: function(a) {
        a.currentTarget.dataset.type;
        var t = a.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../refunddetail/refunddetail?id=" + t
        });
    },
    SendGood: function(a) {
        var t = a.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../expressdelivery/expressdelivery?refundId=" + t
        });
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        a.setData({
            pageIndex: this.data.pageIndex
        }), a.loadData(!1, !0);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var a = this, t = a.data.pageIndex + 1;
        a.setData({
            pageIndex: t
        }), a.loadData(!0, !0);
    }
});