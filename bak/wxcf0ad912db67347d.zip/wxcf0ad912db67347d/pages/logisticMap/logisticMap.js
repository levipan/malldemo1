function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = getApp(), e = require("../../utils/config.js");

Page({
    data: {
        statusCode: 0,
        showPhone: "",
        statusMsg: "",
        showTime: "",
        markers: [],
        dadaInfo: {}
    },
    loadData: function() {
        var e = this;
        a.getOpenId(function(a) {
            e._getDadaInfo(function(a) {
                var s = a.data.result;
                if (a.success) {
                    var r = [];
                    if (r.push({
                        id: 1,
                        iconPath: "../../images/default-logo.png",
                        latitude: s.supplierLat,
                        longitude: s.supplierLng,
                        width: 34,
                        height: 34,
                        callout: {
                            content: s.supplierName,
                            padding: 10,
                            borderRadius: 2,
                            display: "ALWAYS"
                        }
                    }), 1 != s.statusCode) {
                        var n = s.statusMsg;
                        2 == s.statusCode && (n = "骑士正赶往商家"), 3 == s.statusCode && (n = "骑士正在送货"), s.statusCode >= 4 && (n = "已送达"), 
                        r.push({
                            id: 2,
                            iconPath: "../../images/dada.png",
                            width: 34,
                            height: 34,
                            latitude: s.transporterLat,
                            longitude: s.transporterLng,
                            callout: {
                                content: n,
                                padding: 10,
                                borderRadius: 2,
                                display: "ALWAYS"
                            }
                        }), e._getPositin();
                    }
                    e.data.markers = [].concat(t(e.data.markers), r), e.setData({
                        dadaInfo: s,
                        markers: e.data.markers,
                        statusMsg: s.statusMsg,
                        statusCode: s.statusCode,
                        showPhone: 1 == s.statusCode ? s.supplierPhone : s.transporterPhone
                    });
                    var d = [ {
                        latitude: e.data.latitude,
                        longitude: e.data.longitude
                    }, {
                        latitude: s.supplierLat,
                        longitude: s.supplierLng
                    } ];
                    s.transporterLat && s.transporterLng && d.push({
                        latitude: s.transporterLat,
                        longitude: s.transporterLng
                    }), e.mapCtx.includePoints({
                        points: d,
                        padding: [ "100", "100", "100", "100" ]
                    });
                }
            });
        });
    },
    onLoad: function(t) {
        var a = this, e = t.latitude, s = t.longitude, r = t.orderId;
        this.mapCtx = wx.createMapContext("map", this);
        var n = {
            id: 0,
            iconPath: "../../images/marker.png",
            latitude: e,
            longitude: s,
            width: 34,
            height: 34
        };
        this.data.markers.push(n), this.setData({
            orderId: r,
            longitude: s,
            latitude: e,
            markers: this.data.markers
        }, function() {
            a.loadData();
        });
    },
    onUnload: function() {
        clearInterval(this.datatimer);
    },
    _getDadaInfo: function(t) {
        var s = this;
        a.getOpenId(function(r) {
            r && e.httpGet(a.getUrl("MyOrder/GetDadaOrderDetail"), {
                openId: r,
                orderId: s.data.orderId
            }, function(a) {
                t && t(a);
            });
        });
    },
    _getPositin: function() {
        var t = this;
        this.datatimer = setInterval(function() {
            t._getDadaInfo(function(a) {
                var e = a.data.result, s = {};
                if (a.success) {
                    if (1 != e.statusCode) {
                        var r = e.statusMsg;
                        2 == e.statusCode && (r = "骑士正赶往商家"), 3 == e.statusCode && (r = "骑士正在送货"), e.statusCode >= 4 && (r = "已送达", 
                        clearInterval(t.datatimer)), s = {
                            id: 2,
                            iconPath: "../../images/dada.png",
                            width: 34,
                            height: 34,
                            latitude: e.transporterLat,
                            longitude: e.transporterLng,
                            callout: {
                                content: r,
                                padding: 10,
                                borderRadius: 2,
                                display: "ALWAYS"
                            }
                        };
                    }
                    t.data.markers[2] = s, t.setData({
                        dadaInfo: e,
                        statusMsg: e.statusMsg,
                        statusCode: e.statusCode,
                        showPhone: 1 == e.statusCode ? e.supplierPhone : e.transporterPhone,
                        markers: t.data.markers
                    });
                }
            });
        }, 1e4);
    },
    phoneCall: function(t) {
        wx.makePhoneCall({
            phoneNumber: t.currentTarget.dataset.phone
        });
    }
});