function t(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var a = require("../../utils/config.js"), e = getApp(), i = e.add, s = e.subtract, r = (e.multiply, 
e.divide, null), o = (new Array(), new Array(), new Array(), new Array(), 0), d = 0, n = 0, l = 0, h = [];

Page({
    staticData: {},
    data: t({
        pageLoading: !1,
        isSubmitting: !1,
        couponHide: !0,
        isUseIntegral: !1,
        isClose: !1,
        userIntegralMaxRate: 1,
        integralPerMoneyRate: 0,
        userIntegrals: 0,
        deductionPoints: 0,
        pointsDeductionMoney: 0,
        maxDeductionPoints: 0,
        maxPointsDeductionMoney: 0,
        isUseCapitalAmount: !1,
        passwordHide: !0,
        usedCapitalAmount: "0.00",
        pwd: "",
        againPwd: "",
        confirmedPwd: !1,
        deliveryType: 4,
        billHide: !0,
        getRequestUrl: e.getRequestUrl,
        remark: "",
        areatf: !1,
        isGiftOrder: "",
        giftid: "",
        products: [],
        templateList: [],
        appletTemplate: [],
        roomId: 0,
        addressData: {
            name: "",
            phone: "",
            address: "",
            fullName: "",
            regionId: "",
            id: 0
        },
        showOrderComfirm: !1,
        orderInfo: {},
        showAddress: !1,
        productErrorList: [],
        showDaDa: !1,
        promptMsg: "",
        isPickedUp: !1,
        giftFormData: null
    }, "isSubmitting", !1),
    onLoad: function(t) {
        var a = this, i = t.cartItemIds || "", s = t.skuid || "", r = t.count || 0, o = t.isSelfSupport || 0, d = t.shopBranchId || 0, n = t.isServiceShop || 0, l = t.roomId || 0, h = t.productId || "", u = wx.getStorageSync("defaultAddr") || {}, c = t.bargainId || 0, p = t.bargainTeamId || 0, f = t.flashSaleId || 0;
        this.setData({
            deliver: t.deliver ? t.deliver : "",
            isGiftOrder: t.isGiftOrder ? t.isGiftOrder : "",
            giftid: t.giftid ? t.giftid : "",
            isSelfSupport: o,
            defaultAddr: u,
            productId: h,
            isServiceShop: n,
            roomId: l,
            showAddress: t.deliver > 1,
            isGiftSubmit: "giftSubmit" === t.type,
            bargainId: c,
            bargainTeamId: p,
            flashSaleId: f
        }), this.setData({
            options: t
        }), this.staticData.form = {
            openId: e.globalData.openId,
            cartItemIds: i,
            skuid: s,
            isSelfSupport: o,
            isServiceShop: n,
            count: r,
            roomId: l,
            isNewExclusive: t.isNewExclusive || !1,
            shopBranchId: d,
            productDeliveryType: t.deliver,
            isGiftOrder: t.isGiftOrder || !1,
            addressId: 0,
            products: t.products || "",
            groupSolitaireId: t.groupSolitaireId || ""
        }, "groupSubmit" === t.type && (this.staticData.form.fightGroupActiveId = t.fightGroupActiveId, 
        this.staticData.form.fightGroupId = t.fightGroupId), c && (this.staticData.form.bargainId = c, 
        this.staticData.form.bargainTeamId = p), f && (this.staticData.form.flashSaleId = f), 
        "giftSubmit" === t.type && (this.staticData.giftForm = {
            openId: e.globalData.openId,
            quantity: t.quantity,
            type: "integralPro" === t.giftType ? 0 : 1,
            id: t.giftId
        }), h && (this.staticData.form.productId = h), this.loadData(), wx.request({
            url: e.getUrl("Common/GetWeiXinMsgTemplateListByApplet"),
            data: {
                openId: e.globalData.openId
            },
            success: function(t) {
                (t = t.data).success && a.setData({
                    templateList: t.data
                });
            }
        }), e.getSysSettingData(function(t) {
            t.isShowShopBranchLink = e.globalData.IsShowShopBranchLink, a.setData(t);
        });
    },
    onShow: function() {
        e.globalData.cacheAddress && this.staticData.selectAddress && (this.setData({
            address: e.globalData.cacheAddress.address + e.globalData.cacheAddress.addressDetail,
            shipTo: e.globalData.cacheAddress.name,
            cellPhone: e.globalData.cacheAddress.phone
        }), this.staticData.form.addressId = e.globalData.cacheAddress.addressId, this.loadData());
    },
    loadData: function() {
        var t = this;
        wx.showLoading(), this.data.isSelfSupport ? a.httpGet(e.getUrl("Order/ConfirmCommunitySelfOrder"), this.staticData.form, function(a) {
            t._confirmOrderCallback(a);
        }) : this.data.isServiceShop ? a.httpGet(e.getUrl("Order/ConfirmServiceShopOrder"), this.staticData.form, function(a) {
            t._confirmOrderCallback(a);
        }) : this.staticData.form.groupSolitaireId ? a.httpPost(e.getUrl("Order/ConfirmGroupSolitaireOrder"), this.staticData.form, function(a) {
            t._confirmOrderCallback(a);
        }) : "giftSubmit" !== this.data.options.type ? wx.request({
            url: e.getUrl("Order/GetConfirmOrder"),
            data: this.staticData.form,
            success: function(a) {
                a = a.data, t._confirmOrderCallback(a);
            }
        }) : this.loadPreGiftOrder();
    },
    _confirmOrderCallback: function(t) {
        wx.hideLoading();
        var a = this;
        if (t.success) {
            var r = t.data;
            r.Coupons && r.Coupons.forEach(function(t) {
                t.Begin = t.Begin.substr(0, 10), t.End = t.End.substr(0, 10);
            });
            var o = r.DeliveryFee, d = s(r.TotalAmount, r.ChoiceCoupon ? r.ChoiceCoupon.Amount : 0);
            a.data.isGiftOrder && (d = 0), r.IsFreeFreight && d >= r.FreeFreightAmount && (o = 0);
            var n = r.Items, l = this.staticData.form.cartItemIds.split(","), h = r.TotalAmount;
            if (2 === parseInt(this.data.deliver)) {
                h = 0, n = [], l = [];
                var u = [];
                r.Items.map(function(t) {
                    t.Message ? u.push(t) : (h = i(h, t.Total), l.push(t.CartId), n.push(t));
                }), this.setData({
                    productErrorList: u
                }), d = s(h, r.ChoiceCoupon ? r.ChoiceCoupon.Amount : 0);
            }
            var c = !1, p = !1;
            3 == this.data.deliver && (c = -1 != r.AllowDeliverTypes.indexOf(6), p = -1 != r.AllowDeliverTypes.indexOf(1)), 
            r.PromptMsg && wx.showModal({
                content: r.PromptMsg,
                showCancel: !1
            }), this.setData({
                showDaDa: c,
                isPickedUp: p,
                promptMsg: r.PromptMsg || "",
                isClose: r.IsClose,
                freeFreightAmount: r.FreeFreightAmount,
                isFreeFreight: r.IsFreeFreight,
                products: n,
                productAmount: a.data.isGiftOrder ? 0 : h,
                fullDiscount: r.FullDiscount,
                cartItemIds: l,
                allowDeliverTypes: r.AllowDeliverTypes,
                coupons: r.Coupons,
                choiceCoupon: r.ChoiceCoupon,
                userIntegrals: r.Integral ? r.Integral.Integral : 0,
                userIntegralMaxRate: r.Integral ? r.Integral.MaxRate / 100 : 0,
                integralPerMoneyRate: r.Integral ? r.Integral.Rule : 0,
                capitalAmount: r.CapitalAmount.toFixed(2),
                shopBranchId: parseInt(this.staticData.form.shopBranchId),
                shopShipper: r.ShopShipper ? r.ShopShipper : "",
                branch: r.Branch,
                deliveryFee: r.Branch.DeliveryFee,
                serviceShop: r.ServiceShop || {},
                deliverf: o,
                initFee: o,
                isLimitBuy: r.IsLimitBuy ? r.IsLimitBuy : "",
                skuid: this.staticData.form.skuid,
                count: this.staticData.form.count,
                groupHeaderDiscount: r.FGHeaderDiscount,
                pageLoading: !0
            }), 1 == this.data.deliver ? this.setData({
                shipTo: r.ShipTo,
                deliveryType: r.AllowDeliverTypes[0],
                cellPhone: r.CellPhone || "",
                address: r.Address ? r.Address : ""
            }) : (!this.staticData.selectAddress && r.ShippingAddress && (this.setData({
                shipTo: r.ShippingAddress.ShipTo,
                cellPhone: r.ShippingAddress.CellPhone || "",
                address: r.ShippingAddress.Address + " " + r.ShippingAddress.AddressDetail
            }), this.staticData.form.addressId = r.ShippingAddress.Id), this.staticData.selectAddress || this.setData({
                deliveryType: r.AllowDeliverTypes[0]
            })), 1 == this.data.deliver ? (this.setData({
                orderAmount: d
            }), 2 != r.AllowDeliverTypes[0] && 2 != r.AllowDeliverTypes[1] || this.setData({
                orderAmount: i(d, 2 == r.AllowDeliverTypes[0] ? r.Branch.DeliveryFee : 0)
            })) : 3 == this.data.deliver ? this.setData({
                deliveryFee: this.data.deliverf,
                orderAmount: i(parseFloat(d.toFixed(2)), 6 === this.data.deliveryType ? parseFloat(this.data.deliverf ? this.data.deliverf : 0) : 0)
            }) : this.setData({
                deliveryFee: this.data.deliverf,
                orderAmount: i(parseFloat(d.toFixed(2)), parseFloat(this.data.deliverf ? this.data.deliverf : 0)),
                deliveryType: 4
            }), this.calcPointMaxCanUse(), this.getHasSetPayPwd(), this.data.isUseCapitalAmount && this.countCapital();
        } else "502" == t.code ? wx.navigateTo({
            url: "../login/login"
        }) : e.showErrorModal(t.msg, function(a) {
            a.confirm && ("18" == t.code ? wx.switchTab({
                url: "../index/index"
            }) : wx.navigateBack({
                delta: 1
            }));
        });
    },
    setAppletTemplate: function() {
        for (var t = this, a = [], e = 0; e < t.data.templateList.length; e++) 1 == t.data.isSelfSupport || 1 == t.data.isServiceShop ? 19 == t.data.templateList[e].MessageType && a.push(t.data.templateList[e].TemplateId) : t.staticData.form.fightGroupActiveId > 0 ? 25 != t.data.templateList[e].MessageType && 26 != t.data.templateList[e].MessageType || a.push(t.data.templateList[e].TemplateId) : 1 == t.data.deliveryType && 13 == t.data.templateList[e].MessageType ? a.push(t.data.templateList[e].TemplateId) : 2 == t.data.deliveryType && 15 == t.data.templateList[e].MessageType ? a.push(t.data.templateList[e].TemplateId) : 4 == t.data.deliveryType && 18 == t.data.templateList[e].MessageType ? a.push(t.data.templateList[e].TemplateId) : 19 == t.data.templateList[e].MessageType && a.push(t.data.templateList[e].TemplateId);
        t.setData({
            appletTemplate: a
        });
    },
    changeShipTo: function(t) {
        this.setData({
            shipTo: t.detail.value
        });
    },
    changeCellPhone: function(t) {
        this.setData({
            cellPhone: t.detail.value
        });
    },
    changeAddress: function(t) {
        this.setData({
            address: t.detail.value
        });
    },
    changeDeliverType: function(t) {
        var a = parseFloat(t.currentTarget.dataset.type);
        this.setData({
            deliveryType: a,
            showAddress: this.data.deliver > 1 && 6 === a
        }), this.caleOrderAmount(), this.data.isUseCapitalAmount && this.changeIsUseCapitalAmount();
    },
    hideCoupon: function(t) {
        this.setData({
            areatf: !1,
            couponHide: !0
        });
    },
    openChooseCoupon: function(t) {
        this.setData({
            couponHide: !1,
            areatf: !0
        });
    },
    selectCoupon: function(t) {
        var a = t.currentTarget.dataset.index, e = {};
        "0" == t.currentTarget.dataset.id ? e = null : Object.assign(e, this.data.coupons[a]), 
        this.setData({
            choiceCoupon: e,
            couponHide: !0,
            areatf: !1
        }), this.calcPointMaxCanUse(), this.caleOrderAmount();
    },
    bindRemarkInput: function(t) {
        this.data.remark = t.detail.value;
    },
    caleOrderAmount: function() {
        var t = 0, a = this.data.productAmount, e = 2 == this.data.deliveryType || 4 == this.data.deliveryType || 6 === this.data.deliveryType ? this.data.deliveryFee : 0, i = this.data.choiceCoupon ? this.data.choiceCoupon.Amount : 0, r = this.data.productAmount - (this.data.choiceCoupon ? this.data.choiceCoupon.Amount : 0);
        3 == this.data.deliver ? 6 === this.data.deliveryType ? this.setData({
            deliverf: this.data.initFee
        }) : this.setData({
            deliverf: 0
        }) : (4 == this.data.deliveryType && this.data.isFreeFreight && r >= this.data.freeFreightAmount && (e = 0, 
        this.setData({
            deliverf: 0
        })), this.setData({
            deliverf: this.data.initFee
        })), t = a - i + e, this.data.deductionPoints > 0 && this.data.isUseIntegral && (t -= this.data.pointsDeductionMoney);
        var o = this.data.usedCapitalAmount ? parseFloat(this.data.usedCapitalAmount).toFixed(2) : 0;
        o = parseFloat(o), parseFloat(o) > t && (o = t, this.setData({
            usedCapitalAmount: t ? t.toFixed(2) : "0.00"
        })), o ? this.setData({
            orderAmount: s(t, o).toFixed(2)
        }) : this.setData({
            orderAmount: (t < 0 ? 0 : t).toFixed(2)
        });
    },
    ChkUsePoint: function(t) {
        t.detail.value ? this.setData({
            isUseIntegral: !0,
            deductionPoints: this.data.maxDeductionPoints,
            pointsDeductionMoney: this.data.maxPointsDeductionMoney
        }) : this.setData({
            isUseIntegral: !1,
            deductionPoints: 0,
            pointsDeductionMoney: 0
        }), this.caleOrderAmount();
    },
    calcPointMaxCanUse: function() {
        var t = 0, a = this.data.productAmount, i = this.data.choiceCoupon ? this.data.choiceCoupon.Amount : 0;
        t = e.MoneyRound(a - i, 2);
        var s = e.MoneyFix2(100 * e.mul(t, this.data.userIntegralMaxRate) / 100);
        s > t && (s = t);
        var r = Math.ceil((s * this.data.integralPerMoneyRate).toFixed(2));
        r > this.data.userIntegrals && (r = this.data.userIntegrals, (s = e.div(Math.floor(e.mul(e.div(r, this.data.integralPerMoneyRate), 100)), 100)) > t && (s = t)), 
        this.setData({
            maxDeductionPoints: r,
            maxPointsDeductionMoney: s,
            deductionPoints: r,
            pointsDeductionMoney: s
        });
    },
    onInputIntegral: function(t) {
        var a = t.detail.value;
        /[^\d|.]/.test(a) && (a = a.replace(/[^\d|.]/g, "")), this.data.maxDeductionPoints < a && (a = this.data.maxDeductionPoints);
        var i = e.div(Math.floor(e.mul(e.div(a, this.data.integralPerMoneyRate), 100)), 100);
        i > this.data.maxPointsDeductionMoney && (i = this.data.maxPointsDeductionMoney), 
        this.setData({
            deductionPoints: a,
            pointsDeductionMoney: i
        }), this.caleOrderAmount();
    },
    changeIsUseCapitalAmount: function() {
        this.setData({
            isUseCapitalAmount: !this.data.isUseCapitalAmount
        }), this.data.isUseCapitalAmount && !this.data.confirmedPwd && this.setData({
            passwordHide: !1,
            pwd: "",
            againPwd: ""
        }), this.data.isUseCapitalAmount || this.setData({
            usedCapitalAmount: "0.00"
        }), this.caleOrderAmount(), this.data.isUseCapitalAmount && this.countCapital();
    },
    formatCapitalAmount: function(t) {
        var a = t.detail.value;
        this.setData({
            usedCapitalAmount: a || "0.00"
        });
    },
    onInputCapitalAmount: function(t) {
        var a = t.detail.value;
        /[^\d|.]/.test(a) && (a = a.replace(/[^\d|.]/g, "")), a = a.replace(/^(\-)*(\d+)\.(\d\d).*$/, "$1$2.$3"), 
        this.setData({
            usedCapitalAmount: a
        }), this.caleOrderAmount();
    },
    countCapital: function() {
        var t = this.data.capitalAmount ? parseFloat(this.data.capitalAmount) : 0, a = this.data.orderAmount ? parseFloat(this.data.orderAmount) : 0;
        t < a ? this.setData({
            usedCapitalAmount: parseFloat(t.toFixed(2))
        }) : this.setData({
            usedCapitalAmount: a.toFixed(2)
        }), this.setData({
            orderAmount: s(a, parseFloat(this.data.usedCapitalAmount)).toFixed(2)
        });
    },
    handleCancelConfirm: function() {
        this.setData({
            showOrderComfirm: !1
        });
    },
    handleOkConfirm: function() {},
    handleOrderConfirm: function() {
        if (!this.data.promptMsg) {
            if (2 == this.data.deliveryType || 4 == this.data.deliveryType || 6 == this.data.deliveryType) {
                if (!this.data.address) return void wx.showToast({
                    title: "请填写收货地址",
                    icon: "none"
                });
                if (2 == this.data.deliveryType && this.data.address.length > 20) return void wx.showToast({
                    title: "收货地址不得超过20个字",
                    icon: "none"
                });
                if (4 == this.data.deliveryType && this.data.address.length > 50) return void wx.showToast({
                    title: "收货地址不得超过50个字",
                    icon: "none"
                });
            }
            if (this.data.shipTo) if (11 == this.data.cellPhone.length) if (this.data.products.length <= 0) wx.showToast({
                title: "商品不可购买",
                icon: "none"
            }); else {
                if (!e.globalData.ShowOrderConfirm) return this.submitOrder();
                var t = {};
                1 === parseInt(this.data.deliver) ? 2 === this.data.deliveryType ? (t.warning = "此订单需要团长配送，请仔细确认地址！", 
                t.city = "收货人：" + this.data.shipTo, t.address = this.data.address.replace("/,/g", "")) : this.data.isServiceShop ? (t.warning = "此订单需要到店核销，请仔细确认地址！", 
                t.city = "核销门店：" + this.data.serviceShop.Name, t.address = this.data.serviceShop.Address) : (t.warning = "此订单需要到店自提，请仔细确认地址！", 
                t.city = "自提门店：" + this.data.branch.ShopBranchName, t.address = this.data.branch.RegionFullName) : 3 === parseInt(this.data.deliver) ? 1 == this.data.deliveryType ? (t.warning = "此订单需要到店自提，请仔细确认地址！", 
                t.city = "自提门店：" + this.data.branch.ShopBranchName, t.address = this.data.branch.RegionFullName) : (t.warning = "此订单需要达达配送，请仔细确认地址！", 
                t.city = "收货人：" + this.data.shipTo, t.address = this.data.address.replace("/,/g", "")) : (t.warning = "此订单需要快递发货，请仔细确认地址！", 
                t.city = "收货人：" + this.data.shipTo, t.address = this.data.address.replace("/,/g", "")), 
                this.setData({
                    showOrderComfirm: !0,
                    orderInfo: t
                });
            } else wx.showToast({
                title: "请填写正确的收货人手机",
                icon: "none"
            }); else wx.showToast({
                title: "请填写收货人信息",
                icon: "none"
            });
        }
    },
    submitOrder: function() {
        var t = this;
        if (!this.data.isSubmitting) {
            this.setData({
                isSubmitting: !0
            });
            var i = [];
            this.data.products.forEach(function(t) {
                i.push({
                    ProductId: t.ProductId,
                    SkuId: t.SkuId,
                    Quantity: t.Quantity,
                    roomId: t.RoomId
                });
            });
            var s = {
                openId: e.globalData.openId,
                deliveryType: this.data.deliveryType,
                shipTo: this.data.shipTo,
                cellPhone: this.data.cellPhone,
                address: this.data.address,
                addressId: this.staticData.form.addressId,
                useIntegral: this.data.isUseIntegral ? this.data.deductionPoints : 0,
                useCapital: this.data.usedCapitalAmount,
                payPassword: this.data.pwd,
                couponId: this.data.choiceCoupon ? this.data.choiceCoupon.RecordId : 0,
                couponType: this.data.choiceCoupon ? this.data.choiceCoupon.Type : 0,
                remark: this.data.remark,
                paymentType: 1,
                deliveryFee: 2 == this.data.deliveryType || 4 == this.data.deliveryType || 6 == this.data.deliveryTyp ? this.data.deliveryFee : 0,
                formId: "",
                cartItems: this.data.cartItemIds,
                branchId: this.data.shopBranchId,
                skuItems: i,
                isSelfSupport: this.data.isSelfSupport,
                isGiftOrder: this.data.isGiftOrder,
                memberGiftId: this.data.giftid,
                isServiceShop: this.data.isServiceShop,
                IsFrontWareHouse: 3 === parseInt(this.data.deliver),
                groupSolitaireId: this.staticData.form.groupSolitaireId,
                isNewExclusive: this.staticData.form.isNewExclusive,
                fightGroupActiveId: this.staticData.form.fightGroupActiveId,
                fightGroupId: this.staticData.form.fightGroupId,
                bargainId: this.staticData.form.bargainId,
                bargainTeamId: this.staticData.form.bargainTeamId,
                flashSaleId: this.staticData.form.flashSaleId
            };
            this.data.productId && (s.productId = this.data.productId), this.data.isSelfSupport ? a.httpPost(e.getUrl("Order/SubmitShopBranchOrder"), s, function(a) {
                t._submitOrderCallBack(a);
            }) : this.data.isServiceShop ? a.httpPost(e.getUrl("Order/SubmitServiceShopOrder"), s, function(a) {
                t._submitOrderCallBack(a);
            }) : this.staticData.form.groupSolitaireId ? a.httpPost(e.getUrl("Order/SubmitGroupSolitaireOrder"), s, function(a) {
                t._submitOrderCallBack(a);
            }) : a.httpPost(e.getUrl("Order/SubmitOrder"), s, function(a) {
                t._submitOrderCallBack(a);
            });
        }
    },
    _submitOrderCallBack: function(t) {
        var a = this;
        if (t.success) {
            var i = JSON.parse(wx.getStorageSync("solitaireCartData") || "{}"), s = this.data.shopBranchId;
            i[s] && (delete i[s], wx.setStorageSync("solitaireCartData", JSON.stringify(i))), 
            e.getCartAllData({
                shopBranchId: this.data.shopBranchId
            }), this.setAppletTemplate(), t = t.data, this.staticData.form.isNewExclusive && (e.globalData.isHideNewUserActive = !0), 
            t.NeedPay ? e.orderPay(t.OrderId, 0, !1, this.data.appletTemplate, function(e) {
                a._toPayResult(t, e);
            }, this.data.isServiceShop ? 2 : 0, this.staticData.form.groupSolitaireId) : (console.log("this.data.appletTemplate.length:" + this.data.appletTemplate), 
            null != this.data.appletTemplate && this.data.appletTemplate.length > 0 ? wx.requestSubscribeMessage({
                tmplIds: this.data.appletTemplate,
                success: function(a) {
                    if ("requestSubscribeMessage:ok" == a.errMsg) {
                        var i = Object.keys(a).filter(function(t) {
                            return "accept" === a[t];
                        });
                        if (i.length > 0) {
                            var s = i.join(",");
                            console.log("authorizedTemplateIds:" + s), wx.request({
                                url: e.getUrl("Common/GetAuthorizedSubscribeMessage"),
                                data: {
                                    templateIds: s,
                                    orderId: t.OrderId,
                                    openId: e.globalData.openId
                                },
                                success: function(t) {}
                            });
                        }
                    }
                },
                fail: function(t) {
                    20004 === t.errCode && wx.showModal({
                        title: "提示",
                        content: "建议开启订阅消息，接收商城发送的消息通知",
                        cancelText: "取消",
                        confirmText: "去开启",
                        showCancel: !0,
                        success: function(t) {
                            wx.openSetting({});
                        }
                    });
                },
                complete: function(e) {
                    a._toPayResult(t);
                }
            }) : this._toPayResult(t));
        } else e.showErrorModal(t.msg), this.setData({
            isSubmitting: !1
        });
    },
    _toPayResult: function(t, a) {
        return a && a.fail ? wx.redirectTo({
            url: "/pages/orderlist/orderlist?status=0"
        }) : "groupSubmit" === this.data.options.type ? wx.redirectTo({
            url: "/subPages/groupDetail/groupDetail?orderId=" + t.OrderId
        }) : void wx.redirectTo({
            url: "../ordersuccess/ordersuccess?orderid=" + t.OrderId + "&orderType=" + (this.data.isServiceShop ? 2 : 0)
        });
    },
    hidePassword: function() {
        this.setData({
            isUseCapitalAmount: !1,
            passwordHide: !0,
            usedCapitalAmount: "0.00"
        }), this.caleOrderAmount();
    },
    getHasSetPayPwd: function() {
        var t = this;
        a.httpGet(e.getUrl("Payment/GetHasSetPayPwd"), {
            openId: e.globalData.openId
        }, function(a) {
            a.success && t.setData({
                hasSetPayPwd: !0
            });
        });
    },
    onInputPwd: function(t) {
        this.setData({
            pwd: t.detail.value
        });
    },
    confirmPwd: function() {
        var t = this, i = this.data.pwd, s = this.data.againPwd;
        if (this.data.hasSetPayPwd) {
            if (i.length < 6) return void e.showErrorModal("请输入正确的密码");
            a.httpPost(e.getUrl("Payment/CheckPayPwd"), {
                openId: e.globalData.openId,
                pwd: i
            }, function(a) {
                a.success ? t.setData({
                    isUseCapitalAmount: !0,
                    passwordHide: !0,
                    confirmedPwd: !0
                }) : (t.setData({
                    isUseCapitalAmount: !1
                }), e.showErrorModal("支付密码错误"));
            });
        } else {
            if (i.length < 6) return void e.showErrorModal("支付密码不能少于6位");
            if ("" == s) return void e.showErrorModal("请确认密码");
            if (i != s) return void e.showErrorModal("两次密码输入不一致");
            a.httpPost(e.getUrl("Payment/PostSetPayPwd"), {
                openId: e.globalData.openId,
                pwd: i
            }, function(a) {
                a.success ? t.setData({
                    isUseCapitalAmount: !0,
                    passwordHide: !0,
                    confirmedPwd: !0,
                    hasSetPayPwd: !0
                }) : (t.setData({
                    isUseCapitalAmount: !1
                }), e.showErrorModal("设置密码失败"));
            });
        }
    },
    onInputAgainPwd: function(t) {
        this.setData({
            againPwd: t.detail.value
        });
    },
    changeArea: function(t) {
        var a = this;
        o = t.detail.value[0], d = t.detail.value[1], n = t.detail.value.length > 2 ? t.detail.value[2] : 0, 
        l = t.detail.value.length > 3 ? t.detail.value[3] : 0, a.setAreaData(o, d, n, l);
    },
    ArrayContains: function(t, a) {
        for (var e = t.length; e--; ) if (t[e] === a) return !0;
        return !1;
    },
    setProvinceCityData: function(t) {
        var a = this;
        null != t && (r = t);
        var e = r, i = [], s = [];
        for (var n in e) {
            var l = e[n].name, u = e[n].id;
            i.push(l), s.push(u), h.length > 0 && u == h[0] && (o = n);
        }
        a.setData({
            provinceName: i,
            provinceCode: s
        });
        var c = r.length > o ? r[o].city : r[0].city, p = [], f = [];
        for (var n in c) {
            var l = c[n].name, u = c[n].id;
            p.push(l), f.push(u), h.length > 1 && u == h[1] && (d = n);
        }
        a.setData({
            cityName: p,
            cityCode: f
        }), a.getSubRegion(c[d].id, c, d);
    },
    getSubRegion: function(t, i, s) {
        var r = this;
        a.httpGet(e.getUrl("MyShippingAddress/GetSub"), {
            parentId: t
        }, function(t) {
            if (t.success) {
                var a = t.data.Regions, e = [], i = [];
                if (null != a && a.length > 0) {
                    for (var d in a) {
                        var u = a[d].name, c = a[d].id;
                        e.push(u), i.push(c), h.length > 2 && c == h[2] && (n = d);
                    }
                    r.setData({
                        districtName: e,
                        districtCode: i
                    }), r.getSubStreet(a[n].id);
                } else r.setData({
                    districtName: [],
                    districtCode: [],
                    streetName: [],
                    streetCode: []
                });
                var p = [];
                p.push(o), p.push(s), p.push(n), p.push(l), r.setData({
                    value: p
                }), h = [];
            }
        }, !0);
    },
    getSubStreet: function(t, i, s) {
        var r = this;
        a.httpGet(e.getUrl("MyShippingAddress/GetSub"), {
            parentId: t
        }, function(t) {
            if (t.success) {
                var a = t.data.Regions, e = [], i = [];
                if (null != a && a.length > 0) {
                    e.push("其它"), i.push(0);
                    for (var s in a) {
                        var o = a[s].name, d = a[s].id;
                        e.push(o), i.push(d), h.length > 3 && d == h[3] && (l = s);
                    }
                    r.setData({
                        streetName: e,
                        streetCode: i
                    });
                } else r.setData({
                    streetName: [],
                    streetCode: []
                });
            }
        }, !0);
    },
    getItemIndex: function(t, a) {
        for (var e = t.length; e--; ) if (t[e] === a) return e;
        return -1;
    },
    setAreaData: function(t, a, i, s) {
        var o = this;
        void 0 == r || null == r ? wx.request({
            url: e.getUrl("MyShippingAddress/GetAll"),
            async: !0,
            success: function(t) {
                t.data.success && o.setProvinceCityData(t.data.data);
            },
            error: function(t) {}
        }) : o.setProvinceCityData(null);
    },
    bindChangePassword: function(t) {
        wx.navigateTo({
            url: "../userbindphone/userbindphone?formPage=changePwd"
        });
    },
    getChooseAddress: function() {
        this.staticData.selectAddress = !0, wx.navigateTo({
            url: "../addresslist/addresslist?type=2"
        });
    },
    onGiftSwitchChange: function(a) {
        var e = this, i = a.detail.value;
        this.data.confirmedPwd || this.setData({
            passwordHide: !1,
            pwd: "",
            againPwd: ""
        }), this.setData(t({
            isUseCapitalAmount: i
        }, "giftData.useCapital", this.data.giftData.gift.TotalAmount), function() {
            e.calcGiftOrderAmount();
        });
    },
    calcGiftOrderAmount: function() {
        var a, i = this.data, s = i.isUseCapitalAmount;
        if (i.isGiftSubmit) {
            var r = this.data.giftData, o = r.gift.TotalAmount, d = r.needGetPasswordSet, n = r.useCapital;
            r.CapitalAmount;
            if (d) {
                var l = 0, h = 0;
                s ? (h = n > o ? o : n, l = e.subtract(o, h)) : (h = 0, l = o), this.setData((a = {}, 
                t(a, "giftData.giftOrderAmount", l), t(a, "giftData.useCapital", h), a));
            }
        }
    },
    setGiftStore: function(t) {
        this.setData({
            giftStore: t
        });
    },
    goGiftStore: function() {
        var t = this.data.options, a = t.giftType, e = t.giftId, i = this.data.giftData.gift.Quantity;
        wx.navigateTo({
            url: "/pages/stores/stores?giftType=" + a + "&giftId=" + e + "&quantity=" + i
        });
    },
    onInputChange: function(t) {
        var a = t.detail.value, e = t.currentTarget.dataset.name;
        this.data.giftFormData[e] = a, this.setData({
            giftFormData: this.data.giftFormData
        });
    },
    _giftResult: function(t) {
        wx.requestSubscribeMessage({
            tmplIds: this.data.appletTemplate,
            success: function(a) {
                if ("requestSubscribeMessage:ok" == a.errMsg) {
                    var i = Object.keys(a).filter(function(t) {
                        return "accept" === a[t];
                    });
                    if (i.length > 0) {
                        var s = i.join(",");
                        wx.request({
                            url: e.getUrl("Common/GetAuthorizedSubscribeMessage"),
                            data: {
                                templateIds: s,
                                orderId: t.OrderId,
                                openId: e.globalData.openId
                            },
                            success: function(t) {}
                        });
                    }
                }
            },
            fail: function(t) {
                20004 === t.errCode && wx.showModal({
                    title: "提示",
                    content: "建议开启订阅消息，接收商城发送的消息通知",
                    cancelText: "取消",
                    confirmText: "去开启",
                    showCancel: !0,
                    success: function(t) {
                        wx.openSetting({});
                    }
                });
            },
            complete: function() {
                wx.redirectTo({
                    url: "/pages/orderlist/orderlist?status=0"
                });
            }
        });
    },
    submitGiftOrder: function() {
        var t = this, i = this.data.giftFormData, s = i.shipTo, r = i.contactPhone, o = i.remark, d = this.data, n = d.giftData.useCapital, l = d.pwd, h = d.options, u = h.quantity, c = h.giftType, p = h.giftId, f = d.giftStore, m = d.isIntegralPro;
        if (!s) return wx.showToast({
            title: "请填写姓名",
            icon: "none",
            mark: !0
        });
        if (!r || 11 !== r.length) return wx.showToast({
            title: "号码格式错误",
            icon: "none",
            mark: !0
        });
        if (!f) return wx.showToast({
            title: "请选择门店",
            icon: "none",
            mark: !0
        });
        this.setData({
            isSubmitting: !0
        });
        var g = {
            openId: e.globalData.openId,
            giftId: p,
            storeId: f.Id,
            shipTo: s,
            contactPhone: r,
            remark: o,
            quantity: u,
            useCapital: n,
            payPassword: l,
            type: "integralPro" === c ? 0 : 1
        };
        a.httpPost(e.getUrl("Gifts/Submit"), g, function(a) {
            t.setData({
                isSubmitting: !1
            });
            var i = a.success, s = a.msg, r = a.data, o = r.IsNeedPay, d = r.OrderId;
            if (!i) return wx.showModal({
                title: "提示",
                content: s,
                showCancel: !1,
                confirmText: "确定",
                confirmColor: "#FB1438",
                success: function(t) {
                    t.confirm && wx.redirectTo({
                        url: "/subPages/integralhome/integralhome"
                    });
                }
            });
            if (m) {
                if (!o) return t._giftResult(a.data);
                e.orderPay(d, 0, !1, t.data.appletTemplate, function() {
                    t._giftResult(a.data);
                }, t.data.isServiceShop ? 2 : 0);
            }
        });
    },
    loadPreGiftOrder: function() {
        var t = this, i = "integralPro" === this.data.options.giftType;
        a.httpGet(e.getUrl("Gifts/GetPreSubmit"), this.staticData.giftForm, function(a) {
            if (wx.hideLoading(), !a.success) return wx.showModal({
                title: "提示",
                content: a.msg,
                showCancel: !1,
                confirmText: "确定",
                confirmColor: "#FB1438",
                success: function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }
            });
            var e = a.data.gift, s = e.TotalAmount, r = e.CapitalAmount, o = e.TotalAmount, d = a.data.pickUp, n = d.CellPhone, l = d.ShipTo, h = r > 0 && o > 0;
            h && t.getHasSetPayPwd();
            var u = Object.assign(a.data, {
                isUseCapital: !1,
                giftOrderAmount: s,
                useCapital: 0,
                needGetPasswordSet: h
            }), c = {
                shipTo: l || "",
                contactPhone: n || "",
                remark: ""
            };
            t.setData({
                giftData: u,
                pageLoaded: !0,
                isIntegralPro: i,
                pageLoading: !0,
                giftFormData: c
            });
        });
    }
});