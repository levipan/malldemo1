function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var e = getApp(), a = require("../../utils/config.js"), s = require("../../utils/qqmap-wx-jssdk.min.js"), i = null;

Page({
    data: {
        contactUser: "",
        contactPhone: "",
        passwordOne: "",
        shopBranchName: "",
        addressPathName: "",
        addressPathCode: "",
        addressDetail: "",
        addressDetail1: "",
        parentContactPhone: "",
        currentFromLatLng: "",
        provinceName: [],
        provinceCode: [],
        provinceSelIndex: 0,
        cityName: [],
        cityCode: [],
        citySelIndex: 0,
        districtName: [],
        districtCode: [],
        districtSelIndex: 0,
        streetName: [],
        streetCode: [],
        streetSelIndex: 0,
        showDistpicker: !1,
        value: [ 0, 0, 0, 0 ],
        checked: !1,
        showCitypicker: !1,
        procitydata: [],
        procitydataValue: [ 0, 0 ],
        provinceSelectIndex: 0,
        citySelectIndex: 0,
        banks: [],
        bankName: "",
        bankIndex: -1,
        bankAddressId: "",
        bankAddress: "",
        bankUserName: "",
        bankCardNumber: "",
        IdCard: "",
        showBindPhone: !1,
        sellerId: 0,
        headBg: e.getRequestUrl + "/Images/storeapply.jpg"
    },
    onLoad: function(t) {
        var a = this;
        t.sellerId && (this.data.sellerId = t.sellerId, e.globalData.sellerId = t.sellerId), 
        e.getOpenId(function(n) {
            n && (wx.request({
                url: e.getUrl("MemberCenter/GetApplyShopbracnStatus"),
                data: {
                    openId: n
                },
                success: function(s) {
                    if ((s = s.data).success) {
                        if (0 == s.data.Status) return wx.showModal({
                            showCancel: !1,
                            content: "您已是团长",
                            success: function(t) {
                                t.confirm && wx.switchTab({
                                    url: "../index/index"
                                });
                            }
                        });
                        if (1 == s.data.Status) return wx.showModal({
                            showCancel: !1,
                            content: "团长已冻结",
                            success: function(t) {
                                t.confirm && wx.switchTab({
                                    url: "../index/index"
                                });
                            }
                        });
                        if ((2 == s.data.Status || 3 == s.data.Status) && !a.data.again) return wx.navigateTo({
                            url: "../userapplyresult/userapplyresult?type=store&status=" + s.data.Status + "&remark=" + s.data.Remark
                        });
                        e.globalData.userInfo.CellPhone || t.storePhone || a.setData({
                            showBindPhone: !0
                        });
                    }
                }
            }), e.getSysSettingData(function(n) {
                n.isOpenSubledger = e.globalData.IsOpenSubledger, n.communityJoinPhone = e.globalData.CommunityJoinPhone, 
                n.again = t.again || !1, n.contactPhone = t.cellPhone || e.globalData.userInfo.CellPhone || "", 
                n.sellerId = t.sellerId || 0, n.hasStorePhone = t.storePhone || !1, n.parentContactPhone = t.storePhone || "", 
                a.setData(n), i = new s({
                    key: e.globalData.QQMapKey
                }), a.getLocation();
            }), t.again && wx.request({
                url: e.getUrl("MemberCenter/GetApplyShopbracnStatus"),
                data: {
                    openId: e.globalData.openId
                },
                success: function(t) {
                    if ((t = t.data).success) {
                        t = t.data, a.setData({
                            contactUser: t.ContactUser || "",
                            contactPhone: t.ContactPhone || "",
                            passwordOne: t.PasswordOne || "",
                            shopBranchName: t.ShopBranchName || "",
                            addressPathName: t.AddressPathName || "",
                            addressPathCode: t.AddressPath || "",
                            addressDetail: t.AddressDetail || "",
                            parentContactPhone: t.ParentContactPhone || "",
                            currentFromLatLng: t.Latitude ? t.Latitude + "," + t.Longitude : "",
                            bankUserName: t.bankUserName || "",
                            bankCardNumber: t.bankCardNumber || "",
                            IdCard: t.idCard || "",
                            bankName: t.bankName || "",
                            bankAddressId: t.bankAddressId || ""
                        });
                        var e = a;
                        i.reverseGeocoder({
                            location: {
                                latitude: t.Latitude,
                                longitude: t.Longitude
                            },
                            get_poi: 1,
                            poi_options: "page_size=10;radius=1000;policy=2",
                            success: function(t) {
                                e.setData({
                                    addressDetail1: t.result.formatted_addresses.recommend
                                });
                            },
                            fail: function(t) {
                                wx.showToast({
                                    title: "获取位置失败"
                                });
                            }
                        });
                    }
                }
            }), t.source && a.setData({
                checked: !0
            }));
        });
    },
    changeVal: function(e) {
        var a = e.currentTarget.dataset.field, s = e.detail.value;
        "bankCardNumber" != a && "IdCard" != a || (s = s.replace(/\s*/g, "")), this.setData(t({}, a, s));
    },
    setProvinceCityData: function() {
        var t = this.data.procitydata, e = [], a = [];
        for (var s in t) {
            var i = t[s].name, n = t[s].id;
            e.push(i), a.push(n);
        }
        this.setData({
            provinceNames: e,
            provinceCodes: a
        }), this.setSubCityData(this.data.provinceSelectIndex);
    },
    setSubCityData: function(t) {
        var e = this.data.procitydata[t].cities, a = [], s = [];
        for (var i in e) {
            var n = e[i].name, o = e[i].id;
            a.push(n), s.push(o);
        }
        this.setData({
            cityNames: a,
            cityCodes: s
        });
    },
    changeCityArea: function(t) {
        t.detail.value[0] != this.data.provinceSelectIndex && (this.setData({
            provinceSelectIndex: t.detail.value[0],
            procitydataValue: [ t.detail.value[0], 0 ]
        }), this.setSubCityData(t.detail.value[0])), t.detail.value[1] != this.data.citySelectIndex && this.setData({
            citySelectIndex: t.detail.value[1],
            procitydataValue: [ t.detail.value[0], t.detail.value[1] ]
        });
    },
    citypickerSure: function() {
        this.setData({
            bankAddressId: this.data.provinceCodes[this.data.provinceSelectIndex] + "," + this.data.cityCodes[this.data.citySelectIndex],
            bankAddress: this.data.provinceNames[this.data.provinceSelectIndex] + this.data.cityNames[this.data.citySelectIndex],
            showCitypicker: !1
        });
    },
    callTel: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.communityJoinPhone
        });
    },
    bindPicker: function() {
        this.gerProvince(), this.setData({
            showDistpicker: !0
        });
    },
    changeArea: function(t) {
        var e = this;
        t.detail.value[0] != e.data.provinceSelIndex && (e.setData({
            provinceSelIndex: t.detail.value[0],
            value: [ t.detail.value[0], 0, 0, 0 ]
        }), e.getSubCity(e.data.provinceCode[t.detail.value[0]])), t.detail.value[1] != e.data.citySelIndex && (e.setData({
            citySelIndex: t.detail.value[1],
            value: [ t.detail.value[0], t.detail.value[1], 0, 0 ]
        }), e.getSubDistrict(e.data.cityCode[t.detail.value[1]])), t.detail.value[2] != e.data.districtSelIndex && (e.setData({
            districtSelIndex: t.detail.value[2],
            value: [ t.detail.value[0], t.detail.value[1], t.detail.value[2], 0 ]
        }), e.getSubStreet(e.data.districtCode[t.detail.value[2]])), t.detail.value[3] != e.data.streetSelIndex && e.setData({
            streetSelIndex: t.detail.value[3],
            value: [ t.detail.value[0], t.detail.value[1], t.detail.value[2], t.detail.value[3] ]
        });
    },
    showDistpicker: function() {
        this.setData({
            showDistpicker: !0
        });
    },
    distpickerCancel: function() {
        this.setData({
            showDistpicker: !1,
            showCitypicker: !1
        });
    },
    distpickerSure: function() {
        var t = this.data.provinceName[this.data.provinceSelIndex] + "," + this.data.cityName[this.data.citySelIndex] + "," + this.data.districtName[this.data.districtSelIndex] + "," + this.data.streetName[this.data.streetSelIndex], e = this.data.provinceCode[this.data.provinceSelIndex] + "," + this.data.cityCode[this.data.citySelIndex] + "," + this.data.districtCode[this.data.districtSelIndex] + "," + this.data.streetCode[this.data.streetSelIndex];
        this.setData({
            addressPathName: t,
            addressPathCode: e
        }), this.distpickerCancel();
    },
    getLocation: function() {
        var t = this;
        wx.getLocation({
            type: "gcj02",
            success: function(e) {
                i.reverseGeocoder({
                    location: {
                        latitude: e.latitude,
                        longitude: e.longitude
                    },
                    get_poi: 1,
                    poi_options: "page_size=10;radius=1000;policy=2",
                    success: function(a) {
                        t.setData({
                            cityname: a.result.address_component.city,
                            location: a.result.formatted_addresses.recommend
                        }), t.data.again || t.setData({
                            currentFromLatLng: e.latitude + "," + e.longitude
                        });
                    }
                });
            }
        });
    },
    gerProvince: function() {
        var t = this;
        if (!(this.data.provinceCode && this.data.provinceCode.length > 0)) {
            var a = [], s = [], i = [];
            wx.request({
                url: e.getUrl("Common/GetSubRegion"),
                data: {
                    parent: 0
                },
                success: function(e) {
                    if (e.data.success) {
                        a = e.data.data;
                        for (var n in a) {
                            var o = a[n].Name, d = a[n].Id;
                            s.push(o), i.push(d);
                        }
                        t.setData({
                            provinceName: s,
                            provinceCode: i
                        }), t.getSubCity(t.data.provinceCode[0]);
                    } else wx.showToast({
                        title: e.msg,
                        icon: "none"
                    });
                }
            });
        }
    },
    getSubCity: function(t) {
        var s = this;
        a.httpGet(e.getUrl("Common/GetSubRegion"), {
            parent: t
        }, function(t) {
            if (t.success) {
                var e = t.data, a = [], i = [];
                for (var n in e) {
                    var o = e[n].Name, d = e[n].Id;
                    a.push(o), i.push(d);
                }
                s.setData({
                    cityName: a,
                    cityCode: i
                }), s.getSubDistrict(s.data.cityCode[0]);
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }, !0);
    },
    getSubDistrict: function(t) {
        var s = this;
        a.httpGet(e.getUrl("Common/GetSubRegion"), {
            parent: t
        }, function(t) {
            if (t.success) {
                var e = t.data, a = [], i = [];
                for (var n in e) {
                    var o = e[n].Name, d = e[n].Id;
                    a.push(o), i.push(d);
                }
                a.push("其它"), i.push(0), s.setData({
                    districtName: a,
                    districtCode: i
                }), s.getSubStreet(s.data.districtCode[0]);
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }, !0);
    },
    getSubStreet: function(t) {
        var s = this;
        if (0 == t) {
            var i = [], n = [];
            return i.push("其它"), n.push(0), void s.setData({
                streetName: i,
                streetCode: n
            });
        }
        a.httpGet(e.getUrl("Common/GetSubRegion"), {
            parent: t
        }, function(t) {
            if (t.success) {
                var e = t.data, a = [], i = [];
                for (var n in e) {
                    var o = e[n].Name, d = e[n].Id;
                    a.push(o), i.push(d);
                }
                a.push("其它"), i.push(0), s.setData({
                    streetName: a,
                    streetCode: i
                });
            }
        }, !0);
    },
    chooseAddress: function() {
        wx.navigateTo({
            url: "../storelocation/storelocation?page=apply&cityname=" + this.data.cityname + "&location=" + this.data.location
        });
    },
    postApply: function() {
        var t = this;
        if (!this.data.contactPhone && !e.globalData.userInfo.CellPhone) return this.setData({
            showBindPhone: !0
        });
        this.data.contactUser ? 11 === this.data.contactPhone.length ? this.data.passwordOne.length < 6 ? wx.showToast({
            title: "请输入至少6位密码",
            icon: "none"
        }) : this.data.addressPathName ? this.data.addressDetail1 ? this.data.addressDetail ? this.data.addressDetail.length > 50 ? wx.showToast({
            title: "提货地址过长，请重新填写",
            icon: "none"
        }) : this.data.shopBranchName ? this.data.checked ? (wx.showLoading({
            title: "提交中..."
        }), e.getOpenId(function(s) {
            a.httpPost(e.getUrl("MemberCenter/PostApplyShopBranch"), {
                openId: s,
                contactUser: t.data.contactUser,
                contactPhone: t.data.contactPhone,
                passwordOne: t.data.passwordOne,
                shopBranchName: t.data.shopBranchName,
                addressPath: t.data.addressPathCode,
                addressDetail: t.data.addressDetail,
                parentContactPhone: t.data.parentContactPhone,
                shopImages: e.globalData.userInfo.Photo,
                latitude: t.data.currentFromLatLng.split(",")[0],
                longitude: t.data.currentFromLatLng.split(",")[1],
                IdCard: t.data.IdCard,
                bankName: t.data.bankName,
                bankAddressId: t.data.bankAddressId,
                bankCardNumber: t.data.bankCardNumber,
                bankUserName: t.data.bankUserName,
                sellerId: t.data.sellerId
            }, function(t) {
                wx.hideLoading(), t.success ? (wx.showToast({
                    title: "提交成功"
                }), setTimeout(function() {
                    wx.redirectTo({
                        url: "../userapplyresult/userapplyresult?type=store&status=2"
                    });
                }, 1500)) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        })) : wx.showToast({
            title: "请阅读并同意加盟协议",
            icon: "none"
        }) : wx.showToast({
            title: "请输入你的店铺名称",
            icon: "none"
        }) : wx.showToast({
            title: "请输入提货地址",
            icon: "none"
        }) : wx.showToast({
            title: "请选择小区/楼盘",
            icon: "none"
        }) : wx.showToast({
            title: "请选择省市区街道",
            icon: "none"
        }) : wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }) : wx.showToast({
            title: "请输入你的姓名",
            icon: "none"
        });
    },
    checkboxChange: function(t) {
        this.setData({
            checked: t.detail.value[0] || !1
        });
    },
    onUpdatephone: function(t) {
        this.setData({
            contactPhone: e.globalData.userInfo.CellPhone,
            showBindPhone: !1
        });
    }
});