Page({
    data: {},
    onLoad: function() {
        this.usercenter = this.selectComponent("#usercenter"), this.usercenter.onLoad();
    },
    onShow: function() {
        this.usercenter.onShow();
    }
});