require("../../utils/config.js"), getApp();

Page({
    staticData: {
        scrollTop: 0,
        windowH: 500,
        bodyW: 295,
        navHeight: 500,
        autoNext: !1,
        listRects: [],
        listKeys: {},
        listSubLefts: [],
        listSubRects: [],
        listInit: !1,
        isIos: !1,
        isNeedScroll: !1,
        count: 0
    },
    data: {
        pageInit: !1,
        pageno: 1,
        Products: [],
        isEnd: !1,
        keyword: "",
        timeload: null,
        oldShopBranchId: 0,
        scrollTop: 0,
        listScrollLeft: 0,
        listScrollTop: 0,
        translateY: 0,
        anchoring: !0,
        intoView: 0,
        transition: ""
    },
    onLoad: function(t) {
        this.data.options = t;
    },
    onHide: function() {},
    onReady: function() {
        this.categories = this.selectComponent("#categories"), this.categories.onLoad(this.data.options);
    },
    onShow: function() {},
    onPullDownRefresh: function() {}
});