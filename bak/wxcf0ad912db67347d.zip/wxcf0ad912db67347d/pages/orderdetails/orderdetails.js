var e = getApp(), t = require("../../utils/constant").SERVICE, a = require("../../utils/busEvent");

Page({
    data: {
        OrderInfo: null,
        OrderId: 0,
        isSubmitting: !1,
        codeHide: !0,
        pageLoaded: !1,
        templateList: [],
        appletTemplate: [],
        IsShowPickupDate: !0,
        SERVICE: t
    },
    onLoad: function(t) {
        var a = this;
        this.setData({
            OrderId: t.orderid
        }), e.getSysSettingData(function(t) {
            t.isOpenSubledger = e.globalData.IsOpenSubledger, t.IsShowPickupDate = e.globalData.IsShowPickupDate, 
            a.setData(t);
        }, !0, !0);
        var r = this;
        wx.request({
            url: e.getUrl("Common/GetWeiXinMsgTemplateListByApplet"),
            data: {
                openId: e.globalData.openId
            },
            success: function(e) {
                (e = e.data).success && r.setData({
                    templateList: e.data
                });
            }
        });
    },
    onShow: function() {
        wx.showLoading({
            title: "加载中"
        });
        var t = this, a = t.data.OrderId;
        wx.request({
            url: e.getUrl("MyOrder/GetOrderDetail"),
            data: {
                openId: e.globalData.openId,
                orderId: a
            },
            success: function(a) {
                if (wx.hideLoading(), (a = a.data).success) {
                    var r = a.data;
                    if (r.IsDaDaDeliver && r.CityDeliverStatusDesc && r.RiderInfo) {
                        var d = {
                            statusMsg: r.CityDeliverStatusDesc,
                            transporterName: r.RiderInfo.split("：")[0],
                            transporterPhone: r.RiderInfo.split("：")[1]
                        };
                        t.setData({
                            isDaDa: !0,
                            dadaOrderInfo: d
                        });
                    }
                    t.setData({
                        OrderInfo: r,
                        shopBranchId: r.BranchInfo ? r.BranchInfo.Id : 0,
                        pageLoaded: !0
                    });
                } else "502" == a.code ? wx.navigateTo({
                    url: "../login/login"
                }) : e.showErrorModal(a.msg, function(e) {
                    e.confirm && wx.navigateBack({
                        delta: 1
                    });
                });
            }
        });
    },
    goToProductDetail: function(e) {
        var t = e.currentTarget.dataset.productid, a = 7 == this.data.OrderInfo.OrderType ? "../storeProductdetail/storeProductdetail?id=" : "../productdetail/productdetail?id=";
        9 == this.data.OrderInfo.OrderType && (a = "../serviceProductdetail/serviceProductdetail?serviceType=" + this.data.OrderInfo.ServiceShopInfo.ServiceType + "&serviceShopId=" + this.data.OrderInfo.ServiceShopInfo.Id + "&id="), 
        wx.navigateTo({
            url: a + t + "&shopBranchId=" + this.data.shopBranchId
        });
    },
    goRefundDetail: function(e) {
        var t = e.currentTarget.dataset;
        wx.navigateTo({
            url: "../refunddetail/refunddetail?id=" + t.itemid
        });
    },
    showPickCode: function() {
        var t = this;
        wx.request({
            url: e.getUrl("MyOrder/GetPickupCodeQRCode"),
            data: {
                openId: e.globalData.openId,
                pickupCode: 9 === this.data.OrderInfo.OrderType ? this.data.OrderInfo.VerifyCode : this.data.OrderInfo.PickupCode
            },
            success: function(a) {
                a.data.success ? t.setData({
                    pickupcode: a.data.data,
                    codeHide: !1
                }) : (a.data.code = 502) ? wx.navigateTo({
                    url: "../login/login"
                }) : e.showErrorModal(a.data.msg);
            }
        });
    },
    hideCode: function() {
        this.setData({
            codeHide: !0
        });
    },
    goUsercenter: function() {
        a.emit("tabUserChange", {
            url: "../usercenter/usercenter"
        });
    },
    RefundOrder: function(e) {
        var t = e.currentTarget.dataset.orderid, a = e.currentTarget.dataset.itemid;
        wx.navigateTo({
            url: "../refundapply/refundapply?orderid=" + t + "&itemid=" + a
        });
    },
    confirmTakeDelivery: function(t) {
        var a = this, r = t.currentTarget.dataset.orderid;
        wx.showModal({
            title: "提示",
            content: "确认商品全部签收后再点收货哦~",
            confirmColor: e.globalData.PrimaryColor,
            success: function(t) {
                t.confirm && wx.request({
                    url: e.getUrl("MyOrder/GetConfirmReceiveGoods"),
                    data: {
                        orderId: r,
                        openId: e.globalData.openId
                    },
                    success: function(t) {
                        t.data.success ? a.onShow() : e.showErrorModal(t.data.msg);
                    }
                });
            }
        });
    },
    orderPay: function(t) {
        var a = this, r = t.currentTarget.dataset.orderid;
        wx.request({
            url: e.getUrl("MyOrder/GetOrderDetail"),
            data: {
                openId: e.globalData.openId,
                orderId: r
            },
            success: function(t) {
                if ((t = t.data).success) {
                    var d = t.data;
                    a.setAppletTemplate(d.DeliveryType), e.orderPay(r, 0, !1, a.data.appletTemplate);
                }
            }
        });
    },
    openMap: function(e) {
        var t = e.currentTarget.dataset, a = t.latitude, r = t.longitude;
        a && r && wx.openLocation({
            latitude: a,
            longitude: r
        });
    },
    bindTellPhone: function(e) {
        e.currentTarget.dataset.phone;
        wx.makePhoneCall({
            phoneNumber: e.currentTarget.dataset.phone
        });
    },
    bindBonus: function() {
        var e = this.data.OrderInfo, t = e.ShareHref;
        wx.navigateTo({
            url: "../outurl/outurl?type=needLogin&url=" + encodeURIComponent(t) + "&ShareTitle=" + e.ShareTitle + "&ShareImg=" + e.ShareImg
        });
    },
    setAppletTemplate: function(e) {
        for (var t = this, a = [], r = 0; r < t.data.templateList.length; r++) 7 == t.data.OrderInfo.OrderType ? 19 == t.data.templateList[r].MessageType && a.push(t.data.templateList[r].TemplateId) : 1 == e && 13 == t.data.templateList[r].MessageType ? a.push(t.data.templateList[r].TemplateId) : 2 == e && 15 == t.data.templateList[r].MessageType ? a.push(t.data.templateList[r].TemplateId) : 4 == e && 18 == t.data.templateList[r].MessageType ? a.push(t.data.templateList[r].TemplateId) : 19 == t.data.templateList[r].MessageType && a.push(t.data.templateList[r].TemplateId);
        t.setData({
            appletTemplate: a
        });
    },
    handleCopy: function() {
        wx.setClipboardData({
            data: this.data.OrderInfo.ShipOrderNumber
        });
    },
    goLogisticMap: function() {
        wx.navigateTo({
            url: "../logisticMap/logisticMap?orderId=" + this.data.OrderId + "&latitude=" + this.data.OrderInfo.ReceiveLatitude + "&longitude=" + this.data.OrderInfo.ReceiveLongitude
        });
    }
});