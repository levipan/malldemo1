var t = require("../../utils/config.js"), e = getApp(), a = require("../../utils/busEvent");

Page({
    data: {
        RefundInfo: null,
        Credentials: [],
        ProgressStatue: [],
        hasload: !1
    },
    onLoad: function(t) {
        var a = this;
        e.getSysSettingData(function(t) {
            a.setData(t);
        });
        var r = t.id;
        this.setData({
            RefundId: r,
            PrimaryColor: e.globalData.PrimaryColor,
            PrimaryTxtColor: e.globalData.PrimaryTxtColor
        }, !0);
    },
    onShow: function() {
        wx.showLoading({
            title: "加载中"
        }), this.initData();
    },
    initData: function() {
        var t = this;
        wx.request({
            url: e.getUrl("MyOrderRefund/GetRefundDetail"),
            data: {
                openId: e.globalData.openId,
                refundId: this.data.RefundId
            },
            success: function(a) {
                wx.hideLoading(), (a = a.data).success ? t.setData({
                    RefundInfo: a.data,
                    Credentials: a.data.UserCredentials,
                    ProgressStatue: a.data.RefundLogs,
                    hasload: !0
                }) : "502" == a.code ? wx.navigateTo({
                    url: "../login/login"
                }) : wx.showModal({
                    title: "提示",
                    content: "售后不存在，请刷新后再试",
                    showCancel: !1,
                    confirmColor: e.globalData.PrimaryColor,
                    success: function(t) {
                        t.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        });
    },
    goToProductDetail: function(t) {
        var e = t.currentTarget.dataset.productid;
        wx.navigateTo({
            url: "../productdetail/productdetail?id=" + e
        });
    },
    SendGood: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../expressdelivery/expressdelivery?refundId=" + e
        });
    },
    goUsercenter: function() {
        a.emit("tabUserChange", {
            url: "../usercenter/usercenter"
        });
    },
    prevImage: function(t) {
        var e = this, a = (t.target.dataset.index, t.target.dataset.src);
        wx.previewImage({
            current: a,
            urls: e.data.Credentials
        });
    },
    postCancel: function() {
        var a = this;
        wx.showModal({
            content: "是否撤销售后？",
            confirmText: "确定",
            confirmColor: "#fb1438",
            success: function(r) {
                r.confirm && t.httpGet(e.getUrl("MyOrderRefund/Cancel"), {
                    openId: e.globalData.openId,
                    refundId: a.data.RefundId
                }, function(t) {
                    wx.showToast({
                        title: t.msg,
                        icon: "none"
                    }), t.success && wx.redirectTo({
                        url: "../refundlist/refundlist"
                    });
                });
            }
        });
    }
});