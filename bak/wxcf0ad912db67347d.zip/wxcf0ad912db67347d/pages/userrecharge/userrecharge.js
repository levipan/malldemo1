var t = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var e = this, n = JSON.parse(t.rule);
        this.setData({
            rule: n,
            amount: n[0].ChargeAmount
        }), a.getSysSettingData(function(t) {
            e.setData(t);
        }, !0);
    },
    checkAmount: function(t) {
        this.setData({
            amount: t.currentTarget.dataset.amount
        });
    },
    submitRecharge: function() {
        var e = this;
        e.data.amount > 99999 && wx.showToast({
            title: "充值金额最大不能超过99999"
        }), t.httpPost(a.getUrl("MyCapital/PostCharge"), {
            openId: a.globalData.openId,
            typeId: "Himall.Plugin.Payment.WeiXinPay_SmallProg",
            amount: e.data.amount,
            ispresent: !0
        }, function(t) {
            if (t.success) {
                var e = t.data;
                wx.requestPayment({
                    timeStamp: e.timeStamp,
                    nonceStr: e.nonceStr,
                    package: "prepay_id=" + e.prepayId,
                    signType: "MD5",
                    paySign: e.sign,
                    success: function(t) {
                        wx.showToast({
                            title: "充值成功"
                        });
                    },
                    fail: function(t) {}
                });
            } else a.showErrorModal(t.msg);
        });
    },
    onShareAppMessage: function() {}
});