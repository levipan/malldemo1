var e = getApp(), t = require("../wxParse/wxParse.js"), r = require("../../utils/config.js");

Page({
    data: {
        Agreement: "",
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(a) {
        var o = this;
        this.setData({
            PrimaryColor: e.globalData.PrimaryColor,
            PrimaryTxtColor: e.globalData.PrimaryTxtColor
        }), e.getOpenId(function(a) {
            a && (wx.showLoading({
                title: "加载中"
            }), r.httpGet(e.getUrl("Home/GetCommunityAgreement"), {
                openId: a
            }, function(e) {
                wx.hideLoading();
                var r = e.data.CommunityAgreement;
                t.wxParse("Agreement", "html", r, o);
            }));
        });
    },
    goback: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            checked: !0
        }), wx.navigateBack();
    }
});