var a = require("../../utils/config.js"), t = require("../../utils/adaPay.js"), e = getApp();

Page({
    data: {
        rechargeHide: !0,
        cashHide: !0,
        pageno: 0,
        isEnd: !1,
        showCashChange: !0,
        hasPwd: !1,
        hasload: !1,
        list: []
    },
    onLoad: function(t) {
        var o = this;
        a.httpGet(e.getUrl("MyCapital/GetCapital"), {
            openId: e.globalData.openId
        }, this.getCapital), wx.showNavigationBarLoading(), e.getSysSettingData(function(a) {
            a.PrimaryColorlight = e.hex2rgb(e.globalData.PrimaryColor, .8), o.setData(a);
        }, !0);
    },
    getCapital: function(a) {
        a.success ? (this.setData({
            total: a.data,
            isOpen: a.data.isOpen,
            hasload: !0,
            rule: JSON.stringify(a.data.rule)
        }), this.loadData()) : 502 == a.code ? (wx.showToast({
            title: "请先登录账号"
        }), wx.navigateTo({
            url: "../login/login"
        })) : e.showErrorModal(a.msg), wx.hideNavigationBarLoading();
    },
    loadData: function() {
        if (!this.data.isEnd) {
            wx.showLoading({
                title: "加载中"
            });
            var t = this;
            this.data.pageno++, this.setData({
                pageno: this.data.pageno
            }), a.httpGet(e.getUrl("MyCapital/GetList"), {
                openId: e.globalData.openId,
                pagesize: 15,
                pageno: this.data.pageno
            }, function(a) {
                t.data.list.push.apply(t.data.list, a.data.rows), t.setData({
                    list: t.data.list,
                    isEnd: a.data.rows.length < 15
                }), wx.hideLoading();
            });
        }
    },
    bindChangePassword: function(a) {
        wx.navigateTo({
            url: "../userbindphone/userbindphone?formPage=changePwd"
        });
    },
    confirmCash: function(t) {
        var o = this;
        if (!this.data.outAmount || this.data.outAmount < this.data.total.WithDrawMinimum || this.data.outAmount > this.data.total.WithDrawMaximum) e.showErrorModal("提现金额必须在可提现区间内"); else if (this.data.pwd) if (this.data.pwd.length < 6) e.showErrorModal("支付密码不能少于6位"); else if (this.data.hasPwd) this.postApplyWithDraw(t); else {
            if (!this.data.pwdagain) return void e.showErrorModal("因为未设置过密码，请确认密码");
            if (this.data.pwd != this.data.pwdagain) return void e.showErrorModal("两次密码输入不一致，请确认");
            a.httpPost(e.getUrl("Payment/PostSetPayPwd"), {
                openId: e.globalData.openId,
                pwd: this.data.pwd
            }, function(a) {
                a.success ? (o.setData({
                    hasSetPayPwd: !0
                }), o.postApplyWithDraw(t)) : e.showErrorModal("设置密码失败");
            });
        } else e.showErrorModal("请输入交易密码");
    },
    postApplyWithDraw: function(t) {
        var o = this;
        a.httpPost(e.getUrl("MyCapital/PostApplyWithDraw"), {
            openId: e.globalData.openId,
            applyType: 1,
            formId: t.detail.formId,
            amount: o.data.outAmount,
            pwd: o.data.pwd
        }, function(a) {
            a.success ? (o.setData({
                cashHide: !0,
                pwd: "",
                pwdagain: "",
                outAmount: ""
            }), wx.showToast({
                title: "提现申请成功"
            })) : e.showErrorModal(a.msg);
        });
    },
    confirmCharge: function() {
        var o = this;
        if (o.data.inAmount) {
            var i = e.globalData.IsOpenSubledger ? "Himall.Plugin.Payment.Adapay" : "Himall.Plugin.Payment.WeiXinPay_SmallProg";
            a.httpPost(e.getUrl("MyCapital/PostCharge"), {
                openId: e.globalData.openId,
                typeId: i,
                amount: o.data.inAmount
            }, function(a) {
                if (a.success) if (e.globalData.IsOpenSubledger) {
                    var i = a.data;
                    i.expend.open_id = e.globalData.openId, t.doPay(i, function(a) {
                        "succeeded" === a.result_status ? (o.setData({
                            rechargeHide: !0
                        }), wx.showToast({
                            title: "充值成功"
                        })) : wx.showToast({
                            title: "充值失败",
                            icon: "none"
                        });
                    });
                } else {
                    var n = a.data;
                    wx.requestPayment({
                        timeStamp: n.timeStamp,
                        nonceStr: n.nonceStr,
                        package: "prepay_id=" + n.prepayId,
                        signType: "MD5",
                        paySign: n.sign,
                        success: function(a) {
                            o.setData({
                                rechargeHide: !0
                            }), wx.showToast({
                                title: "充值成功"
                            });
                        },
                        fail: function(a) {}
                    });
                } else e.showErrorModal(a.msg);
            });
        } else e.showErrorModal("充值金额必须大于零");
    },
    showCashChange: function(t) {
        var o = this;
        this.data.hasPwd || a.httpGet(e.getUrl("Payment/GetHasSetPayPwd"), {
            openId: e.globalData.openId
        }, function(a) {
            a.success && o.setData({
                hasPwd: !0
            });
        }), this.setData({
            cashHide: !t.currentTarget.dataset.type
        });
    },
    showrechargeChange: function(a) {
        this.data.isOpen ? wx.navigateTo({
            url: "../userrecharge/userrecharge?rule=" + this.data.rule
        }) : this.setData({
            rechargeHide: !a.currentTarget.dataset.type
        });
    },
    onInputOutAmount: function(a) {
        this.setData({
            outAmount: a.detail.value
        });
    },
    onInputPwd: function(a) {
        this.setData({
            pwd: a.detail.value
        });
    },
    onInputPwdAgain: function(a) {
        this.setData({
            pwdagain: a.detail.value
        });
    },
    onInputInAmount: function(a) {
        this.setData({
            inAmount: a.detail.value
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.loadData();
    }
});