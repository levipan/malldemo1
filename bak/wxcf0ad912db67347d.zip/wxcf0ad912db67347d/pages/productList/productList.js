function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = require("../../utils/config.js"), e = getApp();

Page({
    data: {
        ids: "",
        pageNo: 0,
        pageSize: 10,
        hasGetSysSetting: !1,
        products: [],
        backShow: "none",
        SkuShow: "none",
        couponShow: "none",
        skuPrice: 0,
        skuStock: 0,
        preview: !1,
        isBindIphone: !1,
        choosetype: "",
        IsShowPickupDate: !0
    },
    onLoad: function(t) {
        var a = wx.getStorageSync("shopBranchId"), o = t.shopBranchId || a;
        t.ids && (this.setData({
            shopBranchId: o,
            ids: t.ids,
            IsShowPickupDate: e.globalData.IsShowPickupDate
        }), this.search());
    },
    onReady: function() {
        this.storeCart = this.selectComponent("#storeCart");
    },
    onShow: function() {
        var t = this;
        e.globalData.IsConBindCellPhone && !e.globalData.userInfo.CellPhone && this.setData({
            isBindIphone: !0
        }), this.data.hasGetSysSetting || e.getSysSettingData(function(a) {
            a.IsShowHishopCopyRight = e.globalData.IsShowHishopCopyRight, a.ProductSaleCountOnOff = e.globalData.ProductSaleCountOnOff, 
            a.SiteName = e.globalData.SiteName, a.PrimaryColorlight7 = e.hex2rgb(e.globalData.PrimaryColor, .7), 
            a.IsJumpLink = e.globalData.IsJumpLink, a.KeepOnRecordPic = e.globalData.KeepOnRecordPic, 
            a.KeepOnRecordUrl = e.globalData.KeepOnRecordUrl, a.hasGetSysSetting = !0, t.setData(a), 
            e.globalData.IsConBindCellPhone && !e.globalData.userInfo.CellPhone && t.setData({
                isBindIphone: !0
            }), wx.setNavigationBarTitle({
                title: e.globalData.SiteName
            });
        });
    },
    search: function() {
        var t = this;
        a.httpGet(e.getUrl("Home/GetStoreProductList"), {
            shopBranchId: wx.getStorageSync("shopBranchId"),
            openId: wx.getStorageSync("mallAppletOpenId"),
            pageno: this.data.pageNo,
            productSearchType: 1,
            pagesize: 10,
            keyword: "",
            ids: this.data.ids
        }, function(a) {
            a.success && (a.data.Data.forEach(function(t) {
                t.Tags && (t.Tags = t.Tags.split(","));
            }), t.setData({
                products: a.data.Data
            }));
        });
    },
    goProduct: function(t) {
        wx.navigateTo({
            url: "../productdetail/productdetail?shopBranchId=" + wx.getStorageSync("shopBranchId") + "&id=" + t.currentTarget.dataset.id
        });
    },
    clickSku: function(t) {
        var a = this;
        e.getOpenId(function(e) {
            a.loadData(t.currentTarget.dataset.id), a.setData({
                choosetype: "buy"
            });
        });
    },
    clickback: function(t) {
        this.setData({
            backShow: "none",
            SkuShow: "none",
            couponShow: "none"
        }), this.loadData();
    },
    loadData: function(t) {
        var a = this;
        wx.showLoading({
            title: "加载中"
        }), wx.request({
            url: e.getUrl("CommunityStore/GetProductDetail"),
            data: {
                openId: e.globalData.openId,
                productId: t,
                shopBranchId: this.data.shopBranchId,
                preview: this.data.preview
            },
            success: function(t) {
                if (wx.hideLoading(), (t = t.data).success) {
                    var e = t.data, o = [ e.ProductId, 0, 0, 0 ];
                    if (a.setData({
                        deliver: e.DeliveryType,
                        DeliveryFeeTip: e.DeliveryFeeTip
                    }), 0 == e.SkuItemList.length) a.setData({
                        curSkuData: e.Skus[0],
                        skuStock: e.Stock
                    }); else {
                        var s = {}, i = e.Skus.filter(function(t) {
                            return t.Stock > 0;
                        });
                        if (e.Skus.forEach(function(t) {
                            s[t.SkuId] = t;
                        }), e.Skus = s, 1 === i.length) {
                            o = i[0].SkuId.split("_");
                            var r = e.Skus[i[0].SkuId];
                            a.setData({
                                skuStock: r.Stock,
                                curSkuData: r
                            });
                        }
                    }
                    a.setData({
                        ProductId: e.ProductId,
                        limitCount: e.LimitCount,
                        skuArr: o,
                        SkuItemList: e.SkuItemList,
                        Skus: e.Skus,
                        skuImg: e.ThumbnailUrl60,
                        defaultImg: e.ThumbnailUrl60,
                        skuPrice: e.MinSalePrice,
                        selectTextArr: [],
                        selectedSkuContent: "",
                        buyAmount: 1,
                        limitStatus: e.Status || 1,
                        MeasureUnit: e.MeasureUnit,
                        backShow: "",
                        SkuShow: ""
                    }), 0 != a.data.SkuItemList.length && a.setDisabledSku();
                }
            }
        });
    },
    setDisabledSku: function() {
        var a = this.data.SkuItemList, e = this.data.Skus, o = a.length, s = this.data.skuArr, i = 0;
        s.forEach(function(t) {
            0 !== t && (i += 1);
        }), i >= o && (a.forEach(function(a) {
            var o = a.AttributeIndex;
            a.AttributeValue.forEach(function(a) {
                var i = [].concat(t(s));
                i[o + 1] = a.ValueId, e[i.join("_")] && !e[i.join("_")].Stock ? a.disabled = !0 : a.disabled = !1;
            });
        }), this.setData({
            SkuItemList: this.data.SkuItemList
        }));
    },
    reduceAmount: function(t) {
        var a = this.data.buyAmount;
        (a -= 1) <= 0 || this.setData({
            buyAmount: a
        });
    },
    addAmount: function() {
        if (this.data.skuStock) {
            var t = this.data.buyAmount, a = this.data.skuStock, o = this.data.limitCount;
            if (t += 1, 0 == o) {
                if (t > a) return void wx.showToast({
                    title: "超过最大可购买数",
                    icon: "none"
                });
                this.setData({
                    buyAmount: t
                });
            } else {
                if (t > a || t > o) return void wx.showToast({
                    title: "超过最大可购买数",
                    icon: "none"
                });
                this.setData({
                    buyAmount: t
                });
            }
        } else e.showErrorModal("请选择规格");
    },
    changeAmount: function(t) {
        var a = parseInt(t.detail.value), o = this.data.skuStock, s = this.data.limitCount;
        if (0 == s) {
            if (isNaN(a) || a > o || a <= 0) return e.showErrorModal("请输入正确的数量,不能大于库存或者小于等于0"), 
            void this.setData({
                buyAmount: a <= 0 ? 1 : o
            });
            this.setData({
                buyAmount: a
            });
        } else {
            if (isNaN(a) || a > o || a <= 0 || a > s) return e.showErrorModal("请输入正确的数量,不能大于最大可购买或者小于等于0"), 
            void this.setData({
                buyAmount: 1
            });
            this.setData({
                buyAmount: a
            });
        }
    },
    doCommit: function(t) {
        var a = this;
        t.currentTarget.dataset.option;
        if (this.data.curSkuData && this.data.curSkuData.Stock) if (this.data.buyAmount <= 0) e.showErrorModal("请输入要购买的数量"); else {
            var o = this.data.buyAmount, s = this.data.skuArr.join("_");
            e.getOpenId(function(t) {
                wx.navigateTo({
                    url: "../ordersubmit/ordersubmit?skuid=" + s + "&count=" + o + "&shopBranchId=" + a.data.shopBranchId + "&deliver=" + a.data.deliver
                });
            });
        } else e.showErrorModal("请选择规格");
    },
    swithSku: function(t) {
        var a = t.currentTarget.dataset.index, e = t.currentTarget.dataset.skuvalue, o = t.currentTarget.dataset.imgurl, s = t.currentTarget.dataset.id, i = this.data.skuArr;
        0 === a && o != this.data.skuImg && (o = o || this.data.defaultImg, this.setData({
            skuImg: o
        })), i[a + 1] = parseInt(i[a + 1]) === s ? 0 : s, this.data.selectTextArr[a] = i[a + 1] ? e : "";
        var r = this.data.Skus[this.data.skuArr.join("_")], n = "";
        this.data.selectTextArr.forEach(function(t, a) {
            t && (a > 0 && n && (n += "，"), n += t);
        }), this.setData({
            skuArr: i,
            selectTextArr: this.data.selectTextArr,
            selectedSkuContent: n,
            curSkuData: r || null
        }), r && this.setData({
            skuPrice: r.SalePrice,
            skuStock: r.Stock
        }), this.setDisabledSku();
    },
    getPhoneNumber: function(t) {
        "getPhoneNumber:ok" === t.detail.errMsg && this.setData({
            isBindIphone: !1
        });
    }
});