var t = require("../../utils/config.js"), e = getApp();

require("../../utils/busEvent");

Page({
    data: {
        data: null
    },
    onLoad: function(t) {
        var a = this;
        e.getSysSettingData(function(t) {
            a.setData(t);
        }, !0), wx.setNavigationBarTitle({
            title: "选择团长"
        }), this.setData({
            currentBranchId: t.currentBranchId,
            newBranchId: t.newBranchId,
            formPage: t.formPage,
            productId: t.productId ? t.productId : "",
            solitaireId: t.solitaireId || "",
            serviceShopId: t.serviceShopId || "",
            serviceType: t.serviceType || "",
            groupId: t.groupId || "",
            orderId: t.orderId || ""
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        wx.getLocation({
            type: "gcj02",
            success: function(e) {
                var a = e.latitude, r = e.longitude;
                t.initData(a + "," + r);
            },
            fail: function() {
                t.initData(""), wx.showModal({
                    title: "",
                    content: "请打开地理位置授权，方便为您提供合适的门店",
                    success: function(t) {
                        t.confirm && wx.openSetting();
                    }
                });
            }
        });
    },
    initData: function(a) {
        var r = this;
        t.httpGet(e.getUrl("home/GetPickUpInfo"), {
            currentBranchId: this.data.currentBranchId,
            newBranchId: this.data.newBranchId,
            fromLatLng: a
        }, function(t) {
            t.success ? r.setData({
                data: t.data
            }) : (wx.showToast({
                title: t.msg,
                icon: "none"
            }), setTimeout(function() {
                wx.setStorageSync("shopBranchId", r.data.newBranchId), wx.switchTab({
                    url: "../index/index"
                });
            }, 1500));
        });
    },
    chooseStore: function(t) {
        var a = t.currentTarget.dataset.id;
        if ("storeProductdetail" != this.data.formPage || a != this.data.data.currentBranchId) switch (wx.setStorageSync("shopBranchId", a), 
        e.updateCartTotal(0), e.globalData.cartData.items = {}, e.getCartAllData({
            shopBranchId: a
        }), e.globalData.newStoreId = "", this.data.formPage) {
          case "productdetail":
            e.changeShopbranch(), wx.redirectTo({
                url: "../productdetail/productdetail?id=" + this.data.productId + "&shopBranchId=" + a
            });
            break;

          case "storeProductdetail":
            e.changeShopbranch(), wx.redirectTo({
                url: "../storeProductdetail/storeProductdetail?id=" + this.data.productId + "&shopBranchId=" + a
            });
            break;

          case "storehome":
            wx.switchTab({
                url: "../index/index"
            });
            break;

          case "storeSelfSupport":
            e.busEvent("storeSelfSupport", "../storeSelfSupport/storeSelfSupport?id=" + a);
            break;

          case "serviceProductdetail":
            wx.redirectTo({
                url: "../serviceProductdetail/serviceProductdetail?id=" + this.data.productId + "&shopBranchId=" + a + "&serviceShopId=" + this.data.serviceShopId + "&serviceType=" + this.data.serviceType
            });
            break;

          case "serviceStore":
            wx.redirectTo({
                url: "../serviceStore/serviceStore?id=" + this.data.serviceShopId + "&shopBranchId=" + a
            });
            break;

          case "groupsolitairedetail":
            wx.redirectTo({
                url: "../groupsolitairedetail/groupsolitairedetail?activeId=" + this.data.solitaireId
            });
            break;

          case "groupDetail":
            wx.redirectTo({
                url: "/subPages/groupDetail/groupDetail?groupId=" + this.data.groupId + "&orderId=" + this.data.orderId + "&shopBranchId=" + a
            });
            break;

          default:
            wx.redirectTo({
                url: "../video/video?productid=" + this.data.productId
            });
        } else wx.showToast({
            title: "该商品为" + this.data.data.newShopName + "特有商品",
            icon: "none"
        });
    },
    onHide: function() {}
});