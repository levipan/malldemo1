var o = getApp();

Page({
    data: {
        isShowBusinessLicense: !1
    },
    onLoad: function(a) {
        var n = this;
        o.getSysSettingData(function(a) {
            n.setData({
                version: o.globalData.Version || "4.0",
                isShowBusinessLicense: o.globalData.IsShowBusinessLicense
            });
        }, !0);
    },
    openBusinessLicense: function() {
        wx.navigateTo({
            url: "../businesslicense/businesslicense"
        });
    },
    goProtocol: function() {
        wx.navigateTo({
            url: "../loginprotocol/loginprotocol"
        });
    },
    outLogin: function() {
        wx.showModal({
            title: "提示",
            confirmColor: o.globalData.PrimaryColor,
            content: "确定退出登录吗？",
            success: function(a) {
                a.confirm && (wx.removeStorageSync("mallAppletOpenId"), o.globalData.wxUserInfo = null, 
                o.globalData.openId = "", o.globalData.cartData.total = 0, o.globalData.cartData.items = {}, 
                wx.navigateBack());
            }
        });
    }
});