var a = getApp(), t = require("../../utils/config.js");

Page({
    data: {
        OrderId: "",
        ProductList: [],
        TxtareaName: [],
        isSubmit: !1,
        getRequestUrl: a.getRequestUrl
    },
    onLoad: function(e) {
        var r = this, o = e.id, n = {
            openId: a.globalData.openId,
            orderId: o
        };
        t.httpGet(a.getUrl("MyComment/GetAppendComment"), n, r.getProductData), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: a.globalData.PrimaryColor
        }), r.setData({
            OrderId: o,
            PrimaryColor: a.globalData.PrimaryColor,
            PrimaryTxtColor: a.globalData.PrimaryTxtColor
        });
    },
    getProductData: function(t) {
        var e = this;
        if (t.success) {
            var r = [], o = [];
            t.data.forEach(function(t, e, n) {
                var d = {
                    Id: t.CommentId,
                    AppendContent: "",
                    Images: [],
                    WXmediaId: []
                };
                r.push(d), o.push("txt_" + t.CommentId), t.CommentImages.forEach(function(t, e) {
                    -1 == t.CommentImage.indexOf("http://") && -1 == t.CommentImage.indexOf("https://") && (t.CommentImage = a.getRequestUrl + t.CommentImage);
                }), t.EvaluationTime = t.EvaluationTime.replace(/T/, " ");
            }), e.setData({
                ProductList: t.data,
                ScoreGrade: r,
                TxtareaName: o
            });
        } else a.showErrorModal(t.msg, function(a) {
            a.confirm && wx.navigateBack({
                delta: 1
            });
        });
    },
    ScoreGrade: function(a) {
        var t = a.currentTarget.dataset.grade, e = a.currentTarget.dataset.index, r = this.data.ScoreGrade;
        r[e].grade = parseInt(t), this.setData({
            ScoreGrade: r
        });
    },
    uploadImg: function(t) {
        var e = this, r = t.currentTarget.dataset.index, o = e.data.ScoreGrade, n = o[r], d = t.currentTarget.dataset.imgindex;
        wx.chooseImage({
            count: 1,
            success: function(t) {
                var r = t.tempFilePaths;
                wx.uploadFile({
                    url: a.getUrl("MyOrderRefund/PostUploadAppletImage"),
                    filePath: r[0],
                    name: "file",
                    formData: {
                        openId: a.globalData.openId
                    },
                    success: function(a) {
                        if ((a = JSON.parse(a.data)).success) {
                            var t = a.data.Data[0].ImageUrl;
                            void 0 != d ? n.Images[parseInt(d)] = t : n.Images.push(t), e.setData({
                                ScoreGrade: o
                            });
                        }
                    }
                });
            }
        });
    },
    delImg: function(a) {
        var t = a.currentTarget.dataset.index, e = a.currentTarget.dataset.imgindex;
        this.data.ScoreGrade[t].Images.splice(e, 1), this.setData({
            ScoreGrade: this.data.ScoreGrade
        });
    },
    formSubmit: function(e) {
        var r = this;
        if (r.data.isSubmit) return !1;
        e.detail.formId;
        var o = r.data.ScoreGrade, n = r.data.TxtareaName;
        if (n.length <= 0) return a.showErrorModal("文本框不存在"), !1;
        var d = !1;
        if (n.forEach(function(a, t, n) {
            r.ToTrim(e.detail.value[a]).length <= 0 ? d = !0 : o[t].AppendContent = r.ToTrim(e.detail.value[a]);
        }), d) return a.showErrorModal("请输入评价内容"), !1;
        r.setData({
            isSubmit: !0
        }), t.httpPost(a.getUrl("MyComment/PostAppendComment"), {
            openId: a.globalData.openId,
            productCommentsJSON: JSON.stringify(o)
        }, function(t) {
            t.success ? a.showErrorModal("评论已提交", function(a) {
                a.confirm && wx.redirectTo({
                    url: "../orderlist/orderlist"
                });
            }) : a.showErrorModal("评论提交失败", function(a) {
                a.confirm && wx.navigateBack({
                    delta: 1
                });
            });
        });
    },
    ToTrim: function(a) {
        return a.replace(/(^\s*)|(\s*$)/g, "");
    }
});