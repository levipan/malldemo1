function a(a) {
    if (Array.isArray(a)) {
        for (var e = 0, t = Array(a.length); e < a.length; e++) t[e] = a[e];
        return t;
    }
    return Array.from(a);
}

require("../../utils/config.js");

var e = getApp();

Page({
    data: {
        ReviewInfo: null,
        positive: 0,
        commentList: null,
        pageIndex: 1,
        pageSize: 10,
        commentType: 0,
        ProductId: null
    },
    onLoad: function(a) {
        var t = this, r = a.id, o = a.shopBranchId;
        t.setData({
            ProductId: r,
            shopBranchId: o || 0,
            PrimaryColor: e.globalData.PrimaryColor
        }), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: e.globalData.PrimaryColor
        }), wx.request({
            url: e.getUrl("product/GetStatisticsReview"),
            data: {
                ProductId: r,
                shopBranchId: o
            },
            success: function(a) {
                if ((a = a.data).success) {
                    var e = a.data, r = (e.reviewNum1 / e.reviewNum * 100).toFixed(0);
                    t.setData({
                        ReviewInfo: e,
                        positive: r
                    });
                } else "502" == a.code ? wx.navigateTo({
                    url: "../login/login"
                }) : wx.showModal({
                    title: "提示",
                    content: a.msg,
                    confirmColor: this.data.PrimaryColor,
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        }), t.loadData(t, !1);
    },
    prevImage: function(a) {
        var e = a.target.dataset.imgs, t = a.target.dataset.src;
        wx.previewImage({
            current: t,
            urls: e || [ t ]
        });
    },
    previewAppendImgs: function(e) {
        var t = e.target.dataset.item, r = [], o = e.target.dataset.src;
        t.AppendImages.forEach(function(e, t) {
            r = [].concat(a(r), [ e.CommentImage ]);
        }), wx.previewImage({
            current: o,
            urls: r || [ o ]
        });
    },
    formatDuring: function(a) {
        var e = parseInt(a / 864e5), t = parseInt(a % 864e5 / 36e5), r = parseInt(a % 36e5 / 6e4), o = a % 6e4 / 1e3;
        return e > 0 ? e + "天" : t > 0 ? t + "小时" : r > 0 ? r + "分钟" : o > 0 ? o + "秒" : void 0;
    },
    loadData: function(a, t) {
        wx.request({
            url: e.getUrl("product/GetLoadReview"),
            data: {
                openId: e.globalData.openId,
                PageIndex: a.data.pageIndex,
                PageSize: a.data.pageSize,
                type: a.data.commentType,
                ProductId: a.data.ProductId,
                shopBranchId: a.data.shopBranchId
            },
            success: function(e) {
                if ((e = e.data).success) {
                    var r = e.data.Data;
                    if (r.forEach(function(e) {
                        e.AppendDate && (e.AppendSpace = a.formatDuring(new Date(e.AppendDate.replace(/-/g, "/")) - new Date(e.ReviewDate.replace(/-/g, "/")))), 
                        e.Images = [], "" != e.ImageUrl1 && e.Images.push(e.ImageUrl1), "" != e.ImageUrl2 && e.Images.push(e.ImageUrl2), 
                        "" != e.ImageUrl3 && e.Images.push(e.ImageUrl3), "" != e.ImageUrl4 && e.Images.push(e.ImageUrl4), 
                        "" != e.ImageUrl5 && e.Images.push(e.ImageUrl5);
                        var t = e.UserName, r = [], o = !0, n = !1, s = void 0;
                        try {
                            for (var i, c = t[Symbol.iterator](); !(o = (i = c.next()).done); o = !0) {
                                var l = i.value;
                                r.push(l);
                            }
                        } catch (a) {
                            a = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(a);
                            n = !0, s = a;
                        } finally {
                            try {
                                !o && c.return && c.return();
                            } finally {
                                if (n) throw s;
                            }
                        }
                        2 === r.length ? t = r[0] + "*" : t.length > 2 && (t = r[0] + "***" + r[r.length - 1]), 
                        e.UserName = t;
                    }), t) {
                        var o = a.data.commentList;
                        o.push.apply(o, r), a.setData({
                            commentList: o
                        });
                    } else a.setData({
                        commentList: r
                    });
                } else "502" == e.code ? wx.navigateTo({
                    url: "../login/login"
                }) : wx.showModal({
                    title: "提示",
                    content: e.msg,
                    confirmColor: this.data.PrimaryColor,
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        });
    },
    bingComment: function(a) {
        var e = this, t = a.currentTarget.dataset.typeid;
        e.setData({
            pageIndex: 1,
            commentType: t
        }), e.loadData(e, !1);
    },
    onReachBottom: function() {
        var a = this, e = a.data.pageIndex;
        e = parseInt(e) + 1, a.setData({
            pageIndex: e
        }), a.loadData(a, !0);
    }
});