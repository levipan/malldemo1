var e = getApp();

Page({
    data: {
        orderInfo: null,
        templateList: [],
        appletTemplate: [],
        isShowSolitaire: !1
    },
    onLoad: function(t) {
        var a = this;
        a.setData({
            orderid: t.orderid,
            orderType: t.orderType
        }), wx.request({
            url: e.getUrl("Order/GetOrderSuccess"),
            data: {
                openId: e.globalData.openId,
                id: t.orderid
            },
            success: function(e) {
                (e = e.data).success ? a.setData({
                    orderInfo: e.data,
                    isShowSolitaire: e.data.IsGroupSolitaire
                }) : wx.showToast({
                    title: e.msg
                });
            }
        }), wx.request({
            url: e.getUrl("Common/GetWeiXinMsgTemplateListByApplet"),
            data: {
                openId: e.globalData.openId
            },
            success: function(e) {
                (e = e.data).success ? a.setData({
                    templateList: e.data
                }) : wx.showToast({
                    title: e.msg
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    goOrderlist: function() {
        wx.redirectTo({
            url: "../orderlist/orderlist?status=0"
        });
    },
    setAppletTemplate: function() {
        for (var e = this, t = [], a = 0; a < e.data.templateList.length; a++) 1 == e.data.orderInfo.DeliveryType && 13 == e.data.templateList[a].MessageType ? t.push(e.data.templateList[a].TemplateId) : 2 == e.data.orderInfo.DeliveryType && 15 == e.data.templateList[a].MessageType ? t.push(e.data.templateList[a].TemplateId) : 4 == e.data.orderInfo.DeliveryType && 18 == e.data.templateList[a].MessageType ? t.push(e.data.templateList[a].TemplateId) : 19 == e.data.templateList[a].MessageType && t.push(e.data.templateList[a].TemplateId);
        e.setData({
            appletTemplate: t
        });
    },
    onShareAppMessage: function(t) {
        var a, r, o = this.data.orderid;
        this.data.orderInfo && (a = this.data.orderInfo.ShareImgUrl, r = this.data.orderInfo.ShareTitle);
        var s = "pages/ordershare/ordershare?orderId=" + o;
        return 2 == t.target.dataset.type && (r = this.data.orderInfo.GroupSolitaire.ShareDesc, 
        a = this.data.orderInfo.GroupSolitaire.ShareImgUrl, s = "/pages/groupsolitairedetail/groupsolitairedetail?activeId=" + this.data.orderInfo.GroupSolitaire.GroupSolitaireId + "&shopBranchId=" + wx.getStorageSync("shopBranchId")), 
        wx.request({
            url: e.getUrl("MyOrder/GetOrderShareAddIntegral"),
            data: {
                orderId: o,
                openId: e.globalData.openId
            },
            success: function(e) {}
        }), e.globalData.userInfo.IsDistributor && (s += "&referralUserId=" + e.globalData.userInfo.UserId), 
        {
            title: r,
            imageUrl: a,
            path: s
        };
    },
    bindBonus: function(e) {
        var t = e.currentTarget.dataset.sharehref, a = e.currentTarget.dataset.sharetitle, r = e.currentTarget.dataset.shareimg, o = t;
        wx.navigateTo({
            url: "../outurl/outurl?type=needLogin&url=" + encodeURIComponent(o) + "&ShareTitle=" + a + "&ShareImg=" + r
        });
    },
    onHideGolitaire: function() {
        this.setData({
            isShowSolitaire: !1
        });
    }
});