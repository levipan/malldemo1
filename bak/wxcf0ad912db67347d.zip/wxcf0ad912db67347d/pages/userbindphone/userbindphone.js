var e = require("../../utils/config.js"), t = getApp();

Page({
    data: {
        changePwd: !1,
        cellPhone: "",
        imgCodeData: {},
        time: 0
    },
    onLoad: function(e) {
        this.setData({
            formPage: e.formPage || "",
            PrimaryColor: t.globalData.PrimaryColor,
            PrimaryTxtColor: t.globalData.PrimaryTxtColor
        }), this.setInitState(), this.loadImageCheckCode(), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: t.globalData.PrimaryColor
        });
    },
    setInitState: function(e) {
        var a = t.globalData.userInfo.CellPhone;
        this.setData({
            changePwd: a && a.length > 0 || !1,
            cellPhone: a || "",
            CellPhoneStr: a ? a.substr(0, 3) + "****" + a.substr(7) : ""
        }), wx.setNavigationBarTitle({
            title: this.data.changePwd ? "重置交易密码" : "绑定手机"
        }), a || wx.showToast({
            title: "请先绑定手机号码",
            icon: "none"
        });
    },
    loadImageCheckCode: function() {
        var a = this;
        e.httpGet(t.getUrl("Login/GetImageCheckCode"), {}, function(e) {
            e.success && a.setData({
                imgCodeData: e.data
            });
        });
    },
    getPhoneNumber: function(a) {
        var o = this;
        "getPhoneNumber:ok" === a.detail.errMsg && e.httpGet(t.getUrl("Login/GetBindWXPhone"), {
            openId: t.globalData.openId,
            encryptedData: a.detail.encryptedData,
            iv: a.detail.iv,
            js_code: t.globalData.jsCode
        }, function(e) {
            e.success ? (wx.showToast({
                title: "成功绑定手机"
            }), t.globalData.userInfo.CellPhone = e.data, "changePwd" == o.data.formPage ? o.setInitState() : setTimeout(function() {
                wx.navigateBack({
                    delta: 1
                });
            }, 1500)) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        });
    },
    bindChangePwdFormSubmit: function(a) {
        var o = this, n = a.detail.target.id, i = a.detail.value.password, l = a.detail.value.pw, s = a.detail.value.checkCode;
        if ("sendCode1" != n) if (i.length < 6 || l.length < 6 || l != i || 0 == s.length) {
            var d = i.length < 6 ? "交易密码长度不能少于6位" : 0 == l.length ? "请输入确认交易密码" : l != i ? "交易密码输入不一致" : "请输入手机验证码";
            wx.showToast({
                title: d,
                icon: "none",
                mask: !0
            });
        } else this.verifyCheckCode(s, function(a) {
            e.httpPost(t.getUrl("MemberCenter/PostChangePayPwd"), {
                openId: t.globalData.openId,
                certificate: encodeURIComponent(a),
                password: i
            }, function(e) {
                var t = "新密码设置成功";
                e.success ? setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 1500) : t = e.msg, wx.showToast({
                    title: t,
                    icon: "none",
                    mask: !0
                });
            });
        }); else this.bindSendCheckCode(o.data.imageCheckCoded);
    },
    verifyCheckCode: function(a, o) {
        var n = this, i = this.data.changePwd ? t.getUrl("MemberCenter/GetCheckPhoneOrEmailCheckCode") : t.getUrl("Login/GetCheckPhoneOrEmailCheckCode"), l = {
            openId: t.globalData.openId,
            checkCode: a,
            contact: n.data.cellPhone
        };
        e.httpGet(i, l, function(e) {
            e.success && o instanceof Function ? o(e.data) : wx.showToast({
                title: e.msg,
                icon: "none",
                mask: !0
            });
        });
    },
    bindSendCheckCode: function(a, o) {
        if (!(this.data.time > 0)) {
            var n = {
                openId: t.globalData.openId,
                contact: this.data.cellPhone
            };
            a && (n.id = this.data.imgCodeData.Id, n.imageCheckCode = a, n.checkBind = !0);
            var i = this, l = this.data.changePwd ? t.getUrl("MemberCenter/GetPhoneOrEmailCheckCode") : t.getUrl("Login/GetPhoneOrEmailCheckCode");
            e.httpGet(l, n, function(e) {
                var t = "验证码已发送至您的手机";
                e.success ? (i.setData({
                    time: 60
                }), i.setTimePlay()) : t = e.msg, wx.showToast({
                    title: t,
                    icon: "none",
                    duration: 2e3,
                    mask: !0
                });
            });
        }
    },
    setTimePlay: function() {
        var e = this;
        setInterval(function() {
            e.setData({
                time: e.data.time - 1
            });
        }, 1e3);
    },
    bindKeyInput: function(e) {
        this.setData({
            imageCheckCoded: e.detail.value
        });
    },
    bindMobileFormSubmit: function(e) {
        var a = this, o = e.detail.target.id, n = e.detail.value.phone, i = e.detail.value.imgCode, l = e.detail.value.checkCode;
        if (this.setData({
            cellPhone: n
        }), "sendCode" == o && n.length > 0 && i.length > 0) this.bindSendCheckCode(i, !0); else if (0 != n.length && 0 != i.length && 0 != l.length) this.verifyCheckCode(l, function(e) {
            wx.showToast({
                title: "成功绑定手机"
            }), t.globalData.userInfo.CellPhone = n, "changePwd" == a.data.formPage ? a.setInitState() : setTimeout(function() {
                wx.navigateBack({
                    delta: 1
                });
            }, 1500);
        }); else {
            var s = 0 == n.length ? "请输入手机号码" : 0 == i.length ? "请输入图形验证码" : "请输入手机验证码";
            wx.showToast({
                title: s,
                icon: "none",
                image: "",
                mask: !0
            });
        }
    }
});