var t = getApp(), a = require("../../utils/config.js");

Page({
    data: {
        total: 0,
        balance: 0,
        draw: 0,
        freeze: 0,
        pageNo: 0,
        pageSize: 10,
        isNext: !0,
        recordList: [],
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(e) {
        var i = this;
        t.getDistrbutionName(function(t) {
            t.MyCommissionName && wx.setNavigationBarTitle({
                title: t.MyCommissionName
            }), i.setData({
                distributionName: t
            });
        }), t.getSysSettingData(function(t) {
            i.setData(t);
        }, !0), t.getOpenId(function(e) {
            e && (wx.showLoading({
                title: "加载中"
            }), a.httpGet(t.getUrl("Distribution/GetMyCommission"), {
                openId: e
            }, function(t) {
                wx.hideLoading(), t.success ? i.setData({
                    pageload: !1,
                    total: t.data.settlementAmount,
                    balance: t.data.balance,
                    draw: t.data.withdrawals,
                    freeze: t.data.unsettled
                }) : i.setData({
                    pageload: !1
                });
            }));
        }), this.getRecordList();
    },
    onReady: function() {},
    onReachBottom: function() {
        this.data.isNext && this.getRecordList();
    },
    getRecordList: function() {
        var e = this;
        t.getOpenId(function(i) {
            if (i) {
                if (e.loading) return;
                e.loading = !0, e.data.pageNo++, a.httpGet(t.getUrl("Distribution/GetRecordList"), {
                    openId: i,
                    pageSize: e.data.pageSize,
                    pageNo: e.data.pageNo
                }, function(t) {
                    if (e.loading = !1, t.success) {
                        var a = e.data.isNext, i = e.data.recordList.slice();
                        t.data.length < e.data.pageSize && (a = !1), i = i.concat(t.data), e.setData({
                            recordList: i,
                            isNext: a
                        });
                    }
                });
            }
        });
    }
});