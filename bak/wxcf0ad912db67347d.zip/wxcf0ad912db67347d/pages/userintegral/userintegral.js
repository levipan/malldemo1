var a = require("../../utils/config.js"), e = getApp();

Page({
    data: {
        rechargeHide: !0,
        cashHide: !0,
        pageno: 0,
        isEnd: !1,
        hasload: !1,
        list: []
    },
    onLoad: function(a) {
        var t = this;
        this.setData({
            integral: a.integral,
            franchiseeId: wx.getStorageSync("FranchiseeId") || 0
        }), e.getSysSettingData(function(a) {
            t.setData(a);
        }, !0);
    },
    onShow: function() {
        this.loadData();
    },
    loadData: function() {
        if (!this.data.isEnd) {
            wx.showLoading({
                title: "加载中"
            });
            var t = this;
            this.data.pageno++, this.setData({
                pageno: this.data.pageno
            }), a.httpGet(e.getUrl("MemberCenter/GetIntegralRecordList"), {
                openId: e.globalData.openId,
                pagesize: 15,
                pageno: this.data.pageno
            }, function(a) {
                a.data.forEach(function(a, e, t) {
                    if (a.ReMark && a.ReMark.indexOf("订单") >= 0) {
                        var i = a.ReMark.split("订单号")[1] ? a.ReMark.split("订单号")[1] : "";
                        a.ReMark = i.replace(/,/g, "，");
                    } else "其他" == a.TypeName ? a.ReMark = a.ReMark : "积分抵扣" != a.TypeName && "领卡礼包" !== a.TypeName && (a.ReMark = "");
                    "积分抵扣" == a.TypeName && (-1 == a.ReMark.indexOf("兑换") ? a.ReMark = "订单号" + a.ReMark : a.ReMark = a.ReMark), 
                    a.ReMark.indexOf(":") > -1 && (a.ReMark = a.ReMark.replace(/:/g, "：")), "订单评价" === a.TypeName && (a.ReMark = "：" + a.OrderId);
                }), t.data.list.push.apply(t.data.list, a.data), t.setData({
                    list: t.data.list,
                    hasload: !0,
                    isEnd: a.data.length < 15
                }), wx.hideLoading();
            });
        }
    },
    onReachBottom: function() {
        this.loadData();
    },
    bindIntegralHome: function() {
        wx.navigateTo({
            url: "../integralhome/integralhome"
        });
    }
});