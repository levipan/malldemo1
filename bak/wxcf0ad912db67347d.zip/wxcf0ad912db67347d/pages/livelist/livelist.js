Page({
    data: {},
    onLoad: function(o) {
        this.livelist = this.selectComponent("#livelist"), this.livelist.onLoad();
    },
    onReady: function() {},
    onShow: function() {
        this.livelist.onShow();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.livelist.onPullDownRefresh && this.livelist.onPullDownRefresh();
    },
    onReachBottom: function() {
        this.livelist.onReachBottom && this.livelist.onReachBottom();
    },
    onShareAppMessage: function() {}
});