function t(t, e, o) {
    return e in t ? Object.defineProperty(t, e, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = o, t;
}

var e = getApp(), o = require("../../utils/config.js");

Page({
    data: {
        isEmpty: !1,
        CouponList: null,
        PageIndex: 1,
        PageSize: 10,
        showtip: !1
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        var t = this;
        t.setData({
            PageIndex: 1,
            CouponList: []
        }), t.loadData(t, !1);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var t = this, e = t.data.PageIndex;
        e = parseInt(e) + 1, t.setData({
            PageIndex: e
        }), t.loadData(t, !0);
    },
    onShareAppMessage: function() {},
    getCoupon: function(a) {
        var n = this, i = a.currentTarget.dataset.index;
        o.httpGet(e.getUrl("Coupon/GetUserCoupon"), {
            couponId: a.currentTarget.dataset.id,
            openId: e.globalData.openId
        }, function(e) {
            if (e.success) wx.showToast({
                title: "优惠券领取成功"
            }); else if (502 == e.code) wx.showToast({
                title: "请先登录账号",
                icon: "none"
            }), wx.navigateTo({
                url: "../login/login"
            }); else if (1 == e.code) wx.showToast({
                title: e.msg,
                icon: "none"
            }), (o = n).setData({
                PageIndex: 1,
                CouponList: []
            }), o.loadData(o, !1); else if (2 == e.code) {
                wx.showToast({
                    title: "已超过最大可领取数",
                    icon: "none"
                });
                a = "CouponList[" + i + "].canReceive";
                (o = n).setData(t({}, a, !1));
            } else if (3 == e.code) {
                wx.showToast({
                    title: "优惠券已抢光",
                    icon: "none"
                });
                var o = n, a = "CouponList[" + i + "].canReceive";
                o.setData(t({}, a, !1));
            } else wx.showToast({
                title: e.msg,
                icon: "none"
            });
        });
    },
    loadData: function(t, o) {
        wx.showLoading({
            title: "加载中"
        }), wx.request({
            url: e.getUrl("Coupon/GetCouponCenterList"),
            data: {
                pageIndex: t.data.PageIndex,
                pageSize: t.data.PageSize
            },
            success: function(a) {
                if ((a = a.data).success) {
                    var n = a.data.Data;
                    if (o) {
                        var i = t.data.CouponList, s = n.length <= 0;
                        i.push.apply(i, n), t.setData({
                            CouponList: i,
                            isEmpty: s
                        });
                    } else {
                        s = n.length <= 0;
                        t.setData({
                            CouponList: n,
                            isEmpty: s
                        });
                    }
                } else e.showErrorModal(a.msg, function(t) {
                    t.confirm && wx.navigateBack({
                        delta: 1
                    });
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    showRemark: function(t) {
        this.setData({
            useingTip: t.currentTarget.dataset.remark,
            showtip: !0
        });
    },
    hidetip: function() {
        this.setData({
            showtip: !1
        });
    }
});