var e = getApp();

Page({
    data: {
        outurl: "",
        originUrl: ""
    },
    onLoad: function(t) {
        t.referralUserId && e.setRefferUserId(t.referralUserId);
        var a = decodeURIComponent(t.url);
        this.setData({
            payOrderId: t.payOrderId || null,
            shareTitle: t.ShareTitle || "",
            shareImg: t.ShareImg || "",
            type: t.type || "",
            originUrl: a
        }), a.toLowerCase().indexOf("http://") > -1 && (a = a.replace("http://", "https://")), 
        a.indexOf("from=shopapplet") < 0 && (a.indexOf("?") > -1 ? a += "&from=shopapplet" : a += "?from=shopapplet"), 
        a = a.indexOf("/?") > -1 ? a.replace("/m/?", "/m/?r=" + new Date().getTime() + "/&") : a.replace("/m/", "/m/?r=" + new Date().getTime() + "/"), 
        this.setData({
            originUrl: a
        });
    },
    closePage: function() {
        wx.navigateBack();
    },
    onShow: function() {
        var t = this, a = t.data.originUrl;
        "needLogin" === t.data.type ? wx.getStorageSync("mallAppletOpenId") ? e.getOpenId(function(e) {
            a += "&AppletSessionId=" + e, t.data.payOrderId && (a += "&orderid=" + t.data.payOrderId), 
            t.setData({
                outurl: a
            });
        }) : (t.setData({
            outurl: ""
        }), e.showErrorModal("如果您想要参加活动，请先登录哟！", function() {
            wx.navigateTo({
                url: "../login/login"
            });
        })) : t.setData({
            outurl: a
        });
    },
    onShareAppMessage: function(t) {
        var a, r = this, n = t.webViewUrl;
        return "needLogin" === r.data.type ? (a = "pages/outurl/outurl?type=needLogin&url=" + encodeURIComponent(this.data.originUrl.replace("AppletSessionId", "asid")), 
        r.data.shareTitle && (a += "&ShareTitle=" + r.data.shareTitle + "&ShareImg=" + r.data.shareImg)) : a = "pages/outurl/outurl?type=needLogin&url=" + encodeURIComponent(n.replace("AppletSessionId", "asid")), 
        e.globalData.userInfo.IsDistributor && (a += "&referralUserId=" + e.globalData.userInfo.UserId), 
        {
            path: a,
            title: r.data.shareTitle ? r.data.shareTitle : "",
            imageUrl: r.data.shareImg ? r.data.shareImg : "",
            success: function(e) {
                r.setData({
                    outurl: n
                }), wx.showToast({
                    title: "转发成功",
                    icon: "success",
                    duration: 2e3
                });
            },
            fail: function(e) {}
        };
    },
    bindmessage: function(t) {
        var a = t.detail.data[0];
        if (a.orderId) {
            var r = a.orderId, n = a.successUrl, o = a.errorUrl;
            e.getOpenId(function(t) {
                t && wx.request({
                    url: e.getUrl("Payment/GetPaymentList"),
                    data: {
                        openId: t,
                        orderId: r
                    },
                    success: function(e) {
                        if ((e = e.data).success) {
                            var t = e.data;
                            wx.requestPayment({
                                timeStamp: t.timeStamp,
                                nonceStr: t.nonceStr,
                                package: "prepay_id=" + t.prepayId,
                                signType: "MD5",
                                paySign: t.sign,
                                success: function(e) {
                                    wx.showModal({
                                        title: "提示",
                                        content: "支付成功！",
                                        showCancel: !1,
                                        success: function(e) {
                                            e.confirm && (this.setData({}), wx.navigateTo({
                                                url: "../outurl/outurl?type=needLogin&payOrderId=" + r + "&url=" + n
                                            }));
                                        }
                                    });
                                },
                                fail: function(e) {
                                    wx.showModal({
                                        title: "提示",
                                        content: "支付失败",
                                        showCancel: !0,
                                        success: function(e) {
                                            wx.navigateTo({
                                                url: "../outurl/outurl?type=needLogin&payOrderId=" + r + "&url=" + o
                                            });
                                        }
                                    });
                                }
                            });
                        } else wx.showModal({
                            title: "提示",
                            content: e.msg,
                            showCancel: !1,
                            success: function(e) {
                                wx.navigateTo({
                                    url: "../outurl/outurl?type=needLogin&payOrderId=" + r + "&url=" + o
                                });
                            }
                        });
                    }
                });
            });
        }
    }
});