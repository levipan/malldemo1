var e = require("../../utils/config.js"), a = getApp();

Page({
    data: {
        IsSubmitting: !1,
        RefundId: 0,
        ShowData: null,
        ExpressCompanyName: "",
        ShipOrderNumber: "",
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(e) {
        var t = this, r = e.refundId;
        t.setData({
            RefundId: r,
            PrimaryColor: a.globalData.PrimaryColor,
            PrimaryTxtColor: a.globalData.PrimaryTxtColor
        }), wx.request({
            url: a.getUrl("MyOrderRefund/GetRefundDeliveryToReceivingModel"),
            data: {
                openId: a.globalData.openId,
                refundId: r
            },
            success: function(e) {
                if ((e = e.data).success) {
                    var r = e.data;
                    t.setData({
                        ShowData: r
                    });
                } else "502" == e.code ? wx.navigateTo({
                    url: "../login/login"
                }) : a.showErrorModal(e.msg, function(e) {
                    e.confirm && wx.navigateBack({
                        delta: 1
                    });
                });
            }
        });
    },
    changeExpressCompanyName: function(e) {
        this.setData({
            ExpressCompanyName: e.detail.value
        });
    },
    changeShipOrderNumber: function(e) {
        this.setData({
            ShipOrderNumber: e.detail.value
        });
    },
    submitExpressDelivery: function(t) {
        var r = this;
        if (!this.data.IsSubmitting) if (this.data.ExpressCompanyName) if (this.data.ShipOrderNumber) {
            this.setData({
                isSubmitting: !0
            });
            var i = {
                openId: a.globalData.openId,
                refundId: this.data.RefundId,
                expressCompanyName: this.data.ExpressCompanyName,
                shipOrderNumber: this.data.ShipOrderNumber
            };
            e.httpPost(a.getUrl("MyOrderRefund/PostUserDeliveryToReceiving"), i, function(e) {
                e.success ? a.showErrorModal("寄货信息提交成功", function(e) {
                    e.confirm && wx.redirectTo({
                        url: "../refundlist/refundlist"
                    });
                }) : (a.showErrorModal(res.msg), r.setData({
                    isSubmitting: !1
                }));
            });
        } else wx.showToast({
            title: "请填写快递单号",
            icon: "none"
        }); else wx.showToast({
            title: "请填写快递公司",
            icon: "none"
        });
    }
});