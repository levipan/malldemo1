var e = getApp(), a = require("../../utils/busEvent");

Page({
    data: {
        isEmpty: !1,
        Status: 0,
        OrderList: null,
        PageIndex: 1,
        PageSize: 10,
        codeHide: !0,
        templateList: [],
        appletTemplate: []
    },
    onLoad: function(a) {
        var t = this, r = a.status;
        "" != a.status && void 0 != a.status || (r = 0);
        var o = this;
        o.setData({
            Status: r
        }), e.getSysSettingData(function(e) {
            t.setData(e);
        }, !0), wx.request({
            url: e.getUrl("Common/GetWeiXinMsgTemplateListByApplet"),
            data: {
                openId: e.globalData.openId
            },
            success: function(e) {
                (e = e.data).success && o.setData({
                    templateList: e.data
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        wx.hideShareMenu();
        var a = this;
        a.setData({
            PageIndex: 1,
            OrderList: []
        }), a.loadData(a.data.Status, a, !1), e.getShareConfig(function(e) {
            a.setData({
                shareTitle: e.baskShareTitle,
                shareImage: e.baskShareImage
            });
        }), wx.request({
            url: e.getUrl("MemberCenter/GetUserOtherInfo"),
            data: {
                openId: e.globalData.openId
            },
            success: function(e) {
                (e = e.data).success && a.setData({
                    nickname: e.data.Nick
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onReachBottom: function() {
        var e = this, a = e.data.PageIndex + 1;
        e.setData({
            PageIndex: a
        }), e.loadData(e.data.Status, e, !0);
    },
    goToExp: function(e) {
        var a = e.currentTarget.dataset.expname, t = e.currentTarget.dataset.shipnum, r = e.currentTarget.dataset.orderid, o = e.currentTarget.dataset.phonenumber;
        wx.navigateTo({
            url: "../logistics/logistics?expressCompanyName=" + a + "&shipOrderNumber=" + t + "&phoneNumber=" + o + "&orderId=" + r
        });
    },
    goToDaDaExp: function(e) {
        var a = e.currentTarget.dataset, t = a.orderid, r = a.latitude, o = a.longitude;
        wx.navigateTo({
            url: "../logisticMap/logisticMap?latitude=" + r + "&longitude=" + o + "&orderId=" + t
        });
    },
    closeOrder: function(a) {
        var t = this, r = a.target.dataset.orderid;
        wx.showModal({
            title: "提示",
            content: "确定要取消订单吗？",
            confirmColor: e.globalData.PrimaryColor,
            success: function(a) {
                a.confirm && wx.request({
                    url: e.getUrl("MyOrder/GetCloseOrder"),
                    data: {
                        openId: e.globalData.openId,
                        orderId: r
                    },
                    success: function(a) {
                        (a = a.data).success ? wx.showModal({
                            title: "提示",
                            content: a.msg,
                            confirmColor: e.globalData.PrimaryColor,
                            showCancel: !1,
                            success: function(e) {
                                e.confirm && wx.navigateTo({
                                    url: "../orderlist/orderlist?status=" + t.data.Status
                                });
                            }
                        }) : "502" == a.code ? wx.navigateTo({
                            url: "../login/login"
                        }) : e.showErrorModal(a.msg);
                    }
                });
            }
        });
    },
    confirmTakeDelivery: function(a) {
        var t = this, r = a.currentTarget.dataset.orderid;
        wx.showModal({
            title: "提示",
            content: "确认商品全部签收后再点收货哦~",
            confirmColor: e.globalData.PrimaryColor,
            success: function(a) {
                a.confirm && wx.request({
                    url: e.getUrl("MyOrder/GetConfirmReceiveGoods"),
                    data: {
                        orderId: r,
                        openId: e.globalData.openId
                    },
                    success: function(a) {
                        a.data.success ? t.onShow() : e.showErrorModal(a.data.msg);
                    }
                });
            }
        });
    },
    orderPay: function(a) {
        var t = this, r = a.currentTarget.dataset.orderid;
        this.data.payLoading || (this.data.payLoading = !0, wx.request({
            url: e.getUrl("MyOrder/GetOrderDetail"),
            data: {
                openId: e.globalData.openId,
                orderId: r
            },
            success: function(a) {
                if ((a = a.data).success) {
                    var o = a.data;
                    t.setAppletTemplate(o.DeliveryType, o.OrderType), e.orderPay(r, t.data.Status, !0, t.data.appletTemplate, function(e) {
                        e.fail ? t.data.payLoading = !1 : (t.data.PageIndex = 1, t.loadData(t.data.Status, t, !1));
                    });
                }
            }
        }));
    },
    onTabClick: function(e) {
        var a = this;
        a.setData({
            PageIndex: 1
        }), a.loadData(e.currentTarget.dataset.status, a, !1);
    },
    onShareAppMessage: function(a) {
        var t, r, o;
        if ("button" === a.from) {
            t = a.target.dataset.orderid, o = this.data.shareImage ? this.data.shareImage : a.target.dataset.img, 
            r = e.globalData.openId, wx.request({
                url: e.getUrl("MyOrder/GetOrderShareAddIntegral"),
                data: {
                    orderId: t,
                    openId: r
                },
                success: function(e) {}
            });
            var s = a.target.dataset.shopname, d = this.data.shareTitle.replace(/{shequ}/g, s).replace(/{nickname}/g, this.data.nickname);
        }
        var i = "pages/ordershare/ordershare?orderId=" + t;
        return e.globalData.userInfo.IsDistributor && (i += "&referralUserId=" + e.globalData.userInfo.UserId), 
        console.log(i), {
            title: d,
            imageUrl: o,
            path: i
        };
    },
    goUsercenter: function() {
        a.emit("tabUserChange", {
            url: "../usercenter/usercenter"
        });
    },
    showReview: function(e) {
        var a = e.currentTarget.dataset.orderid;
        e.currentTarget.dataset.commentcount > 0 ? wx.navigateTo({
            url: "../commentappend/commentappend?id=" + a
        }) : wx.navigateTo({
            url: "../comment/comment?id=" + a
        });
    },
    goToOrderDetail: function(e) {
        var a = e.currentTarget.dataset.orderid;
        wx.navigateTo({
            url: "../orderdetails/orderdetails?orderid=" + a
        });
    },
    loadData: function(a, t, r) {
        wx.showLoading({
            title: "加载中"
        }), wx.request({
            url: e.getUrl("MyOrder/GetOrders"),
            data: {
                openId: e.globalData.openId,
                status: a,
                pageIndex: t.data.PageIndex,
                pageSize: t.data.PageSize
            },
            success: function(o) {
                if ((o = o.data).success) {
                    var s = o.data.rows;
                    if (r) {
                        var d = t.data.OrderList;
                        d.push.apply(d, s), t.setData({
                            OrderList: d
                        });
                    } else {
                        var i = s.length <= 0;
                        t.setData({
                            Status: a,
                            OrderList: s,
                            isEmpty: i
                        });
                    }
                } else "502" == o.code ? wx.navigateTo({
                    url: "../login/login"
                }) : e.showErrorModal(o.msg, function(e) {
                    e.confirm && wx.navigateBack({
                        delta: 1
                    });
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    hideCode: function() {
        this.setData({
            isVerifyCode: !1,
            codeHide: !0
        });
    },
    showPickCode: function(a) {
        var t = a.currentTarget.dataset.pickupcodestr, r = this;
        wx.request({
            url: e.getUrl("MyOrder/GetPickupCodeQRCode"),
            data: {
                openId: e.globalData.openId,
                pickupCode: t
            },
            success: function(a) {
                a.data.success ? r.setData({
                    pickupcode: a.data.data,
                    codeHide: !1,
                    pickupcodeStr: t
                }) : (a.data.code = 502) ? wx.navigateTo({
                    url: "../login/login"
                }) : e.showErrorModal(a.data.msg);
            }
        });
    },
    showVerifyCode: function(a) {
        var t = a.currentTarget.dataset.pickupcodestr, r = this;
        wx.request({
            url: e.getUrl("MyOrder/GetPickupCodeQRCode"),
            data: {
                openId: e.globalData.openId,
                pickupCode: t
            },
            success: function(a) {
                a.data.success ? r.setData({
                    isVerifyCode: !0,
                    pickupcode: a.data.data,
                    codeHide: !1,
                    pickupcodeStr: t
                }) : (a.data.code = 502) ? wx.navigateTo({
                    url: "../login/login"
                }) : e.showErrorModal(a.data.msg);
            }
        });
    },
    setAppletTemplate: function(e, a) {
        for (var t = this, r = [], o = 0; o < t.data.templateList.length; o++) 7 == a ? 19 == t.data.templateList[o].MessageType && r.push(t.data.templateList[o].TemplateId) : 1 == e && 13 == t.data.templateList[o].MessageType ? r.push(t.data.templateList[o].TemplateId) : 2 == e && 15 == t.data.templateList[o].MessageType ? r.push(t.data.templateList[o].TemplateId) : 4 == e && 18 == t.data.templateList[o].MessageType ? r.push(t.data.templateList[o].TemplateId) : 19 == t.data.templateList[o].MessageType && r.push(t.data.templateList[o].TemplateId);
        t.setData({
            appletTemplate: r
        });
    },
    onOpenActive: function(e) {
        var a = e.currentTarget.dataset.activeid;
        a && wx.navigateTo({
            url: "/pages/groupsolitairedetail/groupsolitairedetail?activeId=" + a + "&shopBranchId=" + wx.getStorageSync("shopBranchId")
        });
    }
});