var a = getApp();

Page({
    data: {
        hasload: !1
    },
    onLoad: function(t) {
        var e = this;
        t.referralUserId && a.setRefferUserId(t.referralUserId), wx.request({
            url: a.getUrl("MyOrder/GetOrderShare"),
            data: {
                orderId: t.orderId
            },
            success: function(a) {
                (a = a.data).success ? e.setData({
                    detail: a.data,
                    shopBranchId: parseInt(a.data.ShopBranchId),
                    hasload: !0
                }) : wx.showToast({
                    title: a.msg
                });
            }
        });
    },
    onShow: function() {
        var t = this;
        a.getSysSettingData(function(e) {
            e.IsShowPickupDate = a.globalData.IsShowPickupDate, t.setData(e);
        }, !0), this.setData({
            isShowTel: a.globalData.IsShowShopBranchLink
        });
    },
    callShopTel: function(a) {
        wx.makePhoneCall({
            phoneNumber: a.currentTarget.dataset.tel
        });
    },
    goProductDetail: function(a) {
        var t = a.currentTarget.dataset.pid, e = this.data.detail.IsSelfSell ? "../storeProductdetail/storeProductdetail?shopBranchId=" : "../productdetail/productdetail?shopBranchId=";
        this.data.detail.ServiceShopId && this.data.detail.isServiceShopOrder && (e = "../serviceProductdetail/serviceProductdetail?serviceShopId=" + this.data.detail.ServiceShopId + "&shopBranchId="), 
        wx.navigateTo({
            url: e + this.data.shopBranchId + "&id=" + t
        });
    },
    goHome: function() {
        a.globalData.newStoreId = this.data.shopBranchId, wx.switchTab({
            url: "../index/index"
        });
    }
});