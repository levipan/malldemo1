function t(t) {
    if (Array.isArray(t)) {
        for (var a = 0, e = Array(t.length); a < t.length; a++) e[a] = t[a];
        return e;
    }
    return Array.from(t);
}

var a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/config")), e = require("../../utils/util"), o = getApp();

Page({
    data: {
        productId: "",
        isPopup: !1,
        shopBranchId: "",
        info: {},
        activeId: "",
        Products: [],
        pageNo: 1,
        pageSize: 10,
        isNoNext: !1,
        loading: !1,
        isEmpty: !1,
        buyRecord: [],
        times: {
            d: 0,
            h: 0,
            m: 0,
            s: 0
        },
        constant: {
            status: {
                noStart: 0,
                ongoing: 1,
                isEnd: 2,
                isColose: 3
            }
        },
        maxNumber: 0
    },
    onLoad: function(t) {
        var a = this;
        t.referralUserId && o.setRefferUserId(t.referralUserId), o.shopBranchChange(t.shopBranchId, "formPage=groupsolitairedetail&solitaireId=" + t.activeId) || (this.setData({
            shopBranchId: t.shopBranchId || wx.getStorageSync("shopBranchId"),
            activeId: t.activeId
        }), o.getSysSettingData(function(t) {
            a.setData(t);
        }), this.loadData());
    },
    onReady: function() {
        this.joinCart = this.selectComponent("#joinCart"), this.cart = this.selectComponent("#cart"), 
        this.productDetail = this.selectComponent("#productDetail");
    },
    onUnload: function() {
        clearInterval(this.timer);
    },
    onPullDownRefresh: function() {
        this.loadData();
    },
    onReachBottom: function() {
        this.data.isNoNext && this.data.info.IsShowList && !this.data.loading && (this.data.pageNo += 1, 
        this.getBuyRecord());
    },
    onShareAppMessage: function() {
        var t = "pages/groupsolitairedetail/groupsolitairedetail?activeId=" + this.data.activeId + "&shopBranchId=" + this.data.shopBranchId;
        return o.globalData.userInfo.IsDistributor && (t += "&referralUserId=" + o.globalData.userInfo.UserId), 
        {
            path: t,
            title: this.data.info.ShareDetails,
            imageUrl: this.data.info.ShareImg
        };
    },
    loadData: function() {
        var t = this;
        o.getOpenId(function(e) {
            a.default.httpGet(o.getUrl("GroupSolitaire/GetActivity"), {
                id: t.data.activeId,
                shopBranchId: t.data.shopBranchId,
                openId: e
            }, function(a) {
                wx.stopPullDownRefresh(), a.success ? 0 != a.data.Products.length ? (t.setData({
                    isEmpty: !1,
                    isInit: !0,
                    isShowCart: a.data.Status == t.data.constant.status.ongoing,
                    info: a.data,
                    Products: a.data.Products
                }), a.data.IsShowList && t.getBuyRecord(), a.data.Status === t.data.constant.status.noStart && a.data.StartSecond > 0 && t._setCountDown()) : t.setData({
                    isEmpty: !0
                }) : wx.showToast({
                    title: a.msg
                });
            });
        }, !0);
    },
    getBuyRecord: function() {
        var e = this;
        this.setData({
            loading: !0
        }), o.getOpenId(function(i) {
            a.default.httpGet(o.getUrl("GroupSolitaire/GetBuyRecord"), {
                id: e.data.activeId,
                openId: i,
                pageNo: e.data.pageNo,
                pageSize: e.data.pageSize
            }, function(a) {
                e.setData({
                    loading: !1
                }), a.success && e.setData({
                    buyRecord: e.data.pageNo > 1 ? [].concat(t(e.data.buyRecord), t(a.data.Models)) : a.data.Models,
                    isNoNext: a.data.Models.length < e.data.pageSize
                });
            });
        }, !0);
    },
    syncCartData: function(t) {
        var a = t.detail;
        if (a) {
            var e = {};
            a.map(function(t) {
                e[t.ProductId] ? e[t.ProductId].quantity = e[t.ProductId].quantity + t.Quantity : e[t.ProductId] = {
                    quantity: t.Quantity
                };
            }), this.data.Products.map(function(t) {
                var a = 0;
                e[t.ProductId] && (a = e[t.ProductId].quantity), t.Quantity = a;
            }), this.setData({
                Products: this.data.Products
            });
        } else this.data.Products.map(function(t) {
            t.Quantity = 0;
        }), this.setData({
            Products: this.data.Products
        });
    },
    setPopupShow: function(t) {
        var a = t.detail;
        this.setData({
            isPopup: a
        });
    },
    onJoinCart: function(t) {
        var a = this, e = t.currentTarget.dataset, i = e.index, n = e.maxnumber, s = this.data.Products[i];
        o.getOpenId(function(t) {
            t && a.setData({
                maxNumber: n || 0,
                productId: s.ProductId
            }, function() {
                s.HasSKU ? a.cart.chooseSku() : a.cart.changeCart({
                    skuId: s.ProductId + "_0_0_0",
                    pid: s.ProductId,
                    quantity: 1
                });
            });
        });
    },
    onOpenDetail: function(t) {
        var a = this, e = t.currentTarget.dataset.id;
        this.setData({
            isPopup: !0,
            productId: e
        }, function() {
            a.productDetail.init();
        });
    },
    onCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.info.InitiatorContact
        });
    },
    _setCountDown: function() {
        var t = this;
        clearInterval(this.timer), this.timer = setInterval(function() {
            t.data.info.StartSecond -= 1;
            var a = e.getTimeRemaining(t.data.info.StartSecond, !1, !0);
            t.setData({
                times: {
                    h: a.hour,
                    m: a.min,
                    s: a.sec
                }
            }), 0 == t.data.info.StartSecond && (clearInterval(t.timer), t.loadData());
        }, 1e3);
    }
});