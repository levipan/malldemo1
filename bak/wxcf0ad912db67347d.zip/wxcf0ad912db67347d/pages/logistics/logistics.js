var e = getApp();

Page({
    data: {
        ExpressCompanyName: "",
        ShipOrderNumber: "",
        ShipTo: "",
        CellPhone: "",
        Address: "",
        LogisticsData: null,
        tabone: "",
        DriverName: "",
        DriverPhone: "",
        explist: "",
        orderId: "",
        phoneNumber: "",
        productImg: "",
        productName: ""
    },
    onLoad: function(r) {
        var a = this, t = r.expressCompanyName, s = r.shipOrderNumber, d = r.orderId, o = r.phoneNumber;
        this.setData({
            ExpressCompanyName: t,
            ShipOrderNumber: s,
            orderId: d,
            phoneNumber: o,
            productImg: r.productImg,
            productName: r.productName
        }), wx.request({
            url: e.getUrl("MyOrder/GetExpressData"),
            data: {
                expressCompanyName: t,
                shipOrderNumber: s,
                orderId: d,
                phoneNumber: o
            },
            success: function(e) {
                if (e.data.success) {
                    var r = e.data.data;
                    r.LogisticsData.success && a.setData({
                        explist: r.LogisticsData.traces
                    });
                }
            }
        });
    },
    handleCopy: function() {
        wx.setClipboardData({
            data: this.data.ShipOrderNumber
        });
    }
});