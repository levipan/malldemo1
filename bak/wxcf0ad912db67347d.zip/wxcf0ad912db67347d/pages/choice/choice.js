getApp();

Page({
    data: {},
    onLoad: function(n) {
        this.choice = this.selectComponent("#choice"), this.choice.onLoad();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});