Page({
    data: {},
    onLoad: function(t) {
        this.cart = this.selectComponent("#cart"), this.cart.onLoad();
    },
    onReady: function() {},
    onShow: function() {
        this.cart.onShow();
    }
});