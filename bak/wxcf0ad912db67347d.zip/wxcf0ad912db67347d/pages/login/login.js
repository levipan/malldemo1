var e = getApp();

Page({
    data: {
        getRequestUrl: e.getRequestUrl,
        showPhone: !1,
        timestamp: new Date(),
        canIUseGetUserProfile: !1
    },
    onLoad: function() {
        this.setData({
            canIUseGetUserProfile: e.globalData.canIUseGetUserProfile
        });
    },
    quickLogin: function() {
        var o = this;
        wx.showLoading({
            title: "登录中",
            mask: !0
        }), e.wxLogin(function(e, t) {
            e && (t.toBindPhone && !t.CellPhone ? o.setData({
                showPhone: !0
            }) : o._back());
        });
    },
    goProtocol: function() {
        wx.navigateTo({
            url: "../loginprotocol/loginprotocol"
        });
    },
    getPhoneNumber: function(o) {
        var t = this;
        "getPhoneNumber:ok" === o.detail.errMsg && e.getPhoneNumber(o.detail, function() {
            t.setData({
                showPhone: !1
            }), setTimeout(function() {
                this._back();
            }, 1500);
        });
    },
    _back: function() {
        var o = getCurrentPages(), t = o[o.length - 2];
        "pages/userapplystore/userapplystore" === t.route ? wx.redirectTo({
            url: "../userapplystore/userapplystore?cellPhone=" + e.globalData.userInfo.CellPhone + "&storePhone=" + (t.options.storePhone || "") + "&sellerId=" + e.globalData.sellerId
        }) : wx.navigateBack();
    }
});