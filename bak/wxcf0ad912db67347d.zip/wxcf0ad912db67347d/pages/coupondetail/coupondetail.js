var o = require("../../utils/config.js"), n = getApp();

Page({
    data: {
        CouponName: "",
        Price: 0,
        LimitText: "",
        CanUseProducts: "",
        CouponsDate: "",
        CouponId: "",
        coupimg: n.getRequestUrl + "/Images/coupdetail-back.jpg",
        coupimgLine: n.getRequestUrl + "/Images/coup-line.jpg",
        Remark: ""
    },
    onLoad: function(e) {
        var t = this, a = e.id;
        t.setData({
            CouponId: a
        });
        var i = {
            openId: n.globalData.openId,
            couponId: a
        };
        o.httpGet(n.getUrl("Coupon/GetCouponDetail"), i, t.getCouponsData);
    },
    getCouponsData: function(o) {
        var e = this;
        if (1 == o.success) {
            var t = o.data, a = t.StartTime.substring(0, 10), i = t.ClosingTime.substring(0, 10), s = "";
            s = 1 == t.UseArea ? "部分商品可用" : "全场通用";
            var u = "";
            u = t.OrderUseLimit > 0 ? "订单满" + t.OrderUseLimit.toFixed(2) + "元可用" : "订单金额无限制", 
            e.setData({
                CouponName: t.CouponName,
                Price: t.Price,
                LimitText: u,
                CanUseProducts: s,
                CouponsDate: a + "~" + i,
                CouponId: t.CouponId,
                Remark: null == t.Remark ? "" : t.Remark
            });
        } else {
            o.msg;
            n.showErrorModal(o.msg, function(o) {
                o.confirm && wx.navigateBack({
                    delta: 1
                });
            });
        }
    },
    GetCoupon: function() {
        var o = this.data.CouponId, e = this;
        "" == o || parseInt(o) <= 0 ? n.showErrorModal("领取的优惠券不存在", function(o) {
            o.confirm && wx.navigateBack({
                delta: 1
            });
        }) : n.getOpenId(function(t) {
            wx.request({
                url: n.getUrl("Coupon/GetUserCoupon"),
                data: {
                    openId: t,
                    couponId: o
                },
                success: function(o) {
                    (o = o.data).success ? wx.showModal({
                        title: "提示",
                        content: o.msg,
                        showCancel: !1
                    }) : "502" == o.code ? wx.navigateTo({
                        url: "../login/login"
                    }) : (e.setData({
                        backShow: "none",
                        couponShow: "none"
                    }), wx.showToast({
                        title: o.msg,
                        icon: "none"
                    }));
                }
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});