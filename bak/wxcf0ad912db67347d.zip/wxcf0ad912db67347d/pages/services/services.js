Page({
    data: {},
    onShow: function(o) {
        this.services.onShow();
    },
    onLoad: function() {
        this.services = this.selectComponent("#services"), this.services.onLoad();
    },
    onReachBottom: function() {
        this.services.onReachBottom && this.services.onReachBottom();
    }
});