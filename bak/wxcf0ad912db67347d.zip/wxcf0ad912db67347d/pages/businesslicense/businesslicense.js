var e = getApp(), t = require("../wxParse/wxParse.js"), i = require("../../utils/config.js");

Page({
    data: {
        Agreement: "",
        PrimaryColor: "",
        PrimaryTxtColor: ""
    },
    onLoad: function(n) {
        var a = this;
        e.getSysSettingData(function(e) {
            a.setData(e);
        }, !1), e.getOpenId(function(n) {
            n && (wx.showLoading({
                title: "加载中"
            }), i.httpGet(e.getUrl("Home/GetBusinessLicense"), {
                openId: n
            }, function(e) {
                wx.hideLoading();
                var i = e.data.BusinessLicense;
                t.wxParse("Agreement", "html", i, a);
            }));
        });
    }
});