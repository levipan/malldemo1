require("../../utils/config.js");

var t, e = require("../../utils/qqmap-wx-jssdk.min.js"), a = null, o = (new Array(), 
0), n = 0, s = getApp();

Page({
    data: {
        fromLatLng: "",
        cityname: "",
        location: "",
        isLogin: !0,
        showDistpicker: !1,
        showSearch: !1,
        ptype: 0
    },
    onLoad: function(a) {
        var o = this, n = this;
        t = new e({
            key: s.globalData.QQMapKey
        }), s.getSysSettingData(function(t) {
            o.setData(t);
        }, !0), n.setData({
            fromLatLng: wx.getStorageSync("o2oFromLatLng"),
            cityname: a.cityname,
            location: a.location,
            ptype: a.ptype ? a.ptype : "0",
            pageform: a.page ? a.page : ""
        });
        var i = n.data.fromLatLng ? n.data.fromLatLng.split(",") : null;
        i && t.reverseGeocoder({
            location: {
                latitude: i[0],
                longitude: i[1]
            },
            get_poi: 1,
            poi_options: "page_size=10;radius=1000;policy=2",
            success: function(t) {
                n.setData({
                    aroundAddrList: t.result.pois
                });
            }
        });
    },
    onShow: function() {
        var t = this;
        wx.getStorageSync("mallAppletOpenId") ? t.setData({
            isLogin: !0
        }) : t.setData({
            isLogin: !1
        });
    },
    getLocation: function() {
        var e = this, a = getCurrentPages(), o = a[a.length - 2].services || a[a.length - 2].stores || a[a.length - 2].data.tabComponent.stores;
        wx.getLocation({
            type: "gcj02",
            success: function(a) {
                e.setData({
                    fromLatLng: a.latitude + "," + a.longitude
                }), wx.setStorage({
                    key: "o2oFromLatLng",
                    data: a.latitude + "," + a.longitude
                }), t.reverseGeocoder({
                    location: {
                        latitude: a.latitude,
                        longitude: a.longitude
                    },
                    get_poi: 1,
                    poi_options: "page_size=10;radius=1000;policy=2",
                    success: function(t) {
                        e.setData({
                            cityname: t.result.address_component.city,
                            location: t.result.formatted_addresses.recommend,
                            aroundAddrList: t.result.pois
                        });
                    },
                    fail: function(t) {
                        wx.showToast({
                            title: "获取位置失败"
                        });
                    }
                }), 1 == e.data.ptype ? (o.setData({
                    fromLatLng: a.latitude + "," + a.longitude
                }), o.getLocation()) : (o.setData({
                    fromLatLng: a.latitude + "," + a.longitude,
                    showNoLocate: !1,
                    isDataEnd: !1,
                    pageIndex: 1,
                    storeList: []
                }), o.getStoreList(1));
            },
            fail: function(t) {
                e.setData({
                    location: "未能获取地理位置"
                }), wx.removeStorageSync("o2oFromLatLng");
            }
        });
    },
    reGetLocation: function() {
        var e = this, a = getCurrentPages(), o = "";
        a[a.length - 2] && a[a.length - 2].stores && (o = a[a.length - 2].stores), a[a.length - 2] && a[a.length - 2].services && (o = a[a.length - 2].services), 
        a[a.length - 2].data && a[a.length - 2].data.tabComponent && a[a.length - 2].data.tabComponent.stores && (o = a[a.length - 2].data.tabComponent.stores), 
        o || (o = a[a.length - 2]), wx.getLocation({
            type: "gcj02",
            success: function(a) {
                e.setData({
                    fromLatLng: a.latitude + "," + a.longitude
                }), wx.setStorage({
                    key: "o2oFromLatLng",
                    data: a.latitude + "," + a.longitude
                }), t.reverseGeocoder({
                    location: {
                        latitude: a.latitude,
                        longitude: a.longitude
                    },
                    get_poi: 1,
                    poi_options: "page_size=10;radius=1000;policy=2",
                    success: function(t) {
                        e.setData({
                            cityname: t.result.address_component.city,
                            location: t.result.formatted_addresses.recommend,
                            showSearch: !1,
                            aroundAddrList: t.result.pois
                        });
                        var a = t.result.address_component.province + "," + t.result.address_component.city + "," + t.result.address_component.district + "," + t.result.address_reference.town.title;
                        o.setData({
                            currentFromLatLng: t.latitude + "," + t.longitude,
                            addressPath: a
                        });
                    },
                    fail: function(t) {
                        wx.showToast({
                            title: "获取位置失败"
                        });
                    }
                }), "apply" != e.data.pageform && (1 == e.data.ptype ? (o.setData({
                    fromLatLng: a.latitude + "," + a.longitude
                }), o.getLocation()) : (o.setData({
                    fromLatLng: a.latitude + "," + a.longitude,
                    showNoLocate: !1,
                    isDataEnd: !1,
                    pageIndex: 1,
                    storeList: []
                }), o.getStoreList(1)));
            },
            fail: function(t) {
                wx.removeStorageSync("o2oFromLatLng"), s.openSetting(function() {
                    e.getLocation();
                });
            }
        });
    },
    goLogin: function() {
        wx.navigateTo({
            url: "../login/login"
        });
    },
    setShowAll: function() {
        this.setData({
            isShowAll: !0
        });
    },
    bindAddressTap: function() {
        o = 0, n = 0, this.setAreaData(), this.setData({
            showDistpicker: !0
        });
    },
    setAreaData: function(t, e) {
        var o = this, t = t || 0, e = e || 0;
        void 0 == a || null == a ? wx.request({
            url: s.getUrl("Common/GetAll"),
            async: !1,
            success: function(a) {
                a.data.success && o.setProvinceCityData(a.data.data, t, e);
            },
            error: function(t) {}
        }) : o.setProvinceCityData(null, t, e);
    },
    setProvinceCityData: function(t, e, o) {
        var n = this;
        null != t && (a = t);
        var s = a, i = [], r = [];
        for (var c in s) {
            var d = s[c].name, g = s[c].id;
            i.push(d), r.push(g);
        }
        n.setData({
            provinceName: i,
            provinceCode: r
        });
        var l = a[e].city, u = [], p = [];
        for (var c in l) {
            var d = l[c].name, g = l[c].id;
            1, u.push(d), p.push(g);
        }
        n.setData({
            cityName: u,
            cityCode: p
        });
    },
    changeArea: function(t) {
        var e = this;
        o = t.detail.value[0], n = t.detail.value[1], e.setAreaData(o, n);
    },
    distpickerCancel: function() {
        this.setData({
            showDistpicker: !1
        });
    },
    distpickerSure: function() {
        var t, e = this.data.cityName[n];
        this.data.cityCode.length > 0 && (t = this.data.cityCode[n]), this.setData({
            cityname: e,
            regionId: t
        }), this.distpickerCancel();
    },
    onInputKeyword: function(t) {
        var e = this, a = t.detail.value;
        "" == a && e.setData({
            showSearch: !1
        }), a != e.data.KeyWord && e.setData({
            KeyWord: a
        });
    },
    searchKeyword: function() {
        var e = this, a = e.data.KeyWord;
        "" != a ? t.getSuggestion({
            keyword: a,
            region: e.data.cityname,
            region_fix: 1,
            success: function(t) {
                e.setData({
                    showSearch: !0,
                    searchList: t.data
                });
            }
        }) : wx.showToast({
            title: "请输入关键字"
        });
    },
    setAddr: function(t) {
        var e = t.currentTarget.dataset.fromlatlng, a = getCurrentPages(), o = a[a.length - 2];
        if ((o.services || o.stores || o.data.tabComponent && o.data.tabComponent.stores) && (o = o.services || o.stores || o.data.tabComponent.stores), 
        "apply" == this.data.pageform) {
            var n = t.currentTarget.dataset.name;
            return o.setData({
                currentFromLatLng: e,
                addressDetail1: n
            }), void wx.navigateBack();
        }
        wx.setStorage({
            key: "o2oFromLatLng",
            data: e
        }), 1 == this.data.ptype ? (o.setData({
            fromLatLng: e
        }), "position" == this.data.pageform ? o.getShopBranch() : o.getLocation()) : (o.setData({
            fromLatLng: e,
            isDataEnd: !1,
            pageIndex: 1,
            storeList: [],
            locationName: t.currentTarget.dataset.name
        }), o.getStoreList(1)), wx.navigateBack();
    },
    clearKeyword: function() {
        this.setData({
            KeyWord: ""
        });
    }
});