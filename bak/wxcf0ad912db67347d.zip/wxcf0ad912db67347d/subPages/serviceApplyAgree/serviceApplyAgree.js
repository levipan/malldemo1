// subPages/serviceApplyAgree/serviceApplyAgree.js
Page({data: {}})