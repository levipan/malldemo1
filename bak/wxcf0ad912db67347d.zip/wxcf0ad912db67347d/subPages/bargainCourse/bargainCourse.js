// subPages/bargainCourse/bargainCourse.js
Page({data: {}})