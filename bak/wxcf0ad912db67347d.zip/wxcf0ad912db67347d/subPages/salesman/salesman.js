// subPages/salesman/salesman.js
Page({data: {}})