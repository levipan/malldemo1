// subPages/bargainTeams/bargainTeams.js
Page({data: {}})