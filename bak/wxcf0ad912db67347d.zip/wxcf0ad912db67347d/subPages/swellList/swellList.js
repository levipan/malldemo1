// subPages/swellList/swellList.js
Page({data: {}})