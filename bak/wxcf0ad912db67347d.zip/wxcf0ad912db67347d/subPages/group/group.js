// subPages/group/group.js
Page({data: {}})