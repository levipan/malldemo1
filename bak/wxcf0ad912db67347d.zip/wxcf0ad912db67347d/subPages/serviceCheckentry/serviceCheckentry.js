// subPages/serviceCheckentry/serviceCheckentry.js
Page({data: {}})