// subPages/swellActivityDeatil/swellActivityDeatil.js
Page({data: {}})