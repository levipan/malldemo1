// subPages/serviceCheckOrder/serviceCheckOrder.js
Page({data: {}})