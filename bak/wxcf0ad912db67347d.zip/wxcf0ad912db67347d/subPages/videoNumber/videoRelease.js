// subPages/videoNumber/videoRelease.js
Page({data: {}})