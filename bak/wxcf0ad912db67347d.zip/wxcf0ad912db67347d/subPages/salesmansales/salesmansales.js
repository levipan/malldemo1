// subPages/salesmansales/salesmansales.js
Page({data: {}})