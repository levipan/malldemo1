// subPages/groupDetail/groupDetail.js
Page({data: {}})