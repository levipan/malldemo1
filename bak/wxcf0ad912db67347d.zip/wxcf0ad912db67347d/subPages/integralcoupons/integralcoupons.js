// subPages/integralcoupons/integralcoupons.js
Page({data: {}})