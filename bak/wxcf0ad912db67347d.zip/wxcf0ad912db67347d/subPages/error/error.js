// subPages/error/error.js
Page({data: {}})