// subPages/serviceHome/serviceHome.js
Page({data: {}})