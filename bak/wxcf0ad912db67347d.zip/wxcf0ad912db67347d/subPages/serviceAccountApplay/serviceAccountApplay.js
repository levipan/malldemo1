// subPages/serviceAccountApplay/serviceAccountApplay.js
Page({data: {}})