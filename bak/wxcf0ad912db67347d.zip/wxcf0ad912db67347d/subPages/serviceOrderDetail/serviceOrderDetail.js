// subPages/serviceOrderDetail/serviceOrderDetail.js
Page({data: {}})