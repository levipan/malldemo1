// subPages/servicelistall/servicelistall.js
Page({data: {}})