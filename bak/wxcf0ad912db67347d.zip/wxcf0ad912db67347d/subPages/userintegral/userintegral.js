// subPages/userintegral/userintegral.js
Page({data: {}})