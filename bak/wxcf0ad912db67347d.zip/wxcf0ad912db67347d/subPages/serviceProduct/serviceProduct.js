// subPages/serviceProduct/serviceProduct.js
Page({data: {}})