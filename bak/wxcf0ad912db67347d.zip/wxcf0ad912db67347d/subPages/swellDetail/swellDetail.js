// subPages/swellDetail/swellDetail.js
Page({data: {}})