// subPages/integralProductDetail/integralProductDetail.js
Page({data: {}})