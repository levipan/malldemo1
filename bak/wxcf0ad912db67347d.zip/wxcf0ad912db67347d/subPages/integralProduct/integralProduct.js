// subPages/integralProduct/integralProduct.js
Page({data: {}})