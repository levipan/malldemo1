// subPages/serviceOrder/serviceOrder.js
Page({data: {}})