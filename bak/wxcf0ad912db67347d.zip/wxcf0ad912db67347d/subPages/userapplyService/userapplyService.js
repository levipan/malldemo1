// subPages/userapplyService/userapplyService.js
Page({data: {}})