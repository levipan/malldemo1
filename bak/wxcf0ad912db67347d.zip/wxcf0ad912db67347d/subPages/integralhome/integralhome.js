// subPages/integralhome/integralhome.js
Page({data: {}})