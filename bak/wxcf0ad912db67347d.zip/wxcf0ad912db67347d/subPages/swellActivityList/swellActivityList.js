// subPages/swellActivityList/swellActivityList.js
Page({data: {}})