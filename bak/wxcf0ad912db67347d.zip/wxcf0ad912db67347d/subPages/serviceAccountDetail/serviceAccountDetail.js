// subPages/serviceAccountDetail/serviceAccountDetail.js
Page({data: {}})