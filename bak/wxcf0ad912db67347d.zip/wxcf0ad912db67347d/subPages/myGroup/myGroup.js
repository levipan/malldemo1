// subPages/myGroup/myGroup.js
Page({data: {}})