// subPages/bargainDetail/bargainDetail.js
Page({data: {}})