var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

!function(t, n) {
    "object" == ("undefined" == typeof exports ? "undefined" : e(exports)) && "object" == ("undefined" == typeof module ? "undefined" : e(module)) ? module.exports = n() : "function" == typeof define && define.amd ? define([], n) : "object" == ("undefined" == typeof exports ? "undefined" : e(exports)) ? exports.AdaPay = n() : t.AdaPay = n();
}(void 0, function() {
    return function(e) {
        function t(u) {
            if (n[u]) return n[u].exports;
            var r = n[u] = {
                i: u,
                l: !1,
                exports: {}
            };
            return e[u].call(r.exports, r, r.exports, t), r.l = !0, r.exports;
        }
        var n = {};
        return t.m = e, t.c = n, t.i = function(e) {
            return e;
        }, t.d = function(e, n, u) {
            t.o(e, n) || Object.defineProperty(e, n, {
                configurable: !1,
                enumerable: !0,
                get: u
            });
        }, t.n = function(e) {
            var n = e && e.__esModule ? function() {
                return e.default;
            } : function() {
                return e;
            };
            return t.d(n, "a", n), n;
        }, t.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }, t.p = "/", t(t.s = 1);
    }([ function(e, t, n) {
        function u(e, t) {
            var n = JSON.parse(e.expend.pay_info);
            wx.requestPayment({
                timeStamp: n.timeStamp,
                nonceStr: n.nonceStr,
                package: n.package,
                signType: n.signType,
                paySign: n.paySign,
                success: function(n) {
                    a.default.payResult.succeeded.result_info = e, t(a.default.payResult.succeeded);
                },
                fail: function(n) {
                    a.default.payResult.failed.result_info = e, t(a.default.payResult.failed);
                }
            });
        }
        function r(e) {
            var t = a.default.channelConfig;
            return "succeeded" !== e.status ? a.default.chackMsg.orderError : t.indexOf(e.pay_channel) < 0 ? a.default.chackMsg.channelError : "false" === e.prod_mode ? a.default.chackMsg.otherError : void 0;
        }
        var a = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n(2));
        e.exports = {
            doPay: function(e, t) {
                var n = r(e);
                n ? t(n) : "alipay_qr" === e.pay_channel || "wx_qr" === e.pay_channel ? u(e, function(e) {
                    t(e);
                }) : "wx_lite" === e.pay_channel ? u(e, function(e) {
                    t(e);
                }) : t({
                    msg: "暂不支持该方式"
                });
            },
            query: function(e, t) {
                requestPayResult(e.query_url).then(function(e) {
                    t(e);
                }).catch(function(e) {
                    a.default.payResult.unknown.result_info = {}, t(a.default.payResult.unknown);
                });
            }
        };
    }, function(e, t, n) {
        var u = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n(0));
        e.exports = {
            doPay: function(e, t) {
                return u.default.doPay(e, t);
            },
            version: "1.0.4"
        };
    }, function(e, t, n) {
        var u = {};
        e.exports = u, u.channelConfig = [ "alipay_qr", "alipay_wap", "wx_lite" ], u.chackMsg = {
            orderError: "发起支付失败",
            channelError: "支付渠道参数错误",
            amountError: "支付金额参数错误",
            queryUrlError: "支付结果url参数未知"
        }, u.payStatus = {
            succeeded: "succeeded",
            failed: "failed",
            pending: "pending",
            timeout: "timeout",
            cancel: "unknown",
            unknown: "unknown",
            paramError: "paramError"
        }, u.payResult = {
            succeeded: {
                result_status: u.payStatus.succeeded,
                result_message: "订单支付成功",
                result_info: {}
            },
            failed: {
                result_status: u.payStatus.failed,
                result_message: "订单支付失败",
                result_info: {}
            },
            pending: {
                result_status: u.payStatus.pending,
                result_message: "订单支付中",
                result_info: {}
            },
            timeout: {
                result_status: u.payStatus.timeout,
                result_message: "订单支付超时",
                result_info: {}
            },
            cancel: {
                result_status: u.payStatus.cancel,
                result_message: "支付取消",
                result_info: {}
            },
            unknown: {
                result_status: u.payStatus.unknown,
                result_message: "订单结果未知",
                result_info: {}
            },
            paramError: {
                result_status: u.payStatus.paramError,
                result_message: "参数错误",
                result_info: {}
            }
        };
    } ]);
});