var n = {}, t = {};

module.exports = {
    $CHANGE_TAB: "changeTab",
    $GETCAR_NUM: "getCarNum",
    on: function(t, e) {
        var u = n[t] || [];
        u.push(e), n[t] = u;
    },
    off: function(t, e) {
        if (e) {
            var u = n[t] || [], f = u.findIndex(function(n) {
                return n === e;
            });
            -1 !== f && u.splice(f, 1);
        } else n[t] = null;
    },
    emit: function(t, e) {
        (n[t] || []).forEach(function(n) {
            "function" == typeof n && n(e);
        });
    },
    setData: function(n, e) {
        t[n] = e;
    },
    getData: function(n) {
        return t[n];
    }
};