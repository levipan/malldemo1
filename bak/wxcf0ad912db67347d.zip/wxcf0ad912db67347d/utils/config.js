function e(e) {
    var o = "";
    if ("object" == (void 0 === e ? "undefined" : n(e))) for (var r in e) "function" != typeof e[r] && "object" != n(e[r]) ? o += r + "=" + e[r] + "&" : "object" == n(e[r]) && (f = "", 
    o += t(r, e[r]));
    return o.replace(/&$/g, "");
}

function t(e, o) {
    if ("object" == (void 0 === o ? "undefined" : n(o))) for (var r in o) if ("object" != n(o[r])) {
        var i = e + "[" + r + "]=" + o[r];
        f += encodeURI(i) + "&";
    } else t(e + "[" + r + "]", o[r]);
    return f;
}

function o(e, t) {
    var o = Object.assign({}, e);
    o.provider = "applet";
    var n = u.getData("userKey");
    t && -1 !== t.indexOf("/Delivery/") && (n = u.getData("userKeyDriver")), n && (o.userKey = n), 
    o.timestamp = new Date().toUTCString(), o.app_key = r;
    var f = [];
    for (var c in o) 0 === o[c] || !1 === o[c] || o[c] ? f.push(c) : delete o[c];
    f = f.sort();
    for (var s = "", d = 0; d < f.length; d++) s += f[d].toLowerCase() + o[f[d]];
    return o.sign = a(s + i), o;
}

var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, r = "openl9dnoxn66j", i = "oasl9dnoxn66ja35doj3d", a = require("./md5.js"), u = require("./busEvent"), f = "";

module.exports = {
    json2Form: e,
    httpGet: function(e, t, n, r) {
        -1 != e.indexOf("/api/") && (t = o(t, e)), wx.request({
            url: e,
            data: t,
            async: r || !0,
            method: "GET",
            success: function(e) {
                n(e.data);
            },
            fail: function(e) {},
            error: function(e) {},
            complete: function(e) {}
        });
    },
    httpPost: function(t, n, r) {
        -1 != t.indexOf("/api/") && (n = o(n, t));
        var i = e(n);
        wx.request({
            url: t,
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            data: i,
            method: "POST",
            success: function(e) {
                r(e.data);
            },
            fail: function(e) {},
            complete: function(e) {}
        });
    },
    md5Data: o
};