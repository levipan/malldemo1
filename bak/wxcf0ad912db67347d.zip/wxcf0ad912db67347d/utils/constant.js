Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.GROUPSOLITAIRE = {
    status: {
        noStart: 0,
        start: 1
    },
    type: {
        img: 0,
        video: 1
    }
}, exports.SERVICE = {
    applyStatus: {
        pass: 0,
        default: -1,
        freeze: 1,
        verify: 2,
        reject: 3
    },
    type: {
        unreal: 1,
        real: 2
    }
};