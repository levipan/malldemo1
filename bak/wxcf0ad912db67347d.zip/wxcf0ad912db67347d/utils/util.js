function e(e) {
    return (e = e.toString())[1] ? e : "0" + e;
}

module.exports = {
    formatTime: function(n) {
        if (void 0 != n && "" != n) {
            n = n.replace(/(\d{4})-(\d{2})-(\d{2})T(.*)?\.(.*)/, "$1/$2/$3 $4");
            var t = (n = new Date(n)).getFullYear(), r = n.getMonth() + 1, o = n.getDate(), u = n.getHours(), i = n.getMinutes(), a = n.getSeconds();
            return [ t, r, o ].map(e).join("-") + " " + [ u, i, a ].map(e).join(":");
        }
    },
    json2Form: function(e) {
        var n = [];
        for (var t in e) n.push(encodeURIComponent(t) + "=" + encodeURIComponent(e[t]));
        return n.join("&");
    },
    isFullUrl: function(e) {
        return e.indexOf("http://") > -1 || e.indexOf("https://") > -1;
    },
    getTimeRemaining: function(e, n, t) {
        var r = parseInt(e / 86400), o = t ? parseInt(e / 3600) : parseInt(e % 86400 / 3600), u = parseInt(e % 3600 / 60), i = parseInt(e % 3600 % 60);
        if (o < 10 && (o = "0" + o), u < 10 && (u = "0" + u), i < 10 && (i = "0" + i), !n) return {
            day: r,
            hour: o,
            min: u,
            sec: i
        };
        var a = "";
        return r > 0 && (a += r + "天"), a += o + ":" + u + ":" + i;
    },
    drawImage: function(e, n, t, r) {
        var o = t, u = r;
        return e / n >= t / r ? e > t ? (o = t, u = n * t / e) : (o = e, u = n) : n > r ? (u = r, 
        o = e * r / n) : (o = e, u = n), {
            width: o,
            height: u
        };
    },
    filterEmjo: function(e) {
        var n = /[\ud800-\udbff][\udc00-\udfff]/g;
        return e = e.replace(n, ""), e = e.replace(/[^\u4e00-\u9fa5^a-z^A-Z^0-9^’^“^”^。^，^,^.^:^;^'^"^\/^\\^|^\-^_^=^+^、]/, "");
    }
};