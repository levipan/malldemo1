var t = require("./utils/config.js"), a = require("./utils/adaPay.js"), e = require("./utils/busEvent"), r = require("./utils/constant").SERVICE;

App({
    getRequestUrl: "https://nsvip.net/",
    getUrl: function(t) {
        return this.getRequestUrl + "mobileshopapi/" + t;
    },
    getAdminUrl: function(t) {
        return this.getRequestUrl + "api/" + t;
    },
    onLaunch: function(t) {
        var a = this;
        wx.getUserProfile && (this.globalData.canIUseGetUserProfile = !0), this._getNavs(), 
        this.getSystemInfo(), wx.setStorageSync("solitaireCartData", ""), e.on("tabUserChange", function(t) {
            a._tabUserChange(t.url, t.reload);
        });
    },
    getSystemInfo: function(t) {
        var a = this;
        this.globalData.systemInfo ? t && t(this.globalData.systemInfo) : wx.getSystemInfo({
            success: function(e) {
                a.globalData.systemInfo = e, t && t(e);
            }
        });
    },
    _getNavs: function(a, e) {
        var r = this;
        !this.globalData.navList.length || e ? t.httpGet(this.getUrl("Common/GetSmallProgFootMenus"), {}, function(t) {
            if (t.success) {
                var e = [], o = {}, n = null;
                t.data.map(function(t, a) {
                    if (t.Url) {
                        -1 != t.Url.indexOf("/cart/cart") && (n = a);
                        var r = t.Url.split("?"), s = r[0].split("/"), i = s[s.length - 1];
                        o[i.toLocaleLowerCase()] = a + 1, e.push({
                            name: i,
                            query: r[1] ? r[1] : "",
                            pagePath: t.Url,
                            iconPath: t.MenuIcon,
                            mark: "",
                            selectedIconPath: t.SelectedIconPath,
                            text: t.Name
                        });
                    }
                }), r.globalData.navData = o, r.globalData.hasCartNav = n, r.globalData.navList = e, 
                a && a();
            }
        }) : a && a();
    },
    _tabUserChange: function(t, a) {
        var e = t.split("?"), r = e[0].split("/"), o = r[r.length - 1];
        return this.globalData.navData[o] ? this.globalData.indexInit ? void 0 : (this.globalData.switchTabData = this.getUrlParams(e[1]), 
        this.globalData.tabIndex = this.globalData.navData[o] - 1, wx.switchTab({
            url: "/pages/index/index"
        })) : wx.navigateTo({
            url: t
        });
    },
    getUrlParams: function(t) {
        if (!t) return null;
        var a = {};
        return t.split("&").map(function(t) {
            var e = t.split("=");
            a[e[0]] = e[1];
        }), a;
    },
    getUserOpenId: function(t) {
        wx.getStorageSync("mallAppletOpenId") && this.globalData.openId ? "function" == typeof t && t(this.globalData.openId) : "function" == typeof t && t("");
    },
    getOpenId: function(t, a) {
        var e = wx.getStorageSync("mallAppletOpenId");
        e && this.globalData.openId ? "function" == typeof t && t(this.globalData.openId) : e ? this.quickLogin(t, a) : a ? "function" == typeof t && t() : wx.navigateTo({
            url: "/pages/login/login"
        });
    },
    wxLogin: function(a, e) {
        var r = this, o = this.globalData.canIUseGetUserProfile ? "getUserProfile" : "getUserInfo";
        wx[o]({
            desc: "用于完善会员在商城的个人信息",
            success: function(o) {
                wx.login({
                    success: function(e) {
                        r.globalData.jsCode = e.code;
                        var n = {
                            nickName: o.userInfo.nickName,
                            gender: o.userInfo.gender,
                            city: o.userInfo.city,
                            province: o.userInfo.province,
                            country: o.userInfo.country,
                            avatarUrl: o.userInfo.avatarUrl,
                            js_code: e.code,
                            bargainId: r.globalData.bargainId || 0,
                            branchId: wx.getStorageSync("shopBranchId") || 0,
                            teamId: r.globalData.teamId || 0,
                            iv: o.iv,
                            encryptedData: o.encryptedData
                        }, s = r.globalData.userInfo.distributorId;
                        s && (n.spreadId = s);
                        var i = r.getRefferUserId();
                        i && (n.distributorId = i), t.httpPost(r.getUrl("Login/quickLogin"), n, function(t) {
                            if (wx.hideLoading(), t.success) {
                                if (t.data.IsDistributor && (n.distributorId = t.data.UserId), r.setUserInfo(Object.assign(n, t.data)), 
                                "function" == typeof a) a(t.data.openId, t); else if ("loginPage" === a) {
                                    if (r.globalData.IsConBindCellPhone && !r.globalData.userInfo.CellPhone) return void wx.redirectTo({
                                        url: "../userbindphone/userbindphone"
                                    });
                                    wx.navigateBack();
                                }
                                r.getCartAllData({
                                    shopBranchId: wx.getStorageSync("shopBranchId") || 0
                                });
                            } else wx.showToast({
                                title: t.msg
                            });
                        });
                    },
                    fail: function(t) {
                        e || wx.navigateTo({
                            url: "../login/login"
                        }), wx.hideLoading();
                    }
                });
            },
            fail: function(t) {
                wx.hideLoading(), a && a(null);
            }
        });
    },
    quickLogin: function(a, e) {
        var r = this;
        wx.login({
            success: function(e) {
                r.globalData.jsCode = e.code;
                var o = {
                    js_code: e.code,
                    bargainId: r.globalData.bargainId || 0,
                    branchId: wx.getStorageSync("shopBranchId") || 0,
                    teamId: r.globalData.teamId || 0,
                    openId: wx.getStorageSync("mallAppletOpenId")
                }, n = r.globalData.userInfo.distributorId;
                n && (o.spreadId = n);
                var s = r.getRefferUserId();
                s && (o.distributorId = s), t.httpPost(r.getUrl("Login/quickLogin"), o, function(t) {
                    if (wx.hideLoading(), t.success) {
                        if (t.data.IsDistributor && (o.distributorId = t.data.UserId), r.setUserInfo(Object.assign(o, t.data)), 
                        "function" == typeof a) a(t.data.openId, t); else if ("loginPage" === a) {
                            if (r.globalData.IsConBindCellPhone && !r.globalData.userInfo.CellPhone) return void wx.redirectTo({
                                url: "../userbindphone/userbindphone"
                            });
                            wx.navigateBack();
                        }
                        r.getCartAllData({
                            shopBranchId: wx.getStorageSync("shopBranchId") || 0
                        });
                    } else wx.showToast({
                        title: t.msg
                    });
                });
            },
            fail: function(t) {
                e || wx.navigateTo({
                    url: "../login/login"
                }), wx.hideLoading();
            }
        });
    },
    setUserInfo: function(t) {
        wx.setStorageSync("mallAppletOpenId", t.openId), this.globalData.userInfo = t, this.globalData.openId = t.openId;
    },
    getColorsConfig: function() {
        var t = {
            PrimaryColor: this.globalData.PrimaryColor,
            PrimaryTxtColor: this.globalData.PrimaryTxtColor,
            PrimaryColorlight: this.hex2rgb(this.globalData.PrimaryColor, .1),
            SecondaryColor: this.globalData.SecondaryColor,
            SecondaryTxtColor: this.globalData.SecondaryTxtColor
        };
        this.globalData.colorsConfig = t;
    },
    getSettingData: function(t, a) {
        var e = this;
        if (this.globalData.initConfig && !a) return this.globalData.colorsConfig || this.getColorsConfig(), 
        t && t(this.globalData.initConfig);
        wx.getStorageSync("shopBranchId") && wx.request({
            url: this.getUrl("Home/getInitConfig"),
            data: {
                openId: wx.getStorageSync("mallAppletOpenId"),
                shopBranchId: wx.getStorageSync("shopBranchId") || ""
            },
            success: function(a) {
                if ((a = a.data).success) {
                    var r = a.data.system;
                    r.PrimaryColor = r.PrimaryColor || "#fb1438", r.PrimaryTxtColor = r.PrimaryTxtColor || "#ffffff", 
                    r.SecondaryColor = r.SecondaryColor || "#515151", r.SecondaryTxtColor = r.SecondaryTxtColor || "#ffffff", 
                    Object.assign(e.globalData, r), e.globalData.initConfig = a.data, e.getColorsConfig(), 
                    t && t(e.globalData.initConfig);
                }
            }
        });
    },
    getSysSettingData: function(t, a, e) {
        var r = this, o = function() {
            var e = {
                IsLargerCategoryTemplate: r.globalData.IsLargerCategoryTemplate,
                PrimaryColor: r.globalData.PrimaryColor,
                PrimaryTxtColor: r.globalData.PrimaryTxtColor,
                PrimaryColorlight: r.hex2rgb(r.globalData.PrimaryColor, .1),
                SecondaryColor: r.globalData.SecondaryColor,
                SecondaryTxtColor: r.globalData.SecondaryTxtColor
            };
            a && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: r.globalData.PrimaryColor
            }), t && t(e);
        };
        !this.globalData.QQMapKey || e ? wx.request({
            url: this.getUrl("Home/GetSysSettingData"),
            data: {},
            success: function(t) {
                (t = t.data).success && (t.data.PrimaryColor = t.data.PrimaryColor || "#fb1438", 
                t.data.PrimaryTxtColor = t.data.PrimaryTxtColor || "#ffffff", t.data.SecondaryColor = t.data.SecondaryColor || "#515151", 
                t.data.SecondaryTxtColor = t.data.SecondaryTxtColor || "#ffffff", Object.assign(r.globalData, t.data), 
                o());
            }
        }) : o();
    },
    hex2rgb: function(t, a) {
        var e = [ 0, 0, 0 ];
        return /#(..)(..)(..)/g.test(t) && (e = [ parseInt(RegExp.$1, 16), parseInt(RegExp.$2, 16), parseInt(RegExp.$3, 16) ]).push(a), 
        "rgba(" + e.join(",") + ")";
    },
    setRefferUserId: function(t) {
        wx.setStorageSync("ReferralUserId", t);
    },
    getRefferUserId: function(t) {
        return wx.getStorageSync("ReferralUserId");
    },
    paySuccess: function(t, a, e, r, o) {
        var n = this;
        wx.showModal({
            title: "提示",
            content: "支付成功！",
            showCancel: !1,
            success: function(s) {
                s.confirm && wx.requestSubscribeMessage({
                    tmplIds: e,
                    success: function(a) {
                        if ("requestSubscribeMessage:ok" == a.errMsg) {
                            var e = Object.keys(a).filter(function(t) {
                                return "accept" === a[t];
                            });
                            if (e.length > 0) {
                                var r = e.join(",");
                                wx.request({
                                    url: n.getUrl("Common/GetAuthorizedSubscribeMessage"),
                                    data: {
                                        templateIds: r,
                                        orderId: t,
                                        openId: n.globalData.openId
                                    },
                                    success: function(t) {}
                                });
                            }
                        }
                    },
                    fail: function(t) {
                        20004 == t.errCode && wx.showModal({
                            title: "提示",
                            content: "建议开启订阅消息，接收商城发送的消息通知",
                            cancelText: "取消",
                            confirmText: "去开启",
                            showCancel: !0,
                            success: function(t) {
                                wx.openSetting({});
                            }
                        });
                    },
                    complete: function(e) {
                        o ? o() : a ? wx.redirectTo({
                            url: "../orderlist/orderlist?status=0"
                        }) : wx.redirectTo({
                            url: "../ordersuccess/ordersuccess?orderid=" + t + "&orderType=" + r
                        });
                    }
                });
            }
        });
    },
    payRequestFail: function(t, a, e, r) {
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: !1,
            success: function(t) {
                e || t.confirm && wx.redirectTo({
                    url: "../orderlist/orderlist?status=" + a
                }), r && r();
            }
        });
    },
    payFail: function(t, a, e) {
        wx.showModal({
            title: "提示",
            content: "支付失败",
            showCancel: !0,
            success: function(r) {
                a || (r.cancel && (t = 1), wx.redirectTo({
                    url: "../orderlist/orderlist?status=" + t
                })), e && e({
                    fail: !0
                });
            }
        });
    },
    orderPay: function(t, e, r, o, n, s) {
        var i = this;
        i.getOpenId(function(l) {
            i.globalData.IsOpenSubledger ? wx.request({
                url: i.getUrl("Payment/GetAdapayPaymentList"),
                data: {
                    openId: l,
                    orderId: t
                },
                success: function(c) {
                    if (c.data.success) {
                        var u = c.data.data;
                        u.expend.open_id = l, a.doPay(u, function(a) {
                            "succeeded" === a.result_status ? i.paySuccess(t, r, o, s, n) : i.payFail(e, r, n);
                        });
                    } else i.payRequestFail(c.data.msg, e, r, n);
                }
            }) : wx.request({
                url: i.getUrl("Payment/GetPaymentList"),
                data: {
                    openId: l,
                    orderId: t
                },
                success: function(a) {
                    if ((a = a.data).success) {
                        var l = a.data;
                        wx.requestPayment({
                            timeStamp: l.timeStamp,
                            nonceStr: l.nonceStr,
                            package: "prepay_id=" + l.prepayId,
                            signType: "MD5",
                            paySign: l.sign,
                            success: function(a) {
                                i.paySuccess(t, r, o, s);
                            },
                            fail: function(t) {
                                i.payFail(e, r, n);
                            }
                        });
                    } else i.payRequestFail(a.msg, e, r, n);
                }
            });
        });
    },
    getUserCoupon: function(t, a) {
        var e = this;
        this.getOpenId(function(r) {
            wx.showLoading({
                title: "加载中"
            }), wx.request({
                url: e.getUrl("Coupon/GetUserCoupon"),
                data: {
                    openId: r,
                    couponId: t
                },
                header: {},
                method: "GET",
                dataType: "json",
                responseType: "text",
                success: function(t) {
                    wx.hideLoading(), setTimeout(function() {
                        wx.showToast({
                            title: t.data.msg,
                            icon: t.data.success ? "success" : "none",
                            duration: 2e3,
                            mask: !0
                        });
                    }, 500), a instanceof Function && a(t.data);
                },
                fail: function(t) {},
                complete: function(t) {}
            });
        });
    },
    updateCartCount: function() {
        var t = this;
        this.getOpenId(function(a) {
            a && wx.request({
                url: t.getUrl("Cart/GetCartCount"),
                data: {
                    openId: a,
                    shopBranchId: wx.getStorageSync("shopBranchId")
                },
                success: function(t) {
                    if (t = t.data, wx.setStorageSync("cartCount", t.data), t.success && t.data > 0) {
                        if (t.data > 99) a = "..."; else var a = t.data.toString();
                        wx.setTabBarBadge({
                            index: 3,
                            text: a
                        });
                    }
                    t.success && 0 == t.data && wx.removeTabBarBadge({
                        index: 3
                    });
                }
            });
        }, "noSkip");
    },
    changeShopbranch: function() {
        var t = wx.getStorageSync("mallAppletOpenId"), a = wx.getStorageSync("shopBranchId");
        t && wx.request({
            url: this.getUrl("Common/GetChangeMemberHistoryShopBranch"),
            data: {
                openId: t,
                shopBranchId: a || "0"
            },
            success: function(t) {}
        });
    },
    getDistrbutionName: function(t) {
        var a = this;
        if (this.globalData.distributorNames) return t(this.globalData.distributorNames);
        wx.request({
            data: {
                openId: this.globalData.openId
            },
            url: this.getUrl("Distribution/GetDistributorKeyName"),
            success: function(e) {
                a.globalData.distributorNames = e.data.data, t(e.data.data);
            }
        });
    },
    globalData: {
        hasCartNav: null,
        indexInit: !1,
        storeColse: !1,
        busEventInit: !1,
        newStoreId: null,
        navList: [],
        navData: {},
        userInfo: {},
        customheaderHeight: 64,
        customTabBarHeight: 54,
        openId: "",
        jsCode: "",
        QQMapKey: "",
        CommunityJoinPhone: "",
        SupplierJoinPhone: "",
        ServiceJoinPhone: "",
        KeepOnRecordPic: "",
        KeepOnRecordUrl: "",
        ProductSaleCountOnOff: !1,
        IsConBindCellPhone: !1,
        cartCount: 0,
        IsJumpLink: !0,
        IsShowShopBranchLink: !1,
        isUserCenter: !0,
        PrimaryColor: "#fb1438",
        PrimaryTxtColor: "#ffffff",
        SecondaryColor: "#424242",
        SecondaryTxtColor: "#ffffff",
        servicePromise: {},
        cartData: {
            total: -1,
            items: {}
        },
        getCartTimeOld: 0,
        getCartTimeCurrent: +new Date()
    },
    getOpenIdToUserKey: function(a) {
        var r = this;
        if (this.globalData.userKey) return a({
            success: !0,
            userKey: this.globalData.userKey
        });
        this.getOpenId(function(o) {
            o && t.httpGet(r.getAdminUrl("ServiceShopHome/GetLoginByOpenId"), {
                openId: o
            }, function(t) {
                t.success ? (e.setData("userKey", t.UserKey), r.globalData.userKey = t.UserKey, 
                a && a({
                    success: !0,
                    userKey: r.globalData.userKey
                })) : a && a({
                    success: !1
                });
            });
        });
    },
    getOpenIdToUserKeyDriver: function(a) {
        var r = this;
        if (this.globalData.userKeyDriver) return a({
            success: !0,
            userKey: this.globalData.userKeyDriver
        });
        this.getOpenId(function(o) {
            o && t.httpGet(r.getAdminUrl("Delivery/GetLoginByOpenId"), {
                openId: o
            }, function(t) {
                t.success ? (e.setData("userKeyDriver", t.UserKey), r.globalData.userKeyDriver = t.UserKey, 
                a && a({
                    success: !0,
                    userKey: r.globalData.userKeyDriver
                })) : a && a({
                    success: !1
                });
            });
        });
    },
    mergeArray: function(t, a) {
        for (r = 0; r < t.length; r++) for (var e = 0; e < a.length; e++) t[r] === a[e] && t.splice(r, 1);
        for (var r = 0; r < a.length; r++) t.push(a[r]);
        return t;
    },
    removeByValue: function(t, a) {
        for (var e = 0; e < t.length; e++) if (t[e] == a) {
            t.splice(e, 1);
            break;
        }
        return t;
    },
    uniqueArry: function(t) {
        for (var a = [], e = {}, r = 0; r < t.length; r++) e[t[r]] || (a.push(t[r]), e[t[r]] = 1);
        return a;
    },
    showErrorModal: function(t, a) {
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: !1,
            confirmColor: this.globalData.PrimaryColor,
            success: function(t) {
                a && a(t);
            }
        });
    },
    openSetting: function(t) {
        wx.openSetting({
            success: function(a) {
                t();
            }
        });
    },
    MoneyRound: function(t, a) {
        return a = a || 2, Math.round(t * Math.pow(10, a)) / Math.pow(10, a);
    },
    MoneyFix2: function(t) {
        var a = t.toFixed(3);
        return a.substring(0, a.lastIndexOf(".") + 3);
    },
    mul: function(t, a) {
        var e = 0, r = t.toString(), o = a.toString();
        try {
            e += r.split(".")[1].length;
        } catch (t) {}
        try {
            e += o.split(".")[1].length;
        } catch (t) {}
        return Number(r.replace(".", "")) * Number(o.replace(".", "")) / Math.pow(10, e);
    },
    div: function(t, a) {
        var e, r, o = 0, n = 0;
        try {
            o = t.toString().split(".")[1].length;
        } catch (t) {}
        try {
            n = a.toString().split(".")[1].length;
        } catch (t) {}
        return e = Number(t.toString().replace(".", "")), r = Number(a.toString().replace(".", "")), 
        this.mul(e / r, Math.pow(10, n - o));
    },
    countDown: function(t, a) {
        var e = 0, r = 0, o = 0, n = 0;
        t > 0 && (e = "" + Math.floor(t / 86400), r = "" + Math.floor(t / 3600 - 24 * e), 
        o = "" + Math.floor(t / 60 - 24 * e * 60 - 60 * r), n = "" + Math.floor(t - 24 * e * 60 * 60 - 60 * r * 60 - 60 * o)), 
        o < 10 && (o = "0" + o), n < 10 && (n = "0" + n), a(e, r, o, n);
    },
    add: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, e = void 0, r = void 0;
        try {
            e = t.toString().split(".")[1].length;
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            e = 0;
        }
        try {
            r = a.toString().split(".")[1].length;
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            r = 0;
        }
        var o = Math.pow(10, Math.max(e, r));
        return (this.multiply(t, o) + this.multiply(a, o)) / o;
    },
    subtract: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, e = void 0, r = void 0;
        try {
            e = t.toString().split(".")[1].length;
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            e = 0;
        }
        try {
            r = a.toString().split(".")[1].length;
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            r = 0;
        }
        var o = Math.pow(10, Math.max(e, r));
        return (this.multiply(t, o) - this.multiply(a, o)) / o;
    },
    multiply: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, e = 0, r = t.toString(), o = a.toString();
        try {
            e += r.split(".")[1].length;
        } catch (t) {}
        try {
            e += o.split(".")[1].length;
        } catch (t) {}
        return Number(r.replace(".", "")) * Number(o.replace(".", "")) / Math.pow(10, e);
    },
    divide: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, e = 0, r = 0;
        try {
            e = t.toString().split(".")[1].length;
        } catch (t) {}
        try {
            r = a.toString().split(".")[1].length;
        } catch (t) {}
        var o = Number(t.toString().replace(".", "")), n = Number(a.toString().replace(".", ""));
        return this.multiply(o / n, Math.pow(10, r - e));
    },
    calcTextLength: function(t) {
        var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 28;
        if (t) {
            t += "";
            for (var e = 0, r = 0; r < t.length; r++) {
                var o = t.substr(r, 1);
                /[a-zA-Z]/.test(o) ? e += .7 : /[0-9]/.test(o) ? e += .55 : /\./.test(o) ? e += .27 : /-/.test(o) ? e += .325 : /[\u4e00-\u9fa5]/.test(o) ? e += 1 : /\(|\)/.test(o) ? e += .373 : /\s/.test(o) ? e += .25 : /%/.test(o) ? e += .8 : e += 1;
            }
            return e * a;
        }
    },
    compareVersion: function(t, a) {
        t = t.split("."), a = a.split(".");
        for (var e = Math.max(t.length, a.length); t.length < e; ) t.push("0");
        for (;a.length < e; ) a.push("0");
        for (var r = 0; r < e; r++) {
            var o = parseInt(t[r]), n = parseInt(a[r]);
            if (o > n) return 1;
            if (o < n) return -1;
        }
        return 0;
    },
    getShareConfig: function(a) {
        var e = this;
        if (this.globalData.shareConfig) return a(this.globalData.shareConfig);
        t.httpGet(this.getUrl("CommunityStore/GetCommunityShareConfig"), {}, function(t) {
            if (t.success) return e.globalData.shareConfig = t.data, a(t.data);
        });
    },
    getServicePromises: function(t, a) {
        var e = this;
        if (this.globalData.servicePromise[t]) return a(this.globalData.servicePromise[t]);
        wx.request({
            url: this.getUrl("product/GetServicePromises"),
            data: {
                franchiseeId: t
            },
            success: function(r) {
                e.globalData.servicePromise[t] = r.data.data, a(r.data.data);
            }
        });
    },
    getCartAllData: function(a) {
        var e = this, r = a.shopBranchId;
        this.globalData.getCartTimeCurrent = +new Date(), this.globalData.getCartTimeCurrent - this.globalData.getCartTimeOld < 2e3 ? this.globalData.getCartTimeOld = this.globalData.getCartTimeCurrent : (this.globalData.getCartTimeOld = this.globalData.getCartTimeCurrent, 
        this.getOpenId(function(a) {
            a && t.httpGet(e.getUrl("Cart/GetCartQuantity"), {
                openId: a,
                shopBranchId: r
            }, function(t) {
                if (t.success) {
                    var a = {}, r = 0;
                    t.data.map(function(t) {
                        r += t.Quantity, a[t.ProductId] ? a[t.ProductId].skus[t.SkuId] = t : (a[t.ProductId] = {}, 
                        a[t.ProductId].skus = {}, a[t.ProductId].skus[t.SkuId] = t);
                    }), e.globalData.cartData.total = r, e.globalData.cartData.items = a, e.updateCartTotal(e.globalData.cartData.total);
                }
            });
        }, !0));
    },
    getCartData: function(a) {
        var e = this, r = a.shopBranchId, o = a.type, n = a.callback;
        this.getOpenId(function(a) {
            a && t.httpGet(e.getUrl("Cart/GetCartProducts"), {
                openId: a,
                shopBranchId: r,
                productDeliveryType: o
            }, function(t) {
                t.success && (0 === t.data.list.length && (e.globalData.cartData.items = {}), t.data.list.map(function(t) {
                    t.Items.map(function(t) {
                        e.globalData.cartData.items[t.ProductId] ? e.globalData.cartData.items[t.ProductId].skus[t.SkuId] = {
                            Quantity: t.Quantity,
                            ProductId: t.ProductId,
                            SkuId: t.SkuId
                        } : (e.globalData.cartData.items[t.ProductId] = {}, e.globalData.cartData.items[t.ProductId].skus = {}, 
                        e.globalData.cartData.items[t.ProductId].skus[t.SkuId] = {
                            Quantity: t.Quantity,
                            ProductId: t.ProductId,
                            SkuId: t.SkuId
                        });
                    });
                })), n && n(t);
            });
        });
    },
    updateSwitchBar: function(t) {
        if (t > 0) {
            var a = t;
            a = t > 99 ? "..." : a.toString(), e.emit("setTabBarBadge", a);
        } else e.emit("setTabBarBadge", 0);
    },
    getCartTotal: function(t) {
        return this.updateCartTotal(this.globalData.cartData.total), t && t(this.globalData.cartData.total), 
        this.globalData.cartData.total;
    },
    updateCartTotal: function(t) {
        wx.setStorageSync("cartCount", t), this.globalData.cartData.total = t, this.updateSwitchBar(this.globalData.cartData.total);
    },
    updateCartData: function(t, a) {
        var e = this;
        if ("add" === t && a && (a.map(function(t) {
            e.globalData.cartData.items, e.globalData.cartData.items[t.SkuId] = t;
        }), this.getCartTotal(function(t) {
            e.updateCartTotal(t + a.length);
        })), "del" === t && a) {
            var r = 0;
            a.map(function(t) {
                e.globalData.cartData.items[t.ProductId] && (r += e.globalData.cartData.items[t.ProductId].skus[t.SkuId].Quantity, 
                delete e.globalData.cartData.items[t.ProductId].skus[t.SkuId]);
            }), this.getCartTotal(function(t) {
                e.updateCartTotal(t - r);
            });
        }
        "update" === t && a && a.map(function(t) {
            e.globalData.cartData.items[t.SkuId] = t;
        });
    },
    getPhoneNumber: function(a, e) {
        var r = this;
        t.httpGet(this.getUrl("Login/GetBindWXPhone"), {
            openId: this.globalData.openId,
            encryptedData: a.encryptedData,
            iv: a.iv,
            js_code: this.globalData.jsCode
        }, function(t) {
            t.success ? (wx.showToast({
                title: "成功绑定手机",
                icon: "none"
            }), r.globalData.userInfo.CellPhone = t.data, r.quickLogin(), e && e()) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        });
    },
    setCacheAddressAction: function(t) {
        this.globalData.cacheAddress = t;
    },
    shopBranchChange: function(t, a) {
        var e = !1;
        if (t) {
            var r = wx.getStorageSync("shopBranchId");
            r && r != t && (wx.redirectTo({
                url: "../storeswitch/storeswitch?currentBranchId=" + r + "&newBranchId=" + t + "&" + a
            }), e = !0), r || wx.setStorageSync("shopBranchId", t);
        }
        return e;
    },
    busEmit: function(t, a, r) {
        this.globalData.navData[t] ? (wx.switchTab({
            url: "../index/index"
        }), e.emit("tabUserChange", {
            url: a,
            reload: r
        })) : wx.redirectTo({
            url: a
        });
    },
    customTap: function(a) {
        var o = this, n = a.currentTarget.dataset.link, s = a.currentTarget.dataset.roomid, i = parseInt(a.currentTarget.dataset.showtype);
        if ("#" !== n && n) switch (-1 != n.indexOf("../") && (n = n.replace(/\.\.\//, "/pages/")), 
        i) {
          case 101:
            var l = "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=" + s;
            wx.navigateTo({
                url: l
            });
            break;

          case 102:
          case 103:
          case 107:
            wx.navigateTo({
                url: "/pages/livedetail/livedetail?roomId=" + s
            });
            break;

          case 4:
          case 7:
          case 10:
            c = n;
            wx.navigateTo({
                url: "/pages/outurl/outurl?type=needLogin&url=" + encodeURIComponent(c)
            });
            break;

          case 15:
          case 29:
            wx.switchTab({
                url: n
            });
            break;

          case 26:
            e.emit("tabUserChange", {
                url: n,
                reload: !0
            });
            break;

          case 8:
            var c = n;
            wx.navigateTo({
                url: "/pages/outurl/outurl?url=" + encodeURIComponent(c)
            });
            break;

          case 1:
            var u = n.split("=");
            u = u[u.length - 1], wx.request({
                url: this.getUrl("Home/GetCheckShopProducts"),
                data: {
                    ids: u,
                    shopBranchId: wx.getStorageSync("shopBranchId")
                },
                success: function(t) {
                    (t = t.data).success && (t.data[0].IsSell ? wx.navigateTo({
                        url: n
                    }) : wx.showToast({
                        title: "当前店铺不售卖此商品",
                        icon: "none"
                    }));
                }
            });
            break;

          case 31:
            if (this.globalData.openId) {
                if (!this.globalData.userInfo.CellPhone) return void e.emit("triggerBindphone");
                wx.request({
                    url: this.getUrl("MemberCenter/GetApplyShopbracnStatus"),
                    data: {
                        openId: this.globalData.openId
                    },
                    success: function(t) {
                        (t = t.data).success && (-1 == t.data.Status && wx.navigateTo({
                            url: "/pages/userapplystore/userapplystore?cellPhone=" + o.globalData.userInfo.CellPhone
                        }), 0 == t.data.Status && wx.showToast({
                            title: "您已是团长",
                            icon: "success"
                        }), 1 == t.data.Status && wx.showToast({
                            title: "团长已冻结",
                            icon: "none"
                        }), 2 != t.data.Status && 3 != t.data.Status || wx.navigateTo({
                            url: "/pages/userapplyresult/userapplyresult?type=store&status=" + t.data.Status + "&remark=" + t.data.Remark
                        }));
                    }
                });
            } else wx.showToast({
                title: "请先登录账号",
                icon: "none"
            }), wx.navigateTo({
                url: "/pages/login/login"
            });
            break;

          case 32:
            if (this.globalData.openId) {
                if (!this.globalData.userInfo.CellPhone) return void e.emit("triggerBindphone");
                wx.request({
                    url: this.getUrl("MemberCenter/GetApplySupplierStatus"),
                    data: {
                        openId: this.globalData.openId
                    },
                    success: function(t) {
                        (t = t.data).success && (-1 == t.data.Status && wx.navigateTo({
                            url: "/pages/userapplysupplier/userapplysupplier?contactPhone=" + o.globalData.userInfo.CellPhone
                        }), 0 == t.data.Status && wx.showToast({
                            title: "您已是供应商",
                            icon: "success"
                        }), 1 == t.data.Status && wx.showToast({
                            title: "供应商已冻结",
                            icon: "none"
                        }), 2 != t.data.Status && 3 != t.data.Status || wx.navigateTo({
                            url: "/pages/userapplyresult/userapplyresult?type=supplier&status=" + t.data.Status + "&remark=" + t.data.AuditReason
                        }));
                    }
                });
            } else wx.showToast({
                title: "请先登录账号",
                icon: "none"
            }), wx.navigateTo({
                url: "/pages/login/login"
            });
            break;

          case 33:
            wx.navigateToMiniProgram({
                appId: n,
                extarData: {},
                success: function(t) {}
            });
            break;

          case 23:
            wx.makePhoneCall({
                phoneNumber: n
            });
            break;

          case 36:
            wx.request({
                url: this.getUrl("MemberCenter/GetLastShopBranchInfo"),
                data: {
                    shopBranchId: wx.getStorageSync("shopBranchId")
                },
                success: function(t) {
                    (t = t.data).success && (t.data.IsSelfSell ? e.emit("tabUserChange", {
                        url: "../storeselfsupport/storeselfsupport?Id=" + wx.getStorageSync("shopBranchId"),
                        reload: !0
                    }) : wx.showToast({
                        title: "尚未开通自营店铺",
                        icon: "none"
                    }));
                }
            });
            break;

          case 37:
            n += "&franchiseeId=" + wx.getStorageSync("FranchiseeId"), wx.navigateTo({
                url: n
            });
            break;

          case 11:
            n += "&isNewExclusive=true", wx.navigateTo({
                url: n
            });
            break;

          case 43:
            if (this.globalData.openId) {
                if (!this.globalData.userInfo.CellPhone) return void e.emit("triggerBindphone");
                t.httpGet(this.getUrl("MemberCenter/GetApplyServiceShopStatus"), {
                    openId: this.globalData.openId
                }, function(t) {
                    if (t.success) {
                        if (t.data.Status === r.applyStatus.default) return wx.navigateTo({
                            url: n
                        });
                        if (t.data.Status === r.applyStatus.pass) return wx.showToast({
                            title: "您已是入驻商",
                            icon: "success"
                        });
                        if (t.data.Status === r.applyStatus.freeze) return wx.showToast({
                            title: "入驻商已冻结",
                            icon: "none"
                        });
                        if (t.data.Status == r.applyStatus.verify || t.data.Status == r.applyStatus.reject) return wx.redirectTo({
                            url: "/pages/userapplyresult/userapplyresult?type=Service&status=" + t.data.Status + "&remark=" + t.data.Remark
                        });
                    }
                });
            } else wx.navigateTo({
                url: "/pages/login/login"
            });
            break;

          default:
            e.emit("tabUserChange", {
                url: n
            });
        }
    }
});