module.exports = {
  app_id: '1111111111',
  site_token: '',
  session_key: '',
  api_url: 'https://jshop.jihainet.com/',
  cdn_url: '',
  default_image: '',
  app_title: 'Jshop云商',
  app_description: 'Jshop云商',
  app_logo: 'https://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEKhQDbaWe1HfkwEibibAHDadWs5Y4ZzVKbms8ksL1jcK601vDIZIUYx2ubmB8SQVFUNFQuVbzFnBy8Q/0',
  site_token: "123456",
  list_limit:10,
  image_max:5,
  store_type:2
}