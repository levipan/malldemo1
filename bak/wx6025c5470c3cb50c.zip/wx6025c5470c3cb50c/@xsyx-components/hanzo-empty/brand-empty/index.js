Component({
    properties: {
        descWidth: {
            type: String,
            value: "",
            des: "des宽度"
        },
        layout: {
            type: String,
            value: "col",
            des: "row: 左图右文；col: 上图下文"
        },
        type: {
            type: String,
            value: "list"
        },
        img: String,
        title: String,
        desc: String
    },
    data: {
        imgs: {
            list: "https://front-xps-cdn.xsyx.xyz/2021/02/05/15127966.png",
            search: "https://front-xps-cdn.xsyx.xyz/2021/02/05/1216642053.png"
        }
    },
    methods: {}
});