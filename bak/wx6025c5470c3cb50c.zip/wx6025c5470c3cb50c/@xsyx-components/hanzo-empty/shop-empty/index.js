Component({
    properties: {
        title: String,
        btnText: String
    },
    data: {},
    methods: {
        ontap: function(t) {
            this.triggerEvent("btn-click", t.detail);
        }
    }
});