Component({
    properties: {
        title: String,
        desc: String,
        displaytime: String,
        imgpath: String,
        imgwidth: {
            value: 404,
            type: Number
        },
        imgheight: {
            value: 239,
            type: Number
        }
    },
    data: {},
    methods: {}
});