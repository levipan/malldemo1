var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../router/index")), o = require("../../api/index"), a = getApp();

Component({
    properties: {
        showPop: {
            value: !0,
            type: Boolean
        },
        closeReason: String
    },
    data: {
        url: "",
        imageUrl: ""
    },
    attached: function() {
        this.getH5Url();
    },
    methods: {
        getH5Url: function() {
            var e = this;
            return r(t.default.mark(function r() {
                var n;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, o.puzzleCouponApi.getPuzzleH5url({}, {
                            silence: !0
                        });

                      case 3:
                        n = t.sent, e.setData({
                            url: n.h5Path,
                            imageUrl: "https://front-xps-cdn.xsyx.xyz/2022/02/08/1999227589.png"
                        }), t.next = 10;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(0), console.log(t.t0);

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 7 ] ]);
            }))();
        },
        onClosePop: function() {
            this.setData({
                showPop: !1
            }), this.triggerEvent("puzzleActivePopClose");
        },
        onFindStore: function() {
            n.default.navigateTo({
                path: "/subPages/users/selfdot/mydot/mydot"
            });
        },
        onGoH5: function() {
            var e = this.data.url, t = void 0 === e ? "" : e;
            t && (a.frxs.setMData("inner", {
                i: "3",
                i_type: "store_closed_hoem_popover"
            }), n.default.navigateTo({
                path: "/subActive/pages/tgActive/index",
                query: {
                    baseUrl: t || ""
                }
            })), this.onClosePop();
        }
    }
});