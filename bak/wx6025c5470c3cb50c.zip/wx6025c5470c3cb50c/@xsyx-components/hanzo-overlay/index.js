Component({
    properties: {
        show: Boolean,
        mask: Boolean,
        duration: {
            type: [ Number, Object ],
            value: 300
        },
        zIndex: {
            type: Number,
            value: 1
        }
    },
    data: {},
    methods: {
        onClick: function() {
            this.triggerEvent("click");
        },
        noop: function() {}
    }
});