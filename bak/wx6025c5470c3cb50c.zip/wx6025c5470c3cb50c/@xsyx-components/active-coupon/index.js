Component({
    properties: {
        productInfo: {
            type: Object,
            value: {}
        },
        couponList: {
            type: Array,
            value: []
        },
        showActiveTag: {
            type: Boolean,
            value: !1
        },
        cardType: {
            type: String,
            value: "normal-card"
        }
    },
    data: {},
    ready: function() {},
    methods: {
        onRecieveCoupon: function() {
            var e = this.data, t = e.couponList, o = e.productInfo, n = void 0 === o ? {} : o, r = t.map(function(e) {
                return e.ticketId;
            }), a = {
                skuSn: n.skuSn || "",
                vendorId: n.vendorId || "",
                spuSn: n.spuSn || "",
                firstLevelCategoryId: n.firstLevelCategoryId || "",
                secondLevelCategoryId: n.secondLevelCategoryId || ""
            };
            this.triggerEvent("recieveCoupon", {
                ticketMap: r,
                product: a,
                showPopup: !0
            });
        }
    }
});