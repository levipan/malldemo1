Component({
    properties: {
        checked: Boolean,
        color: {
            type: String,
            value: "rgba(255, 115, 32, 1)"
        },
        width: {
            type: String,
            value: "80rpx"
        },
        height: {
            type: String,
            value: "40rpx"
        },
        checkedType: {
            type: String,
            value: "hollow"
        }
    },
    data: {},
    methods: {
        onSwitch: function() {
            var e = !this.data.checked;
            this.triggerEvent("on-switch", e);
        }
    }
});