Component({
    properties: {
        videoUrl: {
            value: "",
            type: String
        },
        previewUrl: {
            value: "",
            type: String
        },
        width: {
            value: "670rpx",
            type: String
        },
        height: {
            value: "377rpx",
            type: String
        },
        borderRadius: {
            value: "0",
            type: String
        },
        showFullscreenBtn: {
            value: !0,
            type: Boolean
        },
        playStatus: {
            type: Number,
            value: 1,
            observer: function(e, t) {
                e != t && e > 0 && this.updatePlayerStatus(e);
            }
        },
        hanzoData: {
            value: null,
            type: Object
        },
        verticalScreenRotate: {
            value: !1,
            type: Boolean
        }
    },
    data: {
        fullScreen: !1,
        isIPhone: -1 != wx.getSystemInfoSync().model.indexOf("iPhone"),
        previewImgRotate: !1
    },
    lifetimes: {
        attached: function() {
            this.duration = 0, this.currentTime = 0, this.preCurrentTime = 0;
        }
    },
    methods: {
        updatePlayerStatus: function(e) {
            var t = this;
            this.setData({
                playStatus: e
            }, function() {
                var a = wx.createVideoContext("videoProduct", t);
                2 == e ? a.play && a.play() : 3 == e ? t.fullScreen || a.pause && a.pause() : 1 == e && (t.data.fullScreen && t.videoFullscreenChange({
                    detail: {
                        fullScreen: !1
                    }
                }), a.stop && a.stop());
            });
        },
        onPlayerClick: function() {
            this.triggerEvent("player-click", {
                data: this.data.hanzoData
            });
        },
        videoTimeupdate: function(e) {
            this.duration = e.detail.duration, this.currentTime = e.detail.currentTime;
        },
        videoPause: function() {
            this.triggerEvent("pause-click", {
                data: this.data.hanzoData,
                preCurrentTime: this.preCurrentTime,
                duration: this.duration,
                currentTime: this.currentTime
            }), this.preCurrentTime = this.currentTime;
        },
        videoPlay: function() {
            2 != this.data.playStatus && this.onPlayerClick();
        },
        videoEnded: function() {
            this.data.isIPhone && this.data.fullScreen || (this.setData({
                playStatus: 1
            }), this.triggerEvent("player-ended", {
                data: this.data.hanzoData
            }));
        },
        videoFullscreenChange: function(e) {
            this.setData({
                fullScreen: e.detail.fullScreen
            }), this.triggerEvent("player-fullscreen", {
                data: this.data.hanzoData,
                fullScreen: e.detail.fullScreen
            });
        },
        imgLoad: function(e) {
            this.data.verticalScreenRotate && e.detail.width < e.detail.height && this.setData({
                previewImgRotate: !0
            });
        }
    }
});