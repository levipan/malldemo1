var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), o = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../api/index.js"), r = t(require("../../behavior/reciveCoupon")), n = getApp(), a = (0, 
r.default)();

Component({
    properties: {
        reciveVisible: {
            type: Boolean,
            value: !1
        },
        activityId: {
            type: Array,
            observer: function(t) {
                !t || t.length <= 0 || (console.log(t), this.getCouponList(t));
            }
        },
        catepage: Boolean
    },
    data: {
        allCategoryActivity: [],
        multipleCategoryActivity: [],
        showEmpty: !1
    },
    methods: {
        todoRrfresh: function() {
            this.getCouponList();
        },
        handelToCloseRecivePop: function() {
            this.triggerEvent("closePop"), this.setData({
                allCategoryActivity: [],
                multipleCategoryActivity: [],
                showEmpty: !1
            });
        },
        goShop: function() {
            wx.reLaunch({
                url: "/pages/home/index/index"
            });
        },
        closeTips: function() {
            this.triggerEvent("closeTips", !1);
        },
        getCouponListOld: function(t) {
            var r = this;
            return o(e.default.mark(function o() {
                var s, c;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, i.couponApi.getGoodsCardActivity({
                            toolActivityIds: t || r.data.activityId,
                            storeId: n.frxs.getMOrSData("storeId")
                        }, {
                            loading: "加载中",
                            contentType: "application/json",
                            scene: !0
                        });

                      case 3:
                        s = e.sent, t.allCategoryActivity = (t.allCategoryActivity || []).map(function(t) {
                            return wx.$.isArray(t.recommendGoods) && t.recommendGoods.length > 0 && (t.avters = t.recommendGoods || []), 
                            t;
                        }), t.multipleCategoryActivity = (t.multipleCategoryActivity || []).map(function(t) {
                            return wx.$.isArray(t.recommendGoods) && t.recommendGoods.length > 0 && (t.avters = t.recommendGoods || []), 
                            t;
                        }), c = a.members.formatCoupon(s.multipleCategoryActivity || [], "MULTIPLE"), n.frxs._get(s, "whitelist", !1) || (c = c.filter(function(t) {
                            return t.avters;
                        })), r.setData({
                            multipleCategoryActivity: c,
                            allCategoryActivity: a.members.formatCoupon(s.allCategoryActivity || [], "GLOBAL")
                        }), !s.allCategoryActivity && !s.multipleCategoryActivity || s.allCategoryActivity.length <= 0 && c.length <= 0 ? r.setData({
                            showEmpty: !0
                        }) : r.setData({
                            showEmpty: !1
                        }), e.next = 15;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(0), console.log(e.t0);

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, o, null, [ [ 0, 12 ] ]);
            }))();
        },
        getQueryList: function(t) {
            var e = [], o = [];
            return t.length > 0 && t.forEach(function(t) {
                if ((!t.skus || t.skus.length <= 0) && (!t.vendors || t.vendors.length <= 0) && (!t.categoryList || t.categoryList.length <= 0)) o.push(t); else {
                    var i = {
                        areaId: n.frxs.getMOrSData("areaId"),
                        storeId: n.frxs.getMOrSData("storeId"),
                        ticketId: t.activityCode
                    };
                    if (t.skus && t.skus.length > 0 && (i.skus = t.skus, i.type = "SKUSN"), t.vendors && t.vendors.length > 0 && (i.vendors = t.vendors, 
                    i.type = "VENDOR"), t.categoryList && t.categoryList.length > 0) {
                        var r = [];
                        t.categoryList.forEach(function(t) {
                            t.children ? r.push(t.children.cateId) : r.push(t.cateId);
                        }), i.categoryList = r, i.type = "CATE";
                    }
                    e.push(i);
                }
            }), {
                _queryList: e,
                _standbyList: o
            };
        },
        filterdata: function(t, r) {
            return new Promise(function() {
                var n = o(e.default.mark(function o(n, a) {
                    var s;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.prev = 0, s = [], e.next = 4, i.commonPromotionApi.couponProductList({
                                couPonProductDetailReqDTOs: t
                            }, {
                                silence: !0,
                                loading: "加载中",
                                contentType: "application/json"
                            });

                          case 4:
                            (s = e.sent).couponDetails && s.couponDetails.length > 0 && (r.map(function(t) {
                                return s.couponDetails.forEach(function(e) {
                                    e.ticketId === t.activityCode && (t.avters = e.productDetails);
                                }), t;
                            }), n(!0)), e.next = 12;
                            break;

                          case 8:
                            e.prev = 8, e.t0 = e.catch(0), a(void 0), console.log(e.t0, "error");

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, o, null, [ [ 0, 8 ] ]);
                }));
                return function(t, e) {
                    return n.apply(this, arguments);
                };
            }());
        },
        getCouponList: function(t) {
            var r = this;
            return o(e.default.mark(function o() {
                var s, c, l, u, y, p, d, v, g;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ((s = n.frxs.getMOrSData("moduleConfig") || {}).activeAll) {
                            e.next = 4;
                            break;
                        }
                        return r.getCouponListOld(t), e.abrupt("return");

                      case 4:
                        return e.prev = 4, c = n.frxs.isLogin(), i.couponApi.receiveTicketAll({
                            storeId: n.frxs.getMOrSData("storeId"),
                            userKey: c,
                            primaryChannel: "XSYX",
                            secondaryChannels: [ "MEMBER" ],
                            blackBox: n.frxs.storage("safe_bb") || ""
                        }, {
                            contentType: "application/json",
                            silence: !0
                        }), e.next = 9, i.couponApi.getGoodsCardActivityV2({
                            toolActivityIds: t || r.data.activityId,
                            storeId: n.frxs.getMOrSData("storeId") || "",
                            primaryChannel: "XSYX",
                            secondaryChannels: [ "MEMBER" ]
                        }, {
                            loading: "加载中",
                            contentType: "application/json",
                            silence: !0
                        });

                      case 9:
                        if (l = e.sent) {
                            try {
                                !wx.$.storage.get("hasRecive") && s.activeAll && (u = n.frxs.getTime2Close() / 1e3, 
                                wx.$.storage.set("hasRecive", !0, u), wx.$.storage.set("hasGetCouponList", !0, 1800), 
                                r.setData({
                                    tipsShow: !0
                                }), setTimeout(function() {
                                    r.setData({
                                        tipsShow: !1
                                    });
                                }, 3500));
                            } catch (t) {
                                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                                console.log(t);
                            }
                            y = wx.$._get(l, "hotActivity", []) || [], p = y.filter(function(t) {
                                return "YPH" === t.activityType;
                            }), l.hotActivityMulity = p, l.hotActivityMulity = (l.hotActivityMulity || []).map(function(t) {
                                return wx.$.isArray(t.recommendGoods) && t.recommendGoods.length > 0 && (t.avters = t.recommendGoods || []), 
                                t;
                            }), l.goodsActivityList = (l.goodsActivityList || []).map(function(t) {
                                return t.secondaryChannels && t.secondaryChannels.length > 0 && -1 == t.secondaryChannels.indexOf("STORE") && -1 == t.secondaryChannels.indexOf("MEMBER") && (t.showHomeCoupon = !0), 
                                wx.$.isArray(t.recommendGoods) && t.recommendGoods.length > 0 && (t.avters = t.recommendGoods || []), 
                                t;
                            }), l.activityList = (l.activityList || []).map(function(t) {
                                return t.secondaryChannels && t.secondaryChannels.length > 0 && -1 == t.secondaryChannels.indexOf("STORE") && -1 == t.secondaryChannels.indexOf("MEMBER") && (t.showHomeCoupon = !0), 
                                wx.$.isArray(t.recommendGoods) && t.recommendGoods.length > 0 && (t.avters = t.recommendGoods || []), 
                                t;
                            }), d = a.members.formatCoupon(l.hotActivityMulity), v = a.members.formatCoupon(l.goodsActivityList || []), 
                            g = a.members.formatCoupon(l.activityList || []), n.frxs._get(l, "whitelist", !1) || (d = d.filter(function(t) {
                                var e = !0;
                                return "MULTIPLE" !== t.rootType && "MPD" !== t.activityType && "MPD_AUTO" !== t.activityType && "YPH" !== t.activityType || t.avters || (e = !1), 
                                e;
                            }), v = v.filter(function(t) {
                                var e = !0;
                                return "MULTIPLE" !== t.rootType && "MPD" !== t.activityType && "MPD_AUTO" !== t.activityType || t.avters || (e = !1), 
                                e;
                            }), g = g.filter(function(t) {
                                var e = !0;
                                return "MULTIPLE" !== t.rootType && "MPD" !== t.activityType && "MPD_AUTO" !== t.activityType || t.avters || (e = !1), 
                                e;
                            })), r.setData({
                                allCategoryActivity: v,
                                multipleCategoryActivity: g,
                                hotActivityMulityView: d
                            }), !l.goodsActivityList && !l.activityList && !l.hotActivityMulity || v.length <= 0 && g.length <= 0 && d.length <= 0 ? r.setData({
                                showEmpty: !0
                            }) : r.setData({
                                showEmpty: !1
                            });
                        }
                        e.next = 17;
                        break;

                      case 13:
                        e.prev = 13, e.t0 = e.catch(4), console.log(e.t0, "err"), r.setData({
                            allCategoryActivity: [],
                            multipleCategoryActivity: [],
                            showEmpty: !0
                        });

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, o, null, [ [ 4, 13 ] ]);
            }))();
        },
        closePop: function() {
            this.setData({
                reciveVisible: !1
            }), this.triggerEvent("closePop");
        },
        toWindow: function(t) {
            this.triggerEvent("toWindow", t.detail);
        }
    }
});