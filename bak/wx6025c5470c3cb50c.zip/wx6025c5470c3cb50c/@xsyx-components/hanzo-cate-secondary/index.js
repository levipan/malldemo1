var t = getApp();

Component({
    __page: !0,
    properties: {
        cateList: {
            type: Array,
            value: [],
            observer: function() {
                this.getTabsOffset();
            }
        },
        navHeight: Number,
        secondTabIndex: {
            type: Number,
            value: 0,
            observer: function(t, e) {
                var s = this;
                t != e && this.setData({
                    secondTabIndex: t
                }, function() {
                    s.setScrollLeft();
                });
            }
        },
        isShowAll: {
            type: Boolean,
            value: !1
        },
        tabsList: Array,
        tabsSelectIndex: Number
    },
    data: {
        scrollLeft: 0
    },
    methods: {
        changeAllCate: function() {
            this.setData({
                isShowAll: !this.data.isShowAll
            });
            var e = this.data, s = e.tabsList, a = void 0 === s ? [] : s, i = e.tabsSelectIndex, n = void 0 === i ? 0 : i, o = {
                slot: "分类页_二级橱窗展开",
                cat_id: wx.$._get(a, "".concat(n, ".windowId"), ""),
                cat_name: wx.$._get(a, "".concat(n, ".windowName"), "")
            };
            t.frxs.XSMonitor.sendEvent("slot_click", o, "");
        },
        closePopup: function() {
            this.setData({
                isShowAll: !1
            });
        },
        selectCate: function(t) {
            var e = t.currentTarget.dataset.index, s = void 0 === e ? "" : e;
            console.log(this.data.cateList, "".concat(s.windowId));
            var a = wx.$._get(this.data.cateList, "".concat(s, ".windowId"), "");
            s !== this.data.secondTabIndex && (this.setData({
                secondTabIndex: s
            }), this.triggerEvent("selectChange", {
                id: a,
                index: s
            }));
        },
        tabListOffset: [],
        getTabsOffset: function() {
            var t = this;
            this.data.cateList.length > 0 ? wx.createSelectorQuery().in(this).selectAll(".second-item").boundingClientRect(function(e) {
                t.tabListOffset = e || [], t.setScrollLeft();
            }).exec() : this.tabListOffset = [];
        },
        setScrollLeft: function() {
            if (this.data.secondTabIndex >= 0 && this.tabListOffset.length > 0) {
                var e = (this.tabListOffset[this.data.secondTabIndex] || {}).left || 0, s = (t.globalData.sysInfo || {}).scaling || .5, a = parseInt(e - 550 * s / 2 - ((this.tabListOffset[this.data.secondTabIndex] || {}).width || 0) / 2);
                this.setData({
                    scrollLeft: a
                });
            }
        }
    }
});