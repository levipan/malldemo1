var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/defineProperty"), n = e(require("../hanzo-page-loading/loading.js")), i = getApp().frxsConfig.ossDomain;

Component({
    properties: {
        products: Array,
        icon: String,
        image: String,
        title: String,
        guide: String,
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        ossDomain: i,
        imgUrl: {
            success: i + "/2020/08/05/438309748.png",
            success1: i + "/2020/08/05/1940772933.png",
            cry: i + "/2020/08/05/1560007034.png",
            info: i + "/2020/08/05/1600078512.png",
            remind: i + "/2020/08/05/841290607.png",
            help: i + "/2020/08/05/1282111957.png",
            loading: i + "/2020/01/01/1700035391.gif"
        },
        checkBoxMap: {}
    },
    methods: {
        onAddCart: function() {
            var e = this, t = [], i = this.data.checkBoxMap;
            if (Object.keys(i).map(function(n) {
                i["".concat(n)] && t.push(e.data.products[n]);
            }), 0 == t.length) return n.default.showToast({
                title: "请选择需要加购的商品",
                icon: ""
            });
            this.triggerEvent("onAddCart", {
                products: t
            });
        },
        onClose: function() {
            this.triggerEvent("onClose");
        },
        onCheckbox: function(e) {
            var n = e.detail.product;
            this.setData(t({}, "checkBoxMap.".concat(n.index), n.checked));
        }
    }
});