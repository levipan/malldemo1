var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../router/index")), e = require("../../utils/index.js"), o = getApp();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        isOnePage: {
            type: Boolean,
            value: !1
        },
        showBtn: {
            type: Boolean,
            value: !1
        },
        btnText: {
            type: String,
            value: "立即使用"
        },
        couponList: {
            type: Array,
            value: [],
            observer: function(t) {
                if (t.length) {
                    var a = wx.$._get(t, "0.ticketStatusList.0.tmActive", !1) || !1, i = wx.$._get(t, "0.ticketStatusList.0.tmFinish", !1) || !1, s = wx.$._get(t, "0.now", !1) || !1;
                    if (i && a && s) {
                        var r = (0, e.strToTs)(a), n = +o.frxs.strToDate(s), l = r - n > 0;
                        this.setData({
                            isPre: l,
                            dateTips: [ !1, "(明日)", "(后日)", !1 ][o.frxs.formatCouponDateTips(+o.frxs.strToDate(a), n)] || "",
                            dateStr: l ? (0, e.formaterDate)(a, "yyyy年MM月dd日") : (0, e.formaterDate)(i, "yyyy年MM月dd日HH:mm:ss")
                        });
                    }
                }
            }
        },
        hasVideoUrl: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    attacted: function() {
        console.log("--------\x3e", this.data.couponList);
    },
    methods: {
        onGoUseCoupon: function() {},
        onGoToCouponDesc: function() {
            t.default.navigateTo({
                path: "/pages/home/h5Active/index",
                query: {
                    url: "https://item-cms-cdn.xsyxsc.com/item/cms/activityLandingPage/release/20211026/2021102616140163494-1.html?titleBgColor=#ffffff&titleColor=#000000&pageCode=2021102616140163494&displayPosition=C"
                }
            });
        }
    }
});