var t = getApp();

t.XComponent({
    __page: !0,
    properties: {
        loginGuideBotton: {
            type: Number,
            value: 190
        },
        skin: {
            type: String,
            value: "default"
        },
        loginToIndex: {
            type: Boolean,
            value: !1
        },
        bodyStyle: {
            type: String,
            value: ""
        }
    },
    data: {
        isShowLoginGuide: !1
    },
    attached: function() {
        this.initState();
    },
    methods: {
        initState: function() {
            console.log("initState了吗");
            var i = t.frxs.getMOrSData("isLogin"), e = t.frxs.getMOrSData("userKey");
            i && !t.frxs.isNullOrWhiteSpace(e) ? this.setData({
                isShowLoginGuide: !1
            }) : this.setData({
                isShowLoginGuide: !0
            }, function() {}), this.triggerEvent("showStatus", this.data.isShowLoginGuide);
        },
        close: function() {
            this.triggerEvent("tap-cloe"), this.triggerEvent("showStatus", !1), this.setData({
                isShowLoginGuide: !1
            });
        },
        login: function() {
            var i = this, e = this;
            this.triggerEvent("tap-login"), "changdot" === this.data.skin && t.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "登陆"
            }, ""), this.data.loginToIndex && t.frxs.XSMonitor.sendEvent("slot_click", {}, "登录按钮"), 
            t.userSvr.autoLogin({
                loginToIndex: this.data.loginToIndex,
                success: function() {
                    wx.showToast({
                        title: "登录成功"
                    }), e.setData({
                        isShowLoginGuide: !1
                    }), i.triggerEvent("showStatus", !1), setTimeout(function() {
                        i.data.loginToIndex && wx.reLaunch({
                            url: "/pages/home/index/index"
                        });
                    }, 1500);
                }
            });
        }
    }
});