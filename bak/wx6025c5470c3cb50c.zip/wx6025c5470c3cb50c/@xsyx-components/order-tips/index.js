Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        cancelText: {
            type: String,
            value: "去修改"
        },
        products: {
            type: Array,
            value: []
        }
    },
    data: {},
    methods: {
        onCancel: function() {
            this.triggerEvent("on-cancel");
        },
        onOk: function() {
            this.triggerEvent("on-ok");
        },
        onClickMask: function() {
            this.triggerEvent("on-cancel");
        }
    }
});