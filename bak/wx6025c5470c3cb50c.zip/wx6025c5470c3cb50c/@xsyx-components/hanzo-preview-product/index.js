Component({
    properties: {
        content: {
            type: String,
            value: "明天的商品提前看~"
        },
        submitTxt: {
            type: String,
            value: "马上前去"
        },
        isShowClose: {
            type: Boolean,
            value: !0
        },
        zIndex: {
            type: Number,
            value: 1e4
        },
        pickDate: String,
        preSaleTime: String,
        isBeginPreSale: Boolean,
        showBeginPreSaleMask: Boolean
    },
    data: {},
    methods: {
        close: function() {
            this.triggerEvent("close", {});
        },
        submit: function() {
            this.triggerEvent("submit", {});
        },
        getCouponList: function() {
            this.triggerEvent("getCouponList", {});
        }
    }
});