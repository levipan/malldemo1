Component({
    properties: {
        mode: {
            type: String,
            value: "normal"
        },
        amount: {
            type: Number,
            value: 0
        },
        checked: {
            type: Boolean,
            value: !1
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        count: {
            type: Number,
            value: 0
        }
    },
    data: {},
    methods: {
        onChecked: function(t) {
            this.data.disabled || this.triggerEvent("checked", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onSubmit: function() {
            this.data.count <= 0 || this.data.amount <= 0 || this.triggerEvent("submit", {});
        },
        onDel: function() {
            this.data.count <= 0 || this.triggerEvent("del", {});
        }
    }
});