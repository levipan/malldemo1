Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        position: {
            type: String,
            value: "center"
        },
        transitionName: {
            type: String,
            value: "fade"
        },
        mask: {
            type: Boolean,
            value: !0
        },
        zIndex: {
            type: Number,
            value: 2
        },
        needMask: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        onOverlayClick: function() {
            this.triggerEvent("mask-click");
        }
    }
});