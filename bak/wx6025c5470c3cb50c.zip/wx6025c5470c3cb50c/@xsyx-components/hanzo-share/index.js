var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/objectSpread2"), s = e(require("../../router/index")), o = [ "super-explosive_share", "active-super_explosive_share" ], a = getApp();

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function() {}
        },
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                console.log("item", e), this.data.item = e;
            }
        },
        isCreatePoster: {
            value: !0,
            type: Boolean
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        },
        sharePosition: {
            type: String,
            observer: function(e) {
                console.log("分享组件位置val", e), o.indexOf(e) > -1 ? this.setData({
                    isShowSharePoster: !1
                }) : this.setData({
                    isShowSharePoster: !0
                });
            }
        },
        isShowSharePoster: {
            type: Boolean,
            value: !0
        },
        productImg: {
            type: String,
            value: "",
            observer: function(e) {
                var s = t({
                    productImage: e || "",
                    code: this.data.item.storeCode || 1
                }, this.data.item);
                this.setData({
                    item: s
                }), console.log("this.data.item------\x3e", this.data.item);
            }
        }
    },
    data: {
        url: a.frxsConfig.userDomain,
        ossDomain: a.frxsConfig.ossDomain,
        showBtn: !0,
        showCanvas: !1,
        isPoster: !1,
        isShowSharePoster: !0
    },
    attached: function() {
        a.frxs.compareVersion("1.9.91") >= 0 && this.setData({
            isPoster: !0
        });
    },
    methods: {
        _close: function() {
            this.setData({
                show: !1
            });
        },
        _showPoster: function() {
            var e = this;
            if (this.triggerEvent("click-poster"), this.data.isPoster && this.data.isCreatePoster) this.setData({
                showBtn: !1,
                showCanvas: !0
            }); else {
                if (!this.data.isCreatePoster) return;
                this.data.isPoster || wx.showModal({
                    title: "温馨提示",
                    content: "您的微信版本过低，请升级微信后再使用。",
                    showCancel: !0,
                    cancelText: "取消",
                    cancelColor: "#000000",
                    confirmText: "确定",
                    confirmColor: "#3CC51F",
                    success: function(t) {
                        t.confirm && (s.default.navigateTo({
                            path: "/subPages/home/wxgoup/wxgoup"
                        }), e.posterExit());
                    },
                    fail: function() {},
                    complete: function() {}
                });
            }
        },
        posterClose: function() {
            this.setData({
                showBtn: !0,
                showCanvas: !1
            });
        },
        posterExit: function() {
            this.setData({
                show: !1,
                showBtn: !1,
                showCanvas: !1
            }), this.triggerEvent("shareclose", {
                close: !0
            });
        }
    }
});