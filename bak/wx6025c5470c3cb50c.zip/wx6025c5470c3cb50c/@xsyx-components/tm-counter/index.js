Component({
    externalClasses: [ "pro-class" ],
    properties: {
        forUser: {
            type: String,
            value: "for-product-card"
        },
        value: Number,
        step: {
            type: Number,
            value: 1
        },
        max: {
            type: Number,
            value: 99
        },
        min: {
            type: Number,
            value: 0
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        editable: Boolean,
        async: {
            type: Boolean,
            value: !1
        },
        iconSize: {
            type: String,
            value: "74rpx"
        },
        numStyle: String,
        theme: {
            type: String,
            value: "red"
        },
        valueBold: {
            type: Boolean,
            value: !1
        },
        saleRemain: {
            type: Number,
            value: 0
        },
        needPlus: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        value: 0
    },
    methods: {
        onPlus: function() {
            if (!this.data.disabled) {
                var e = this.data, t = e.value, a = e.step, i = e.max, s = e.saleRemain;
                if (t == i || t == s) return this.triggerEvent("plusMax", this.data.value);
                var n = t + a;
                n <= i && this.update(n), this.triggerEvent("plus", this.data.value);
            }
        },
        onMinus: function() {
            if (!this.data.disabled) {
                var e = this.data, t = e.value, a = e.step, i = e.min;
                if (t == i) return this.triggerEvent("minusMin", this.data.value);
                t == a && this.triggerEvent("minusStep", 0);
                var s = t - a;
                s >= i && this.update(s), this.triggerEvent("minus", this.data.value);
            }
        },
        onInput: function(e) {
            this.data.disabled || this.triggerEvent("input", e.detail);
        },
        onBlur: function(e) {
            this.data.disabled || this.triggerEvent("blur", e.detail);
        },
        onFocus: function(e) {
            this.data.disabled || this.triggerEvent("focus", e.detail);
        },
        update: function(e) {
            this.data.async || this.setData({
                value: e
            });
        }
    }
});