var t = require("../../const/storage.key.js"), e = getApp();

Component({
    properties: {
        isExposure: {
            type: Boolean,
            value: !1
        },
        fuzzy: {
            type: Boolean,
            value: !1
        },
        goodsStatus: {
            type: String,
            value: "normal"
        },
        colLayoutSize: {
            type: String,
            value: "s202"
        },
        product: {
            type: Object,
            value: {},
            observer: function(t) {
                if (t) {
                    var e = JSON.parse(JSON.stringify(t));
                    e.martketActivity || (e.martketActivity = {}), e.martketActivity.productImg = wx.$._get(t, "productMarkAtmosphere.productCorsetCornerMark.productImg", ""), 
                    e.martketActivity.martketActivityCoupons = wx.$._get(t, "productMarkAtmosphere.martketActivityCoupons", []), 
                    e.productNameCornerMark = wx.$._get(t, "productMarkAtmosphere.productNameCornerMark", []), 
                    this.setData({
                        _product: e
                    });
                }
            }
        },
        cartCount: {
            type: Number,
            optionalTypes: [ String ],
            value: 0,
            observer: function() {
                this.setShowTextButton();
            }
        },
        layout: {
            type: String,
            value: "row"
        }
    },
    data: {
        _product: {},
        showTextButton: !0,
        productMax: 0,
        DOMId: "",
        showFuzzySales: !1
    },
    ready: function() {
        var o = e.frxs.getMOrSData(t.STORAGE_KEY.SHOW_FUZZY_SALES);
        this.setShowTextButton();
        var r = this.data.product, a = r.saleRemain, i = r.ulimitQty, s = -1 == a ? i : 0 == i ? a : i < a ? i : a;
        this.setData({
            productMax: s,
            showFuzzySales: o
        }), this.data.isExposure && this.setData({
            DOMId: e.frxs.newGuid()
        }, this.exposure);
    },
    detached: function() {
        try {
            this.data.isExposure && this.productObserve.disconnect();
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            console.log(t);
        }
    },
    methods: {
        exposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport();
                this.productObserve = e, e.observe(".e".concat(this.data.DOMId), function(e) {
                    e.intersectionRatio > 0 && t.triggerEvent("exposure", {
                        item: t.data.product
                    });
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log(t);
            }
        },
        setShowTextButton: function() {
            this.setData({
                showTextButton: !+this.data.cartCount
            });
        },
        goRankList: function() {
            this.triggerEvent("go-rank-list", {
                product: this.data.product
            });
        },
        onAddMax: function() {
            this.triggerEvent("cart-add-max", {
                product: this.data.product
            });
        },
        onAdd: function() {
            this.triggerEvent("cart-add", {
                product: this.data.product
            });
        },
        onMinusStep: function() {
            this.setData({
                showTextButton: !0
            });
        },
        onReduce: function() {
            this.triggerEvent("cart-reduce", {
                product: this.data.product
            });
        },
        clickMain: function() {
            this.triggerEvent("click-main", {
                product: this.data.product
            });
        },
        onShowCoupon: function(t) {
            this.triggerEvent("recieveCouponClick", t.detail);
        }
    }
});