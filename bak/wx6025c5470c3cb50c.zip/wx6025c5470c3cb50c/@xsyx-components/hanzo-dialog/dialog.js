Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [], t = function t(n) {
    var o = Object.assign({}, t.defaultOptions, n);
    return new Promise(function(t, n) {
        var s, a = (s = getCurrentPages())[s.length - 1].selectComponent(o.selector);
        a && (a.setData(Object.assign({
            onCancel: n,
            onConfirm: t
        }, o)), e.push(a));
    });
};

t.defaultOptions = {
    show: !0,
    title: "",
    content: "",
    zIndex: 100,
    overlay: !0,
    asyncClose: !1,
    styleType: "",
    messageAlign: "",
    transition: "scale",
    selector: "#hanzo-dialog",
    confirmText: "确认",
    cancelText: "取消",
    showConfirmButton: !0,
    showCancel: !1,
    closeOnClickOverlay: !1,
    confirmButtonOpenType: ""
}, t.alert = t, t.confirm = function(e) {
    return t(Object.assign({
        showCancel: !0
    }, e));
}, t.close = function() {
    e.forEach(function(e) {
        e.close();
    }), e = [];
}, t.stopLoading = function() {
    e.forEach(function(e) {
        e.stopLoading();
    });
}, t.setDefaultOptions = function(e) {
    Object.assign(t.defaultOptions, e);
}, t.resetDefaultOptions = function() {
    t.defaultOptions = Object.assign({}, t.defaultOptions);
}, t.resetDefaultOptions();

var n = t;

exports.default = n;