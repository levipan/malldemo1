var n = require("../../@babel/runtime/helpers/defineProperty");

Component({
    properties: {
        show: Boolean,
        title: String,
        content: String,
        useSlot: Boolean,
        asyncClose: Boolean,
        messageAlign: String,
        showCancel: Boolean,
        closeOnClickOverlay: Boolean,
        confirmButtonOpenType: String,
        styleType: {
            type: String,
            value: "error",
            observer: function(n, e) {
                e != n && this.setData({
                    styleType: n
                });
            }
        },
        icon: String,
        iconUrl: String,
        zIndex: {
            type: Number,
            value: 2e3
        },
        confirmText: {
            type: String,
            value: "确认"
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        showConfirmButton: {
            type: Boolean,
            value: !0
        },
        overlay: {
            type: Boolean,
            value: !0
        },
        transition: {
            type: String,
            value: "scale"
        },
        cancleBtnType: {
            type: String
        },
        confirmBtnType: {
            type: String
        },
        confirmStyle: String,
        cancelBtnStyle: String,
        skin: String
    },
    data: {
        loading: {
            confirm: !1,
            cancel: !1
        }
    },
    methods: {
        onConfirm: function() {
            console.log(), this.handleAction("confirm");
        },
        onCancel: function() {
            this.handleAction("cancel");
        },
        onClickOverlay: function() {
            this.onClose("overlay");
        },
        handleAction: function(e) {
            this.data.asyncClose && this.setData(n({}, "loading.".concat(e), !0)), this.onClose(e);
        },
        close: function() {
            this.setData({
                show: !1,
                loading: {
                    confirm: !1,
                    cancel: !1
                }
            });
        },
        onClose: function(n) {
            this.data.asyncClose || this.close(), this.triggerEvent("close", n), this.triggerEvent(n, {
                dialog: this
            });
            var e = this.data["confirm" === n ? "onConfirm" : "onCancel"];
            e && e(this);
        },
        bodyClick: function() {},
        maskClick: function() {
            this.triggerEvent("maskClick");
        }
    }
});