Component({
    __page: !0,
    properties: {
        visible: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                var t = this;
                if (clearTimeout(this.close), e && !this.data.show) return this.setData({
                    show: !0
                }, function() {
                    clearTimeout(t.showEndTimer), t.showEndTimer = setTimeout(function() {
                        t.triggerEvent("animation-show-end");
                    }, 300);
                });
                e || (this.close = setTimeout(function() {
                    t.data.show && (t.triggerEvent("animation-close-end"), setTimeout(function() {
                        t.setData({
                            show: !1
                        });
                    }, 0));
                }, 500));
            }
        },
        mask: {
            type: Boolean,
            value: !0
        },
        top: {
            type: String,
            value: "40%"
        },
        opacity: {
            type: String,
            value: "0.7"
        },
        zIndex: {
            type: String,
            value: "999"
        },
        type: {
            type: String,
            value: "left"
        },
        through: {
            type: Boolean,
            value: !1
        },
        topH: {
            type: Number,
            value: 0
        },
        customStyle: {
            type: String,
            value: ""
        },
        needMask: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        show: !1
    },
    created: function() {},
    methods: {
        touchMove: function() {},
        onClickMask: function() {
            this.triggerEvent("mask");
        }
    }
});