Component({
    data: {
        canIUseGetUserProfile: !1,
        btnDisabled: !1
    },
    lifetimes: {
        attached: function() {
            wx.getUserProfile && this.setData({
                canIUseGetUserProfile: !0
            });
        }
    },
    methods: {
        getUserInfoTap: function() {
            var e = this;
            if (this.data.btnDisabled) setTimeout(function() {
                e.data.btnDisabled && e.setData({
                    btnDisabled: !1
                });
            }, 500); else {
                this.setData({
                    btnDisabled: !0
                });
                var t = this;
                this.data.canIUseGetUserProfile && wx.getUserProfile({
                    desc: "用于您的注册和登陆",
                    success: function(e) {
                        t.done({
                            type: "success",
                            info: e
                        });
                    },
                    fail: function(e) {
                        t.done({
                            type: "fail",
                            info: e
                        });
                    }
                });
            }
        },
        onGotUserInfo: function(e) {
            this.done({
                type: e.detail.userInfo ? "success" : "fail",
                info: e.detail
            });
        },
        done: function(e) {
            this.setData({
                btnDisabled: !1
            }), this.triggerEvent("done", e);
        }
    }
});