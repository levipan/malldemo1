var t = require("../../@babel/runtime/helpers/objectSpread2");

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        title: String,
        imgUrl: String,
        titleDesc: String,
        desc: String,
        moveText: String,
        detail: Object,
        products: Array
    },
    data: {},
    ready: function() {
        this.exposure();
    },
    detached: function() {
        try {
            this.cmsObserve && this.cmsObserve.disconnect();
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            console.log(t);
        }
    },
    methods: {
        exposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport();
                this.cmsObserve = e, e.observe("#hanzo-index-cms-".concat(this.data.detail.position), function(e) {
                    e.intersectionRatio > 0 && (t.triggerEvent("exposure", {
                        cmsDetail: t.data.detail
                    }), t.cmsObserve && t.cmsObserve.disconnect());
                });
            } catch (t) {}
        },
        move: function(e) {
            this.triggerEvent("click-booth", t(t({}, this.data.detail), {}, {
                pointPosition: e.currentTarget.dataset.position
            }));
        }
    }
});