var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), o = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), r = e(require("../../router/index")), n = require("../../api/index.js"), a = require("../../utils/subscribe-message"), s = getApp();

Component({
    data: {
        showProductCouponDesc: !1
    },
    properties: {
        couponList: {
            type: Array,
            value: []
        },
        showTitle: {
            type: Boolean,
            value: !0
        },
        tipsShow: {
            type: Boolean,
            value: !1
        },
        showRule: {
            type: Boolean,
            value: !1
        },
        showIcon: {
            type: Boolean,
            value: !0
        },
        needSendEvent: {
            type: Boolean,
            value: !1
        },
        catepage: Boolean
    },
    methods: {
        closeTips: function() {
            this.triggerEvent("closeTips", !1);
        },
        openProductCouponDesc: function() {
            this.setData({
                showProductCouponDesc: !0
            });
        },
        closeProductCouponDesc: function() {
            this.setData({
                showProductCouponDesc: !1
            });
        },
        goToWindow: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            s.globalData["cateProduct-selectWindowId"] = {
                windId: e
            }, this.data.catepage ? this.triggerEvent("toWindow", {
                windowId: e
            }) : r.default.switchTab({
                path: s.frxsConfig.mall.page.cateProduct
            });
        },
        toHomeUseCoupon: function(e, t, o) {
            var i = o.activityCode, n = void 0 === i ? "" : i, a = o.ticketId, s = void 0 === a ? "" : a, u = o.activityId, d = void 0 === u ? "" : u, c = o.toolActivityId, l = void 0 === c ? "" : c, p = o.tmExpire, v = void 0 === p ? "" : p, m = o.tmFinish, f = void 0 === m ? "" : m, g = o.toolType, h = void 0 === g ? "" : g, b = o.toolName, y = void 0 === b ? "" : b, x = o.orderAmountLimit, T = void 0 === x ? "" : x, w = o.amount, C = void 0 === w ? "" : w, I = o.orderStep, k = {
                activityCode: n,
                activityId: d,
                toolActivityId: l,
                tmExpire: v,
                tmFinish: f,
                ticketId: s,
                toolType: h,
                toolName: y,
                orderAmountLimit: T,
                amount: C,
                orderStep: void 0 === I ? [] : I
            };
            if (!e) return r.default.navigateTo({
                path: "subTMMain/pages/productList/index",
                query: {
                    coupon: encodeURIComponent(JSON.stringify(k))
                }
            });
            var q = e.split("&"), S = {};
            switch (q.length > 0 && q.forEach(function(e) {
                var t = e.split("=");
                S[t[0]] = t[1];
            }), t) {
              case "H_WINDOW":
                break;

              case "H_INDEX":
                wx.$route.navigateTo({
                    name: "home-subTMMain-index",
                    query: S
                });
                break;

              case "H_CMS":
                r.default.navigateTo({
                    path: "/pages/home/h5Active/index",
                    query: {
                        url: e
                    }
                });
                break;

              case "H_PRODUCT_DETAIL":
                wx.$route.navigateTo({
                    name: "home-goods-detail",
                    query: S
                });
                break;

              case "H_CET_ODR":
                wx.$route.navigateTo({
                    url: e,
                    query: {
                        coupon: encodeURIComponent(JSON.stringify(k))
                    }
                });
            }
        },
        onClickCoupon: function(e) {
            var u = this;
            return i(t.default.mark(function i() {
                var d, c, l, p, v, m, f, g, h, b, y, x, T, w, C, I, k, q, S, D, E, _, R, A, M, O, P, N, U, L, B, H, W;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (console.log("点击券"), d = e.currentTarget.dataset.store, c = d.activityCode, l = d.linkUrl, 
                        p = d.avatar, v = d.urlType, m = d.ticketId, f = d.noStart, g = d.activityId, h = void 0 === g ? "" : g, 
                        b = d.toolActivityId, y = void 0 === b ? "" : b, x = d.tmExpire, T = void 0 === x ? "" : x, 
                        w = d.tmFinish, C = void 0 === w ? "" : w, I = d.toolType, k = void 0 === I ? "" : I, 
                        q = d.toolName, S = void 0 === q ? "" : q, D = d.orderAmountLimit, E = void 0 === D ? "" : D, 
                        _ = d.amount, R = void 0 === _ ? "" : _, A = d.orderStep, M = {
                            activityCode: c,
                            activityId: h,
                            toolActivityId: y,
                            tmExpire: T,
                            tmFinish: C,
                            ticketId: m,
                            toolType: k,
                            toolName: S,
                            orderAmountLimit: E,
                            amount: R,
                            orderStep: void 0 === A ? [] : A
                        }, "立即领取" != e.currentTarget.dataset.text) {
                            t.next = 25;
                            break;
                        }
                        return console.log("优惠中心_领券"), s.frxs.XSMonitor.sendEvent("slot_click", {
                            slot: "优惠中心_领券"
                        }, ""), t.prev = 7, t.next = 10, n.couponApi.receiveTicket({
                            code: c,
                            storeId: s.frxs.getMOrSData("storeId") || "",
                            blackBox: s.frxs.storage("safe_bb") || ""
                        }, {
                            loading: "领取中...",
                            silence: !0,
                            contentType: "application/json"
                        });

                      case 10:
                        if (!(O = t.sent)) {
                            t.next = 18;
                            break;
                        }
                        if (!O.errorCode) {
                            t.next = 15;
                            break;
                        }
                        return s.frxs.showToast({
                            icon: "error",
                            title: O.errorMessage,
                            duration: 700,
                            mask: !0,
                            complete: function() {
                                setTimeout(function() {
                                    wx.hideToast();
                                }, 700);
                            }
                        }), t.abrupt("return");

                      case 15:
                        s.frxs.showToast({
                            icon: "success",
                            title: "领取成功",
                            duration: 700,
                            mask: !0,
                            complete: function() {
                                setTimeout(function() {
                                    wx.hideToast(), u.triggerEvent("refreshList");
                                }, 700);
                            }
                        }), (P = s.frxsConfig.tmplIds) && (N = [ P.productBuy, P.discountCouponReminder, P.commodityReduction ], 
                        (0, a.onRequestSubscribeMessage)(N));

                      case 18:
                        t.next = 24;
                        break;

                      case 20:
                        t.prev = 20, t.t0 = t.catch(7), console.log(t.t0), s.frxs.showToast({
                            icon: "error",
                            title: t.t0.rspDesc,
                            duration: 700,
                            mask: !0,
                            complete: function() {
                                setTimeout(function() {
                                    wx.hideToast();
                                }, 700);
                            }
                        });

                      case 24:
                        return t.abrupt("return");

                      case 25:
                        if (u.data.needSendEvent) {
                            console.log("sendEvent", "qugao");
                            try {
                                U = {
                                    slot: f ? "待生效优惠券" : "已生效优惠券",
                                    ticket_id: m
                                }, s.frxs.getMData("zp_activityCode") && (U.activity_code = s.frxs.getMData("zp_activityCode")), 
                                s.frxs.XSMonitor.sendEvent("slot_click", U, "");
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.log(e);
                            }
                        }
                        if (-1 === v.indexOf("H_")) {
                            t.next = 29;
                            break;
                        }
                        return u.toHomeUseCoupon(l, v, e.currentTarget.dataset.store), t.abrupt("return");

                      case 29:
                        if (l) {
                            t.next = 34;
                            break;
                        }
                        if ("CET_ODR" != v) {
                            t.next = 32;
                            break;
                        }
                        return t.abrupt("return", r.default.navigateTo({
                            path: "subShopCart/productList/index",
                            query: {
                                coupon: encodeURIComponent(JSON.stringify(M))
                            }
                        }));

                      case 32:
                        return r.default.subSwitchTab({
                            path: "subMain/main/index",
                            query: {
                                tabCode: "home"
                            },
                            isRedirect: !0
                        }), t.abrupt("return");

                      case 34:
                        0 === l.indexOf("@") ? (L = {}, l.substr(1).split("&").forEach(function(e) {
                            var t = e.split("=");
                            L[t[0]] = t[1];
                        }), e.detail.store.params = L, B = {}, (H = wx.$._get(p, "imgUrl", !1)) && (B.imgUrl = H), 
                        r.default.navigateTo({
                            path: "/subProduct/detail/index",
                            query: o(o({}, L || {}), B)
                        })) : 0 === l.indexOf("%windId=") && l.substr(8) ? u.goToWindow(l.substr(8)) : 0 === l.indexOf("%secondWindowId") && l.substr(16) ? r.default.navigateTo({
                            path: "/subProduct/boutique/boutique",
                            query: {
                                secondWindowId: l.substring(16, l.length)
                            }
                        }) : l ? (W = {
                            path: "/pages/home/h5Active/index",
                            query: {
                                url: l
                            }
                        }, "CET_ODR" === v && (W.path = l, W.query = {
                            coupon: encodeURIComponent(JSON.stringify(M))
                        }), r.default.navigateTo(W)) : r.default.subSwitchTab({
                            path: "subMain/main/index",
                            query: {
                                tabCode: "home"
                            },
                            isRedirect: !0
                        }), u.triggerEvent("closePop");

                      case 36:
                      case "end":
                        return t.stop();
                    }
                }, i, null, [ [ 7, 20 ] ]);
            }))();
        }
    }
});