var t = require("../../const/player-status.js"), e = getApp(), a = !1;

Component({
    properties: {
        skeleton: {
            type: Boolean,
            value: !1
        },
        showFullscreenBtn: {
            type: Boolean,
            value: !1
        },
        enablePlayGesture: {
            type: Boolean,
            value: !0
        },
        params: {
            type: Object,
            value: {}
        },
        likeNum: {
            type: [ Number, String ],
            value: 0,
            observer: function(t, e) {
                t != e && this.updateLikeNum(t);
            }
        },
        playNum: {
            type: [ Number, String ],
            value: 0,
            observer: function(t, e) {
                t != e && this.updatePlayNum(t);
            }
        },
        showProduct: {
            type: Boolean,
            value: !0
        },
        videoStatus: {
            type: Number,
            value: 1,
            observer: function(t, e) {
                t != e && t > 0 && this.updatePlayerStatus(t);
            }
        },
        objectFit: {
            type: String,
            value: "contain"
        },
        followStatus: {
            type: Number,
            value: 0
        },
        showFollow: {
            type: Boolean,
            value: !0
        },
        likeStatus: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        anim: "",
        isload: !1,
        likeNumTx: 0,
        playNumTx: 0
    },
    methods: {
        updatePlayerStatus: function(t) {
            var e = wx.createVideoContext("videoEle", this);
            2 == t ? e.play && e.play() : 3 == t ? e.pause && e.pause() : 1 == t && e.stop && e.stop();
        },
        playVideo: function() {
            this.triggerEvent("player-click", {
                key: this.data.params.key
            }), this.triggerEvent("player-progress", {
                key: this.data.params.key,
                status: t.PLAYER_STATUS.PLAYING
            });
        },
        videoPlay: function() {
            2 != this.data.videoStatus && this.playVideo(), this.triggerEvent("player-status", {
                key: this.data.params.key,
                status: t.PLAYER_STATUS.PLAYING
            });
        },
        videoPause: function() {
            this.triggerEvent("player-pause", {
                key: this.data.params.key
            }), this.triggerEvent("player-status", {
                key: this.data.params.key,
                status: t.PLAYER_STATUS.PAUSE
            });
        },
        videoEnded: function() {
            this.triggerEvent("player-ended", {
                key: this.data.params.key
            }), this.triggerEvent("player-status", {
                key: this.data.params.key,
                status: t.PLAYER_STATUS.END
            });
        },
        videoError: function(t) {
            console.log(t), this.triggerEvent("player-error", {
                key: this.data.params.key,
                error: t
            });
        },
        likeVideo: function() {
            var t = this;
            if (!a) {
                var e = this.data.likeStatus ? 0 : 1;
                a = !0, this.triggerEvent("like-vd", {
                    key: this.data.params.key,
                    likeStatus: e,
                    callback: function() {
                        t.setData({
                            likeStatus: e,
                            anim: e ? "anim" : "cancel"
                        }), setTimeout(function() {
                            a = !1;
                        }, 1e3);
                    },
                    error: function() {
                        a = !1;
                    }
                });
            }
        },
        handleShowProduct: function() {
            this.triggerEvent("show-product", {
                spuSns: this.data.params.spuSns
            });
        },
        updateLikeNum: function(t) {
            t < 1 || this.setData({
                likeNumTx: e.frxs.calculateSum(t)
            });
        },
        updatePlayNum: function(t) {
            t < 1 || this.setData({
                playNumTx: e.frxs.calculateSum(t)
            });
        },
        onTimeupdate: function(t) {
            t.detail.currentTime > 0 && !this.data.isload && this.setData({
                isload: !0
            }), this.triggerEvent("player-time-update", {
                key: this.data.params.key,
                progress: t.detail
            });
        },
        onFollowAuthor: function() {
            var t = this.data.followStatus;
            this.triggerEvent("follow-author", {
                authorId: this.data.params.authorId || "",
                followStatus: t
            });
        },
        onIntoAuthor: function() {
            this.triggerEvent("into-author", {
                authorId: this.data.params.authorId || ""
            });
        }
    }
});