Component({
    properties: {
        type: String,
        size: String,
        color: String
    },
    data: {},
    methods: {}
});