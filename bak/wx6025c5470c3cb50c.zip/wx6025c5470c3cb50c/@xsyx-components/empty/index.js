Component({
    properties: {
        type: String,
        img: String,
        imgwidth: Number,
        imgheight: Number,
        modal: String,
        layout: {
            type: String,
            value: "col",
            des: "row: 左图右文；col: 上图下文"
        }
    }
});