var t, e = require("../../@babel/runtime/helpers/objectSpread2"), s = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../utils/product"), o = (s(t = {}, n.PRODUCT_STATUS.WAITING, "提前加购"), 
s(t, n.PRODUCT_STATUS.ACTIVE, "立即加购"), s(t, n.PRODUCT_STATUS.SOLDOUT, "抢光了"), s(t, n.PRODUCT_STATUS.OVER, "抢光了"), 
s(t, n.PRODUCT_STATUS.LACK, "抢光了"), s(t, n.PRODUCT_STATUS.DOWN, "抢光了"), t);

Component({
    externalClasses: [ "custom-class", "btn-class", "pre-sale-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        custom: Boolean,
        count: Number,
        preSaleTime: String,
        status: {
            type: String,
            value: n.PRODUCT_STATUS.ACTIVE
        },
        buttonText: {
            type: Object,
            value: o,
            observer: function(t) {
                if (t) {
                    var s = e(e({}, o), t);
                    this.setData({
                        btnTextMap: s
                    });
                }
            }
        },
        iconRed: {
            type: Object,
            value: {
                add: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/count-add.png",
                reduce: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/count-reduce.png"
            }
        },
        iconBlue: {
            type: Object,
            value: {
                add: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/add-bule.png",
                reduce: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/reduce-blue.png"
            }
        }
    },
    data: {
        btnTextMap: o
    },
    methods: {
        onAdd: function() {
            var t = this.data, e = t.status, s = t.count;
            this.triggerEvent("add", {
                status: e,
                count: s
            });
        },
        onReduce: function() {
            var t = this.data, e = t.status, s = t.count;
            this.triggerEvent("reduce", {
                status: e,
                count: s
            });
        }
    }
});