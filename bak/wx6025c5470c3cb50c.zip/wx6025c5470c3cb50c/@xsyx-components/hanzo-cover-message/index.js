Component({
    properties: {
        data: {
            type: Array,
            observer: function(t) {
                var e = t.slice(0, this.data.pageSize);
                this.setData({
                    renderData: e
                });
            }
        },
        pageSize: {
            type: Number,
            value: 5
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        renderData: [],
        isRead: !0,
        current: 1
    },
    ready: function() {
        this.triggerEvent("showPopup");
    },
    methods: {
        handleScrollLower: function() {
            this.data.isRead && (this.setData({
                isRead: !1
            }), this.pagingData(this.data.data));
        },
        handleGoShop: function() {
            this.triggerEvent("goShop");
        },
        handleClose: function() {
            this.triggerEvent("close");
        },
        pagingData: function(t) {
            var e = [], a = this.data.current;
            Array.isArray(t) && t.length > 0 ? (a++, e = t.slice(0, a * this.data.pageSize)) : a = 1, 
            this.setData({
                renderData: e,
                current: a,
                isRead: t.length !== e.length
            });
        }
    }
});