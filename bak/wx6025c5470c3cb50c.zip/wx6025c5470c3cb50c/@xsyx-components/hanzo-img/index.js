Component({
    externalClasses: [ "custom-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        src: {
            type: String,
            value: "",
            observer: function(e) {
                var t = this.imageWebp(e, wx.$webpS);
                this.setData({
                    imgSrc: t,
                    support: wx.$webpS && wx.$webpS.support,
                    supportBcg: wx.$webpS && wx.$webpS.supportBcg
                });
            }
        },
        mode: {
            type: String,
            value: ""
        },
        lazyLoad: {
            type: Boolean,
            value: !0
        },
        longPress: {
            type: Boolean,
            value: !1
        },
        isBcg: {
            type: Boolean,
            value: !1
        },
        dataSrc: {
            type: String,
            value: ""
        },
        dataIndex: {
            type: String,
            value: ""
        },
        origin: {
            type: Boolean,
            value: !1
        },
        style: {
            type: String,
            value: ""
        },
        width: {
            type: String,
            value: ""
        }
    },
    data: {
        imgSrc: "",
        imageSrc: [],
        support: !1,
        supportBcg: !1
    },
    attached: function() {},
    methods: {
        handleerror: function(e) {
            this.triggerEvent("error", e.detail);
        },
        handleload: function(e) {
            this.triggerEvent("load", e.detail);
        },
        imgClick: function(e) {
            var t = (e.currentTarget || {}).dataset, r = void 0 === t ? {} : t;
            this.triggerEvent("on-click", r);
        },
        imageWebp: function(e, t) {
            var r = this.imageWidth(e, this.data.width) || "", s = t || {}, i = s.support, n = void 0 !== i && i, a = s.supportBcg, o = void 0 !== a && a;
            if (!r || !n) return r;
            if (this.data.isBcg && !o) return r;
            var u = -1 !== r.indexOf("?") ? "&" : "?";
            if ([ "image.xsyxsc.com", "frxsuatoss.frxs.cn", "frxsuatosss.frxs.cn", "frxsuatoss.xsyxsc.cn", "frxsuatosss.xsyxsc.cn" ].some(function(e) {
                return -1 !== r.indexOf(e);
            })) {
                var x = -1 !== r.indexOf("x-oss-process=image") ? "/format,webp" : u + "x-oss-process=image/format,webp";
                return r + x;
            }
            if ([ "front-xps-cdn.xsyx.xyz" ].some(function(e) {
                return -1 !== r.indexOf(e);
            })) {
                var c = -1 !== r.indexOf("imageMogr2/") ? "|imageMogr2/format/webp" : u + "imageMogr2/format/webp";
                return r + c;
            }
            return r;
        },
        imageWidth: function(e, t) {
            if (!e || !t) return e;
            var r = -1 !== e.indexOf("?") ? "&" : "?";
            if ([ "image.xsyxsc.com", "frxsuatoss.frxs.cn", "frxsuatosss.frxs.cn", "frxsuatoss.xsyxsc.cn", "frxsuatosss.xsyxsc.cn" ].some(function(t) {
                return -1 !== e.indexOf(t);
            })) {
                var s = -1 !== e.indexOf("x-oss-process=image") ? "/resize,w_" + t + ",m_lfit" : r + "x-oss-process=image/resize,w_" + t + ",m_lfit";
                return e + s;
            }
            if ([ "front-xps-cdn.xsyx.xyz" ].some(function(t) {
                return -1 !== e.indexOf(t);
            })) {
                var i = -1 !== e.indexOf("imageMogr2/") ? "|imageMogr2/thumbnail/" + t + "x" : r + "imageMogr2/thumbnail/" + t + "x";
                return e + i;
            }
            return e;
        }
    }
});