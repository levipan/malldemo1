var t = require("../../const/hotListUrl.js");

Component({
    properties: {
        isExposure: {
            type: Boolean,
            value: !1
        },
        list: {
            type: Array,
            value: [],
            observer: function(t) {
                var e = this;
                if ("{}" !== JSON.stringify(this.data.cartNumberMap)) {
                    var a = t.map(function(t) {
                        if (t.key || e.data.cartNumberMap[t.skuSn]) {
                            var a = e.data.cartNumberMap[t.key] ? e.data.cartNumberMap[t.key] : e.data.cartNumberMap[t.skuSn] ? e.data.cartNumberMap[t.skuSn] : 0;
                            t.cartCount = a;
                        }
                        return t;
                    });
                    this.setData({
                        _list: a
                    });
                } else this.setData({
                    _list: t
                });
            }
        },
        cartNumberMap: {
            type: Object,
            value: {},
            observer: function(t) {
                if (this.data.list && this.data.list.length) {
                    var e = this.data.list.map(function(e) {
                        if (e.key || t[e.skuSn]) {
                            var a = t[e.key] ? t[e.key] : t[e.skuSn] ? t[e.skuSn] : 0;
                            e.cartCount = a;
                        }
                        return e;
                    });
                    this.setData({
                        _list: e
                    });
                }
            }
        },
        rankType: {
            type: String,
            value: "hot_sales"
        },
        rankTitle: {
            type: String,
            value: "榜单"
        },
        rankDes: {
            type: String,
            value: ""
        }
    },
    data: {
        _list: [],
        RANK_TYPE_BG_MAPS: t.RANK_TYPE_BG_MAPS,
        RANK_TYPE_TITLE_ICON_MAPS: t.RANK_TYPE_TITLE_ICON_MAPS,
        RANK_TYPE_TITLE_COLOR_MAPS: t.RANK_TYPE_TITLE_COLOR_MAPS
    },
    methods: {
        goToDetail: function() {
            this.triggerEvent("click-more");
        },
        exposure: function(t) {
            var e = t.currentTarget.dataset.index, a = this.data.list[e];
            this.triggerEvent("exposure", {
                val: t.detail,
                key: a.key,
                item: t.detail.item,
                index: e
            });
        },
        clickMain: function(t) {
            var e = t.detail.product, a = t.currentTarget.dataset.index;
            this.triggerEvent("click-main", {
                val: t.detail,
                key: e.key,
                product: e,
                index: a
            });
        },
        addCartMax: function(t) {
            var e = t.detail.product, a = t.currentTarget.dataset.index;
            this.triggerEvent("cart-add-max", {
                val: t.detail,
                key: e.key,
                product: e,
                index: a
            });
        },
        addCart: function(t) {
            var e = t.detail.product, a = t.currentTarget.dataset.index;
            this.triggerEvent("cart-add", {
                val: t.detail,
                key: e.key,
                product: e,
                index: a
            });
        },
        reduceCart: function(t) {
            var e = t.detail.product, a = t.currentTarget.dataset.index;
            this.triggerEvent("cart-reduce", {
                val: t.detail,
                key: e.key,
                product: e,
                index: a
            });
        }
    }
});