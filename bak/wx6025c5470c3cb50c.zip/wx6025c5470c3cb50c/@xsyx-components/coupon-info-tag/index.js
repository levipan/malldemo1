var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../router/index.js"));

Component({
    properties: {
        couponList: {
            type: Array,
            desc: "优惠信息列表",
            value: []
        },
        path: {
            type: String,
            desc: "点击按钮跳转的path",
            value: "/subPages/pages/promotionCenter/index"
        }
    },
    methods: {
        goToCouponList: function() {
            e.default.navigateTo({
                path: this.data.path
            });
        }
    }
});