var e = getApp();

Component({
    properties: {
        className: {
            type: String,
            value: "order"
        },
        pickDate: String,
        preSaleTime: String
    },
    data: {
        show: !0,
        isIPhoneX: !1
    },
    ready: function() {
        this.setData({
            isIPhoneX: e.globalData.isIPhoneX || !1
        });
    },
    methods: {
        onClose: function() {
            this.setData({
                show: !1
            });
        }
    }
});