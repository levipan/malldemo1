var t = wx.getSystemInfoSync().windowWidth / 750;

Component({
    properties: {
        iStyle: {
            type: String,
            value: ""
        },
        value: {
            type: String,
            value: ""
        },
        menuList: {
            type: Array,
            value: []
        },
        align: {
            type: String,
            value: "vertical"
        },
        height: {
            type: String,
            value: ""
        },
        selectIndex: {
            type: Number,
            value: 0,
            observer: function(t) {
                var e = this.data.menuInfo;
                e[t] && e[t].top >= 0 && this.changeTabFun(t, e[t].top);
            }
        },
        theme: {
            type: String,
            value: "red"
        },
        modal: {
            type: String,
            value: ""
        },
        skin: {
            type: Object,
            observer: function(t) {
                t && t.firstAboveSkin && this.setData({
                    skinRed: t.firstAboveSkin
                });
            }
        }
    },
    data: {
        menuInfo: [],
        tabIndex: 0,
        scrollLeft: 0,
        scrollTop: 0,
        width: 0,
        ml: -9 * t,
        initMl: 0,
        initHl: 0,
        svHeight: 0,
        svWidth: 0,
        lastLeft: 0,
        lastWidth: 0,
        slideH: 0,
        skinBlue: "https://front-xps-cdn.xsyx.xyz/2020/07/10/1213187880.png",
        skinRed: "https://front-xps-cdn.xsyx.xyz/2020/07/10/2064817264.png"
    },
    ready: function() {
        var t = this.data.align;
        this.initInfo(), "horizontal" === t ? this.initCal() : "vertical" === t && this.initVertical();
    },
    methods: {
        initInfo: function() {
            var t = this.data, e = t.menuList, n = t.menuInfo;
            e.map(function(t) {
                var e = {};
                e.label = t.label, e.cornerMarkImg = t.cornerMarkImg, e.displayContent = t.displayContent, 
                e.displayType = t.displayType, n.push(e);
            }), this.setData({
                menuInfo: n
            });
        },
        initVertical: function() {
            var t = this;
            wx.createSelectorQuery().in(this).selectAll(".menu__item").boundingClientRect(function(e) {
                var n = t.data.menuInfo;
                n.map(function(t, n) {
                    t.top = e[n].top;
                }), t.setData({
                    menuInfo: n
                });
            }).select(".first").boundingClientRect(function(e) {
                t.setData({
                    initHl: e.top
                });
            }).select(".menu__line__vertical").boundingClientRect(function(e) {
                e && t.setData({
                    slideH: e.height
                });
            }).select(".scroll-view__vertical").boundingClientRect(function() {
                t.setData({
                    svHeight: parseInt(t.data.height) || 0
                });
                var e = t.data, n = e.selectIndex, i = e.menuInfo;
                t.changeTabFun(n, i[n].top);
            }).exec();
        },
        initCal: function() {
            var t = this;
            wx.createSelectorQuery().in(this).selectAll(".menu__item").boundingClientRect(function(e) {
                var n = t.data.menuInfo;
                n.map(function(t, n) {
                    t.left = e[n].left;
                }), t.setData({
                    menuInfo: n
                });
            }).select(".first").boundingClientRect(function(e) {
                t.setData({
                    initMl: e.left
                });
            }).select(".scroll-view").boundingClientRect(function(e) {
                t.setData({
                    svWidth: e.width
                });
                var n = t.data, i = n.selectIndex, a = n.menuInfo;
                t.changeTabFun(i, a[i].left);
            }).exec();
        },
        changeTab: function(t) {
            var e = t.currentTarget.dataset;
            if ("horizontal" === this.data.align) {
                if (this.data.tabIndex === e.index) return;
                this.changeTabFun(e.index, e.left);
            } else {
                if (this.data.tabIndex === e.index) return;
                this.changeTabFun(e.index, e.top);
            }
        },
        changeTabFun: function(t, e) {
            var n = this, i = this.data, a = i.menuInfo, s = i.initMl, l = i.svWidth, o = i.menuList, c = i.align, r = i.svHeight, u = i.initHl, h = i.slideH;
            a.map(function(e, n) {
                return e.active = n === t;
            }), this.setData({
                menuInfo: a,
                tabIndex: t
            }), wx.createSelectorQuery().in(this).select(".active").boundingClientRect(function(t) {
                if ("horizontal" === c) {
                    var i = e - (l - t.width) / 2 - s;
                    n.setData({
                        width: t.width,
                        scrollLeft: i
                    }), setTimeout(function() {
                        n.setData({
                            ml: e - s
                        });
                    }, 80);
                } else {
                    var a = e - (r - t.height) / 2 - u;
                    n.setData({
                        scrollTop: a
                    }), setTimeout(function() {
                        n.setData({
                            ml: e - u + (t.height - h) / 2
                        });
                    }, 80);
                }
            }).exec(), this.triggerEvent("changeMenu", o[t]);
        },
        stopBubble: function() {}
    }
});