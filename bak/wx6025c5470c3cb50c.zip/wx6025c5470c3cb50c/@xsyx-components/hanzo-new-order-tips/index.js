var t = require("../../api/index");

Component({
    properties: {
        modal: {
            type: String,
            value: "modal1"
        },
        duration: {
            type: Number,
            value: 4
        }
    },
    data: {
        img: "",
        text: "",
        show: !1
    },
    attached: function() {
        this.runTips();
    },
    detached: function() {
        clearTimeout(this.timer || 0);
    },
    allTips: [],
    methods: {
        runTips: function() {
            var a = this;
            if (this.allTips && this.allTips.length) try {
                var e = {};
                switch (this.data.modal) {
                  case "modal1":
                    e = this.allTips.shift();
                    break;

                  case "modal2":
                    e = this.allTips.splice(Math.floor(Math.random() * (this.allTips.length - 1)), 1)[0] || {};
                }
                e.wechatName = e.wechatName.substr(0, 4) + (e.wechatName.length > 4 ? "..." : "");
                var i = e, o = i.wechatName, s = i.wechatImage, n = i.isTk;
                this.timer = setTimeout(function() {
                    var t = "";
                    switch (a.data.modal) {
                      case "modal1":
                        t = "最新订单来自".concat(o, "，").concat(a.ramdom(1, 30), "秒前");
                        break;

                      case "modal2":
                        t = n ? "".concat(o, "使用优惠券已下单，").concat(a.ramdom(1, 30), "秒前") : "最新订单来自".concat(o, "，").concat(a.ramdom(1, 30), "秒前");
                    }
                    a.setData({
                        img: s,
                        text: t,
                        show: !0
                    }, function() {
                        setTimeout(function() {
                            a.setData({
                                show: !1
                            }), a.runTips();
                        }, 5e3);
                    });
                }, function() {
                    switch (a.data.modal) {
                      case "modal1":
                      case "modal2":
                        return 1e3 * a.ramdom(2, 4);
                    }
                }());
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log(t), this.allTips = [];
            } else this.timer = setTimeout(function() {
                t.tradeApi.orderTips({}, {
                    silence: !0
                }).then(function(t) {
                    a.allTips = t, a.runTips();
                }).catch(function(t) {
                    console.warn(t), a.timer = setTimeout(function() {
                        a.runTips();
                    }, 5e3);
                });
            }, 5e3);
        },
        ramdom: function(t, a) {
            return Math.floor(Math.random() * (a - t + 1) + t);
        }
    }
});