var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), o = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../@babel/runtime/helpers/objectSpread2"), i = (t(require("../../xapp/runtime.js")), 
t(require("../../utils/outBuisness-store-dialog"))), a = t(require("../../router/index")), n = require("../../api/index.js"), s = require("../../utils/productLive.js"), u = require("behavior/playVideo.js"), c = require("behavior/foodMenu.js"), d = getApp(), p = "OVER";

Component({
    behaviors: [ u, c ],
    properties: {
        activeCenter: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && (this.formatSkuList(), this.formatFootCouponList());
            }
        },
        productInfo: {
            type: Object,
            observer: function(t) {
                if (t.utvList && t.utvList.length && this.setData({
                    utvList: t.utvList
                }), void 0 !== t.saleable && !1 === t.saleable && this.setData({
                    status: p
                }), t.hasNewLive && t.tvLiveDto && "NOT_STARTED" === t.tvLiveDto.tvStatus && t.tvLiveDto.preStartTime) {
                    var e = (0, s.formatNewLiveStartTime)(t.tvLiveDto.preStartTime);
                    this.setData({
                        liveTitle: e
                    });
                }
                this.formatSkuList(), this.formatFootCouponList(), this.formatActiveInfo(t), this.onProductAdsTest();
            }
        },
        ticketDetail: Object,
        styles: {
            type: Object,
            value: {
                "margin-top": "20rpx"
            }
        },
        isExposure: {
            type: Boolean,
            value: !1
        },
        buyer: Array,
        cartCount: {
            type: Number,
            value: 0
        },
        follows: String,
        key: String,
        limit: Number,
        marketPrice: String,
        pickUpDate: String,
        preSaleDate: String,
        price: String,
        saled: String,
        saledTotle: String,
        skeleton: Boolean,
        status: {
            type: String,
            value: "ACTIVE",
            observer: function(t) {
                t !== p && this.data.productInfo && !1 === this.data.productInfo.saleable && this.setData({
                    status: p
                });
            }
        },
        statusText: {
            type: String,
            value: "加入购物车"
        },
        totle: Number,
        timeOffset: Number,
        type: {
            type: String,
            value: "NORMAL"
        },
        windType: {
            type: String,
            value: "NORMAL"
        },
        vendor: String,
        video: String,
        viewNum: String,
        likeNum: String,
        showFullscreenBtn: {
            type: Boolean,
            value: !0
        },
        customFullscreenBtn: {
            type: Boolean,
            value: !1
        },
        showLike: {
            type: Boolean,
            value: !0
        },
        size: String,
        prefix: String,
        brandBtnText: String,
        liveType: String,
        liveTitle: String,
        countdownType: String,
        isContinuousSale: Boolean,
        wantBuy: String,
        salePercent: Number,
        salePctText: String,
        remain: Number,
        ishot: Boolean,
        isGrey: Boolean,
        saleLimitType: String,
        isPraised: {
            type: Boolean,
            observer: function(t) {
                var e = this;
                t ? (this.setData({
                    aimateConfig: [],
                    startAimate: !1,
                    isTouch: !0
                }), this.data.isAnimated || setTimeout(function() {
                    e.setData({
                        isAnimated: !0
                    });
                }, 600)) : (this.lovesConfig(), this.setData({
                    isAnimated: !1
                }));
            }
        },
        storageMode: Number,
        pageKey: String,
        marketAmtSourceType: String,
        hasHotLink: {
            type: Boolean,
            value: !1
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        },
        isNewUser: {
            type: Boolean,
            value: !1
        },
        hotListDesc: String,
        nearBy: String,
        fuzzy: Boolean,
        marketingTagImage: String
    },
    data: {
        aimateConfig: [],
        startAimate: !1,
        isTouch: !1,
        isFullSc: !1,
        isAnimated: !1,
        renameTitle: "",
        storageModeStr: "",
        ossDomain: d.frxsConfig.ossDomain,
        skuSnCouponList: [],
        couponFootMark: null,
        martketActivityCoupons: [],
        productCorsetCornerMark: {},
        productNameCornerMark: [],
        hadRecievedCoupon: !1,
        adsTextTest: "D"
    },
    ready: function() {
        var t = this.data, e = t.video, o = t.isPraised;
        e && !o && this.lovesConfig(), this.data.isExposure && this.exposure();
    },
    detached: function() {
        try {
            this.data.isExposure && this.productObserve.disconnect();
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            console.log(t);
        }
    },
    methods: {
        formatSkuList: function() {
            var t = this.data.productInfo, e = [];
            this.data.activeCenter ? t.skuSnCouponList && (e = t.skuSnCouponList.map(function(t) {
                var e = t.toolName;
                if ("DISCOUNT" === t.toolType) e += "满".concat(t.orderAmountLimit, "元 | ").concat(1 * (t.discount / 10).toFixed(2), "折 | 最高优惠").concat(t.amount, "元"); else if (t.orderStep) {
                    e = e + " | " + t.orderStep.map(function(t) {
                        return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                    }).join(" | ");
                } else e += "满".concat(t.orderAmountLimit, "减").concat(t.amount);
                return e;
            }), this.setData({
                skuSnCouponList: e
            })) : t.skuSnCouponList && (e = t.skuSnCouponList.map(function(t) {
                var e = "GLOBAL" === t.rootType ? "全场" : t.toolName.length > 80 ? t.toolName.slice(0, 77) + "..." : t.toolName;
                t.orderStep ? e += t.orderStep.map(function(t) {
                    return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount);
                }).join("、") : e += "满".concat(t.orderAmountLimit, "减").concat(t.amount);
                return e;
            }), this.setData({
                skuSnCouponList: e
            })), this.formateRecieveStatus();
        },
        formatFootCouponList: function() {
            var t = this.data.productInfo;
            if ("SHOW" == t.cornCouponType) {
                var e = (t.skuSnCouponList || []).length, o = t.productMarkInfo, i = void 0 === o ? {} : o;
                if (e > 0) {
                    var a = t.skuSnCouponList[e - 1], n = "";
                    if ("DISCOUNT" === a.toolType) n = "满".concat(a.orderAmountLimit, "元 | ").concat(1 * (a.discount / 10).toFixed(2), "折 | 最高优惠").concat(a.amount, "元"); else if (a.orderStep) {
                        n = a.orderStep.map(function(t) {
                            return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                        }).join(" | ");
                    } else n = "满".concat(a.orderAmountLimit, "减").concat(a.amount);
                    var s = r({
                        title: a.toolName,
                        couponMsg: n
                    }, i);
                    this.setData({
                        couponFootMark: s
                    });
                } else this.setData({
                    couponFootMark: i
                });
            }
        },
        formatActiveInfo: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (t.productMarkAtmosphere) {
                var e = t.productMarkAtmosphere, o = e.martketActivityCoupons, r = e.productCorsetCornerMark, i = e.productNameCornerMark;
                this.setData({
                    martketActivityCoupons: o,
                    productCorsetCornerMark: r,
                    productNameCornerMark: i
                });
            }
        },
        exposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport({
                    bottom: -300
                }), o = this.data.key;
                this.productObserve = e, e.observe("#product_key_".concat(o), function(e) {
                    e.intersectionRatio > 0 && (t.triggerEvent("exposure", {
                        status: t.data.status
                    }), t.setShowFoodMeunGuide());
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log(t);
            }
        },
        todoRecive: function(t) {
            this.triggerEvent("cart-recive", {
                cart: t.detail,
                key: this.data.key
            }, this.data);
        },
        onAdd: function(t) {
            this.triggerEvent("cart-add", {
                cart: t.detail,
                key: this.data.key
            }, this.data);
        },
        onReduce: function(t) {
            this.triggerEvent("cart-reduce", {
                cart: t.detail,
                key: this.data.key
            }, this.data);
        },
        onCoverClick: function() {
            this.triggerEvent("cover-click", this.data.key, this.data);
        },
        onTitleClick: function() {
            this.triggerEvent("title-click", this.data.key, this.data);
        },
        onBtnClick: function() {
            this.triggerEvent("btn-click", this.data.key, this.data);
        },
        onBrandClick: function() {
            this.triggerEvent("brand-click", this.data);
        },
        onCoverPress: function(t) {
            if (!(this.data.playStatus > 1)) {
                this.triggerEvent("cover-press", this.data.cover, this.data);
                var e = [ t.currentTarget.dataset.src ];
                wx.previewImage({
                    current: e,
                    urls: e
                });
            }
        },
        lovesConfig: function() {
            for (var t = [], e = [ "#947cff", "#f62b48", "#ffe27c", "#f42bf6" ], o = 0; o < 6; o++) {
                var r = {};
                r.time = parseInt(1001 * Math.random() + 0, 10) + "ms", r.color = e[parseInt(4 * Math.random() + 0, 10)], 
                r.top = parseInt(11 * Math.random() + 0, 10) + "rpx", r.left = parseInt(11 * Math.random() + 0, 10) + "rpx", 
                t.push(r);
            }
            this.setData({
                aimateConfig: t,
                startAimate: !0,
                isTouch: !1
            });
        },
        onOnlineReminder: function() {
            if (!i.default.showoutBuisnessDialog()) {
                var t = r(r({}, this.data.productInfo), {}, {
                    activityId: this.data.productInfo.acId,
                    presaleActivityId: this.data.productInfo.acId,
                    productId: this.data.productInfo.prId
                });
                this.triggerEvent("online-reminder", t);
            }
        },
        onSimilarProducts: function() {
            this.triggerEvent("similar-btn-click", this.data.productInfo);
            var t = this.data.productInfo || {}, e = t.acId, o = void 0 === e ? "" : e, r = t.prId, i = void 0 === r ? "" : r, n = t.sku, s = void 0 === n ? "" : n, u = t.areaId, c = void 0 === u ? "" : u, p = t.spuSn, l = {
                acId: o,
                prId: i,
                sku: s,
                areaId: c,
                spuSn: void 0 === p ? "" : p,
                storeId: d.frxs.getMOrSData("storeId") || ""
            };
            a.default.navigateTo({
                path: "/subProduct/similarProduct/index",
                query: l
            });
        },
        hotLinkClick: function() {
            this.data.productInfo.hotLinkSlot = "list_link", this.data.productInfo.hotLinkSource = "search", 
            this.triggerEvent("goHotList", this.data.productInfo), wx.$.getTestMeta("fuzzy") && d.frxs.XSMonitor.sendTestEvent("slot_click", {
                slot: "销量模糊-商品卡片榜单外链"
            }, "点击");
        },
        onShowCoupon: function(t) {
            this.triggerEvent("showCouponPopup", t.detail);
        },
        formateRecieveStatus: function() {
            var t = d.frxs.getStorageSync("receiveCenterStatus") || 0;
            if (t) {
                var e = new Date(t).toLocaleDateString();
                new Date().getTime() > new Date("".concat(e, " ").concat("23:00")).getTime() ? (d.frxs.removeStorageSync("receiveCenterStatus"), 
                this.setData({
                    hadRecievedCoupon: !1
                })) : this.setData({
                    hadRecievedCoupon: !0
                });
            }
        },
        todoFirstRecive: function() {
            var t = this;
            return o(e.default.mark(function o() {
                var r;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, r = d.frxs.isLogin()) {
                            e.next = 4;
                            break;
                        }
                        return e.abrupt("return", d.frxs.toLogin());

                      case 4:
                        return e.next = 6, n.couponApi.receiveTicketAll({
                            storeId: d.frxs.getMOrSData("storeId"),
                            userKey: r,
                            primaryChannel: "XSYX",
                            secondaryChannels: [ "HOME" ],
                            blackBox: d.frxs.storage("safe_bb") || ""
                        }, {
                            contentType: "application/json",
                            silence: !0
                        });

                      case 6:
                        d.frxs.showToast({
                            title: "领券成功"
                        }), d.frxs.setStorageSync("receiveCenterStatus", new Date().getTime()), t.setData({
                            hadRecievedCoupon: !0
                        }), e.next = 13;
                        break;

                      case 11:
                        e.prev = 11, e.t0 = e.catch(0);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, o, null, [ [ 0, 11 ] ]);
            }))();
        },
        onProductAdsTest: function() {
            var t = wx.$.getTestMeta("productAdsText") || "D";
            this.setData({
                adsTextTest: t
            });
        }
    }
});