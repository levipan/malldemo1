var e = getApp();

module.exports = Behavior({
    properties: {
        playStatus: {
            type: Number,
            value: 1,
            observer: function(e, t) {
                e != t && this.updatePlayerStatus(e || 1);
            }
        },
        showFullscreenBtn: {
            type: Boolean,
            value: !1
        },
        timeUpdate: {
            type: Number,
            value: 0,
            observer: function(e, t) {
                e != t && this.upTimeUpdate(e);
            }
        },
        windId: {
            type: Number,
            value: 0
        }
    },
    data: {
        fullScreen: !1,
        playerEnded: !1,
        videoCacheState: !1
    },
    methods: {
        isFullScreen: !1,
        videoTimeUpdate: 0,
        resetSeek: !0,
        updatePlayerStatus: function(e) {
            var t = this;
            this.setData({
                playStatus: e
            }, function() {
                var a = wx.createVideoContext("videoProduct", t);
                2 == e ? a.play && a.play() : 3 == e ? t.fullScreen || a.pause && a.pause() : 1 == e && a.stop && a.stop();
            });
        },
        onPlayerClick: function() {
            this.triggerEvent("player-click", {
                key: this.data.key,
                product: this.data,
                windId: this.data.windId
            });
        },
        videoPause: function() {},
        videoEnded: function() {
            var t = this;
            if (!((e || {}).globalData || {}).isIPhone || !this.fullScreen) {
                var a = wx.createVideoContext("videoProduct", this);
                this.fullScreen && (this.fullScreen = !1, a.exitFullScreen && a.exitFullScreen(), 
                this.videoFullscreenchange({
                    detail: {
                        fullScreen: !1
                    }
                })), this.videoTimeUpdate = 0, this.setData({
                    timeUpdate: 0,
                    playStatus: 1
                }, function() {
                    t.triggerEvent("player-ended", {
                        key: t.data.key,
                        product: t.data,
                        windId: t.data.windId
                    });
                });
            }
        },
        videoPlay: function() {
            this.data.videoCacheState || this.setData({
                videoCacheState: !0
            }), 2 != this.data.playStatus && this.onPlayerClick();
        },
        videoFullscreenchange: function(e) {
            this.fullScreen = e.detail.fullScreen;
            var t = {
                key: this.data.key,
                product: this.data,
                fullScreen: e.detail.fullScreen,
                windId: this.data.windId
            };
            this.setData({
                isFullSc: e.detail.fullScreen
            }), this.triggerEvent("player-fullscreen-change", t);
        },
        playNewPageFullscreen: function(e) {
            var t = {
                key: this.data.key,
                product: this.data,
                timeUpdate: this.videoTimeUpdate,
                windId: this.data.windId
            };
            this.setData({
                isFullSc: e.detail.fullScreen
            }), this.triggerEvent("play-newpage-fullscreen", t);
        },
        playTimeUpdate: function(e) {
            if (this.videoTimeUpdate = e.detail.currentTime, 1 == this.resetSeek) {
                var t = wx.createVideoContext("videoProduct", this);
                t.seek && t.seek(this.data.timeUpdate), this.resetSeek = !1;
            }
        },
        upTimeUpdate: function(e) {
            this.resetSeek = !0;
            var t = wx.createVideoContext("videoProduct", this);
            t.seek(e), 2 == this.data.playStatus && t.play && t.play();
        },
        giveaLike: function() {
            this.triggerEvent("love-click", this.data.key, this.data);
        },
        lovesConfig: function() {
            for (var e = [], t = [ "#947cff", "#f62b48", "#ffe27c", "#f42bf6" ], a = 0; a < 6; a++) {
                var i = {};
                i.time = parseInt(1001 * Math.random() + 0, 10) + "ms", i.color = t[parseInt(4 * Math.random() + 0, 10)], 
                i.top = parseInt(11 * Math.random() + 0, 10) + "rpx", i.left = parseInt(11 * Math.random() + 0, 10) + "rpx", 
                e.push(i);
            }
            this.setData({
                aimateConfig: e,
                startAimate: !0,
                isTouch: !1
            });
        }
    }
});