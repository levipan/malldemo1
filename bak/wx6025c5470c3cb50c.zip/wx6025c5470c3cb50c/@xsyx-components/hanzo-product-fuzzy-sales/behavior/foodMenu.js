var e, t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index")), o = getApp(), n = !1;

module.exports = Behavior({
    properties: {},
    data: {
        currentFoodMenuIndex: 0,
        showFoodMeunGuide: !1,
        utvList: []
    },
    methods: {
        onClickShopMenuTab: function(e) {
            this.setData({
                currentFoodMenuIndex: e.target.dataset.index || 0,
                showFoodMeunGuide: !1
            });
            try {
                if (e.target.dataset.index > 0) {
                    var t = this.properties.productInfo, n = void 0 === t ? {} : t;
                    o.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "菜谱入口",
                        sku: n.sku,
                        sku_sn: n.skuSn
                    }, "");
                }
            } catch (e) {}
        },
        onChangeSwiper: function(t) {
            this.setData({
                currentFoodMenuIndex: t.detail.current || 0
            }), clearTimeout(e);
            try {
                if (t.detail.current > 0) {
                    var n = this.properties.productInfo, u = void 0 === n ? {} : n, r = this.data.utvList[t.detail.current - 1];
                    o.frxs.XSMonitor.sendEvent("slot_show", {
                        slot: "菜谱视频",
                        sku: u.sku,
                        sku_sn: u.skuSn,
                        videoId: r.utvId,
                        sort: t.detail.current - 1
                    }, "");
                }
            } catch (e) {}
        },
        setShowFoodMeunGuide: function() {
            var t = this;
            clearTimeout(e), !n && this.data.utvList.length && (e = setTimeout(function() {
                var e = o.frxs.getMOrSData("foodMenuGuideCount") || 0;
                e < 5 && (t.setData({
                    showFoodMeunGuide: !0
                }, function() {
                    n = !0;
                }), o.frxs.setMAndSData("foodMenuGuideCount", e + 1));
            }, 2500));
        },
        onCloseFoodMeunGuide: function() {
            this.setData({
                showFoodMeunGuide: !1
            });
        },
        onClickFoodMenuCover: function(e) {
            var n = e.currentTarget.dataset.utvid;
            if (n) {
                t.default.navigateTo({
                    path: "/subLive/menuVideo/index",
                    query: {
                        utvId: n,
                        spuSn: this.properties.productInfo.spuSn,
                        from: "menu"
                    }
                });
                try {
                    var u = this.properties.productInfo, r = void 0 === u ? {} : u;
                    o.frxs.XSMonitor.sendEvent("video_play", {
                        slot: "菜谱入口",
                        sku: r.sku,
                        sku_sn: r.skuSn,
                        sort: this.data.currentFoodMenuIndex - 1,
                        videoId: n,
                        from: "menu",
                        video_type: "menu"
                    }, "");
                } catch (e) {}
            }
        }
    }
});