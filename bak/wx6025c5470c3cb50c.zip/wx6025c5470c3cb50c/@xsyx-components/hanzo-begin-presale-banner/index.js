var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../@babel/runtime/helpers/objectSpread2"), s = e(require("../../utils/picasso.js")), r = getApp();

Component({
    properties: {
        className: {
            type: String,
            value: "order"
        },
        pickDate: {
            type: String,
            value: "",
            observer: function(e, t) {
                e != t && this.initShow();
            }
        },
        preSaleTime: {
            type: String,
            observer: function() {
                this.onShowBanner();
            }
        },
        saleDate: {
            type: String,
            observer: function() {
                this.onShowBanner();
            }
        },
        pageCode: String
    },
    lifetimes: {
        attached: function() {
            var e = this;
            (0, s.default)({
                storeId: r.frxs.getMOrSData("storeId")
            }).then(function() {
                var t = wx.$.getTestMeta("storePickupTips") || "A";
                e.data.showTips !== t && (e.setData({
                    showTips: t
                }), "B" === t && e.triggerEvent("close", {}));
            });
        }
    },
    data: {
        show: !0,
        showTips: "A"
    },
    methods: {
        initShow: function() {
            if (this.data.pageCode) {
                var e = "".concat(this.data.saleDate, "-").concat(this.data.preSaleTime ? "presale" : "");
                this.setData({
                    show: (r.frxs.getMOrSData("presale-banner-close") || {})[this.data.pageCode] != e
                }, this.onShowBanner);
            }
        },
        onClose: function() {
            this.setData({
                show: !1
            }, this.onShowBanner), this.triggerEvent("close", {}), this.setPresaleBannerClose();
        },
        onShowBanner: function() {
            var e = this.data, t = e.show, a = e.preSaleTime, s = e.saleDate;
            t && (a || s) ? this.triggerEvent("isShow", !0) : this.triggerEvent("isShow", !1);
        },
        setPresaleBannerClose: function() {
            if (this.data.pageCode) {
                var e = r.frxs.getMOrSData("presale-banner-close") || {};
                r.frxs.setMAndSData("presale-banner-close", a(a({}, e), {}, t({}, this.data.pageCode, "".concat(this.data.saleDate, "-").concat(this.data.preSaleTime ? "presale" : ""))));
            }
        }
    }
});