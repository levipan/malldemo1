var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp().frxsConfig.ossDomain;

Component({
    properties: {
        showCheckBox: Boolean,
        checked: Boolean,
        showBtnBuy: Boolean,
        product: Object,
        showVendor: Boolean,
        cartNum: Number,
        btnCartText: {
            type: String,
            value: "去购买"
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        ossDomain: e
    },
    methods: {
        onBuy: function() {
            this.triggerEvent("onBuy", {
                product: this.data.product
            });
        },
        onReduce: function() {
            this.triggerEvent("onReduce", {
                product: this.data.product
            });
        },
        onCardClick: function() {
            this.triggerEvent("onCardClick", {
                product: this.data.product
            });
        },
        onCheckBox: function() {
            if (!this.data.product.disable) {
                var e = !this.data.checked;
                this.setData({
                    checked: e
                }), this.triggerEvent("onCheckBox", {
                    product: t(t({}, this.data.product), {}, {
                        checked: e
                    })
                });
            }
        }
    }
});