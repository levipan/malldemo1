Component({
    options: {
        styleIsolation: "isolated"
    },
    properties: {
        mainSwitch: {
            type: Boolean,
            value: !1
        },
        productReminderSubscribeStatus: {
            type: String,
            value: ""
        },
        firstProductSubReminder: {
            type: Boolean,
            value: !1
        },
        todayProductSubReminder: {
            type: Boolean,
            value: !1
        },
        productReminderTmpId: {
            type: Boolean,
            value: !1
        },
        isProductSubListPage: {
            type: Boolean,
            value: !1
        },
        subList: {
            type: Array,
            value: [ {
                name: "关注商品上架通知"
            } ]
        },
        subDesc: {
            type: String,
            value: "sm02"
        }
    },
    data: {
        iconType: "circle",
        iconColor: "#8e8e8e",
        listSubTitle: [ "心仪商品上架提醒" ],
        isOpenSetting: !1,
        subDescMap: {
            sm02: "https://front-xps-cdn.xsyx.xyz/2021/04/09/77050390.png",
            sm05: "https://front-xps-cdn.xsyx.xyz/2021/04/09/1940243094.png"
        }
    },
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        requestSubMessage: function() {
            this.setData({
                firstProductSubReminder: !0,
                todayProductSubReminder: !0
            }), this.triggerEvent("request-subscribe-message");
        },
        againLater: function() {
            this.setData({
                firstProductSubReminder: !0,
                todayProductSubReminder: !0,
                productReminderSubscribeStatus: "accept"
            });
        },
        wxOpenSetting: function() {
            this.setData({
                isOpenSetting: !0
            });
        },
        onClose: function() {
            this.triggerEvent("request-subscribe-message");
        }
    }
});