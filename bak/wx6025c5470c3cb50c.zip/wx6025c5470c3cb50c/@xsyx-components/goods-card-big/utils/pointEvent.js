Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var o = require("../../../@babel/runtime/helpers/objectSpread2"), d = getApp(), e = {
    cardClickPoint: function(e) {
        try {
            var t = {}, r = e.product, s = e.liveData, n = e.from, i = e.key, a = e.pageGuid;
            switch (("直播商品卡片" === r.slot || r.hasNewLive) && (s && (t.live_id = s.tvId), t.hasNewLive = r.hasNewLive), 
            n) {
              case "home":
                t = o(o({}, t), {}, {
                    sku_sn: r.skuSn,
                    slot: r.slot,
                    queryId: r.queryId || -1,
                    window_id: r.window_id,
                    gsort: r.gsort,
                    rsort: r.rsort,
                    window_sort: r.window_sort,
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    window_name: -2 === r.window_id ? "首页瀑布流" : r.window_name || "",
                    from: -2 == r.window_id ? "recommend_home" : "operation_home"
                }), d.frxs.XSMonitor.sendTestEvent("homePage_goodsCard_click", {}, "首页商品卡片点击");
                break;

              case "brand":
                t = o(o({}, t), {}, {
                    slot: "RECOMMEND" === r._type ? "recommend_sharelink" : "分类页商品卡片",
                    cat_id: r.window_id,
                    sec_cat_id: r.pointSecondWindowId,
                    cat_name: r.window_name,
                    sort: r.sort || r.prIndex,
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    sku_sn: r.skuSn,
                    from: "recommend_cate"
                }), "RECOMMEND" === r._type && (t.recommend_sid = a, t.from = r.slot || "recommend_sharelink", 
                t.slot = r.slot), r.adId && -2 !== r.window_id && (t.adzone_id = "ad_001033", t.ad_id = r.adId, 
                t.goods_type = "xsyx");
                break;

              case "boutique":
                t = o(o({}, t), {}, {
                    sort: i,
                    slot: r.slot,
                    sku_sn: r.skuSn,
                    cat_id: r.windowId,
                    sec_cat_id: r.secondWindowId
                });
            }
            var _ = o({}, t.ab || {});
            wx.$.getTestMeta("productAdsText") && r.productTitle ? (_.productAdsText = wx.$.getTestMeta("productAdsText"), 
            t = o(o({}, t), {}, {
                ab: _
            })) : (_.productAdsText = "D", t = o(o({}, t), {}, {
                ab: _
            })), d.frxs.XSMonitor.sendEvent("slot_click", t, ""), wx.$.getTestMeta("fuzzy") && d.frxs.XSMonitor.sendTestEvent("slot_click", o(o({}, t), {}, {
                slot: "销量模糊-商品卡片点击"
            }), "点击");
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("cardClickEvent--\x3eerror", o);
        }
    },
    cardExposurePoint: function(e) {
        try {
            var t = {}, r = e.product, s = e.liveData, n = e.from, i = e.key, a = e.pageGuid;
            switch (("直播商品卡片" === r.slot || r.hasNewLive) && (s && (t.live_id = s.tvId), t.hasNewLive = r.hasNewLive), 
            r.utvList && r.utvList.length ? t.slot = "菜谱入口" : t.slot = r.slot, n) {
              case "home":
                t = o(o({}, t), {}, {
                    sku_sn: r.skuSn,
                    queryId: r.queryId || -1,
                    window_id: r.window_id,
                    gsort: r.gsort,
                    rsort: r.rsort,
                    window_sort: r.window_sort,
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    window_name: -2 === r.window_id ? "首页瀑布流" : r.window_name || ""
                }), d.frxs.XSMonitor.sendTestEvent("homePage_goodsCard_show", {}, "首页商品卡片曝光");
                break;

              case "brand":
                t = o(o({}, t), {}, {
                    sku_sn: r.skuSn,
                    queryId: r.queryId || -1,
                    sort: r.sort || r.prIndex,
                    cat_id: r.window_id,
                    sec_cat_id: r.pointSecondWindowId,
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    cat_name: r.window_name
                }), "RECOMMEND" === r._type && (t.recommend_sid = a, t.cat_name = "推荐"), r.adId && -2 !== r.window_id && (t.adzone_id = "ad_001033", 
                t.ad_id = r.adId, t.goods_type = "xsyx");
                break;

              case "boutique":
                t = o(o({}, t), {}, {
                    sort: i,
                    sku_sn: r.skuSn,
                    cat_id: r.windowId,
                    sec_cat_id: r.secondWindowId
                });
            }
            var _ = o({}, t.ab || {});
            wx.$.getTestMeta("productAdsText") && r.productTitle ? (_.productAdsText = wx.$.getTestMeta("productAdsText"), 
            t = o(o({}, t), {}, {
                ab: _
            })) : (_.productAdsText = "D", t = o(o({}, t), {}, {
                ab: _
            })), d.frxs.XSMonitor.sendEvent("slot_show", t, ""), wx.$.getTestMeta("fuzzy") && d.frxs.XSMonitor.sendTestEvent("slot_show", o(o({}, t), {}, {
                slot: "销量模糊-商品卡片曝光"
            }), "商品卡片曝光");
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("cardExposureEvent--\x3eerror", o);
        }
    },
    cardAddPoint: function(e) {
        try {
            var t = {}, r = e.product, s = e.from, n = e.pageGuid;
            switch (s) {
              case "home":
                t = o(o({}, t), {}, {
                    window_id: r.window_id,
                    gsort: r.gsort,
                    rsort: r.rsort,
                    window_sort: r.window_sort,
                    source: "operation_home",
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    window_name: -2 === r.window_id ? "首页瀑布流" : r.window_name || "",
                    queryId: r.queryId || -1
                }), -2 === r.window_id && (t.source = "recommend_home");
                break;

              case "brand":
                t = {
                    sort: r.sort || r.prIndex,
                    cat_id: r.window_id,
                    sec_cat_id: r.pointSecondWindowId,
                    queryId: r.queryId || -1,
                    source: "recommend_cate",
                    ab: r.ab || {},
                    ad_id: r.adId || "",
                    cat_name: "RECOMMEND" === r._type ? "推荐" : r.window_name
                }, "RECOMMEND" === r._type && (t.source = r.slot || "recommend_sharelink", t.recommend_sid = n), 
                r.adId && -2 !== r.window_id && (t.adzone_id = "ad_001033", t.source = "recommend_cate", 
                t.goods_type = "xsyx");
                break;

              case "boutique":
                t = o(o({}, t), {}, {
                    cat_id: r.windowId,
                    sec_cat_id: r.secondWindowId,
                    source: "boutique"
                });
            }
            t = o({
                slot: r.slot,
                sku_sn: r.skuSn,
                extra_operate: r.tsBuyStart - new Date().getTime() > 0 ? "wantBuy" : ""
            }, t);
            var i = r.productMarkAtmosphere, a = void 0 === i ? {} : i;
            a.productCorsetCornerMark && a.productCorsetCornerMark.productDetailImg && (t.slot = "营销大促", 
            t.active_name = "marketing_promotion");
            var _ = o({}, t.ab || {});
            wx.$.getTestMeta("productAdsText") && r.productTitle ? (_.productAdsText = wx.$.getTestMeta("productAdsText"), 
            t = o(o({}, t), {}, {
                ab: _
            })) : (_.productAdsText = "D", t = o(o({}, t), {}, {
                ab: _
            })), d.frxs.XSMonitor.sendEvent("add_product", t, ""), wx.$.getTestMeta("fuzzy") && d.frxs.XSMonitor.sendTestEvent("add_product", o(o({}, t), {}, {
                slot: "销量模糊-商品卡片加购"
            }), "加车"), d.frxs.XSMonitor.sendTestEvent("add_product", o(o({}, t), {}, {
                slot: "首页改版-商品卡片加购"
            }), "加车");
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("cardAddPoint--\x3eerror", o);
        }
    },
    yphBrandPoint: function(o) {
        try {
            d.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "一品汇入口",
                sku_sn: o.skuSn
            });
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("yphBrandPoint--\x3eerror", o);
        }
    },
    cardBrandPoint: function(o) {
        try {
            var e = {
                window_id: o.window_id,
                gsort: o.gsort,
                rsort: o.rsort,
                window_sort: o.window_sort,
                slot: "商品卡片活动",
                sku_sn: o.skuSn,
                queryId: o.queryId || -1,
                go_window_id: o.windowId,
                window_name: -2 === o.window_id ? "首页瀑布流" : o.window_name || "",
                from: -2 == o.window_id ? "recommend_home" : "",
                ab: o.ab || {},
                ad_id: o.adId || ""
            };
            d.frxs.XSMonitor.sendEvent("slot_click", e, "");
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("cardBrandPoint--\x3eerror", o);
        }
    },
    cardVideoPlayPoint: function(e) {
        try {
            var t = e.product, r = e.liveData, s = {};
            "直播商品卡片" === t.slot && r && (s.live_id = r.tvId, s.hasNewLive = t.hasNewLive), s = o({
                sku_sn: t.skuSn,
                window_id: t.window_id,
                gsort: t.gsort,
                rsort: t.rsort,
                window_sort: t.window_sort
            }, s), d.frxs.XSMonitor.sendEvent("home_video_play", s, "");
        } catch (o) {
            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
            console.log("cardVideoPlayPoint--\x3eerror", o);
        }
    }
};

exports.default = e;