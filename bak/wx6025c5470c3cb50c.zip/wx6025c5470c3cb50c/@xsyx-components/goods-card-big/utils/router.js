var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.toSimilarProductsPage = exports.toHotLinkPage = exports.toDetailPage = exports.onBrandClick = void 0;

var t = require("../../../@babel/runtime/helpers/objectSpread2"), r = e(require("../../../router/index.js")), o = require("../../../const/hot-constants.js"), a = e(require("./pointEvent.js")), i = getApp();

exports.toDetailPage = function(e, o) {
    try {
        var a = "recommend_home";
        "home" === o ? a = -2 == e.window_id ? "recommend_home" : "operation_home" : "boutique" === o ? a = "boutique" : "brand" === o ? a = "RECOMMEND" === e._type ? e.slot || "recommend_sharelink" : "recommend_cate" : "prSearch" === o && (a = "search");
        var d = {
            spuSn: e.spuSn || "",
            skuSn: e.skuSn || "",
            acid: e.acId || "",
            prid: e.prId || "",
            storeId: i.frxs.getMOrSData("storeId"),
            imgUrl: e.imgUrl || e.adUrl,
            prName: e.prName,
            saleAmt: e.saleAmt,
            from: a,
            orderAreaId: e.areaId
        };
        wx.$.getTestMeta("productAdsText") && e.productTitle ? d.ab = wx.$.getTestMeta("productAdsText") : d.ab = "D";
        var s = e.productMarkAtmosphere, n = void 0 === s ? {} : s;
        n.productCorsetCornerMark && n.productCorsetCornerMark.productDetailImg && (d.active_name = "marketing_promotion"), 
        r.default.navigateTo({
            path: i.frxsConfig.mall.page.prDetails,
            query: t({}, d)
        });
    } catch (e) {
        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
        console.log("toDetailpage->error----------\x3e", e);
    }
};

exports.onBrandClick = function(e) {
    var t = e.windowId || 0;
    if (e && "YPH" === e.windowType) return a.default.yphBrandPoint(e), void r.default.navigateTo({
        path: "subProduct/boutique/boutique",
        query: {
            secondWindowId: e.secondWindowId || ""
        }
    });
    if (t > 0) {
        i.globalData["cateProduct-selectWindowId"] = {
            windId: t || 0
        };
        var o = {};
        -2 == t && (o = {
            from: "recommend_home"
        }), r.default.switchTab({
            path: i.frxsConfig.mall.page.cateProduct,
            query: o
        }), a.default.cardBrandPoint(e);
    }
};

exports.toHotLinkPage = function(e, t) {
    try {
        var r = e || {}, a = r.listId, d = r.listType, s = o.RANK_ROUTER_KEY[d] || "subPages/home/brand/hotlist/index", n = {
            listId: a,
            from: t,
            listType: o.CONVERT_HOTLIST_CODE[d] || ""
        };
        i.frxs.XSMonitor.sendEvent("slot_click", {
            slot: "list_link",
            source: t,
            list_id: a,
            list_type: d
        }), i.router.navigateTo({
            path: s,
            query: n
        }), wx.$.getTestMeta("fuzzy") && i.frxs.XSMonitor.sendTestEvent("slot_click", {
            slot: "销量模糊-商品卡片榜单外链"
        }, "点击");
    } catch (e) {
        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
        console.log("goHotList---\x3eerror", e);
    }
};

exports.toSimilarProductsPage = function(e) {
    var t = e || {}, o = t.acId, a = void 0 === o ? "" : o, d = t.prId, s = void 0 === d ? "" : d, n = t.sku, u = void 0 === n ? "" : n, l = t.areaId, c = void 0 === l ? "" : l, p = t.spuSn, m = {
        acId: a,
        prId: s,
        sku: u,
        areaId: c,
        spuSn: void 0 === p ? "" : p,
        storeId: i.frxs.getMOrSData("storeId") || ""
    };
    r.default.navigateTo({
        path: "/subProduct/similarProduct/index",
        query: m
    });
};