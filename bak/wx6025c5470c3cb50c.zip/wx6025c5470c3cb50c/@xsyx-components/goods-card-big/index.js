var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../@babel/runtime/helpers/objectSpread2"), i = (t(require("../../xapp/runtime.js")), 
t(require("../../utils/outBuisness-store-dialog.js"))), n = require("../../utils/product.js"), s = require("../../utils/productLive.js"), c = require("./utils/router.js"), u = t(require("./utils/pointEvent.js")), d = require("../../api/index.js"), p = require("behavior/cardMenu.js"), l = getApp();

Component({
    behaviors: [ p ],
    properties: {
        key: String,
        size: {
            type: String,
            value: "big"
        },
        from: {
            type: String,
            value: "home"
        },
        isExposure: {
            type: Boolean,
            value: !1
        },
        moduleConfig: {
            type: Object,
            value: {}
        },
        fuzzy: Boolean,
        pageGuid: String,
        couponInfo: {
            type: Object,
            value: {},
            observer: function(t) {
                t && this.setSinglePrice(t);
            }
        },
        saleInfo: {
            type: Object,
            value: {},
            observer: function(t) {
                var e = this;
                t && this.setData({
                    marketingDataDto: t
                }, function() {
                    e.setLiveData(), e.setCardStatus(), e.setSalePctText();
                });
            }
        },
        cartCount: {
            type: Number,
            value: 0,
            observer: function() {
                this.setCardStatus(), this.setSalePctText();
            }
        },
        product: {
            type: Object,
            value: {},
            observer: function(t) {
                this.initProduct(t), this.formatFootCouponList(), this.onProductAdsTest();
            }
        },
        currentVideoId: {
            type: String,
            observer: function(t) {
                try {
                    var e = this.data, r = e.key, o = e.product;
                    t !== r && o.videoUrl && this.setData({
                        isPlayVideo: !1
                    });
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.log("observer currentVideoId error", t);
                }
            }
        }
    },
    data: {
        status: "ACTIVE",
        skuSnCouponList: [],
        brandBtnText: "",
        statusText: "",
        salePercent: "",
        salePctText: "",
        singlePrice: "",
        utvList: [],
        videoUrl: "",
        couponFootMark: null,
        isPlayVideo: !1,
        liveData: null,
        hotListDesc: "",
        marketingTagImage: "",
        nearBy: "",
        consumers: [],
        showCouponPopup: !1,
        martketActivityCoupons: [],
        productCorsetCornerMark: {},
        productNameCornerMark: [],
        hadRecievedCoupon: !1,
        adsTextTest: "D"
    },
    ready: function() {
        this.data.isExposure && this.exposure();
    },
    detached: function() {
        try {
            this.data.isExposure && this.productObserve.disconnect(), this.videoObserve && this.videoObserve.disconnect(), 
            void 0 !== this.timer && clearTimeout(this.timer);
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            console.log(t);
        }
    },
    methods: {
        initProduct: function(t) {
            var e = this, r = t || {}, o = r.skuSnCouponList, a = r.marketingDataDto, i = void 0 === a ? {} : a, n = r.windowName, s = r.utvList, c = r.videoUrl, u = void 0 === c ? "" : c, d = r.productMarkAtmosphere, p = void 0 === d ? {} : d;
            o && o.length && (this.formateRecieveStatus(), this.formatCouponTag(o));
            var l = p.martketActivityCoupons, h = p.productCorsetCornerMark, v = p.productNameCornerMark;
            this.setData({
                videoUrl: u,
                marketingDataDto: i,
                brandBtnText: n ? "进入" + n : "",
                utvList: s || [],
                hotListDesc: i.hotListDesc || "",
                marketingTagImage: i.marketingTagImage || "",
                nearBy: i.nearBy || "",
                consumers: i.consumers || [],
                martketActivityCoupons: l,
                productCorsetCornerMark: h,
                productNameCornerMark: v
            }, function() {
                e.setLiveData(), e.setCardStatus(), e.setSalePctText();
            });
        },
        exposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport({
                    top: 500
                }), r = this.data, o = r.key, a = r.from;
                this.productObserve = e, e.observe("#product_key_".concat(o), function(e) {
                    e.intersectionRatio > 0 && (t.changeComponentStatus(), "prSearch" !== a && u.default.cardExposurePoint(t.data), 
                    t.triggerEvent("cart-exposure", {
                        index: t.data.key
                    }));
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("exposure--\x3eerror", t);
            }
        },
        changeComponentStatus: function() {
            var t = this;
            try {
                void 0 !== this.timer && clearTimeout(this.timer), this.timer = setTimeout(function() {
                    t.setLiveData(), t.setCardStatus(), t.setSalePctText();
                }, 1e4);
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("changeComponentStatus--\x3eerror", t);
            }
        },
        videoExposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport({
                    top: 800,
                    bottom: 800
                });
                this.videoObserve = e, e.observe("#videoProduct", function(e) {
                    if (e.intersectionRatio < 1) {
                        var r = wx.createVideoContext("videoProduct", t);
                        r.pause && r.pause();
                    }
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("videoExposure--\x3eerror", t);
            }
        },
        setCardStatus: function() {
            try {
                var t = this.data, e = t.product, r = t.marketingDataDto, o = t.cartCount, a = (0, 
                n.getProductStatus)(e, r, o), i = new Date(e.tmBuyStart).getMinutes(), s = l.frxs.formaterDate(e.tmBuyStart, i > 0 ? "M月d日H点m分" : "M月d日H点") + "开抢";
                this.setData({
                    status: a,
                    statusText: s.replace(" ", "")
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("setCardStatus--\x3eerror", t);
            }
        },
        setSinglePrice: function(t) {
            var e = t || {}, r = e.amount, o = e.orderAmountLimit;
            this.data.product.saleAmt >= o && r > 0 && this.setData({
                singlePrice: String(r)
            });
        },
        setLiveData: function() {
            var t = this.data.product;
            t.tvLiveDto && this.setData({
                liveData: (0, s.getLiveInfo)(t.tvLiveDto)
            });
        },
        onPlayerClick: function() {
            (0, s.isToLive)(this.data.product.tvLiveDto, "");
        },
        setSalePctText: function() {
            if (this.data.fuzzy) {
                var t = (0, n.getSalePctText)(this.data.marketingDataDto) || {}, e = t.salePercent, r = t.salePctText;
                this.setData({
                    salePercent: e,
                    salePctText: r
                });
            }
        },
        formatCouponTag: function(t) {
            var e = t.map(function(t) {
                var e = t.toolName;
                if ("DISCOUNT" === t.toolType) e += "满".concat(t.orderAmountLimit, "元 | ").concat(1 * (t.discount / 10).toFixed(2), "折 | 最高优惠").concat(t.amount, "元"); else if (t.orderStep) {
                    e = e + " | " + t.orderStep.map(function(t) {
                        return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                    }).join(" | ");
                } else e += "满".concat(t.orderAmountLimit, "减").concat(t.amount);
                return e;
            });
            this.setData({
                skuSnCouponList: e
            });
        },
        formatFootCouponList: function() {
            var t = this.data.product;
            if ("SHOW" == t.cornCouponType) {
                var e = (t.skuSnCouponList || []).length, r = t.productMarkInfo, o = void 0 === r ? {} : r;
                if (e > 0) {
                    var i = t.skuSnCouponList[e - 1], n = "";
                    if ("DISCOUNT" === i.toolType) n = "满".concat(i.orderAmountLimit, "元 | ").concat(1 * (i.discount / 10).toFixed(2), "折 | 最高优惠").concat(i.amount, "元"); else if (i.orderStep) {
                        n = i.orderStep.map(function(t) {
                            return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                        }).join(" | ");
                    } else n = "满".concat(i.orderAmountLimit, "减").concat(i.amount);
                    var s = a({
                        title: i.toolName,
                        couponMsg: n
                    }, o);
                    this.setData({
                        couponFootMark: s
                    });
                } else this.setData({
                    couponFootMark: o
                });
            }
        },
        onCoverClick: function() {
            var t = this.data, e = t.liveData, r = t.product, o = t.from;
            "prSearch" !== o && u.default.cardClickPoint(this.data, o), this.triggerEvent("tapCard", {
                product: r,
                from: o
            }), e && e.status ? this.onPlayerClick() : (0, c.toDetailPage)(r, o);
        },
        onToDetailPage: function() {
            var t = this.data, e = t.product, r = t.from;
            "prSearch" !== r && u.default.cardClickPoint(this.data), (0, c.toDetailPage)(e, r), 
            this.triggerEvent("tapCard", {
                product: e,
                from: r
            });
        },
        onAdd: function() {
            var t = this.data, e = t.product, r = t.status, a = t.marketingDataDto, i = t.cartCount, n = t.from, s = Object.assign(e, a);
            this.triggerEvent("cart-add", {
                product: s,
                status: r
            }), "prSearch" !== n && u.default.cardAddPoint(this.data), i < 1 && this.setData(o({}, "marketingDataDto.wantBuyQty", Number(a.wantBuyQty) + 1));
        },
        onReduce: function() {
            this.triggerEvent("cart-reduce", {
                product: this.data.product
            });
        },
        onBrandClick: function() {
            (0, c.onBrandClick)(this.data.product), this.triggerEvent("tapCard", {
                product: this.data.product
            });
        },
        hotLinkClick: function() {
            "prSearch" !== this.data.from ? ((0, c.toHotLinkPage)(this.data.product.marketingDataDto, "index"), 
            this.triggerEvent("tapCard", {
                product: this.data.product
            })) : this.triggerEvent("goHotList", {
                product: this.data.product
            });
        },
        onSimilarProducts: function() {
            (0, c.toSimilarProductsPage)(this.data.product);
        },
        todoRecive: function() {
            this.triggerEvent("cart-recive", {
                product: this.data.product
            });
        },
        formateRecieveStatus: function() {
            var t = l.frxs.getStorageSync("receiveCenterStatus") || 0;
            if (t) {
                var e = new Date(t).toLocaleDateString();
                new Date().getTime() > new Date("".concat(e, " ").concat("23:00")).getTime() ? (l.frxs.removeStorageSync("receiveCenterStatus"), 
                this.setData({
                    hadRecievedCoupon: !1
                })) : this.setData({
                    hadRecievedCoupon: !0
                });
            }
        },
        todoFirstRecive: function() {
            var t = this;
            return r(e.default.mark(function r() {
                var o;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, o = l.frxs.isLogin()) {
                            e.next = 4;
                            break;
                        }
                        return e.abrupt("return", l.frxs.toLogin());

                      case 4:
                        return e.next = 6, d.couponApi.receiveTicketAll({
                            storeId: l.frxs.getMOrSData("storeId"),
                            userKey: o,
                            primaryChannel: "XSYX",
                            secondaryChannels: [ "HOME" ],
                            blackBox: l.frxs.storage("safe_bb") || ""
                        }, {
                            contentType: "application/json",
                            silence: !0
                        });

                      case 6:
                        l.frxs.showToast({
                            title: "领券成功"
                        }), l.frxs.setStorageSync("receiveCenterStatus", new Date().getTime()), t.setData({
                            hadRecievedCoupon: !0
                        }), e.next = 13;
                        break;

                      case 11:
                        e.prev = 11, e.t0 = e.catch(0);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, r, null, [ [ 0, 11 ] ]);
            }))();
        },
        onOnlineReminder: function() {
            if (!i.default.showoutBuisnessDialog()) {
                var t = a(a({}, this.data.product), {}, {
                    activityId: this.data.product.acId,
                    presaleActivityId: this.data.product.acId,
                    productId: this.data.product.prId
                });
                this.triggerEvent("online-reminder", t);
            }
        },
        onPlayVideo: function() {
            var t = this;
            this.setData({
                isPlayVideo: !0
            }, function() {
                t.videoExposure();
            });
        },
        bindplay: function() {
            u.default.cardVideoPlayPoint(this.data), this.triggerEvent("bind-play", this.data.key);
        },
        bindVideoended: function() {
            this.setData({
                isPlayVideo: !1
            });
        },
        onShowCoupon: function(t) {
            this.triggerEvent("showCouponPopup", t.detail);
        },
        onProductAdsTest: function() {
            var t = wx.$.getTestMeta("productAdsText") || "D";
            this.setData({
                adsTextTest: t
            });
        }
    }
});