var e, t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index.js")), o = getApp(), n = !1;

module.exports = Behavior({
    properties: {},
    data: {
        currentFoodMenuIndex: 0,
        showFoodMeunGuide: !1
    },
    methods: {
        onClickShopMenuTab: function(e) {
            this.setData({
                currentFoodMenuIndex: e.target.dataset.index || 0,
                showFoodMeunGuide: !1
            });
            try {
                if (e.target.dataset.index > 0) {
                    var t = this.properties.product, n = void 0 === t ? {} : t;
                    o.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "菜谱入口",
                        sku: n.sku,
                        sku_sn: n.skuSn
                    }, "");
                }
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log("onClickShopMenuTab--\x3eerror", e);
            }
        },
        onChangeSwiper: function(t) {
            this.setData({
                currentFoodMenuIndex: t.detail.current || 0
            }), clearTimeout(e);
            try {
                if (t.detail.current > 0) {
                    var n = this.properties.productInfo, r = void 0 === n ? {} : n, u = this.data.utvList[t.detail.current - 1];
                    o.frxs.XSMonitor.sendEvent("slot_show", {
                        slot: "菜谱视频",
                        sku: r.sku,
                        sku_sn: r.skuSn,
                        videoId: u.utvId,
                        sort: t.detail.current - 1
                    }, "");
                }
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log("onChangeSwiper--\x3eerror", e);
            }
        },
        setShowFoodMeunGuide: function() {
            var t = this;
            !n && this.data.utvList.length && (e = setTimeout(function() {
                var e = o.frxs.getMOrSData("foodMenuGuideCount") || 0;
                e < 5 && (t.setData({
                    showFoodMeunGuide: !0
                }, function() {
                    n = !0;
                }), o.frxs.setMAndSData("foodMenuGuideCount", e + 1));
            }, 2500));
        },
        onCloseFoodMeunGuide: function() {
            this.setData({
                showFoodMeunGuide: !1
            });
        },
        onClickFoodMenuCover: function(e) {
            var n = e.currentTarget.dataset.utvid;
            if (n) {
                t.default.navigateTo({
                    path: "/subLive/menuVideo/index",
                    query: {
                        utvId: n,
                        spuSn: this.properties.product.spuSn,
                        from: "menu"
                    }
                });
                try {
                    var r = this.properties.product, u = void 0 === r ? {} : r;
                    o.frxs.XSMonitor.sendEvent("video_play", {
                        slot: "菜谱入口",
                        sku: u.sku,
                        sku_sn: u.skuSn,
                        sort: this.data.currentFoodMenuIndex - 1,
                        videoId: n,
                        from: "menu",
                        video_type: "menu"
                    }, "");
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.log("onClickFoodMenuCover--\x3eerror", e);
                }
            }
        }
    }
});