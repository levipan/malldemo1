var e = require("../../@babel/runtime/helpers/interopRequireWildcard"), t = require("../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../@babel/runtime/helpers/objectSpread2"), a = t(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../@babel/runtime/helpers/toConsumableArray"), o = require("../../api/index.js"), i = e(require("../../utils/events")), u = t(require("../../utils/sample-store-dialog")), c = t(require("../../router/index")), d = require("../../api/formatData/product"), p = (t(require("../../xapp/runtime")), 
t(require("../../plugins/store/singleCoupon.js"))), l = require("../../const/storage.key"), h = require("../../const/hot-constants"), g = require("../../utils/product.js"), m = require("../../utils/cartService.js"), S = (0, 
p.default)();

S = wx.$initStore((0, p.default)());

var f = getApp();

Component({
    properties: {
        spuSn: {
            type: Array,
            value: []
        },
        require: {
            type: Boolean,
            value: !1
        },
        requestIsV2: {
            type: Boolean,
            value: !1
        },
        yuanbenIType: String,
        hasProducts: {
            type: Boolean,
            value: !1
        },
        orderType: {
            type: String,
            value: ""
        },
        zIndex: {
            type: String,
            value: "1000"
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        },
        cartNumberMap: {
            type: Object
        },
        iconStyle: {
            type: String,
            value: "medal",
            desc: "热销icon风格，medal:奖章 crown:王冠"
        },
        fuzzy: {
            type: Boolean,
            value: !1
        }
    },
    link: [ "singleCoupon" ],
    data: {
        windowWidth: wx.getSystemInfoSync().windowWidth,
        productList: [],
        currRecommendIndex: -1,
        isAll: !1,
        isOpen: !1,
        isSearchRecommend: !1,
        isSearchEmpty: !0,
        globalFlag: {
            tempFlag: "new",
            queryFlag: "new"
        },
        _cartNumberMaps: {}
    },
    attached: function() {
        this.data.requestIsV2 && S.getSingleCouponList();
        var e = this.getContext();
        console.log(1234, e), "subPages/home/brand/search/search" === e.route && this.setData({
            isSearchRecommend: !0
        }), this.isFirstRefresh = !0, this.paramSpuSn = [], this.currParamSpuSn = [], this.isLock = !1, 
        this.isEmpty = !1, this.ajaxTime = 0, this.pageNum = 1, this.productObserve = [];
        var t = f.frxs.storage("".concat(this.getContext().route, "-recommend"));
        t || (t = -1), this.setData({
            currRecommendIndex: 1 * t
        }), this.getCount(), this.triggerEvent("attached");
    },
    detached: function() {
        try {
            this.productObserve.forEach(function(e) {
                e.disconnect();
            }), this.productObserve = [];
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.log(e);
        }
    },
    methods: {
        onExposureCard: function(e) {
            if (~[ "detailRecommend", "ofenbuyRecommend" ].indexOf(this.data.yuanbenIType)) try {
                var t = this.getContext(), r = {};
                "prDetail" === t.data.pageType && (r = {}), "ofenBuyList" === t.data.pageType && (r = t.data.ab), 
                f.frxs.XSMonitor.sendEvent("slot_show", {
                    slot: "recommend_guesslike",
                    sku_sn: e.detail.product.eskuSn,
                    sort: e.currentTarget.dataset.index,
                    goods_type: "clothes_yb",
                    spu_sn: e.detail.product.spuSn,
                    ad_id: e.detail.product.adId || "",
                    ab: r
                }, "");
            } catch (e) {}
        },
        onClickCard: function(e) {
            try {
                var t = this.getContext(), r = {};
                "prDetail" === t.data.pageType && (r = {}), "ofenBuyList" === t.data.pageType && (r = t.data.ab), 
                f.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "recommend_guesslike",
                    sku_sn: e.detail.product.eskuSn,
                    sort: e.currentTarget.dataset.index,
                    goods_type: "clothes_yb",
                    spu_sn: e.detail.product.spuSn,
                    ad_id: e.detail.product.adId || "",
                    ab: r
                }, "");
                var a = {
                    spuSn: e.detail.product.spuSn,
                    eskuSn: e.detail.product.eskuSn,
                    from: "recommend_guesslike"
                };
                f.frxs.setMData("inner", {
                    i: "1",
                    i_type: "ad_001024"
                }), wx.$route.navigateTo({
                    name: "home-goods-detail",
                    query: a
                });
            } catch (e) {}
        },
        exposure: function(e, t) {
            var r = this;
            try {
                if (this.productObserve[t]) return;
                var a = this.createIntersectionObserver().relativeToViewport();
                this.productObserve[t] = a, a.observe("#recommend-item-".concat(t), function(a) {
                    if (a.intersectionRatio > 0) {
                        r.triggerEvent("exposure");
                        var n = {
                            slot: "recommend_guesslike",
                            sku_sn: e.skuSn,
                            sort: t,
                            ad_id: e.adId || "",
                            ab: {
                                recommend_guesslike: "new" === r.data.globalFlag.tempFlag ? "A" : "B"
                            },
                            from: "recommend_guesslike"
                        };
                        if (r.data.isSearchRecommend) {
                            var s = r.getContext();
                            n.slot = "为您推荐", n.search_sid = s.search_sid, n.search_key_sid = s.search_key_sid_after, 
                            n.keyword = s.placeHoldVal, n.last_keyword = s.getListKeyWord(), n.ab = s.searchProductType || s.grayType || {};
                        }
                        "PAYMENT_SUCCESS" !== r.position && "ORDER_DETAILS" !== r.position || "PHONE" !== r.data.orderType || (console.log("支付成功页、订单详情 话费充值曝光埋点"), 
                        n.page_type = "pay_phonebill");
                        var o = r.getContext();
                        "STORE" === e.type && "prDetail" === o.data.pageType && (delete n.from, n.goods_type = "xsyx", 
                        n.spu_sn = e.spuSn, n.ad_id = e.adId || "", n.ab = {}), "STORE" === e.type && "ofenBuyList" === o.data.pageType && (delete n.from, 
                        n.goods_type = "xsyx", n.spu_sn = e.spuSn, n.ad_id = e.adId || "", n.ab = o.data.ab), 
                        f.frxs.XSMonitor.sendEvent("slot_show", n, "");
                        var i = r.getContext();
                        if ("subProduct/detail/index" === i.route || "pages/home/productDetail/productDetail" === i.route || "subPages/home/brand/search/search" === i.route) return;
                        r.onFilterRecommendItem(e.spuSn);
                    }
                });
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log(e);
            }
        },
        onFilterRecommendItem: function(e) {
            var t = f.frxs.getStorageSync("cart-reco-uniqlo") || [];
            t.push(e), this.uniqloList = s(new Set(t)), f.frxs.setStorageSync("cart-reco-uniqlo", this.uniqloList);
        },
        onClickRecommendBtn: function() {
            var e = this.data.isOpen;
            this.setData({
                isOpen: !e
            });
        },
        onClickSelectItem: function(e) {
            var t = 1 * e.currentTarget.dataset.time, r = 24 * t * 60 * 60;
            -1 === t ? (f.frxs.storage("".concat(this.getContext().route, "-recommend"), t), 
            this.clear().getList()) : f.frxs.storage("".concat(this.getContext().route, "-recommend"), t, r), 
            this.setData({
                currRecommendIndex: t,
                isOpen: !1
            }), f.frxs.XSMonitor.sendEvent("slot_click", {
                slot: e.currentTarget.dataset.slot
            }, "");
        },
        checkTempStore: function() {
            return 1 * f.frxs.getMOrSData("storeId") == 1 * f.frxsConfig.tempStoreId;
        },
        now: function() {
            return +new Date() + (this.timeOffset || f.frxs.getMOrSData("timeDiffServerAndClient") || 0);
        },
        addCart: function(e) {
            if (this.checkTempStore()) return u.default.showSampleDialog(), !1;
            var t = this.getContext(), r = e.detail.product, a = e.currentTarget.dataset.index;
            r.prName = r.productName || r.prName;
            var n = m.addCart(r, 1, t), s = {
                sku_sn: r.skuSn,
                sort: a,
                extra_operate: r.tsBuyStart < this.now() ? "" : "wantBuy",
                source: "recommend_guesslike",
                ad_id: r.adId || "",
                ab: {
                    recommend_guesslike: "new" === this.data.globalFlag.tempFlag ? "A" : "B"
                }
            };
            if (this.data.isSearchRecommend) {
                var o = this.getContext();
                s.source = "search_recommend", s.search_sid = o.search_sid, s.search_key_sid = o.search_key_sid_after, 
                s.keyword = o.placeHoldVal, s.sort = e.currentTarget.dataset.index, s.last_keyword = o.getListKeyWord(), 
                s.ab = o.searchProductType || o.grayType || {};
            }
            if ("PAYMENT_SUCCESS" !== this.position && "ORDER_DETAILS" !== this.position || "PHONE" !== this.data.orderType || (s.page_type = "pay_phonebill"), 
            e.rankBanner || f.frxs.XSMonitor.sendEvent("add_product", s, ""), "success" === n.rspCode) {
                if ("pages/home/productDetail/productDetail" === t.route || "subProduct/detail/index" === t.route) {
                    var c = m.getCartNum();
                    t.setData({
                        cartNum: c
                    });
                }
                i.default.emit(i.EVENTS.REFRESH_CART, null), r.cartQuantity = n.cartQuantity;
                var d = f.frxs.getMOrSData("storeInfo") || {}, p = [ {
                    skuSn: r.skuSn,
                    eskuSn: r.eskuSn,
                    areaId: this.areaId || d.areaId,
                    qty: n.cartQuantity,
                    optype: r.optype || "manual"
                } ];
                this.triggerEvent("product-recommend-add-cart", {
                    cartSkus: p,
                    cartQuantity: n.cartQuantity,
                    product: r
                }), wx.vibrateShort(), this.getCount();
            } else {
                if ("max" === n.rspCode) return f.frxs.alert({
                    content: n.info
                });
                f.frxs.toptip({
                    title: n.info
                });
            }
        },
        onAddMax: function() {
            console.log(22222, "22222222");
        },
        onReduce: function(e) {
            if (this.checkTempStore()) return u.default.showSampleDialog(), !1;
            var t = this.getContext(), r = e.detail.product;
            r.prName = r.productName || r.prName;
            var a = m.reduceCart(r, 1, t);
            if ("success" === a.rspCode) {
                if ("pages/home/productDetail/productDetail" === t.route || "subProduct/detail/index" === t.route) {
                    var n = m.getCartNum();
                    t.setData({
                        cartNum: n
                    });
                }
                i.default.emit(i.EVENTS.REFRESH_CART, null);
                var s = f.frxs.getMOrSData("storeInfo") || {}, o = [ {
                    skuSn: r.skuSn,
                    eskuSn: r.eskuSn,
                    areaId: this.areaId || s.areaId,
                    qty: a.cartQuantity,
                    optype: r.optype || "manual"
                } ];
                this.triggerEvent("product-recommend-reduce-cart", {
                    cartSkus: o,
                    cartQuantity: a.cartQuantity,
                    product: r
                }), this.getCount();
            } else {
                if ("max" === a.rspCode) return f.frxs.alert({
                    content: a.info
                });
                f.frxs.toptip({
                    title: a.info
                });
            }
        },
        getContext: function() {
            var e = getCurrentPages();
            return e[e.length - 1];
        },
        getPosition: function() {
            try {
                return {
                    "pages/home/productDetail/productDetail": function() {
                        return "PRODUCT_DETAILS";
                    },
                    "subProduct/detail/index": function() {
                        return "PRODUCT_DETAILS";
                    },
                    "subDetail/index": function() {
                        return "PRODUCT_DETAILS";
                    },
                    "pages/home/cart/cart": function() {
                        return "SHOPPING_CART";
                    },
                    "subMain/main/index": function() {
                        return "SHOPPING_CART";
                    },
                    "pages/order/paySuccess/paySuccess": function() {
                        return "PAYMENT_SUCCESS";
                    },
                    "subPages/home/brand/search/search": function() {
                        return "SEARCH_RESULT";
                    },
                    "pages/brand/search/search": function() {
                        return "SEARCH_RESULT";
                    },
                    "pages/users/orderDetail/orderDetail": function() {
                        return "ORDER_DETAILS";
                    },
                    "subPages/users/orderDetail/orderDetail": function() {
                        return "ORDER_DETAILS";
                    },
                    "subPages/users/cancelOrder/result/index": function() {
                        return "ORDER_DETAILS";
                    },
                    "pages/users/shareOrder/shareOrder": function() {
                        return "ORDER_SHARE";
                    },
                    "subPages/users/shareOrder/shareOrder": function() {
                        return "ORDER_SHARE";
                    },
                    "subPages/users/ofenBuy/index": function() {
                        return "GUESS_YOU_FAVORITE_PRODUCT";
                    },
                    "subPages/users/storeLogistics/index": function() {
                        return "ORDER_DETAILS";
                    },
                    "subProduct/group-detail/index": function() {
                        return "PRODUCT_DETAILS";
                    }
                }[this.getContext().route]();
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                return console.log("商品推荐没有匹配到页面", e), "PAYMENT_SUCCESS";
            }
        },
        getParams: function() {
            if (this.data.require && 0 === this.data.spuSn.length) return !1;
            var e = f.frxs.getMOrSData("areaId"), t = f.frxs.getMOrSData("storeId");
            if (!e || !t) return !1;
            this.position = this.getPosition();
            var r = {
                areaId: e,
                storeId: t,
                isFirstRefresh: this.isFirstRefresh ? "true" : "false",
                position: this.position
            };
            if (this.isFirstRefresh) r.currentSpuSns = s(this.data.spuSn.map(function(e) {
                return "spuSnIsNull" === e ? "" : e;
            })); else {
                if (0 === this.currParamSpuSn.length && this.paramSpuSn && (this.currParamSpuSn = this.paramSpuSn.splice(0, 10)), 
                0 === this.currParamSpuSn.length) return !this.data.isAll && this.setData({
                    isAll: !0
                }), !1;
                this.isEmpty = !1, r.spuSns = s(this.currParamSpuSn);
            }
            return r;
        },
        clear: function() {
            return this.productObserve = [], this.isFirstRefresh = !0, this.paramSpuSn = [], 
            this.currParamSpuSn = [], this.isLock = !1, this.isEmpty = !1, this.ajaxTime = 0, 
            this.isCleared = !0, this.setData({
                productList: [],
                isAll: !1
            }), this;
        },
        onOpenPage: function(e) {
            var t = e.detail.product, r = e.currentTarget.dataset.index, a = {
                spuSn: t.spuSn,
                from: "recommend_guesslike"
            }, n = {
                slot: "recommend_guesslike",
                sku_sn: t.skuSn,
                sort: r,
                ad_id: t.adId || "",
                ab: {
                    recommend_guesslike: "new" === this.data.globalFlag.tempFlag ? "A" : "B"
                },
                from: "recommend_guesslike"
            };
            if (this.data.isSearchRecommend) {
                a.from = "search_recommend";
                var s = this.getContext();
                n.slot = "为您推荐", n.search_sid = s.search_sid, n.search_key_sid = s.search_key_sid_after, 
                n.keyword = s.placeHoldVal, n.last_keyword = s.getListKeyWord(), n.ab = s.searchProductType || s.grayType || {};
            }
            "PAYMENT_SUCCESS" !== this.position && "ORDER_DETAILS" !== this.position || "PHONE" !== this.data.orderType || (n.page_type = "pay_phonebill");
            var o = this.getContext();
            "STORE" === t.type && "prDetail" === o.data.pageType && (delete n.from, n.goods_type = "xsyx", 
            n.spu_sn = t.spuSn, n.ad_id = t.adId || "", n.ab = {}), "STORE" === t.type && "ofenBuyList" === o.data.pageType && (delete n.from, 
            n.goods_type = "xsyx", n.spu_sn = t.spuSn, n.ad_id = t.adId || "", n.ab = o.data.ab), 
            c.default.navigateTo({
                path: "/subProduct/detail/index",
                isRedirect: "PRODUCT_DETAILS" === this.position,
                query: a
            }), f.frxs.XSMonitor.sendEvent("slot_click", n, "");
        },
        getNewProducts: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, i, u, c, p, l;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return void 0 === e.data.windowIndex && (e.data.windowIndex = 0), e.isLock = !0, 
                        r = e.getParams(), n = e.position, "ofenBuyList" === e.getContext().data.pageType && (n = "GUESS_YOU_FAVORITE_PRODUCT_LAND_PAGE"), 
                        i = f.frxs.getMOrSData("storeInfo") || {}, t.prev = 7, u = r.currentSpuSns, "SHOPPING_CART" === n && (u = m.getCartList().map(function(e) {
                            return e.spuSn;
                        })), c = [ "getBIRecommendProducts", "getBIRecommendProductsV2" ], t.next = 13, 
                        o.tkPromotionApi[c[+e.data.requestIsV2]]({
                            areaId: f.frxs.getMOrSData("areaId"),
                            storeId: f.frxs.getMOrSData("storeId"),
                            position: n,
                            currentSpuSns: u,
                            guId: f.frxs.getMOrSData("_xsm_g") || "",
                            pageNum: e.pageNum,
                            provinceCode: i.provinceId,
                            cityCode: i.cityId,
                            areaCode: i.countyId,
                            channelUse: "WXAPP",
                            userScopeTypes: [ f.frxs.getMData("isNewUser") ? "NEW_USER" : "NORMAL" ],
                            userKey: f.frxs.getMOrSData("userKey"),
                            requireCoupon: !0,
                            version: "SHOPPING_CART" === n ? "V2" : ""
                        }, {
                            contentType: "application/json",
                            silence: !0
                        });

                      case 13:
                        (p = t.sent) && p.ab && (e.data.ab = p.ab), p && p.businessData && p.businessData.length > 0 && (e.isLock = !1, 
                        e.pageNum++, l = (0, d.formatProductsData)(p.businessData, !0).map(function(t) {
                            if (t.now = Date.now(), wx.$.isArray(t.skuSnCouponList)) {
                                var r = t.skuSnCouponList.map(function(e) {
                                    var t = e.toolName;
                                    if ("DISCOUNT" === e.toolType) t += "满".concat(e.orderAmountLimit, "元 | ").concat(1 * (e.discount / 10).toFixed(2), "折 | 最高优惠").concat(e.amount, "元"); else if (e.orderStep) {
                                        t = t + " | " + e.orderStep.map(function(e) {
                                            return "满".concat(e.useOrderAmountLimit, "减").concat(e.singleToolAmount, "元");
                                        }).join(" | ");
                                    } else t += "满".concat(e.orderAmountLimit, "减").concat(e.amount);
                                    return t;
                                });
                                t.oldSkuSnCouponList = s(t.skuSnCouponList), t.skuSnCouponList = r;
                            }
                            return t.listType && t.list && (t.windowIndex = e.data.windowIndex++, t.list.forEach(function(e) {
                                e.status = "WAITING" === (0, g.getProductStatus)(e) ? "preSale" : "normal";
                            })), t;
                        }), e.setData({
                            productList: e.data.productList.concat(l)
                        }, function() {
                            e.data.productList.forEach(function(t, r) {
                                e.exposure(t, r);
                            });
                        })), t.next = 22;
                        break;

                      case 18:
                        t.prev = 18, t.t0 = t.catch(7), e.isLock = !1, console.log(t.t0);

                      case 22:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 7, 18 ] ]);
            }))();
        },
        createHotSid: function() {
            this.hot_sales_sid = f.frxs.newGuid();
        },
        goHotList: function(e) {
            this.createHotSid(), console.log(e, 9999);
            try {
                f.router.navigateTo({
                    path: h.RANK_ROUTER_KEY[e.detail.product.listType] || "subPages/home/brand/hotlist/index",
                    query: {
                        listId: e.detail.product.listId,
                        listType: e.detail.product.listType
                    }
                });
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log(e);
            }
        },
        getListKeyWord: function() {
            var e = f.frxs.getStorageSync(l.STORAGE_KEY.SEARCH_HISTORY_KEY_DESC) || [];
            return e.length > 0 ? e[0] : "";
        },
        getList: function() {
            var e = this;
            return n(a.default.mark(function t() {
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!(e.isLock || e.isEmpty || e.data.isAll)) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        e.getNewProducts();

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        getSearchRecommendProductDetails: function() {
            var e = this;
            if (this.searchParamSpuSn && !this.searchParamSpuSn.length && this.triggerEvent("recommendFinished"), 
            this.searchParamSpuSn && this.searchParamSpuSn.length) {
                var t = {};
                t.storeId = f.frxs.getMOrSData("storeId"), t.areaId = f.frxs.getMOrSData("areaId"), 
                t.spuSns = this.searchParamSpuSn.splice(0, 10), this.setData({
                    isAll: !this.searchParamSpuSn.length
                }), o.brandHousePromotionApi.searchQueryRecommendProducts(t, {
                    contentType: "application/json"
                }).then(function(t) {
                    e.isLock = !1;
                    var r = JSON.parse(JSON.stringify(e.data.productList));
                    t.productList.forEach(function(e) {
                        r.every(function(t) {
                            return t.spuSn !== e.spuSn;
                        }) && r.push(e);
                    }), e.setData({
                        productList: r
                    }, function() {
                        e.data.productList.forEach(function(t, r) {
                            e.exposure(t, r);
                        });
                    });
                }).catch(function(t) {
                    e.isLock = !1, console.log(t);
                });
            }
        },
        getProducts: function() {
            var e = this, t = this.getParams();
            t && (this.ajaxTime = +new Date(), console.log("getProducts——当前paramSpuSns", this.paramSpuSn), 
            o.brandHousePromotionApi.queryRecommendProducts(t, {
                _time: this.ajaxTime,
                contentType: "application/json"
            }).then(function(r) {
                e.isLock = !1, o.brandHousePromotionApi.time === e.ajaxTime && (e.currParamSpuSn = [], 
                "true" === t.isFirstRefresh && (console.log("isSecond", e.isSecond), !e.isSecond && (e.paramSpuSn = r.spuSns), 
                e.isFirstRefresh = !1), e.data.isAll && e.setData({
                    isAll: !1
                }), t.hasOwnProperty("spuSns") && t.spuSns.length < 10 && (e.isEmpty = !0, e.setData({
                    isAll: !0
                }), console.log("params有spuSns属性&& params.spuSns.length < 10时，isAll为", e.data.isAll)), 
                e.setData({
                    productList: [].concat(s(e.data.productList), s((0, d.formatProductsData)(r.productList, !0)))
                }, function() {
                    e.data.productList.forEach(function(t, r) {
                        e.exposure(t, r);
                    });
                }));
            }).catch(function(t) {
                e.isLock = !1, console.log(t);
            }));
        },
        operateSpuList: function(e) {
            var t = e, r = this.getContext();
            if ("subProduct/detail/index" === r.route || "pages/home/productDetail/productDetail" === r.route || "subPages/home/brand/search/search" === r.route) return s(t);
            var a = f.frxs.getStorageSync("cart-reco-uniqlo"), n = t.length - 2;
            return 0 == a.length || a.length >= n ? (f.frxs.removeStorageSync("cart-reco-uniqlo"), 
            t) : (a.forEach(function(e) {
                t = t.reduce(function(t, r) {
                    return r !== e ? [].concat(s(t), [ r ]) : t;
                }, []);
            }), [].concat(s(t), s(a)));
        },
        getCurrentStorage: function() {},
        getCount: function() {
            var e = this;
            this.cartNumberMap = {}, m.getCartList().map(function(t) {
                e.cartNumberMap[t.skuSn] = t.cartQuantity;
            });
            var t = (this.data.productList || []).map(function(t) {
                return r(r({}, t), {}, {
                    cartCount: e.cartNumberMap[t.skuSn]
                });
            });
            this.setData({
                productList: t,
                _cartNumberMaps: JSON.parse(JSON.stringify(this.cartNumberMap))
            });
        },
        recieveCouponClick: function(e) {
            this.triggerEvent("recieveCouponClick", e.detail);
        },
        rankBanner_addCart: function(e) {
            try {
                this.triggerEvent("rankBannerAddCartProduct", {
                    rankinfo: e.currentTarget.dataset.rankinfo,
                    rindex: e.detail.index,
                    gindex: e.currentTarget.dataset.index,
                    product: e.detail.product,
                    ab: this.data.ab
                });
            } catch (e) {}
            e.rankBanner = !0, this.addCart(e);
        },
        rankBanner_reduceCart: function(e) {
            this.onReduce(e);
        },
        rankBanner_onRankProduct: function(e) {
            this.triggerEvent("rankBannerClickProduct", {
                rankinfo: e.currentTarget.dataset.rankinfo,
                rindex: e.detail.index,
                gindex: e.currentTarget.dataset.index,
                product: e.detail.product,
                ab: this.data.ab
            }), this.rankBanner_onRankMore(e, !0);
        },
        rankBanner_onRankMore: function(e, t) {
            try {
                var r = ~[ "StoreEveningMarket", "StoreMorningMarket", "StoreSceneRecommend" ].indexOf(e.currentTarget.dataset.rankinfo.listType) ? "window_card" : "recommend_home_list";
                !t && this.triggerEvent("rankBannerClickMore", {
                    rankinfo: e.currentTarget.dataset.rankinfo,
                    gindex: e.currentTarget.dataset.index,
                    ab: this.data.ab,
                    from: r
                });
                var a = e.target.dataset.rankinfo;
                a.list && a.list.length && f.frxs.setMAndSData("dayNightCurrentSpuSns", a.list.map(function(e) {
                    return e.spuSn;
                })), f.router.navigateTo({
                    path: h.RANK_ROUTER_KEY[a.listType] || "subPages/home/brand/hotlist/index",
                    query: {
                        listId: a.listId,
                        listType: a.listType,
                        from: r
                    }
                });
            } catch (e) {}
        },
        rankBanner_exposure: function(e) {
            try {
                this.triggerEvent("rankBannerExposure", {
                    rankinfo: e.currentTarget.dataset.rankinfo,
                    rindex: e.detail.index,
                    gindex: e.currentTarget.dataset.index,
                    product: e.detail.item,
                    ab: this.data.ab
                });
            } catch (e) {}
        }
    }
});