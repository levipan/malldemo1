var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../utils/newLogin.js"), i = require("../../api/index.js"), n = getApp();

Component({
    properties: {
        btnGuideIsSHow: {
            type: Boolean,
            value: !0
        },
        popupZIndex: {
            type: String,
            value: "100"
        },
        guideZIndex: {
            type: String,
            value: "100"
        },
        guideBottom: {
            type: String,
            value: "100rpx"
        },
        isCart: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        islogin: !1,
        popupShow: !1,
        loginWxShow: !1,
        getNickNameIsShow: !1,
        isTapGuideClose: !1
    },
    lifetimes: {
        attached: function() {
            var e = n.frxs.getMOrSData("userKey"), t = n.frxs.getMOrSData("isLogin");
            e && t && this.setData({
                islogin: !0
            });
        }
    },
    methods: {
        autoLogin: function() {
            var i = this;
            return t(e.default.mark(function t() {
                var a, r;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!i.autoLoginIsDisabled) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        if (i.autoLoginIsDisabled = !0, a = wx.$.getTestMeta("loginRewriteV2") || "A", !i.data.isCart || "A" !== a) {
                            e.next = 8;
                            break;
                        }
                        return i.triggerEvent("tapLoginA"), setTimeout(function() {
                            i.autoLoginIsDisabled = !1;
                        }, 400), e.abrupt("return");

                      case 8:
                        return e.next = 10, (0, s.autoNewLogin)({
                            frxs: n.frxs,
                            router: !1,
                            redirect: !1
                        }).catch(function() {});

                      case 10:
                        if (!(r = e.sent)) {
                            e.next = 17;
                            break;
                        }
                        if (i.autoLoginIsDisabled = !1, r.userKey && n.frxs.setMAndSData("userKey", r.userKey), 
                        "true" !== r.autoLogin && !0 !== r.autoLogin) {
                            e.next = 17;
                            break;
                        }
                        return i._success(), e.abrupt("return");

                      case 17:
                        i.setData({
                            popupShow: !0
                        }, function() {
                            setTimeout(function() {
                                i.setData({
                                    loginWxShow: !0
                                });
                            }, 300), i.autoLoginIsDisabled = !1;
                        });

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        onTapClose: function() {
            this.setData({
                isTapGuideClose: !0
            }), this.triggerEvent("tapGuideClose");
        },
        onTapMask: function() {
            this.data.getNickNameIsShow ? this._success() : this.onClosePopup();
        },
        onClosePopup: function() {
            this.setData({
                popupShow: !1,
                loginWxShow: !1
            });
        },
        onGetUserInfo: function(e) {
            "success" === e.detail.type ? this.updateUserInfo(e.detail.info) : this._success();
        },
        onCloseNickNamePopup: function() {
            this._success();
        },
        onWxLoginSuccess: function(e) {
            e.detail.registry ? this.setData({
                getNickNameIsShow: !0
            }) : this._success();
        },
        onWxLoginFail: function() {
            this._fail();
        },
        _fail: function() {
            this.triggerEvent("guideLoginFail");
        },
        _success: function() {
            this.triggerEvent("guideLoginSuccess"), this.setData({
                islogin: !0
            });
        },
        updateUserInfo: function(e) {
            var t = this;
            wx.login({
                success: function(s) {
                    var a = s.errMsg, r = s.code;
                    if (a.indexOf("ok")) {
                        var o = {};
                        try {
                            o = {
                                userKey: n.frxs.getMOrSData("userKey"),
                                code: r,
                                encryptedData: e.encryptedData || "",
                                iv: e.iv || "",
                                wechatImage: e.userInfo.avatarUrl,
                                wechatNickName: e.userInfo.nickName,
                                version: wx.getSystemInfoSync().SDKVersion,
                                oldApi: !wx.getUserProfile
                            };
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            t._success();
                        }
                        if (!o.code) return t._success();
                        i.memberApi.updateUserImageNickName(o, {
                            silence: !0
                        }).then(function() {
                            var s = n.frxs.getMOrSData("db-user");
                            s.headImgUrl = e.userInfo.avatarUrl, s.nickName = e.userInfo.nickName, n.frxs.setMAndSData("db-user", s), 
                            t._success();
                        }).catch(function() {
                            t._success();
                        });
                    } else t._success();
                },
                fail: function() {
                    t._success();
                }
            });
        }
    }
});