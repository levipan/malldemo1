Component({
    properties: {
        run: {
            type: "Boolean",
            value: !1
        },
        animateData: Object
    },
    observers: {
        run: function(t, a) {
            t !== a && t && this.run();
        }
    },
    data: {
        show: !1
    },
    methods: {
        createAnimation: function(t, a) {
            var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            return wx.createAnimation({
                duration: t,
                timingFunction: a,
                delay: e
            });
        },
        run: function() {
            var t = this, a = this.data.animateData, e = a.x, n = a.y, i = a.targetX, r = a.targetY;
            this.triggerEvent("animation-start");
            var o = this.createAnimation(1, "step-start"), s = this.createAnimation(1, "step-start");
            o.translateX(e).opacity(1).step(), s.translateY(n).step(), this.setData({
                show: !0,
                animationCart1: o.export(),
                animationCart2: s.export()
            }, function() {
                var a = t.createAnimation(300, "ease-out"), e = t.createAnimation(300, "ease-in");
                a.translateX(i).opacity(.65).step(), e.translateY(r).step(), t.setData({
                    animationCart1: a.export(),
                    animationCart2: e.export()
                }), setTimeout(function() {
                    e.translateY(0).step(), a.translateX(-1e3).step(), t.setData({
                        show: !1,
                        animationCart2: e.export(),
                        animationCart1: a.export()
                    });
                }, 300);
            });
        }
    }
});