Component({
    properties: {
        forUser: {
            type: String,
            value: "for-product-card"
        },
        value: Number,
        step: {
            type: Number,
            value: 1
        },
        max: {
            type: Number,
            value: 99
        },
        min: {
            type: Number,
            value: 0
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        editable: Boolean,
        async: {
            type: Boolean,
            value: !1
        },
        iconSize: {
            type: String,
            value: "74rpx"
        },
        numStyle: String,
        theme: {
            type: String,
            value: "red"
        },
        valueBold: {
            type: Boolean,
            value: !1
        },
        inputWidth: {
            type: Number,
            value: 120
        }
    },
    data: {
        value: 0
    },
    methods: {
        onPlus: function() {
            if (!this.data.disabled) {
                var t = this.data, e = t.value, a = t.step, i = t.max;
                if (e == i) return this.triggerEvent("plusMax", this.data.value);
                var u = e + a;
                u <= i && this.update(u), this.triggerEvent("plus", this.data.value);
            }
        },
        onMinus: function() {
            if (!this.data.disabled) {
                var t = this.data, e = t.value, a = t.step, i = t.min;
                if (e == i) return this.triggerEvent("minusMin", this.data.value);
                e == a && this.triggerEvent("minusStep", 0);
                var u = e - a;
                u >= i && this.update(u), this.triggerEvent("minus", this.data.value);
            }
        },
        onInput: function(t) {
            this.data.disabled || this.triggerEvent("input", t.detail);
        },
        onBlur: function(t) {
            this.data.disabled || this.triggerEvent("blur", t.detail);
        },
        onFocus: function(t) {
            this.data.disabled || this.triggerEvent("focus", t.detail);
        },
        update: function(t) {
            this.data.async || this.setData({
                value: t
            });
        }
    }
});