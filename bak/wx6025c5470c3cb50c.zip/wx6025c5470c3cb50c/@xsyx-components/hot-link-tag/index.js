Component({
    properties: {
        product: {
            type: Object,
            value: {}
        },
        maxPrice: {
            type: Number,
            value: 9999
        },
        className: {
            type: String,
            value: ""
        },
        iconStyle: {
            type: String,
            value: "medal",
            desc: "热销icon风格，medal:奖章 crown:王冠"
        },
        isFromProdDetail: {
            type: Boolean,
            value: !1,
            desc: "商详页需要定制化"
        }
    },
    methods: {
        mainClick: function() {
            this.triggerEvent("goHotList", this.data.product);
        }
    }
});