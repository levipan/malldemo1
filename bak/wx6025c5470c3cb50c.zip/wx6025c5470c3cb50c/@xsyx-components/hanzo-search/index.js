Component({
    properties: {
        styles: {
            type: Object,
            value: {
                "margin-top": "24rpx"
            }
        },
        cartCount: {
            type: Number
        },
        type: {
            type: String,
            value: "cart"
        },
        inputDisabled: {
            type: Boolean,
            value: !1
        },
        isFixed: {
            type: Boolean,
            value: !0
        },
        isMenuSearch: {
            type: Boolean,
            value: !1
        },
        hasShare: {
            type: Boolean,
            value: !0
        },
        openType: String,
        modal: {
            type: String,
            value: ""
        },
        theme: {
            type: String,
            value: "red",
            observer: function(e, t) {
                e != t && this.setData({
                    theme: e
                });
            }
        },
        value: {
            type: String,
            value: "",
            observer: function(e, t) {
                e != t && this.setData({
                    searchVal: e
                });
            }
        },
        placeholder: {
            value: "搜索商品",
            type: String
        },
        showEmptyBtn: {
            value: !0,
            type: Boolean
        },
        focus: {
            value: !1,
            type: Boolean
        }
    },
    data: {
        searchVal: ""
    },
    methods: {
        handleSearchBlur: function(e) {
            this.triggerEvent("search-blur", e.detail.value);
        },
        bindSearch: function(e) {
            this.triggerEvent("search-confirm", e.detail.value);
        },
        handleFocusSearch: function(e) {
            this.triggerEvent("search-focus", e.detail.value);
        },
        searchText: function(e) {
            this.setData({
                searchVal: e.detail.value
            }), this.triggerEvent("search-input", e.detail.value);
        },
        bindToCart: function(e) {
            this.triggerEvent("to-cart", e);
        },
        handlesearch: function(e) {
            this.triggerEvent("search-click", e);
        },
        handleTap: function(e) {
            this.triggerEvent("search-tap", e);
        },
        emptyInput: function(e) {
            this.setData({
                searchVal: ""
            }), this.triggerEvent("search-empty", e);
        }
    }
});