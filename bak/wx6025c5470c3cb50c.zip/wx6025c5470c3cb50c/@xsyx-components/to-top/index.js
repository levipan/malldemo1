Component({
    properties: {
        style: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        onGoTop: function() {
            this.triggerEvent("to-top");
        }
    }
});