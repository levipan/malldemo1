Component({
    properties: {
        shareDetail: Object,
        extendData: Object,
        customStyle: String
    },
    data: {},
    methods: {
        close: function() {
            this.triggerEvent("close", {});
        }
    }
});