var t = require("../../../@babel/runtime/helpers/interopRequireWildcard"), e = require("../../../@babel/runtime/helpers/interopRequireDefault"), s = require("../../../@babel/runtime/helpers/objectSpread2"), o = require("../../../api/index.js"), a = e(require("../../../@xsyx-components/hanzo-page-loading/loading.js")), i = t(require("../../../utils/events.js")), n = getApp();

module.exports = Behavior({
    properties: {
        isCanComment: Boolean,
        isThumbsUp: Boolean,
        isVomitSlot: Boolean,
        isCanCancel: Boolean,
        commentStatus: String,
        commentReadStatus: String,
        thumbsUpStatus: String,
        orderTimer: String
    },
    data: {
        vomitSlotOffset: {},
        thumbsUpOffset: {}
    },
    methods: {
        onThumbsUp: function(t) {
            var e = this;
            if ("NO_COMMENT" !== this.data.commentStatus) return a.default.showToast({
                title: "提交建议后，不能修改点赞或吐槽哦！",
                bgColor: "rgba(0,0,0,0.7)",
                icon: ""
            });
            this.updateCommentStatus({
                type: "PRAISE",
                success: function(s) {
                    var o = t.touches[0], a = o.clientX, i = o.clientY;
                    i = (i -= 350 * e.getSysInfo().screenRatio) > 100 ? i : 100, e.setData({
                        showThumbsUp: "PRAISE" == s,
                        thumbsUpOffset: {
                            left: a + "px",
                            top: i + "px"
                        }
                    }, function() {
                        setTimeout(function() {
                            e.setData({
                                showThumbsUp: !1
                            });
                        }, 1500);
                    });
                },
                fail: function() {}
            });
        },
        onVomitSlot: function(t) {
            var e = this;
            if ("NO_COMMENT" !== this.data.commentStatus) return a.default.showToast({
                title: "提交建议后，不能修改点赞或吐槽哦！",
                bgColor: "rgba(0,0,0,0.7)",
                icon: ""
            });
            this.updateCommentStatus({
                type: "BAD",
                success: function(s) {
                    var o = t.touches[0], a = o.clientX, i = o.clientY;
                    i = (i -= 380 * e.getSysInfo().screenRatio) > 100 ? i : 100, e.setData({
                        showVomitSlot: "BAD" == s,
                        vomitSlotOffset: {
                            left: a + "px",
                            top: i + "px"
                        }
                    }, function() {
                        setTimeout(function() {
                            e.setData({
                                showVomitSlot: !1
                            });
                        }, 1500);
                    });
                },
                fail: function() {}
            });
        },
        getContext: function() {
            var t = getCurrentPages();
            return t[t.length - 1];
        },
        updateCommentStatus: function(t) {
            var e = this, r = this.data.productDetails, u = t.type == this.data.thumbsUpStatus ? "NONE" : t.type, d = this.data.orderId || r.orderId, c = this.getContext(), l = {
                orderId: d,
                activityId: r.presaleActivityId,
                productId: r.productId,
                skuSn: r.skuSn,
                status: u,
                storeCode: this.data.storeCode,
                storeName: this.data.storeName,
                orderDateNew: n.frxs.formaterDate(c._get(this, "data.orderTimer", +new Date()), "yyyy-MM-dd HH:mm:ss")
            };
            a.default.showLoading({
                title: "",
                bgColor: "none"
            }), o.videoApi.fetchUpdateStatus(l, {
                silence: !0,
                contentType: "application/json"
            }).then(function(o) {
                a.default.close(), wx.vibrateShort(), "NONE" == u && a.default.showToast({
                    title: "取消成功",
                    icon: "",
                    bgColor: ""
                });
                try {
                    n.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "NONE" == u ? "PRAISE" == e.data.thumbsUpStatus ? "商品-取消点赞" : "商品-取消吐槽" : "PRAISE" == u ? "商品点赞" : "商品吐槽",
                        sku_sn: r.skuSn,
                        sku: r.sku,
                        order_id: d
                    }, "");
                } catch (t) {}
                t.success(u), i.default.emit(i.EVENTS.UPDATA_ORDER_THUMBSUP_STATUS, s(s({}, r), {}, {
                    orderId: d,
                    thumbsUpStatus: u
                }));
            }).catch(function(e) {
                a.default.close(), n.frxs.alert((e || {}).rspDesc || "操作失败，请稍候重试！"), t.fail();
            });
        },
        sysInfo: null,
        getSysInfo: function() {
            return this.sysInfo || (t = wx.getSystemInfoSync(), s(s({}, t), {}, {
                screenRatio: t.windowWidth / 750
            }));
            var t;
        },
        onMsg: function(t) {
            this.triggerEvent("onOrderComment", s(s({}, this.data.productDetails), {}, {
                orderId: this.data.orderId,
                thumbsUpStatus: this.data.thumbsUpStatus
            }));
        }
    }
});