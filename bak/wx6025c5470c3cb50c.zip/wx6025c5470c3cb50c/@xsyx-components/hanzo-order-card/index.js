var t = require("./behavior/comment.js"), e = getApp();

Component({
    behaviors: [ t ],
    properties: {
        phone: String,
        orderType: String,
        status: {
            type: String,
            value: ""
        },
        realPrice: String,
        modal: String,
        imageUrl: String,
        provider: String,
        isDirect: Boolean,
        title: String,
        subTitle: String,
        pickUpTime: String,
        price: String,
        oldPrice: String,
        count: Number,
        newUserProduct: {
            type: Boolean,
            value: !1
        },
        showBtnBuy: {
            type: Boolean,
            value: !1
        },
        pickupGray: {
            type: Boolean,
            value: !1
        },
        orderId: String,
        productDetails: {
            type: Object,
            observer: function(t) {
                t && t.deliveryTimeMS && this.getCanCommentStatus(t);
            }
        },
        buyText: {
            type: String,
            value: "要求再次上线"
        },
        storeCode: String,
        storeName: String,
        isShowGoodAndBad: {
            type: Boolean,
            value: !0
        },
        refundStatus: String,
        receiptFlag: Boolean
    },
    data: {
        isShowCommentBtn: !1
    },
    methods: {
        handleSign: function() {
            this.triggerEvent("handleSign", this.data.productDetails);
        },
        getCanCommentStatus: function(t) {
            var e = (t || {}).deliveryTimeMS, r = new Date(new Date(void 0 === e ? "" : e).toLocaleDateString()).getTime(), i = +new Date();
            this.setData({
                isShowCommentBtn: i > r && !this.data.receiptFlag
            });
        },
        onAddCart: function(t) {
            this.triggerEvent("onAddCart", {
                orderId: this.data.orderId,
                productDetails: this.data.productDetails,
                position: t.detail,
                orderType: this.data.orderType
            });
        },
        onClickTips: function() {
            this.triggerEvent("onClickTips", {});
        },
        onCancelOrder: function() {
            this.triggerEvent("onCancelOrder", {
                orderId: this.data.orderId,
                productDetails: this.data.productDetails
            });
        },
        onOnlineCancelOrder: function() {
            this.triggerEvent("onOnlineCancelOrder", {
                orderId: this.data.orderId,
                productDetails: this.data.productDetails
            });
        },
        onPhoneCustomer: function() {
            wx.$route.navigateTo({
                name: "custom-service",
                query: {
                    storeOrderId: this.data.orderId,
                    subStoreOrderId: e.frxs._get(this, "data.productDetails.subOrderId", ""),
                    target: "store",
                    vendorId: e.frxsConfig.vendorInfo.id,
                    vendorCode: e.frxsConfig.vendorInfo.code
                }
            });
        }
    }
});