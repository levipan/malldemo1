var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), s = require("../../@babel/runtime/helpers/asyncToGenerator"), r = e(require("../../utils/outBuisness-store-dialog")), a = e(require("../../const/shop-status.js")), o = e(require("../../router/index")), n = require("../../utils/subscribe-message"), i = require("../../api/index.js"), u = e(require("../../@xsyx-components/hanzo-page-loading/loading.js")), c = getApp();

Component({
    properties: {},
    data: {
        showCancel: !0,
        isShowModal: !1,
        storeStatusChangeReason: "门店歇业中",
        showModalType: ""
    },
    attached: function() {
        var e = this, t = getCurrentPages().pop().__wxExparserNodeId__;
        this.currentWxExparserNodeId = t, r.default.onEventoutBuisnessDialogStatus(t, function(t) {
            var s = ((c || {}).globalData || {}).storeInfo;
            if (s) {
                var r = "门店歇业中";
                if (s.storeStatus === a.default.FROZEN && (r = "小店休息中，无法接单哦，您可以选择附近门店下单。如有疑问，请咨询兴盛优选全国服务热线4008889997"), 
                s.storeStatus === a.default.OUT_BUSINESS && (r = s.storeStatusChangeReason), s.storeStatus === a.default.NOT_ONLINE) if ("init_home" == t) r = s.indexHint || "门店即将开业，快来提前逛逛吧。试试提前签到换取优惠券红包，等开业来使用吧！"; else {
                    var o = s.shoppingHint || "门店尚未开业，无法加购下单，试试提前签到换取优惠券红包，等开业来使用吧！";
                    u.default.showToast({
                        title: o
                    });
                }
                console.log("position", t), e.setData({
                    isShowModal: !0,
                    showModalType: s.storeStatus,
                    position: t,
                    storeStatusChangeReason: r
                });
            }
        });
    },
    detached: function() {},
    methods: {
        changeLocation: function() {
            var e = getCurrentPages();
            wx.$.sessionStorage.set("toPageConfig", {
                path: e.route,
                query: e.options,
                type: "navigateBack"
            }), c.router.navigateTo({
                path: "/subPages/users/selfdot/mydot/mydot"
            }), c.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "切换自提店"
            }, "");
        },
        onOutBusinessModal: function(e) {
            "confirm" === e.detail && c.userSvr.getWechatLocation({
                isShowLoading: !0,
                hasStoreId: !0,
                success: function(e) {
                    o.default.navigateTo({
                        path: "/subPages/users/changdot/changdot",
                        query: {
                            mapX: e.longitude,
                            mapY: e.latitude
                        }
                    });
                }
            });
            var t = getCurrentPages().pop().__wxExparserNodeId__;
            t === this.currentWxExparserNodeId && (r.default.setFalseWxExparserNodeIdList(t), 
            this.setData({
                isShowModal: !1
            }));
        },
        onNotOnlineModal: function() {
            var e = this;
            return s(t.default.mark(function s() {
                var r, a, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, c.frxs.isLogin()) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return", c.frxs.toLogin());

                      case 3:
                        if (!(r = c.frxsConfig.tmplIds)) {
                            t.next = 11;
                            break;
                        }
                        return a = [ r.openReminder ], t.next = 8, (0, n.onRequestSubscribeMessage)(a);

                      case 8:
                        o = t.sent, console.log("result", o), o && "accept" === o[r.openReminder] && e.subscribeMessage();

                      case 11:
                        t.next = 15;
                        break;

                      case 13:
                        t.prev = 13, t.t0 = t.catch(0);

                      case 15:
                      case "end":
                        return t.stop();
                    }
                }, s, null, [ [ 0, 13 ] ]);
            }))();
        },
        subscribeMessage: function() {
            return s(t.default.mark(function e() {
                var s, r;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, s = c.frxs.getMOrSData("storeInfo") || {}, e.next = 4, i.memberApi.openStoreSub({
                            storeId: s.storeId
                        }, {
                            silence: !0
                        });

                      case 4:
                        r = e.sent, console.log("data", r), e.next = 10;
                        break;

                      case 8:
                        e.prev = 8, e.t0 = e.catch(0);

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 0, 8 ] ]);
            }))();
        }
    }
});