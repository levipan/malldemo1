Component({
    properties: {
        color: {
            type: String,
            desc: "价格颜色，可选值为 red black",
            value: "red"
        },
        price: {
            type: Number,
            desc: "价格",
            value: 0,
            observer: function(e) {
                var t = Number(e).toFixed(this.data.toFixed);
                this.setData({
                    priceValue: t
                });
            }
        },
        toFixed: {
            type: Number,
            value: 2,
            desc: "保留几位小数，可选值为 0 1 2",
            observer: function(e) {
                var t = Number(this.data.price).toFixed(e);
                this.setData({
                    priceValue: t
                });
            }
        },
        size: {
            type: String,
            value: "s42",
            desc: "大小，可选值为 s46 s42 s30"
        },
        bold: {
            type: Boolean,
            value: !0,
            desc: "是否加粗"
        }
    },
    data: {
        priceValue: "0.00"
    }
});