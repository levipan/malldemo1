var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), o = (e(require("../../xapp/runtime")), 
require("../../api/index")), i = getApp();

Component({
    properties: {
        showPhoneTips: Boolean
    },
    data: {
        visible: !1
    },
    attached: function() {
        this.getSelfPhoneNumber();
    },
    detached: function() {},
    methods: {
        getPhone: function(e) {
            var a = this;
            return r(t.default.mark(function r() {
                var s, l, c;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, s = i.frxs.isLogin()) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", i.frxs.toLogin());

                      case 4:
                        return t.next = 6, o.commonStoreApi.getStoreContactsTelProtected(n(n({}, e), {}, {
                            userKey: s
                        }), {
                            contentType: "application/json"
                        });

                      case 6:
                        l = t.sent, (c = wx.$._get(l, "contactsTelProtected", !1)) ? a.triggerEvent("virtual-phone-show") : a.onCallPhone(l.contactsTel), 
                        a.setData(n(n({}, l), {}, {
                            visible: c
                        })), t.next = 16;
                        break;

                      case 12:
                        t.prev = 12, t.t0 = t.catch(0), console.error(t.t0), a.triggerEvent("virtual-phone-error");

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 12 ] ]);
            }))();
        },
        getSelfPhoneNumber: function() {
            if (this.data.showPhoneTips) {
                var e = (i.frxs.getStorageSync("db-user") || {}).mobileNo, t = void 0 === e ? "" : e;
                this.setData({
                    lastFourMobileNo: t.slice(t.length - 4)
                });
            }
        },
        onCloseModal: function(e) {
            var t = this;
            this.setData({
                visible: !1
            }, function() {
                "function" == typeof e ? e() : t.triggerEvent("virtual-phone-close");
            });
        },
        onClickCancel: function() {
            this.onCloseModal(), this.triggerEvent("virtual-phone-cancel");
        },
        onCallPhone: function(e) {
            wx.makePhoneCall({
                phoneNumber: e
            });
        },
        onClickOk: function() {
            var e = this;
            this.onCloseModal(function() {
                e.triggerEvent("virtual-phone-ok"), e.onCallPhone(e.data.contactsTel);
            });
        }
    }
});