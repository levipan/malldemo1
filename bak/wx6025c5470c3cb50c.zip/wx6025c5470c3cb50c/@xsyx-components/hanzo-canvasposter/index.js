var t = require("../../@babel/runtime/helpers/typeof"), e = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), i = require("../../api/index"), o = getApp();

Component({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(t) {
                this.setData({
                    item: t
                });
            }
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        hasStorage: !1,
        img: "",
        body_img_width: 300,
        body_img_height: 864,
        btn_title: "保存图片",
        storage_key: "shareCircleImg",
        storage: {}
    },
    ready: function() {
        var t = wx.getStorageSync("shareCircleImg");
        this.setData({
            storage: t || {}
        }), wx.showLoading({
            title: "生成中...",
            mask: !0
        }), this.getAuth(), this.data.item && this.data.item.code ? this.getStorePoster(this.data.item) : this.data.item && this.data.item.prName && this.getProductDetailPoster(this.data.item);
    },
    methods: {
        getStorePoster: function(t) {
            var e = this;
            i.commonStoreApi.storePoster({
                storeId: t.storeId
            }, {
                contentType: "application/json",
                silence: !0
            }).then(function(t) {
                wx.hideLoading(), e.setData({
                    img: t
                });
            }).catch(function() {
                wx.hideLoading(), e.setData({
                    img: "https://front-xps-cdn.xsyx.xyz/2021/06/15/536702877.png"
                });
            });
        },
        getProductDetailPoster: function(t) {
            var e = this, n = {
                spuSn: t.spuSn,
                storeId: t.storeId,
                areaId: t.areaId,
                storeName: t.address,
                couponPrice: t.couponAfterPrice || 0,
                productId: t.productId,
                activityId: t.activityId
            }, s = o.frxs.getMOrSData("db-user");
            s && (n.userName = s.nickName, n.userAvatar = encodeURIComponent(s.headImgUrl || s.wechatImage)), 
            i.commonPromotionApi.productPosterImage(n, {
                contentType: "application/json",
                silence: !0
            }).then(function(t) {
                e.setData({
                    img: t.img
                }), wx.hideLoading();
            }).catch(function() {
                e.setData({
                    img: "https://front-xps-cdn.xsyx.xyz/2021/06/15/536702877.png"
                }), wx.hideLoading();
            });
        },
        _close: function() {
            this.setData({
                show: !1
            }), this.triggerEvent("posterexit", {
                a: 1
            });
        },
        _saveImg: function(t) {
            var e = this;
            this.getAuth(t).then(function() {
                wx.getSetting({
                    success: function(t) {
                        !1 === t.authSetting["scope.writePhotosAlbum"] || e.downloadFile([ e.data.img ]).then(function(t) {
                            wx.saveImageToPhotosAlbum({
                                filePath: t[0],
                                success: function() {
                                    wx.showToast({
                                        title: "保存成功，请在相册中查看分享",
                                        icon: "none"
                                    });
                                },
                                fail: function() {
                                    wx.showToast({
                                        title: "保存失败",
                                        icon: "none"
                                    }), wx.getSetting({
                                        success: function(t) {
                                            !1 === t.authSetting["scope.writePhotosAlbum"] && e.setData({
                                                btn_title: "点击开启保存到相册"
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    }
                });
            });
        },
        getAuth: function(t) {
            var e = this;
            return new Promise(function(i) {
                wx.getSetting({
                    success: function(o) {
                        o.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                            btn_title: "保存图片"
                        }), i(!0)) : !1 === o.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                            btn_title: "点击开启保存到相册"
                        }), t && wx.openSetting({
                            success: function(t) {
                                t.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                                    btn_title: "保存图片"
                                }), i(!0)) : i(!1);
                            },
                            fail: function() {
                                i(!1);
                            }
                        })) : i(!1);
                    },
                    fail: function() {
                        wx.showToast({
                            title: "查询设置失败",
                            icon: "none"
                        });
                    }
                });
            });
        },
        downloadFile: function(i) {
            var o, n = [], s = e(i);
            try {
                var a = function() {
                    var t = o.value;
                    if (0 == t.indexOf("http")) n.push(new Promise(function(e) {
                        wx.downloadFile({
                            url: t,
                            success: function(t) {
                                console.log(t), 200 === t.statusCode ? e(t.tempFilePath) : e(null);
                            },
                            fail: function(t) {
                                console.log(t), e(null);
                            }
                        }), setTimeout(function() {
                            e(null);
                        }, 3e4);
                    })); else {
                        if (!(t.indexOf("/") >= 0)) return {
                            v: new Promise(function(t, e) {
                                e("图片下载失败！");
                            })
                        };
                        n.push(t);
                    }
                };
                for (s.s(); !(o = s.n()).done; ) {
                    var r = a();
                    if ("object" === t(r)) return r.v;
                }
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                s.e(t);
            } finally {
                s.f();
            }
            return new Promise(function(t, e) {
                Promise.all(n).then(function(e) {
                    t(e);
                }).catch(function(t) {
                    console.log(t), e(t);
                });
            });
        }
    }
});