Component({
    relations: {
        "../index": {
            type: "parent",
            linked: function() {},
            linkChanged: function() {},
            unlinked: function() {}
        }
    },
    properties: {
        iStyle: {
            type: String,
            value: ""
        },
        label: {
            type: String,
            value: ""
        },
        name: {
            type: String,
            value: ""
        }
    },
    data: {
        isShow: !1
    }
});