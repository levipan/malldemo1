Component({
    relations: {
        "./tab/index": {
            type: "child",
            linked: function() {},
            linkChanged: function() {},
            unlinked: function() {}
        }
    },
    properties: {
        iStyle: {
            type: String,
            value: ""
        },
        value: {
            type: String,
            value: ""
        },
        tab: {
            type: Array,
            value: []
        },
        align: {
            type: String,
            value: "horizontal"
        },
        tabStyle: {
            type: String,
            value: ""
        }
    },
    data: {
        selectIndex: 0,
        tabIndex: 0,
        scrollLeft: 0,
        width: 0,
        ml: 0,
        initMl: 0,
        svWidth: 0,
        panelNodes: [],
        isLower: !1,
        lastLeft: 0,
        lastWidth: 0
    },
    ready: function() {
        this.getAllPanel(), this.initCal();
    },
    methods: {
        getAllPanel: function() {
            var t = this, e = this.data.value, a = [], n = this.getRelationNodes("./tab/index");
            this.setData({
                panelNodes: n
            }), n.map(function(n, i) {
                var l = n.data, s = l.label, o = l.name;
                e === o && t.setData({
                    selectIndex: i
                }), a.push({
                    text: s
                });
            }), this.setData({
                tab: a
            });
        },
        initCal: function() {
            var t = this;
            wx.createSelectorQuery().in(this).selectAll(".tab__item").boundingClientRect(function(e) {
                if (e) {
                    var a = t.data.tab;
                    a.map(function(n, i) {
                        i === a.length - 1 && t.setData({
                            lastLeft: e[i].left,
                            lastWidth: e[i].width
                        }), n.left = e[i].left;
                    }), t.setData({
                        tab: a
                    });
                }
            }).select(".first").boundingClientRect(function(e) {
                e && t.setData({
                    initMl: e.left
                });
            }).select(".scroll-view").boundingClientRect(function(e) {
                var a = t.data, n = a.selectIndex, i = a.tab;
                e && i.length > 0 && (t.setData({
                    svWidth: e.width
                }), console.log("tab", i), console.log("tab.selectIndex", i[n]), t.changeTabFun(n, i[n].left));
            }).exec();
        },
        changeTab: function(t) {
            var e = t.currentTarget.dataset, a = e.index, n = e.left;
            this.data.tabIndex !== a && this.changeTabFun(a, n);
        },
        changeTabFun: function(t, e) {
            var a = this, n = this.data, i = n.tab, l = n.initMl, s = n.svWidth, o = n.panelNodes;
            i.map(function(e, a) {
                return e.active = a === t;
            }), this.setData({
                tab: i,
                tabIndex: t
            }), wx.createSelectorQuery().in(this).select(".active").boundingClientRect(function(t) {
                if (t) {
                    var n = e - (s - t.width) / 2 - l;
                    a.setData({
                        width: t.width,
                        scrollLeft: n
                    }), setTimeout(function() {
                        a.setData({
                            ml: e - l
                        });
                    }, 80);
                }
            }).exec(), o.map(function(e, a) {
                e.setData({
                    isShow: t === a
                });
            }), this.triggerEvent("changeTab", {
                name: o[t].data.name
            });
        },
        bindscroll: function(t) {
            var e = t.detail.scrollLeft, a = this.data, n = a.svWidth, i = a.initMl, l = a.lastLeft, s = a.lastWidth;
            e >= Math.floor(l - n + s - i) - 1 ? this.setData({
                isLower: !0
            }) : this.setData({
                isLower: !1
            });
        },
        toPanel: function(t) {
            var e = this, a = this.data.panelNodes;
            this.setData({
                selectIndex: 0
            }), a.map(function(a, n) {
                var i = a.data.name;
                t === i && e.setData({
                    selectIndex: n
                });
            }), this.initCal();
        }
    }
});