Component({
    properties: {
        skeleton: Boolean,
        page: Number,
        list: Array,
        videoDataMap: {
            type: Object,
            value: {}
        }
    },
    attached: function() {},
    methods: {
        toVideo: function(t) {
            var e = t.currentTarget.dataset.itIndex;
            this.triggerEvent("to-video", {
                page: this.data.page,
                itIndex: e,
                detail: this.data.list[e]
            });
        }
    }
});