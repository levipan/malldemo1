Component({
    options: {
        multipleSlots: !0
    },
    properties: {},
    data: {
        componentList: {
            id: 12,
            x: 87,
            y: 54,
            zIndex: 1,
            width: "750",
            height: "500",
            name: "View",
            props: {
                init: {}
            },
            styles: {
                margin: {
                    top: 30,
                    left: 20,
                    right: 0,
                    bottom: 0
                },
                border: {
                    color: {
                        rgba: {
                            a: 1,
                            b: 93,
                            g: 94,
                            r: 90
                        }
                    },
                    border: {
                        width: 1,
                        style: "solid",
                        top: !1,
                        bottom: !0,
                        left: !1,
                        right: !1
                    }
                },
                boxShadow: {
                    color: {
                        rgba: {
                            a: 1,
                            b: 93,
                            g: 94,
                            r: 90
                        }
                    },
                    x: 4,
                    y: 4,
                    blurry: 4,
                    expand: 0
                },
                borderRadius: {
                    topLeft: 20,
                    topRight: 20,
                    bottomLeft: 20,
                    bottomRight: 20
                },
                background: {
                    color: {
                        rgba: {
                            a: 1,
                            b: 93,
                            g: 94,
                            r: 90
                        }
                    }
                },
                font: {
                    fontSize: "40",
                    fontWeight: "600",
                    fontType: "",
                    lineHeight: "",
                    letterSpacing: "",
                    alignMode: "",
                    color: {
                        rgba: {
                            a: 1,
                            b: 93,
                            g: 94,
                            r: 90
                        }
                    }
                }
            },
            children: [ {
                name: "Text",
                props: {
                    text: "111",
                    textOverflow: "",
                    lineClamp: 2
                }
            }, {} ],
            events: [ {
                type: "jump",
                params: {
                    path: "",
                    appId: ""
                }
            } ]
        }
    },
    attached: function() {
        this.styleMap = {
            padding: this.handlePOMStyle,
            margin: this.handlePOMStyle,
            border: this.handleBorderStyle,
            boxShadow: this.handleBoxShadow,
            borderRadius: this.handleBorderRadius,
            background: this.handleBackground,
            font: this.handleFontStyle
        }, this.initStyleFunction();
    },
    methods: {
        isObject: function(t) {
            return "[object Object]" === Object.prototype.toString.call(t);
        },
        handleFontStyle: function(t) {
            var o = t.color.rgba ? "rgba(".concat(t.color.rgba.a, ",").concat(t.color.rgba.b, ",").concat(t.color.rgba.g, ",").concat(t.color.rgba.r, ")") : "#ffffff";
            return "font-size: ".concat(t.fontSize, "rpx; font-weight: ").concat(t.fontWeight, " ;line-height: ").concat(t.lineHeight, "rpx; color: ").concat(o, ";letter-spacing: ").concat(t.letterSpacing, ";");
        },
        handleBackground: function(t) {
            var o = "";
            return t.color && (o += t.color.rgba ? " background-color: rgba(".concat(t.color.rgba.a, ",").concat(t.color.rgba.b, ",").concat(t.color.rgba.g, ",").concat(t.color.rgba.r, ")") : "#ffffff"), 
            t.img && (o += "background:url(".concat(t.img.link, ") ").concat(t.img.link.backgroundRepeat, ";background-size: ").concat(t.img.backgroundSize, ";")), 
            o;
        },
        handleBorderRadius: function(t) {
            return "border-radius: ".concat(t.topLeft ? t.topLeft : 0, "rpx ").concat(t.topRight ? t.topRight : 0, "rpx ").concat(t.bottomRight ? t.bottomRight : 0, "rpx ").concat(t.bottomLeft ? t.bottomLeft : 0, "rpx;");
        },
        handleBoxShadow: function(t) {
            var o = t.color ? "rgba(".concat(t.color.rgba.a, ",").concat(t.color.rgba.b, ",").concat(t.color.rgba.g, ",").concat(t.color.rgba.r, ")") : "#ffffff";
            return "box-shadow: ".concat(t.x, "rpx ").concat(t.y, "rpx ").concat(t.blurry ? t.blurry + "rpx" : "", " ").concat(t.expand ? t.expand + "rpx" : "", " ").concat(o, ";");
        },
        handlePOMStyle: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", o = arguments.length > 1 ? arguments[1] : void 0, n = "";
            return Object.keys(t).forEach(function(e) {
                n = "".concat(o, "-").concat(e, ":").concat(t[e]);
            }), n;
        },
        handleBorderStyle: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (!this.isObject(t) || !t.border) return "";
            var o = t.color ? "rgba(".concat(t.color.rgba.a, ",").concat(t.color.rgba.b, ",").concat(t.color.rgba.g, ",").concat(t.color.rgba.r, ")") : "#ffffff", n = "".concat(t.border.width, "rpx ").concat(t.border.style, " ").concat(o), e = "";
            return Object.keys(function(o) {
                "width" != o && "style" != o && t[o] && (e += "border-".concat(o, ": ").concat(n));
            }), e;
        },
        handleComponentInitData: function(t) {
            var o = {
                styles: "",
                events: t.events,
                props: t.props
            };
            if (o.styles += "width:".concat(t.width, ";height:").concat(t.height, ";z-index: ").concat(t.zIndex, ";position: absolute;"), 
            t.styles && (o.styles += this.mapStyleStr(t.styles)), "Text" == t.name && ("clip" === t.textOverflow ? o.styles += "overflow: hidden;" : "ellipsis" === t.textOverflow && (o.styles += "display: -webkit-box;-webkit-box-orient: vertical; -webkit-line-clamp: ".concat(t.lineClamp, ";overflow: hidden;"))), 
            t.children && t.children.length) {
                o.children = [];
                for (var n = 0; n < t.children.length; n++) o.push(this.handleComponentInitData(t.children[n]));
            }
            return o;
        },
        initStyleFunction: function() {
            var t = this.data.componentList, o = void 0 === t ? [] : t, n = this.handleComponentInitData(o);
            console.log("------生成的数----\x3e", n), this.setData({
                componentList: n
            });
        },
        mapStyleStr: function() {
            var t = this, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (!this.isObject(o)) return "";
            var n = "";
            return Object.keys(o).forEach(function(e) {
                t.styleMap[e] && t.isObject(o[e]) && (n += t.styleMap[e](o[e], e));
            }), n;
        },
        onClickView: function(t) {
            console.log("---\x3e>", t);
        }
    }
});