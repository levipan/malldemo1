Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        item: {
            type: Object,
            value: {}
        },
        showRadio: {
            type: Boolean,
            value: !1
        },
        counterClass: {
            type: String,
            value: "new-counter-class"
        },
        theme: {
            type: String,
            value: ""
        },
        needCounter: {
            type: Boolean,
            value: !0
        },
        source: {
            type: String,
            value: "trade",
            desc: "使用场景 trade-交易 order-订单"
        },
        min: {
            value: 0,
            type: Number
        },
        photoType: {
            type: String,
            value: "cart"
        }
    },
    data: {
        editable: !0,
        showRecomd: !0
    },
    methods: {
        closeRecommodMore: function() {
            this.setData({
                showRecomd: !1
            });
        },
        wantoBuyMore: function(e) {
            var t = getApp(), r = t.frxs._get(e, "currentTarget.dataset.prd", -1);
            -1 != r && (t.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "查看更多相似",
                sku_sn: r.skuSn,
                ab: ""
            }, ""), t.router.navigateTo({
                path: "subProduct/similarProduct/index",
                query: {
                    acId: r.acId,
                    prId: r.preId,
                    sku: r.sku,
                    areaId: t.frxs.getMOrSData("areaId") || r.areaId,
                    storeId: t.frxs.getMOrSData("storeId"),
                    spuSn: r.spuSn
                }
            }));
        },
        toProduct: function(e) {
            var t = getApp(), r = t.frxs._get(e, "currentTarget.dataset.prd", -1);
            if (-1 != r) {
                var o = {
                    path: "/pages/home/productDetail/productDetail",
                    query: {
                        orderStoreId: r.storeId || t.frxs.getMOrSData("storeId"),
                        orderAreaId: r.areaId,
                        acid: r.acId,
                        prid: r.prId,
                        prType: r.productType
                    }
                };
                t.router.navigateTo(o);
            }
        },
        plusMax: function(e) {
            this.triggerEvent("plusMax", e);
        },
        openCouponProduct: function(e) {
            this.triggerEvent("openCouponProduct", e);
        },
        cleanLosePd: function(e) {
            this.triggerEvent("cleanLosePd", e);
        },
        goPrdDetail: function(e) {
            this.triggerEvent("goPrdDetail", e);
        },
        onBlur: function(e) {
            this.triggerEvent("onBlur", e);
        },
        onFocus: function(e) {
            this.triggerEvent("onFocus", e);
        },
        onChange: function(e) {
            this.triggerEvent("onChange", e);
        },
        onSwipeRight: function(e) {
            this.triggerEvent("onSwipeRight", e);
        },
        onReduce: function(e) {
            this.triggerEvent("onReduce", e);
        },
        onAdd: function(e) {
            this.triggerEvent("onAdd", e);
        },
        checkRadio: function(e) {
            this.triggerEvent("checkRadio", e);
        }
    }
});