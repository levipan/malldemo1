Component({
    properties: {
        buyer: Array,
        nearBy: Number,
        label: String,
        rightLabel: String,
        size: String,
        textClass: String,
        mode: {
            type: String,
            value: "normal"
        },
        isHeadReverse: {
            type: Boolean,
            value: !1,
            desc: "头像是否反叠"
        },
        hasMoreHead: {
            type: Boolean,
            value: !1,
            desc: "是否存在省略头像"
        }
    },
    data: {},
    methods: {}
});