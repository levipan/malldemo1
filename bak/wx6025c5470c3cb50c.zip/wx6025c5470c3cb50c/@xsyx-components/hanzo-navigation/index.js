var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../router/index"));

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        backDelta: {
            type: Number,
            value: 1
        },
        back: {
            type: Boolean,
            default: !1
        },
        title: {
            type: String,
            default: ""
        },
        background: {
            type: String,
            default: "#fff"
        },
        color: {
            type: String,
            default: "#000"
        },
        fixed: {
            type: Boolean,
            default: !1
        },
        expandClass: {
            type: String,
            default: ""
        },
        backIconColor: {
            type: String,
            default: "#000"
        },
        expandStyle: {
            type: String,
            default: ""
        }
    },
    data: {
        statusbarHeight: wx.getSystemInfoSync().statusBarHeight || 44,
        height: 46,
        isCompaty: !1,
        placeholderHeight: 45 + (wx.getSystemInfoSync().statusBarHeight || 44)
    },
    attached: function() {
        var e = this, t = wx.getSystemInfoSync() || {}, a = t.SDKVersion, n = t.version, r = n && a && this.compareVersion(a, "2.4.3") >= 0 && this.compareVersion(n, "7.0.0") >= 0;
        this.setData({
            height: 46,
            isCompaty: r
        }), setTimeout(function() {
            wx.createSelectorQuery().in(e).select("#hanzo-nav").boundingClientRect(function(t) {
                t && (e.setData({
                    placeholderHeight: t.height - 1
                }), e.triggerEvent("onUpdate", t.height - 1));
            }).exec();
        }, 100);
    },
    methods: {
        compareVersion: function(e, t) {
            for (var a = e.split("."), n = t.split("."), r = Math.max(a.length, n.length); a.length < r; ) a.push("0");
            for (;n.length < r; ) n.push("0");
            for (var i = 0; i < r; i++) {
                var o = parseInt(a[i]), s = parseInt(n[i]);
                if (o > s) return 1;
                if (o < s) return -1;
            }
            return 0;
        },
        navBack: function(t) {
            this.data.backDelta > 0 && (getCurrentPages().length > 1 ? wx.navigateBack({
                delta: this.data.backDelta
            }) : e.default.switchTab({
                path: "/pages/home/index/index"
            }));
            this.triggerEvent("onBack", t);
        }
    }
});