Component({
    attached: function() {
        this.getSaleBottomHeight();
    },
    data: {
        safeAreaBottom: 0
    },
    methods: {
        getSaleBottomHeight: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(e) {
                    try {
                        var a = e.safeArea, o = e.screenHeight;
                        o > a.bottom && t.setData({
                            safeAreaBottom: o - a.bottom
                        }), t.triggerEvent("onReady", t.data.safeAreaBottom);
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        t.triggerEvent("onReady", t.data.safeAreaBottom);
                    }
                }
            });
        }
    }
});