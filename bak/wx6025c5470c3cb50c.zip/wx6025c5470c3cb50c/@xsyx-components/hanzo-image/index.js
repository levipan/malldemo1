Component({
    properties: {
        src: String,
        mode: String,
        lazyLoad: {
            type: Boolean,
            value: !0
        },
        ariaLabel: String
    },
    data: {},
    methods: {
        handleerror: function(e) {
            this.triggerEvent("error", e);
        },
        handleload: function(e) {
            this.triggerEvent("load", e);
        }
    }
});