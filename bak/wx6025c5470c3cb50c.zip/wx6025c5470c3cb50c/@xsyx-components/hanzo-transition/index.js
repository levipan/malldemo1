var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("./transition"));

Component({
    behaviors: [ e.default ],
    externalClasses: [ "extend-class" ],
    options: {
        addGlobalClass: !0
    }
});