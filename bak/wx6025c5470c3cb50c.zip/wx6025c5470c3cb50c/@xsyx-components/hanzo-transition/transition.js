Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../@babel/runtime/helpers/typeof");

function t(t) {
    var a = e(t);
    return null !== t && ("object" === a || "function" === a);
}

var a = function(e) {
    return {
        enter: "hanzo-".concat(e, "-enter hanzo-").concat(e, "-enter-active"),
        "enter-to": "hanzo-".concat(e, "-enter-to hanzo-").concat(e, "-enter-active"),
        leave: "hanzo-".concat(e, "-leave hanzo-").concat(e, "-leave-active"),
        "leave-to": "hanzo-".concat(e, "-leave-to hanzo-").concat(e, "-leave-active")
    };
}, n = function() {
    return new Promise(function(e) {
        return setTimeout(e, 1e3 / 30);
    });
}, s = Behavior({
    properties: {
        show: {
            type: Boolean,
            value: !0,
            observer: "observeShow"
        },
        duration: {
            type: [ Number, Object ],
            value: 300,
            observer: "observeDuration"
        },
        name: {
            type: String,
            value: "fade",
            observer: "updateClasses"
        },
        customClass: String,
        customStyle: String
    },
    data: {
        type: "",
        inited: !1,
        display: !1,
        classNames: a("fade")
    },
    attached: function() {
        this.data.show && this.show();
    },
    methods: {
        observeShow: function(e) {
            e ? this.show() : this.leave();
        },
        updateClasses: function(e) {
            this.setData({
                classNames: a(e)
            });
        },
        show: function() {
            var e = this, a = this.data, s = a.classNames, o = a.duration, r = t(o) ? o.leave : o;
            Promise.resolve().then(n).then(function() {
                return e.setData({
                    inited: !0,
                    display: !0,
                    classes: s.enter,
                    currentDuration: r
                });
            }).then(n).then(function() {
                return e.setData({
                    classes: s["enter-to"]
                });
            });
        },
        leave: function() {
            var e = this, a = this.data, s = a.classNames, o = a.duration, r = t(o) ? o.leave : o;
            0 != +r ? Promise.resolve().then(n).then(function() {
                return e.setData({
                    classes: s.leave,
                    currentDuration: r
                });
            }).then(n).then(function() {
                return e.setData({
                    classes: s["leave-to"]
                });
            }) : this.onTransitionEnd();
        },
        onTransitionEnd: function() {
            this.data.show || (this.setData({
                display: !1
            }), this.triggerEvent("transitionend"));
        }
    }
});

exports.default = s;