var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../api/index.js"), a = e(require("../../router/index.js")), i = require("../../utils/wx-api.js");

Component({
    data: {
        read: !1,
        showPopup: !1,
        showDialogType: "",
        _btnTapDisabeld: !1
    },
    methods: {
        onTick: function() {
            this.setData({
                read: !this.data.read
            });
        },
        onGetPhoneNumber: function(e) {
            var a = this;
            (0, i.getPhoneNumberHookFn)(e), setTimeout(function() {
                a.data._btnTapDisabeld && a.setData({
                    _btnTapDisabeld: !1
                });
            }, 500), this.setData({
                read: !0,
                showPopup: !1
            }), this.openTypeBtnDisabled = !1;
            var n = getApp(), r = this, o = {
                unBind: [ "getPhoneNumber:fail:cancel to bind phone" ],
                cancel: [ "getPhoneNumber:fail:cancel to confirm login", "getPhoneNumber:fail:user cancel" ],
                frequency: [ "getPhoneNumber:fail too frequency" ]
            };
            if ("getPhoneNumber:ok" == e.detail.errMsg) {
                var s = n.frxs.getMOrSData("userKey"), l = n.frxs.getMOrSData("storeId"), u = wx.getSystemInfoSync() || {}, d = {
                    loginMode: "ENCRYPTED_DATA",
                    userKey: s,
                    encryptedData: e.detail.encryptedData,
                    iv: e.detail.iv,
                    item: "WECHAT_MINI_MEMBER",
                    "terminal.devId": "",
                    "terminal.brand": u.brand,
                    "terminal.os": u.system,
                    "terminal.type": u.model,
                    "request.providerName": "TONGDUN",
                    "request.blackBox": n.frxs.storage("safe_bb") || ""
                };
                e.detail.code && (d.loginMode = "CODE_EXCHANGE_PHONE_NO", d.code = e.detail.code), 
                l && (d.currentStoreId = l), t.authApi.manualLogin(d, {
                    silence: !0,
                    loading: "登录中"
                }).then(function(e) {
                    n.frxs.setStorageSync("isLogin", !0), n.frxs.setMAndSData("userKey", e.userKey), 
                    n.userSvr.getUserInfo({
                        getMode: "db",
                        success: function(t) {
                            n.frxs.setMAndSData("db-user", t), t.currentStoreId > 0 && n.frxs.isNullOrWhiteSpace(l) && n.frxs.setMAndSData("storeId", t.currentStoreId), 
                            r.triggerEvent("wxLoginSuccess", {
                                registry: e.registry
                            });
                        },
                        fail: function() {
                            r.triggerEvent("wxLoginSuccess", {
                                registry: e.registry
                            });
                        }
                    });
                }).catch(function(e) {
                    "loginExpire" === e.rspCode ? (n.frxs.removeMAndS("userKey"), n.frxs.removeMData("wxGetUserProfileInfo"), 
                    n.frxs.removeMData("wxLoginSuccessCode"), n.userSvr.autoLogin()) : n.frxs.alert({
                        content: e.rspDesc
                    }), r.triggerEvent("wxLoginFail");
                });
            } else e.detail.errMsg.indexOf("deny") > 0 || o.cancel.indexOf(e.detail.errMsg) >= 0 || e.detail.errMsg.indexOf("cancel") > 0 || o.unBind.indexOf(e.detail.errMsg) >= 0 || (e.detail.errMsg.indexOf("frequency") > 0 || o.frequency.indexOf(e.detail.errMsg) >= 0 ? (n.frxs.alert({
                content: "授权过于频繁，请使用手机号+短信验证码登录"
            }), r.triggerEvent("wxLoginFail")) : (n.frxs.alert({
                content: "如未授权，您可尝试使用手机号+短信验证码登录"
            }), r.triggerEvent("wxLoginFail")));
        },
        onTapOpenTypeBtn: function() {
            this.openTypeBtnDisabled = !0, this.setData({
                _btnTapDisabeld: !0
            });
        },
        onLogin: function() {
            this.data._btnTapDisabeld || (this.setData({
                _btnTapDisabeld: !0
            }), this.showDialog("onLogin"));
        },
        onPhone: function() {
            var e = this;
            if (!this.data._btnTapDisabeld && (this.setData({
                _btnTapDisabeld: !0
            }), !this.showDialog("onPhone"))) {
                var t = {};
                try {
                    var a = getCurrentPages().slice(-1)[0];
                    t = ~a.route.indexOf("subLogin/pages/login/index") ? a.options : {
                        ret: a.route
                    };
                } catch (e) {}
                wx.$CG.$tran.open({
                    pageName: "telLogin",
                    moduleName: "login",
                    query: t
                }), setTimeout(function() {
                    e.data._btnTapDisabeld && e.setData({
                        _btnTapDisabeld: !1
                    });
                }, 500);
            }
        },
        onPopupConfirm: function() {
            this.setData({
                read: !0,
                _btnTapDisabeld: !1,
                showPopup: !1
            }), this[this.data.showDialogType]();
        },
        showDialog: function(e) {
            return !this.data.read && (this.setData({
                showPopup: !0,
                showDialogType: e
            }), !0);
        },
        onClosePopup: function() {
            var e = this;
            this.setData({
                showPopup: !1
            }), setTimeout(function() {
                e.data._btnTapDisabeld && e.setData({
                    _btnTapDisabeld: !1
                });
            }, 500);
        },
        onPreviewFile: function(e) {
            t.memberApi.getFileSummary({
                platformType: "MEMBER_MINI"
            }, {
                loading: "下载中",
                contentType: "application/json"
            }).then(function(t) {
                try {
                    var i = {
                        protocol: "兴盛优选用户服务协议",
                        privacy: "兴盛优选隐私政策"
                    }, n = e.currentTarget.dataset.type, r = void 0 === n ? "protocol" : n, o = "", s = "";
                    t.some(function(e) {
                        if ("协议及隐私政策" === e.categoryName) {
                            var t = i[r];
                            e.detailList.some(function(e) {
                                return e.qualificationName === t && (o = e.fileUrl, s = e.fileType), e.qualificationName === t;
                            });
                        }
                        return "协议及隐私政策" === e.categoryName;
                    }), o && ("PDF" === s ? wx.downloadFile({
                        url: o,
                        success: function(e) {
                            e.tempFilePath && wx.openDocument({
                                filePath: e.tempFilePath
                            });
                        }
                    }) : "HTML" === s ? a.default.navigateTo({
                        path: "/pages/users/h5url/index",
                        query: {
                            url: o
                        }
                    }) : wx.previewImage({
                        urls: [ o ]
                    }));
                } catch (e) {}
            });
        }
    }
});