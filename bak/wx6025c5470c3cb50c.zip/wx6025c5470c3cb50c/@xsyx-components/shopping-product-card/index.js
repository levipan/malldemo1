var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/numberPrecision.js")), e = getApp();

e.XComponent({
    __page: !0,
    properties: {
        version: {
            type: String,
            value: "v1"
        },
        layout: {
            type: String,
            value: "row"
        },
        product: {
            type: Object,
            value: {},
            observer: function(t) {
                t && this.initProduct(t);
            }
        },
        size: {
            type: String,
            value: "small"
        },
        pointType: String,
        singleCoupon: {
            type: Object,
            value: {},
            observer: function(t, e) {
                console.log("单品券", t, e), t && this.initCouponInfo(t);
            }
        }
    },
    data: {
        productStatus: "NORMAL",
        serviceFlagList: [],
        propertyFlagImgList: [],
        preSaleTime: "",
        pointTypeMap: {
            cateYBEnter: {
                from: "brand_dj",
                inner: 1,
                i_type: "brand_shopping_button"
            },
            adsDetailRankList: {
                from: "list_hot_sales_dj",
                inner: 1,
                i_type: "list_hot_sales_dj"
            },
            detailRecommend: {
                from: "recommend_guesslike",
                inner: 1,
                i_type: "ad_001020"
            },
            ofenbuyRecommend: {
                from: "recommend_guesslike",
                inner: 1,
                i_type: "ad_001024"
            },
            tmCateProduct: {
                from: "brand_page_dj"
            },
            searchRecommend: {
                from: "search_recommend",
                inner: 1,
                i_type: "ad_001032"
            },
            search: {
                from: "search",
                inner: 6,
                i_type: "ad_001030"
            }
        },
        couponAfterPrice: ""
    },
    methods: {
        initProduct: function(t) {
            var o = this.getProductStatus(t);
            if (this.setData({
                productStatus: o
            }), "PRE_SALE" === o) {
                var r = e.frxs.formaterDate(t.tmBuyStart, "MM月dd日 hh:mm") + "开售";
                this.setData({
                    preSaleTime: r
                });
            }
            this.handleCouponInfo(t), this.handlerTagInfo(t);
        },
        getProductStatus: function(t) {
            var e = "NORMAL", o = t.tmBuyStart, r = void 0 === o ? "" : o;
            if (r) {
                var n = new Date().getTime();
                new Date(r.replace(/-/g, "/")).getTime() >= n && (e = "PRE_SALE");
            }
            return e;
        },
        handleCouponInfo: function(t) {
            var e = [], o = (t || {}).eskuSnFlag;
            (o = o || {}).couponFlag && "v1" === this.data.version && e.push("满".concat(o.couponFlag.orderAmountLimit, "减").concat(o.couponFlag.amount)), 
            o.propertyFlag && "v2" === this.data.version && (e = e.concat(o.propertyFlag)), 
            o.serviceFlag && (e = e.concat(o.serviceFlag));
            this.setData({
                serviceFlagList: e.splice(0, {
                    v1: 2,
                    v2: 3
                }[this.data.version])
            });
        },
        handlerTagInfo: function(t) {
            var e = [], o = (t || {}).eskuSnFlag;
            (o = o || {}).propertyFlag && o.propertyFlag.length && (o.propertyFlag.map(function(t) {
                "上新" === t ? e.push("https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/yhc/home/home_label1.png") : "热销" === t ? e.push("https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/yhc/home/home_label2.png") : -1 != t.indexOf("折") ? e.push("https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/yhc/home/home_label3.png") : "包邮" === t ? e.push("https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/yhc/home/home_label4.png") : "现货" === t && e.push("https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/yhc/home/home_label5.png");
            }), this.setData({
                propertyFlagImgList: e
            }));
        },
        initCouponInfo: function(e) {
            var o = e.amount, r = e.orderAmountLimit, n = this.data.product.saleAmt;
            if (r <= n) {
                var a = 1 * t.default.keepDecimal(t.default.minus(n, o), 2);
                this.setData({
                    couponAfterPrice: a
                });
            }
        },
        onExposureCard: function() {
            var t = this.data, e = t.product, o = void 0 === e ? {} : e, r = t.productStatus, n = void 0 === r ? "NORMAL" : r;
            this.triggerEvent("exposure", {
                product: o,
                productStatus: n
            });
        },
        onClickProductCard: function() {
            var t = this.data, o = t.product, r = void 0 === o ? {} : o, n = t.productStatus, a = void 0 === n ? "NORMAL" : n, i = r.spuSn, s = void 0 === i ? "" : i, p = r.eskuSn, u = void 0 === p ? "" : p;
            this.triggerEvent("clickCard", {
                product: r,
                productStatus: a
            });
            var c = {
                spuSn: s,
                eskuSn: u
            };
            if (this.data.pointType) {
                var d = this.data, h = d.pointTypeMap, l = d.pointType;
                c.from = h[l].from;
                try {
                    e.frxs.setMData("inner", {
                        i: "1",
                        i_type: h[l].i_type
                    });
                } catch (t) {}
            }
            wx.$route.navigateTo({
                name: "home-goods-detail",
                query: c
            });
        }
    }
});