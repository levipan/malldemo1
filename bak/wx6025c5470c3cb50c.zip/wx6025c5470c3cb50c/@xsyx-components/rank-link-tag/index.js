Component({
    properties: {
        product: {
            type: Object,
            value: {}
        },
        size: {
            type: String,
            value: "s26"
        },
        theme: {
            type: String,
            value: "hot"
        }
    },
    data: {
        icons: {
            hot: "https://front-xps-cdn.xsyx.xyz/2022/01/04/1407067506.png",
            often: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/search/rank-often-icon.png?imageMogr2/format/webp",
            new: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/search/rank-new-icon.png?imageMogr2/format/webp"
        },
        arrows: {
            hot: "https://front-xps-cdn.xsyx.xyz/2022/01/04/1905496554.png",
            often: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/search/rank-often-arrow.png?imageMogr2/format/webp",
            new: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/search/rank-new-arrow.png?imageMogr2/format/webp"
        },
        colors: {
            hot: "c-e78043",
            often: "c-ff0000",
            new: "c-2d9800"
        }
    },
    methods: {
        mainClick: function() {
            this.triggerEvent("goRankList", this.data.product);
        }
    }
});