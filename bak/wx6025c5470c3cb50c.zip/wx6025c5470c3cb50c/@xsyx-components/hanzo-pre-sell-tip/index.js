Component({
    properties: {
        styles: {
            type: Object,
            value: {}
        },
        title: {
            type: String
        },
        hours: {
            type: String
        },
        minute: {
            type: String,
            value: "30"
        },
        second: {
            type: String,
            value: "59"
        },
        newIndex: Boolean
    },
    data: {},
    methods: {}
});