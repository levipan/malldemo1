var e = require("../../../@babel/runtime/helpers/interopRequireWildcard")(require("../../../utils/events.js")), t = require("../../../const/storage.key.js"), i = require("../../../api/index.js"), a = getApp();

module.exports = Behavior({
    data: {
        isLive: !1,
        liveDetail: {}
    },
    attached: function() {
        e.default.on(e.EVENTS.UPDATE_NAV_LIVEICON, this.updateLiveIcon, this);
    },
    detached: function() {
        e.default.remove(e.EVENTS.UPDATE_NAV_LIVEICON, this);
    },
    methods: {
        timer: 0,
        loadLiveTime: 0,
        getLives: function() {
            this.data.areaId && (a.globalData[t.STORAGE_KEY.LAST_LOAD_NAV] = +new Date(), i.videoApi.getNavigationIcon({
                areaId: this.data.areaId
            }, {}).then(function(i) {
                var s = i || [];
                s.map(function(e) {
                    e.startTimeTs = +a.frxs.strToDate(e.tmDisplayStart), e.endTimeTs = +a.frxs.strToDate(e.tmDisplayEnd), 
                    e.guid = a.frxs.newGuid();
                }), a.globalData[t.STORAGE_KEY.NAV_LIVE_DATA] = s, e.default.emit(e.EVENTS.UPDATE_NAV_LIVEICON, s);
            }).catch(function() {}));
        },
        updateLiveIcon: function() {
            var e = this.getLive();
            e ? this.setData({
                isLive: !0,
                liveDetail: e
            }) : this.removeLiveIcon();
        },
        removeLiveIcon: function() {
            this.setData({
                isLive: !1,
                liveDetail: {}
            });
        },
        refreshLives: function() {
            3e5 < +new Date() - (a.globalData[t.STORAGE_KEY.LAST_LOAD_NAV] || 0) && !this.data.isLive && this.getLives();
        },
        getLive: function() {
            var e = a.globalData[t.STORAGE_KEY.NAV_LIVE_DATA] || [];
            if (0 == e.length) return null;
            var i = +a.frxs.getSysDateTime();
            return e.find(function(e) {
                return e.startTimeTs <= i && i <= e.endTimeTs;
            }) || null;
        },
        refreshLiveStatus: function() {
            var e = this.getLive();
            if (e || this.data.isLive) return !e && this.data.isLive ? this.removeLiveIcon() : void (e && e.guid != this.data.liveDetail.guid && this.setData({
                isLive: !0,
                liveDetail: e
            }));
        }
    }
});