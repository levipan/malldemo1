var e = require("../../../@babel/runtime/helpers/interopRequireWildcard")(require("../../../utils/events.js")), t = require("../../../const/storage.key.js"), i = require("../../../api/index.js"), a = getApp();

module.exports = Behavior({
    properties: {},
    data: {
        videoCount: 0
    },
    attached: function() {
        e.default.on(e.EVENTS.UPDATE_NEW_VIDEOCOUNT, this.updateVideoCount, this);
    },
    detached: function() {
        e.default.remove(e.EVENTS.UPDATE_NEW_VIDEOCOUNT, this);
    },
    methods: {
        getNewVideoCount: function() {
            var o = this;
            if ("youshi" != this.data.channel) {
                var n = a.frxs.getMOrSData("userKey"), r = a.frxs.getMOrSData("isLogin"), s = a.frxs.getMOrSData(t.STORAGE_KEY.VIDEO_NAV_CLICK_TIME);
                if (n || r || !s || !(s > +a.frxs.strToDate(a.frxs.formaterDate(+new Date() - 864e5, "yyyy-MM-dd 23:00:00")))) if ("tompreview" != this.data.urlOrigin) i.videoApi.fetchIconCount({
                    userKey: n
                }, {
                    silence: !0
                }).then(function(t) {
                    e.default.emit(e.EVENTS.UPDATE_NEW_VIDEOCOUNT, t || 0), a.globalData.new_video_count = t || 0, 
                    o.setData({
                        videoCount: t || 0
                    });
                }).catch(function() {}); else {
                    var u = a.globalData.new_video_count;
                    u > 0 && this.setData({
                        videoCount: u
                    });
                }
            } else e.default.emit(e.EVENTS.UPDATE_NEW_VIDEOCOUNT, 0);
        },
        updateVideoCount: function(e) {
            this.setData({
                videoCount: e || 0
            });
        },
        videoNavClick: function() {
            e.default.emit(e.EVENTS.UPDATE_NEW_VIDEOCOUNT, 0), a.frxs.setMAndSData(t.STORAGE_KEY.VIDEO_NAV_CLICK_TIME, +new Date());
            var o = a.frxs.getMOrSData("userKey"), n = a.frxs.getMOrSData("isLogin");
            o && n && i.videoApi.fetchVdeioNavClick({
                userKey: o
            }, {
                silence: !0,
                loginVerify: !1
            }).then(function() {}).catch(function() {});
        }
    }
});