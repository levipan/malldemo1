var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/interopRequireWildcard"), a = require("../../@babel/runtime/helpers/defineProperty"), r = require("../../@babel/runtime/helpers/objectSpread2"), n = t(require("../../utils/events.js")), i = e(require("../../router/index")), s = require("../../api/index.js"), o = require("../../utils/subscribe-message"), l = require("../../utils/cartService.js"), u = getApp(), c = u.frxsConfig.ossDomain;

Component({
    behaviors: [ require("./behavior/video.js"), require("./behavior/live.js") ],
    properties: {
        channel: {
            type: String,
            value: "home"
        },
        isShowCoupon: {
            type: Boolean,
            value: !1
        },
        showBrand: {
            type: Boolean,
            value: !0
        },
        mode: {
            type: String,
            value: "normal"
        },
        isShowPage: {
            type: Boolean,
            value: !0
        },
        areaId: {
            type: Number,
            value: 0,
            observer: function(e, t, a) {
                this.areaIdObserver(e, t, a);
            }
        },
        ghostIsShowHome: {
            value: !0,
            type: Boolean
        },
        isbrandhouse: {
            type: Boolean,
            value: !1
        },
        bizStatus: {
            type: Boolean,
            value: !0,
            observer: function(e, t) {
                e != t && this.setData({
                    bizStatus: e
                });
            }
        },
        ghostLocation: {
            type: String,
            value: "left"
        },
        urlOrigin: String
    },
    data: {
        cartCount: 0,
        channel: "home",
        iphonex: !1,
        hasNewBrand: !1,
        navBar: [],
        isShow: !1,
        showYearBill: !1,
        defaultNavbar: {
            home: {
                navName: "首页",
                unSelectUrl: c + "/2020/03/20/1418631368.png",
                selectedIconUrl: c + "/2020/03/20/612927962.png",
                defUnSUrl: c + "/2020/03/20/1418631368.png",
                defSUrl: c + "/2020/03/20/612927962.png",
                previewUrl: c + "/2020/03/20/1307174023.png",
                isIconGif: !1
            },
            brand: {
                navName: "分类",
                unSelectUrl: c + "/2019/09/07/1128533121.gif",
                selectedIconUrl: c + "/2019/09/07/360339924.png",
                defUnSUrl: c + "/2019/09/07/1128533121.gif",
                defSUrl: c + "/2019/09/07/360339924.png",
                previewUrl: c + "/2020/03/20/1706792037.png",
                isIconGif: !0
            },
            youshi: {
                navName: "拿手菜",
                unSelectUrl: c + "/2020/05/19/1608002302.png",
                selectedIconUrl: c + "/2020/05/19/944346471.png",
                defUnSUrl: c + "/2020/05/19/1608002302.png",
                defSUrl: c + "/2020/05/19/944346471.png",
                previewUrl: c + "/2020/05/19/2058763949.png",
                isIconGif: !0
            },
            cart: {
                navName: "购物车",
                unSelectUrl: c + "/2020/03/20/1871271759.png",
                selectedIconUrl: c + "/2020/03/20/506325726.png",
                defUnSUrl: c + "/2020/03/20/1871271759.png",
                defSUrl: c + "/2020/03/20/506325726.png",
                previewUrl: c + "/2020/03/20/1513729996.png",
                isIconGif: !1
            },
            center: {
                navName: "我的",
                unSelectUrl: c + "/2020/03/20/283811418.png",
                selectedIconUrl: c + "/2020/03/20/883710858.png",
                defUnSUrl: c + "/2020/03/20/283811418.png",
                defSUrl: c + "/2020/03/20/883710858.png",
                previewUrl: c + "/2020/03/20/1302719499.png",
                isIconGif: !1
            },
            bgUrl: ""
        },
        bottomBlankHeignt: u.globalData.isIPhoneX ? 68 : 0,
        ossDomain: c
    },
    ready: function() {
        this.init();
    },
    attached: function() {
        var e = this, t = l.getCartNum();
        this.setData({
            cartCount: t,
            hasNewBrand: "youshi" !== this.data.channel
        }), n.default.on(n.EVENTS.ADD_CART, function() {
            e.setData({
                cartCount: l.getCartNum()
            });
        }), this.addCateShowStatusEvent(), "youshi" == this.data.channel ? this.videoNavClick() : this.getNewVideoCount(), 
        console.info("初始化：", this.data.areaId), this.getLives(), n.default.on(n.EVENTS.REFRESH_CART, this.updateCartNum, this), 
        n.default.on("NAV_BAR_UPDATE", this.updateNavBar, this);
    },
    detached: function() {
        n.default.remove(n.EVENTS.ADD_CART), n.default.remove(n.EVENTS.REFRESH_CART, this.updateCartNum, this), 
        n.default.remove("NAV_BAR_UPDATE_" + this.data.channel), n.default.remove("NAV_BAR_UPDATE", this.updateNavBar), 
        n.default.remove(n.EVENTS.UPDATE_CATE_SHOW_STATUS);
    },
    pageLifetimes: {
        show: function() {
            var e = this;
            this.intervalTimer && clearInterval(this.intervalTimer), this.intervalTimer = setInterval(function() {
                e.refreshLiveStatus(), e.refreshLives();
            }, 1e4);
        },
        hide: function() {
            clearInterval(this.intervalTimer);
        }
    },
    methods: {
        init: function() {
            u.frxs.checkIsIphoneX() && this.setData({
                iphonex: !0
            });
        },
        updateCartNum: function() {
            var e = l.getCartNum();
            this.setData({
                cartCount: e
            });
        },
        setYearBillShow: function() {
            var e = u.frxsConfig.yearBillRange.split("||"), t = new Date(e[0]), a = new Date(e[1]), r = new Date();
            return r > t && r < a && (this.setData({
                showYearBill: !0
            }), !0);
        },
        goIndex: function() {
            var e = this.data.channel;
            this.triggerEvent("goIndex"), "brand" == e && u.frxs.XSMonitor.sendEvent("gohomebynavbar"), 
            "home" != e ? (u.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "底部栏_首页"
            }), i.default.switchTab({
                path: "/pages/home/index/index"
            }), this.onSubscribeMessage()) : this.triggerEvent("back-to-top");
        },
        goBrand: function() {
            this.triggerEvent("goBrand"), "brand" != this.data.channel && (u.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "底部栏_分类"
            }), i.default.switchTab({
                path: "/pages/home/cateProduct/index"
            }), this.onSubscribeMessage());
        },
        goCart: function() {
            if (this.triggerEvent("goCart"), "cart" != this.data.channel) {
                u.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "底部栏_购物车"
                });
                var e = getCurrentPages()[getCurrentPages().length - 1];
                e.setData({
                    loginSuccessToPage: "cart"
                }), i.default.switchTab({
                    path: "/pages/home/cart/cart",
                    meta: {
                        showGetPhoneNumber: function() {
                            -1 == u.frxs.compareVersion("1.2.0") ? i.default.navigateTo({
                                path: "/subPages/users/loginstep2/loginstep2"
                            }) : e.setData({
                                isShowGetPhoneNumber: !0,
                                loginSuccessToPage: "cart"
                            });
                        }
                    }
                }), this.onSubscribeMessage();
            }
        },
        goCenter: function() {
            if (this.triggerEvent("goCenter"), "center" != this.data.channel) {
                u.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "底部栏_我的"
                });
                var e = getCurrentPages()[getCurrentPages().length - 1];
                e.setData({
                    loginSuccessToPage: "center"
                }), i.default.switchTab({
                    path: "/pages/users/center/center",
                    meta: {
                        showGetPhoneNumber: function() {
                            -1 == u.frxs.compareVersion("1.2.0") ? i.default.navigateTo({
                                path: "/subPages/users/loginstep2/loginstep2"
                            }) : e.setData({
                                isShowGetPhoneNumber: !0,
                                loginSuccessToPage: "center"
                            });
                        }
                    }
                }), this.onSubscribeCenterPageMessage();
            }
        },
        goYoushi: function() {
            this.triggerEvent("goYoushi"), "youshi" != this.data.channel && (u.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "底部栏_兴盛优视"
            }), i.default.navigateTo({
                path: "/pages/video/index/index"
            }), this.onSubscribeMessage());
        },
        loadedAreaId: 0,
        areaIdObserver: function(e, t) {
            if (e != t) {
                var a = e > 0 ? e : u.frxs.getMOrSData("areaId") || 0;
                this.loadedAreaId != a && (this.loadedAreaId = a, this.getNavbar(a), this.getLives(a));
            }
        },
        getNavbar: function(e) {
            var t = this, a = this.getClientValidNavbar(e), r = wx.getStorageSync("storeId");
            if (a) this.renderData(a); else if (r) {
                var n = {
                    areaId: e || this.data.areaId,
                    storeId: r
                };
                s.brandHousePromotionApi.fetchQueryFootNav(n, {
                    silence: !0
                }).then(function(a) {
                    t.jxNavbarData(a, e);
                }).catch(function() {
                    t.renderData(t.getClientNavbar(e));
                });
            } else this.renderData(this.data.defaultNavbar);
        },
        getClientNavbar: function(e) {
            var t = u.frxs.constDefinition.storageKey.NAVBARDATA + e, a = u.frxs.getMOrSData(t);
            return a && a.data ? (a.data.bgUrl = "", a.data) : this.data.defaultNavbar;
        },
        getClientValidNavbar: function(e) {
            return e ? null : this.data.defaultNavbar;
        },
        jxNavbarData: function(e, t) {
            var a = this.getClientNavbar(t), i = u.frxs.constDefinition.storageKey.NAVBARDATA + t, s = (e || {}).navItem || [];
            if (s.length > 0) {
                var o = {
                    home: "CHOICE",
                    brand: "BRAND_HOUSE",
                    cart: "SHOP_CAR",
                    center: "MY",
                    youshi: "UTV"
                };
                Object.keys(o).map(function(t) {
                    a[t] = r(r(r({}, a[t]), s.find(function(e) {
                        return e.navCode == o[t];
                    }) || {}), {}, {
                        defConfig: !e.hasOwnProperty("defaultConfig") || e.defaultConfig
                    });
                }), a.bgUrl = (e || {}).backgroundUrl || "";
                var l = {
                    dtime: +new Date(),
                    data: a
                };
                u.frxs.setMAndSData(i, l), n.default.emit("NAV_BAR_UPDATE", l.data);
            } else {
                var c = {
                    dtime: +new Date(),
                    data: a
                };
                u.frxs.setMAndSData(i, c);
            }
            this.renderData(a);
        },
        renderData: function(e) {
            for (var t in e) if (e[t].unSelectUrl) {
                var a = e[t].unSelectUrl;
                e[t].isIconGif = "gif" == a.substring(a.lastIndexOf(".") + 1);
            }
            var r = Object.assign({}, e, {});
            this.setYearBillShow(), this.setData({
                isShow: !0,
                navBar: r
            });
        },
        updateNavBar: function(e) {
            this.data.isShowPage || this.renderData(e);
        },
        imgError: function(e) {
            var t = e.currentTarget.dataset, r = t.imgnode, n = t.errorurl;
            n && this.setData(a({}, "navBar." + r, n));
        },
        addCateShowStatusEvent: function() {
            var e = this;
            n.default.on(n.EVENTS.UPDATE_CATE_SHOW_STATUS, function(t) {
                e.data.showBrand != t && e.setData({
                    showBrand: t
                });
            });
        },
        onSubscribeMessage: function() {
            var e = u.frxsConfig.tmplIds;
            if (e) {
                var t = [ e.productBuy, e.pick, e.productReminder ];
                (0, o.allowedSubscribe)(t);
            }
        },
        onSubscribeCenterPageMessage: function() {
            if (u.frxs.getMOrSData("isLogin")) {
                var e = function() {
                    console.log("sendMessage--\x3e推送");
                    var e = {
                        operationTime: new Date().getTime()
                    };
                    u.frxs.setStorageSync("centerMessageData", e);
                    var t = u.frxsConfig.tmplIds;
                    if (t) {
                        var a = [ t.productBuy, t.coupouOverdue, t.commodityReduction ];
                        (0, o.onRequestSubscribeMessage)(a);
                    }
                };
                try {
                    var t = u.frxs.getStorageSync("centerMessageData");
                    if (t) {
                        var a = t.operationTime;
                        new Date(a).toDateString() !== new Date().toDateString() ? e() : console.log("当天不推送...");
                    } else e();
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.log("onSubscribeCenterPageMessage--\x3eerror", e);
                }
            }
        }
    }
});