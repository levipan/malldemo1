var t = require("../../utils/product"), e = require("../../utils/index"), r = getApp();

Component({
    properties: {
        key: String,
        product: {
            type: Object,
            value: {},
            observer: function(t) {
                if (t) {
                    var e = JSON.parse(JSON.stringify(t));
                    e.martketActivity || (e.martketActivity = {}), e.martketActivity.productImg = wx.$._get(t, "productMarkAtmosphere.productCorsetCornerMark.productImg", ""), 
                    e.martketActivity.martketActivityCoupons = wx.$._get(t, "productMarkAtmosphere.martketActivityCoupons", []), 
                    e.productNameCornerMark = wx.$._get(t, "productMarkAtmosphere.productNameCornerMark", []), 
                    this.setData({
                        _product: e
                    });
                }
            }
        },
        cartCount: Number,
        ticketDetail: Object,
        modal: String,
        itemIndex: Number,
        isExposure: {
            type: Boolean,
            value: !1
        },
        status: {
            type: String,
            value: t.PRODUCT_STATUS.ACTIVE,
            observer: function(t) {
                this.handlePreStatusText(this.data.product, t);
            }
        }
    },
    data: {
        statusText: "",
        _product: {}
    },
    ready: function() {
        this.data.isExposure && this.exposure();
    },
    methods: {
        handlePreStatusText: function(r, i) {
            if (i === t.PRODUCT_STATUS.WAITING) {
                var a = this.now(), s = (r || {}).tmBuyStart;
                if (s) {
                    var o = (0, e.timeName)(a, (0, e.strToTs)(s));
                    this.setData({
                        statusText: o + "开抢"
                    });
                }
            }
        },
        now: function() {
            return +new Date() + (r.frxs.getMOrSData("timeDiffServerAndClient") || 0);
        },
        exposure: function() {
            var t = this;
            try {
                var e = wx.createIntersectionObserver().relativeToViewport();
                this.cmsObserve = e, e.observe("#cms-product-item_".concat(this.data.itemIndex), function(e) {
                    e.intersectionRatio > 0 && (t.triggerEvent("exposure", {
                        key: t.data.key,
                        item: t.data,
                        index: t.data.itemIndex
                    }), t.cmsObserve && t.cmsObserve.disconnect());
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log(t, "err");
            }
        },
        toProductDetail: function() {
            this.triggerEvent("to-product-detail", {
                key: this.data.key,
                item: this.data,
                index: this.data.itemIndex
            });
        },
        onAdd: function(t) {
            this.setData({
                swipeX: 0
            }), this.triggerEvent("cart-add", {
                val: t.detail,
                key: this.data.key,
                item: this.data,
                index: this.data.itemIndex
            });
        },
        onReduce: function(t) {
            this.setData({
                swipeX: 0
            }), this.triggerEvent("cart-reduce", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        }
    }
});