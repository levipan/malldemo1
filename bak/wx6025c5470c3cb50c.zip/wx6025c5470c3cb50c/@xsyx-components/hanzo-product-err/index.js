var o = getApp();

Component({
    properties: {
        pageErrorMsg: {
            type: Object,
            value: {}
        },
        storeStatus: {
            type: String,
            value: ""
        },
        storeIsLocked: {
            type: Boolean,
            value: !1
        },
        isShowYoushiBanner: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isIPhoneX: o.globalData.isIPhoneX,
        ossDomain: o.frxsConfig.ossDomain
    },
    methods: {
        goToSwitchStore: function() {
            this.triggerEvent("goToSwitchStore");
        },
        goToHistoryStore: function() {
            this.triggerEvent("goToHistoryStore");
        },
        toYoushi: function() {
            this.triggerEvent("goToYoushi");
        }
    }
});