var e = getApp();

Component({
    properties: {
        isExposure: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        DOMId: ""
    },
    ready: function() {
        this.data.isExposure && this.setData({
            DOMId: e.frxs.newGuid()
        }, this.exposure);
    },
    detached: function() {
        try {
            this.data.isExposure && this.productObserve.disconnect();
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.log(e);
        }
    },
    methods: {
        exposure: function() {
            var e = this;
            try {
                var t = this.createIntersectionObserver().relativeToViewport();
                this.productObserve = t, t.observe(".e".concat(this.data.DOMId), function(t) {
                    t.intersectionRatio > 0 && e.triggerEvent("exposure");
                });
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log(e);
            }
        }
    }
});