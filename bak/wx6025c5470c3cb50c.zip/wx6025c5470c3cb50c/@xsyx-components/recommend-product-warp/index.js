Component({
    properties: {
        showWarp: Boolean,
        userInfo: {
            type: Object,
            value: {
                nickName: "",
                headerImage: ""
            }
        },
        userName: String,
        userAvatar: String
    },
    data: {},
    methods: {}
});