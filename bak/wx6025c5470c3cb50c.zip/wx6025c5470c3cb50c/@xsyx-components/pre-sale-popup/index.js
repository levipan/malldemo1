var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../router/index.js")), e = require("../../behavior/newCouponLink.js"), i = require("../../utils/datetime.js"), o = getApp();

o.XComponent({
    __page: !0,
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        products: {
            type: Object,
            value: [],
            observer: function(t) {
                !this.data.show && (t || []).length > 0 && this.setData({
                    show: !0
                });
            }
        },
        pickDate: String,
        preSaleTime: String,
        inPreSaleTime: {
            type: Boolean,
            value: null,
            observer: function(t) {
                this.setShowClickMask(t);
            }
        }
    },
    data: {
        couponStatusMap: {},
        showClickMask: !1,
        prePopupShow: !1
    },
    lifetimes: {
        attached: function() {
            this.firstInitTime || (this.firstInitTime = Date.now());
        }
    },
    watch: {
        showClickMask: function(t) {
            this.triggerEvent("showPrePopup", {
                value: t || this.data.prePopupShow,
                type: "showClickMask"
            });
        },
        prePopupShow: function(t) {
            this.triggerEvent("showPrePopup", {
                value: t || this.data.showClickMask,
                type: "prePopupShow"
            });
        }
    },
    methods: {
        setShowClickMask: function(t) {
            this.showPreSalePopup = this.authShowPreSalePopup(t), t && this.showPreSalePopup ? this.setData({
                showClickMask: !0
            }) : (this.setData({
                showClickMask: !1
            }), this.triggerEvent("showPrePopup", {
                value: this.data.prePopupShow || this.data.showClickMask,
                type: "setShowClickMask"
            }));
        },
        authShowPreSalePopup: function(t) {
            var e = o.frxs.formaterDate(new Date().getTime() + (o.frxs.getMOrSData("timeDiffServerAndClient") || 0), "yyyy-MM-dd");
            return !(e === o.frxs.getMOrSData("openTomorrowPopupDate") || !t) && e;
        },
        onClickPreSaleMask: function() {
            o.frxs.setMAndSData("openTomorrowPopupDate", this.showPreSalePopup), this.setData({
                showClickMask: !1,
                prePopupShow: !0
            });
        },
        authStoreEndTime: function() {
            var t = "23:00";
            try {
                t = o.frxs.getMOrSData("request_fetchSysParam")["7Z_LIMIT_TIME"].split("-")[1] || t;
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                t = "23:00";
            }
            var e = (0, i.formaterDate)((0, i.now)(), "yyyy-MM-dd"), s = (0, i.strToTs)(e + " " + t);
            return !!this.firstInitTime && 1 * s < this.firstInitTime;
        },
        toProduct: function(t) {
            if (!this.isLock) {
                this.isLock = !0;
                var i = t.currentTarget.dataset.index;
                (0, e.__toLink)(this.data.products[i]), this.triggerEvent("afterStoreEnd", this.authStoreEndTime()), 
                this.closePopup(), o.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "去使用",
                    ticket_name: this.data.products[i].toolName
                }, ""), this.isLock = !1;
            }
        },
        toCoupupList: function() {
            this.closePopup(), t.default.navigateTo({
                path: "/subPages/pages/promotionCenter/index"
            }), this.triggerEvent("afterStoreEnd", this.authStoreEndTime());
        },
        closePopup: function() {
            this.setData({
                prePopupShow: !1
            });
        },
        maskClick: function() {
            this.closePopup();
        },
        beginPreSaleMaskClick: function() {
            this.closePopup(), this.authStoreEndTime() || wx.reLaunch({
                url: o.frxsConfig.mall.page.prIndex + "?origin=tompreview"
            });
        },
        popupClick: function() {
            var t = (this.data.popupDetails || {}).link;
            if ("string" == typeof t && "true" == t.toLowerCase() && (t = !0), 1 == t) {
                if (3 == this.data.popupDetails.type) this.triggerEvent("toUrl", this.data.popupDetails); else {
                    var e = (this.data.popupDetails || {}).linkAddress || 0;
                    this.triggerEvent("goWindow", {
                        windId: e
                    });
                }
                this.closePopup();
            } else this.closePopup();
        }
    }
});