Component({
    options: {
        styleIsolation: "isolated"
    },
    properties: {
        title: {
            type: String,
            value: ""
        },
        listSubTitle: {
            type: String,
            value: []
        },
        productReminderSubscribeStatus: {
            type: String,
            value: ""
        },
        firstProductSubReminder: {
            type: Boolean,
            value: !1
        },
        todayProductSubReminder: {
            type: String,
            value: !1
        }
    },
    data: {
        iconType: "circle",
        iconColor: "#8e8e8e"
    },
    detached: function() {},
    methods: {}
});