Component({
    properties: {
        title: {
            type: "String"
        },
        iconType: {
            type: String,
            value: "default"
        },
        iconUrl: String
    },
    data: {
        iconMap: {
            default: "https://front-xps-cdn.xsyx.xyz/2021/06/24/1201005482.png",
            risk: "https://front-xps-cdn.xsyx.xyz/2021/06/24/1565184768.png"
        }
    },
    methods: {
        onClickUpdateBtn: function() {
            this.triggerEvent("click-update");
        }
    }
});