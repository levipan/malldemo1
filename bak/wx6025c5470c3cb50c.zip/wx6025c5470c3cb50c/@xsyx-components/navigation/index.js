Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        isControlBack: {
            type: Boolean,
            value: !1
        },
        customRootStyle: {
            type: String,
            value: ""
        },
        navigationBarTextStyle: {
            type: String,
            value: "black"
        },
        backgroundStyle: {
            type: String,
            desc: "注入的行内样式",
            value: ""
        },
        title: String,
        textColor: String,
        mode: {
            type: String,
            value: ""
        },
        backButton: {
            type: Boolean,
            value: !0
        },
        backPath: {
            type: String,
            value: "/pages/home/index/index"
        },
        showDefaultCustom: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        barHeight: 44,
        statusBarHeight: wx.getSystemInfoSync().statusBarHeight,
        pagesLength: null,
        showBackButton: !0
    },
    attached: function() {
        var t = this;
        this.setData({
            pagesLength: getCurrentPages().length
        }), setTimeout(function() {
            var e = t.data.barHeight + t.data.statusBarHeight - 1;
            t.triggerEvent("onUpdate", e);
        }, 100), this.onVerifyLowVersion();
    },
    methods: {
        onClickBackButton: function() {
            this.data.isControlBack ? this.triggerEvent("click-backBtn", this) : this.onBackPage();
        },
        onBackPage: function() {
            var t = this.data, e = t.backPath, a = t.pagesLength;
            (void 0 === a ? 1 : a) > 1 ? wx.navigateBack({
                delta: 1
            }) : wx.reLaunch({
                url: e || "/pages/home/index/index"
            });
        },
        onVerifyLowVersion: function() {
            var t = wx.getSystemInfoSync() || {}, e = t.SDKVersion, a = t.version, n = this.data.pagesLength, o = void 0 === n ? 1 : n, i = this.compareVersion(e, "2.4.3"), s = this.compareVersion(a, "7.0.0");
            e && a && i && s && o > 1 && this.setData({
                showBackButton: !1
            });
        },
        compareVersion: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", a = 1 * t.split(".").join(""), n = 1 * e.split(".").join("");
            return a <= n;
        }
    }
});