var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = (e(require("../../xapp/runtime")), 
require("../../api/index")), o = e(require("../../router/index")), s = getApp();

Component({
    properties: {
        showTreasurePop: Boolean,
        countTime: Object,
        treasureStatus: Number,
        openBoxStatus: Number,
        treasureConfig: Object
    },
    data: {
        rewardInfo: {},
        isNotBuy: !1
    },
    methods: {
        onOpenTreasureBox: function() {
            var e = this;
            if (!this._openBoxlock) {
                var o = s.frxs.getMOrSData("userKey");
                if (!o) return;
                this._openBoxlock = !0;
                var r = this.properties.treasureConfig, n = r.mktActivityCode, a = r.sessions, i = r._difftime, u = r.systemTimestamp;
                t.couponApi.postOpenTreasure({
                    userKey: o,
                    sceneCode: "CBX",
                    activityCode: n,
                    sessions: a,
                    blackBox: s.frxs.storage("safe_bb") || ""
                }, {
                    contentType: "application/json",
                    silence: !0,
                    loading: "开箱中"
                }).then(function(t) {
                    setTimeout(function() {
                        e._openBoxlock = !1;
                    }, 2e3);
                    var o = (t || {}).applyResult, r = void 0 !== o && o;
                    if (r) {
                        var n = s.frxs.formaterDate(Date.now() + i, "hh") >= 23;
                        e.setData({
                            rewardInfo: t,
                            isNotBuy: n
                        }), e.setMandSForTreasure(u);
                    } else s.frxs.showToast({
                        title: "开箱失败"
                    });
                    e.triggerEvent("open-box", {
                        status: r,
                        config: e.data.treasureConfig
                    });
                }).catch(function(t) {
                    setTimeout(function() {
                        e._openBoxlock = !1;
                    }, 2e3), "FE19831006010" === t.rspCode && e.setMandSForTreasure(u), e.triggerEvent("open-box", {
                        status: !1,
                        config: e.data.treasureConfig
                    }), s.frxs.showToast({
                        title: t.rspDesc || "开箱失败"
                    });
                });
            }
        },
        setMandSForTreasure: function(e) {
            var t = s.frxs.getMOrSData("treasure") || {};
            t[this.properties.treasureConfig.sessions] = {
                status: !0,
                time: s.frxs.formaterDate(e, "yyyy-MM-dd")
            }, s.frxs.setMAndSData("treasure", t);
        },
        onCloseTreasurePop: function() {
            this.triggerEvent("on-close"), 2 == this.properties.treasureStatus && s.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "关闭抢兴币宝箱弹窗"
            }, "");
        },
        onGoBuy: function() {
            this.onCloseTreasurePop(), o.default.switchTab({
                path: "/pages/home/index/index"
            });
        },
        onLookProduct: function() {
            this.onCloseTreasurePop();
        },
        onLookXinxin: function() {
            this.onCloseTreasurePop(), o.default.navigateTo({
                path: "/subPages/pages/star/detail/index"
            });
        }
    }
});