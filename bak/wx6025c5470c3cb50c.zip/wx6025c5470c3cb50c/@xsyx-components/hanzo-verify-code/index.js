var t = require("../../api/index.js"), e = wx.getSystemInfoSync().windowWidth / 750, n = "https://front-xps-cdn.xsyx.xyz/2019/12/05/1835210908.png", s = 0, r = getApp();

Component({
    properties: {},
    data: {
        dragX: 0,
        initX: 0,
        result: "",
        bgImgUrl: n,
        parsent: 0,
        progressWidth: 0,
        codeMoveY: 0,
        errMsg: "图片验证失败",
        ossDomain: "https://front-xps-cdn.xsyx.xyz/"
    },
    startX: 0,
    renderT: 0,
    parsent: 0,
    isFrozen: !1,
    attached: function() {
        this.init();
    },
    methods: {
        init: function() {
            var e = this;
            t.turingApi.getTuringTestDataByUserKey({}, {
                silence: !0
            }).then(function(t) {
                n = t.bigPicUrl, e.setData({
                    bgImgUrl: n,
                    codeImg: t.smallPicUrl,
                    codeMoveY: t.y,
                    dragX: 0
                }, function() {
                    s = new Date();
                });
            }).catch(function(t) {
                t.data || (n = "https://front-xps-cdn.xsyx.xyz/2019/12/05/519800220.png"), e.setData({
                    bgImgUrl: n,
                    codeImg: ""
                }), "FE10031998001" === t.rspCode && r.aldstat.sendEvent("验证码错误超过错误频次,前端展示"), "FE10031999996" === t.rspCode ? (e.success("fallback"), 
                e.closeView()) : e.fail(t.rspDesc || "网络异常，稍后再试！", !0);
            });
        },
        closeView: function() {
            this.triggerEvent("close-verify");
        },
        verifyTouchmove: function(t) {
            var n = t.detail.x - 0;
            n = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, n = t, s = 490 * e, r = 0;
                return n = Math.max(r, n), n = Math.min(s, n);
            }(n), n /= e;
            var s = (n = parseInt(n)) / 610 * 100;
            s = parseInt(s), console.log("parsent:" + s), console.log("this.parsent" + this.parsent), 
            s != this.parsent ? (this.parsent = s, this.startX = n, this.updateRender()) : console.log("abort");
        },
        updateRender: function() {
            var t = this;
            this.renderT || (this.renderT = setTimeout(function() {
                var e = t.startX, n = t.parsent;
                t.setData({
                    dragX: e,
                    parsent: n
                }, function() {
                    t.renderT = null;
                });
            }, 100));
        },
        success: function(t) {
            var e = this;
            this.setData({
                result: "true"
            }, function() {
                s = new Date() - s, s = parseInt(s / 1e3), setTimeout(function() {
                    e.triggerEvent("sure-order", {
                        token: t
                    });
                }, 1e3);
            });
        },
        fail: function(t) {
            var e = this, n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            this.setData({
                result: "false",
                errMsg: t
            }, function() {
                setTimeout(function() {
                    e.setData({
                        result: "",
                        dragX: 0,
                        initX: 0
                    }, function() {
                        n || e.init();
                    });
                }, 800);
            });
        },
        verifyTouchend: function() {
            var e = this, n = this.startX, s = this.data.codeMoveY;
            this.canDrag = !1, this.isFrozen = !0;
            var r = function(t) {
                var e = t, n = parseInt(1e3 * Math.random()), s = parseInt(1e4 * Math.random());
                return n = (n = "111" + n).substr(-3), s = (s = "1111" + s).substr(-4), e = (e = "000" + e).substr(-3), 
                +(e = "".concat(n).concat(e).concat(s));
            }(n), a = function(t) {
                var e = t, n = parseInt(1e4 * Math.random()), s = parseInt(1e3 * Math.random());
                return n = (n = "1111" + n).substr(-4), s = (s = "111" + s).substr(-3), e = (e = "000" + e).substr(-3), 
                +(e = "".concat(n).concat(e).concat(s));
            }(s);
            t.turingApi.verifyPic({
                name: r,
                date: a
            }, {
                silence: !0
            }).then(function(t) {
                e.isFrozen = !1, e.success(t);
            }).catch(function(t) {
                e.isFrozen = !1, "FE10031999996" === t.rspCode ? (e.success("fallback"), e.closeView()) : e.fail(t.rspDesc || "网络异常，稍后再试！");
            });
        }
    }
});