Component({
    properties: {
        customStyle: {
            type: String,
            desc: "注入的行内样式",
            value: ""
        },
        color: {
            type: String,
            desc: "徽标颜色",
            value: "#E60012"
        },
        count: {
            type: Number,
            desc: "徽标数"
        },
        overflowCount: {
            type: Number,
            desc: "展示封顶的数字值",
            value: 99
        }
    }
});