Component({
    properties: {
        ossDomain: {
            type: String
        },
        loadText: {
            type: String,
            value: "加载中..."
        },
        size: {
            type: Number,
            value: 36
        }
    },
    data: {},
    methods: {}
});