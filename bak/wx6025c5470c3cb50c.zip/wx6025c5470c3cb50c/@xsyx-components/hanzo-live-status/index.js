var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../const/live-play-statusName.js")), t = require("../../utils/productLive.js");

Component({
    properties: {
        statusValue: {
            type: String,
            value: "",
            observer: function(e) {
                console.log("val", e);
            }
        },
        statusName: {
            type: String,
            value: ""
        },
        zIndex: {
            type: Number,
            value: 100
        },
        liveInfo: {
            type: Object,
            observer: function(e) {
                if (e && "NOT_STARTED" === e.tvStatus && e.preStartTime) {
                    var a = (0, t.formatNewLiveStartTime)(e.preStartTime);
                    this.setData({
                        statusName: a
                    });
                }
            }
        },
        extendClass: String
    },
    data: {
        liveStatusName: e.default
    }
});