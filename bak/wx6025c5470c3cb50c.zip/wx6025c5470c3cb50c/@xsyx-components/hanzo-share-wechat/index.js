var t = getApp();

Component({
    properties: {},
    data: {
        url: t.frxsConfig.userDomain,
        ossDomain: t.frxsConfig.ossDomain,
        showBtn: !0
    },
    attached: function() {},
    methods: {
        posterExit: function() {
            this.setData({
                showBtn: !1
            }), this.triggerEvent("shareClose");
        }
    }
});