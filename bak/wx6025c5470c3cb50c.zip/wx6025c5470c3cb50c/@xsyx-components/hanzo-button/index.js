Component({
    externalClasses: [ "h-class" ],
    properties: {
        modal: {
            type: String,
            value: ""
        },
        type: {
            type: String,
            value: "primary"
        },
        inline: {
            type: Boolean,
            value: !1
        },
        size: {
            type: String,
            value: "default"
        },
        shape: {
            type: String,
            value: "circle"
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        loading: {
            type: Boolean,
            value: !1
        },
        long: {
            type: Boolean,
            value: !1
        },
        openType: String,
        appParameter: String,
        hoverStopPropagation: Boolean,
        hoverStartTime: {
            type: Number,
            value: 20
        },
        hoverStayTime: {
            type: Number,
            value: 70
        },
        lang: {
            type: String,
            value: "en"
        },
        sessionFrom: {
            type: String,
            value: ""
        },
        sendMessageTitle: String,
        sendMessagePath: String,
        sendMessageImg: String,
        showMessageCard: Boolean,
        noMargin: Boolean,
        btnStyle: String
    },
    methods: {
        handleTap: function() {
            if (this.data.disabled) return !1;
            this.triggerEvent("onTap");
        },
        bindgetuserinfo: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.detail, n = void 0 === t ? {} : t;
            this.triggerEvent("onGetUserInfo", n);
        },
        bindcontact: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.detail, n = void 0 === t ? {} : t;
            this.triggerEvent("onContact", n);
        },
        bindgetphonenumber: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.detail, n = void 0 === t ? {} : t;
            this.triggerEvent("onGetPhoneNumber", n);
        },
        binderror: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.detail, n = void 0 === t ? {} : t;
            this.triggerEvent("onError", n);
        }
    }
});