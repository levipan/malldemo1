var e = getApp();

Component({
    properties: {
        phone: {
            type: String,
            value: e.frxsConfig.serviceTel
        },
        bodyStyle: {
            type: String,
            value: ""
        },
        msg: {
            type: String,
            value: "您在使用兴盛优选过程中有任何问题，欢迎致电咨询，我们将竭诚为您服务！"
        }
    },
    data: {
        ossDomain: e.frxsConfig.ossDomain
    },
    methods: {
        phoneCall: function() {
            this.triggerEvent("onClick"), wx.makePhoneCall({
                phoneNumber: this.data.phone
            });
        }
    }
});