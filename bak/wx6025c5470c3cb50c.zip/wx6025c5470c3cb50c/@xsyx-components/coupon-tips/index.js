var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = (e(require("../../xapp/runtime")), 
require("../../utils/index")), o = e(require("../../router/index")), r = getApp();

r.XComponent({
    __page: !0,
    useConfig: !1,
    properties: {
        zIndex: {
            type: Number,
            value: 1
        },
        moduleConfig: {
            type: Object,
            value: {}
        },
        bottomStep: {
            type: String,
            value: "138"
        },
        bottomXStep: {
            type: String,
            value: "206"
        },
        bottom: {
            type: String,
            value: "114"
        },
        bottomX: {
            type: String,
            value: "182"
        },
        couponTipsStatus: {
            type: Boolean,
            value: !1
        },
        couponList: {
            type: Object,
            value: {},
            observer: function(e) {
                var t = e;
                if (0 !== (t = t || []).length) {
                    var o = [];
                    t.forEach(function(e) {
                        "DISCOUNT" === e.toolType && (e.fracture = e.maxDiscount / 10), o.push(e);
                    });
                    this.$forEach([], function(e) {
                        return function(e) {
                            try {
                                var t = e.startTime, o = e.endTime, i = e.areaId;
                                i *= 1;
                                var s = Date.now() + (r.frxs.getMOrSData("timeDiffServerAndClient") || 0);
                                if (s < +new Date(t) || s > +new Date(o)) return !1;
                                if (1 * r.frxs.getMOrSData("areaId") !== i && -1 !== i) return !1;
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.error(e);
                            }
                            return !1;
                        }(e);
                    }), this.setState({
                        isShowWholeProductTips: !wx.$.storage.get("closeWholeProductTips"),
                        list: o
                    });
                }
            }
        }
    },
    data: {
        isIPhoneX: t.isIPhoneX
    },
    methods: {
        onShow: function() {
            this.setState({
                isLogin: r.frxs.isLogin(),
                isShowWholeProductTips: !wx.$.storage.get("closeWholeProductTips"),
                hasGetCouponList: wx.$.storage.get("hasGetCouponList")
            });
        },
        onOpenCoupon: function() {
            if (r.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "浮条_领券"
            }, ""), !r.frxs.isLogin()) return r.frxs.toLogin();
            o.default.navigateTo({
                path: "/subPages/pages/promotionCenter/index"
            });
        },
        onCloseWholeProductTips: function() {
            this.setState({
                isShowWholeProductTips: !1
            });
            var e = 1 * wx.$.sessionStorage.get("activeCloseTime");
            e = !wx.$.isNumber(e) || e <= 0 ? 6 : e, wx.$.storage.set("closeWholeProductTips", !0, r.frxs.getFormatTime2Close(e) / 1e3), 
            r.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "关闭优惠券引导"
            }, "");
        }
    }
});