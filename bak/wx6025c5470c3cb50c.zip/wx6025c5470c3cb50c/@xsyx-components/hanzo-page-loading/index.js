var o = getApp().frxsConfig.ossDomain;

Component({
    properties: {
        show: Boolean,
        title: String,
        useSlot: Boolean,
        icon: String,
        image: String,
        iconSize: Number,
        zIndex: {
            type: Number,
            value: 1e4
        },
        bgColor: String,
        delayed: Boolean
    },
    data: {
        imgUrl: {
            success: o + "/2020/08/05/438309748.png",
            success1: o + "/2020/08/05/1940772933.png",
            cry: o + "/2020/08/05/1560007034.png",
            info: o + "/2020/08/05/1600078512.png",
            remind: o + "/2020/08/05/841290607.png",
            help: o + "/2020/08/05/1282111957.png",
            loading: o + "/2020/01/01/1700035391.gif",
            xsyxLoading: o + "/custom/shopping-vip/qugaoFiles/icons/xsyx-loading.gif"
        }
    },
    methods: {
        close: function() {
            this.setData({
                show: !1
            });
        }
    }
});