Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = (require("../../static/list/signUp"), 
[]), n = function e(n) {
    return n = Object.assign({
        delayed: !1
    }, e.defaultOptions, n), new Promise(function(e, o) {
        var i, s = (i = getCurrentPages())[i.length - 1].selectComponent(n.selector);
        return s && (s.setData(Object.assign({
            onCancel: o,
            onConfirm: e
        }, n)), t.push(s), n.duration > 0 && setTimeout(function() {
            s.close();
        }, n.duration)), s;
    });
};

n.defaultOptions = {
    show: !0,
    title: "",
    content: "",
    zIndex: 1e4,
    overlay: !0,
    asyncClose: !1,
    styleType: "",
    messageAlign: "",
    transition: "scale",
    selector: "#hanzo-loading",
    closeOnClickOverlay: !1
}, n.showLoading = function(t) {
    return "xsyxLoading" == t.icon ? n(e({
        title: "",
        iconSize: 104,
        bgColor: "none",
        icon: "xsyxLoading",
        duration: 3e4
    }, t)) : n(e({
        duration: 3e4,
        icon: "loading",
        iconSize: 60
    }, t));
}, n.showToast = function(t) {
    return n(e({
        duration: 2e3
    }, t));
}, n.close = function() {
    t.forEach(function(e) {
        e.close();
    }), t = [];
}, n.stopLoading = function() {
    t.forEach(function(e) {
        e.stopLoading();
    });
}, n.setDefaultOptions = function(e) {
    Object.assign(n.defaultOptions, e);
}, n.resetDefaultOptions = function() {
    n.defaultOptions = Object.assign({}, n.defaultOptions);
}, n.resetDefaultOptions();

var o = n;

exports.default = o;