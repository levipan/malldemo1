var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp();

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        detail: Object,
        productLen: Number,
        productsWidth: Number,
        progressScrollLeft: Number,
        shareImg: String
    },
    ready: function() {
        this.init(), this.exposure();
    },
    detached: function() {
        try {
            this.cmsObserve && this.cmsObserve.disconnect();
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            console.log(t);
        }
    },
    data: {
        isActivity: !1
    },
    methods: {
        cmsScroll: function(t) {
            var e = t.detail.scrollLeft, i = this.data.productsWidth / (670 / 214), r = e / i / this.data.productLen * 100;
            this.setData({
                progressScrollLeft: r
            }), this.productExposure(Math.floor(e / i) + 4);
        },
        init: function() {
            var t = this;
            try {
                var i = e.frxs.getQuerys(this.data.detail.linkUrl).pageCode;
                i && this.setData({
                    isActivity: i
                });
            } catch (t) {}
            this.hasShowProductLen = 0, setTimeout(function() {
                wx.createSelectorQuery().in(t).select("#products").boundingClientRect(function(e) {
                    e && t.setData({
                        productsWidth: e.width - 1
                    });
                }).exec();
            }, 100);
        },
        move: function(e) {
            this.triggerEvent("click-booth", t(t({}, this.data.detail), {}, {
                pointPosition: e.currentTarget.dataset.position
            }));
        },
        exposure: function() {
            var t = this;
            try {
                var e = this.createIntersectionObserver().relativeToViewport();
                this.cmsObserve = e, e.observe("#hanzo-index-cms-".concat(this.data.detail.position), function(e) {
                    if (e.intersectionRatio > 0) {
                        t.triggerEvent("exposure", {
                            cmsDetail: t.data.detail
                        }), t.isExposure = !0;
                        var i = t.data.productLen > 4 ? 4 : t.data.productLen;
                        t.productExposure(i);
                    }
                });
            } catch (t) {}
        },
        productExposure: function(t) {
            if (this.isExposure) {
                var e = t > this.data.productLen ? this.data.productLen : t;
                this.hasShowProductLen < e && (this.triggerEvent("product-exposure", {
                    start: this.hasShowProductLen,
                    end: e,
                    cmsDetail: this.data.detail
                }), this.hasShowProductLen = e);
            }
        }
    }
});