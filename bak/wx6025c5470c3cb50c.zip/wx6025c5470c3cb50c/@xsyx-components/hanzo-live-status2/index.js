var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../const/live-play-statusName.js"));

Component({
    properties: {
        statusValue: {
            type: String,
            value: ""
        },
        statusName: {
            type: String,
            value: ""
        },
        zIndex: {
            type: Number,
            value: 100
        },
        extendClass: String
    },
    data: {
        liveStatusName: e.default
    },
    attached: function() {},
    methods: {
        onPlayerClick: function() {
            this.triggerEvent("player-click", {});
        }
    }
});