var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../../../@babel/runtime/helpers/typeof"), o = require("../../../../@babel/runtime/helpers/createForOfIteratorHelper"), n = require("../../../../@babel/runtime/helpers/objectSpread2"), s = require("../../../../utils/index.js"), i = t(require("../../utils/share"));

Component({
    properties: {
        wxExparserNodeId: String
    },
    data: {
        isIPhoneX: s.isIPhoneX,
        showModal: !1,
        wechart: !0,
        poster: !0,
        showPoster: !1,
        shareOptions: {},
        posterUrl: ""
    },
    lifetimes: {
        attached: function() {
            var t = this, e = this.data.wxExparserNodeId;
            i.default.init(e, function(e) {
                var o = e.show, s = e.options;
                if (s) {
                    t.onShare = s.onShare, t.onPoster = s.onPoster;
                    var i = (s.type || []).reduce(function(t, e) {
                        return t[e] = !0, t;
                    }, {
                        poster: !1,
                        wechart: !1
                    });
                    t.setData(n(n({}, i), {}, {
                        shareOptions: s.options
                    }));
                }
                t.setData({
                    showModal: o
                });
            });
        }
    },
    methods: {
        onCloseModal: function() {
            i.default.hideModal(this.data.wxExparserNodeId);
        },
        onWechartShare: function() {
            this.onCloseModal(), this.onShare && this.onShare();
        },
        onPosterShare: function() {
            var t = this;
            this.onCloseModal(), this.onPoster && this.onPoster(function(e) {
                e && t.setData({
                    posterUrl: e
                });
            }), this.setData({
                showPoster: !0
            });
        },
        onClasePoster: function() {
            this.setData({
                showPoster: !1
            });
        },
        onSavePoster: function(t) {
            var e = this;
            this.getAuth(t).then(function(t) {
                wx.getSetting({
                    success: function(t) {
                        !1 === t.authSetting["scope.writePhotosAlbum"] || e.downloadFile([ e.data.posterUrl ]).then(function(t) {
                            wx.saveImageToPhotosAlbum({
                                filePath: t[0],
                                success: function(t) {
                                    wx.showToast({
                                        title: "保存成功，请在相册中查看分享",
                                        icon: "none"
                                    }), e.onClasePoster(), console.log(t);
                                },
                                fail: function(t) {
                                    console.log(t), wx.showToast({
                                        title: "保存失败",
                                        icon: "none"
                                    }), wx.getSetting({
                                        success: function(t) {
                                            !1 === t.authSetting["scope.writePhotosAlbum"] && e.setData({
                                                btn_title: "点击开启保存到相册"
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    }
                });
            });
        },
        getAuth: function(t) {
            var e = this;
            return new Promise(function(o, n) {
                wx.getSetting({
                    success: function(n) {
                        n.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                            btn_title: "保存图片"
                        }), o(!0)) : !1 === n.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                            btn_title: "点击开启保存到相册"
                        }), t && wx.openSetting({
                            success: function(t) {
                                t.authSetting["scope.writePhotosAlbum"] ? (e.setData({
                                    btn_title: "保存图片"
                                }), o(!0)) : o(!1);
                            },
                            fail: function(t) {
                                o(!1);
                            }
                        })) : o(!1);
                    },
                    fail: function(t) {
                        wx.showToast({
                            title: "查询设置失败",
                            icon: "none"
                        });
                    }
                });
            });
        },
        downloadFile: function(t) {
            var n, s = [], i = o(t);
            try {
                var r = function() {
                    var t = n.value;
                    if (0 == t.indexOf("http")) s.push(new Promise(function(e, o) {
                        wx.downloadFile({
                            url: t,
                            success: function(t) {
                                console.log(t), 200 === t.statusCode ? e(t.tempFilePath) : e(null);
                            },
                            fail: function(t) {
                                console.log(t), e(null);
                            }
                        }), setTimeout(function() {
                            e(null);
                        }, 3e4);
                    })); else {
                        if (!(t.indexOf("/") >= 0)) return {
                            v: new Promise(function(t, e) {
                                e("图片下载失败！");
                            })
                        };
                        s.push(t);
                    }
                };
                for (i.s(); !(n = i.n()).done; ) {
                    var a = r();
                    if ("object" === e(a)) return a.v;
                }
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                i.e(t);
            } finally {
                i.f();
            }
            return new Promise(function(t, e) {
                Promise.all(s).then(function(e) {
                    console.log("下载完图片：", e), t(e);
                }).catch(function(t) {
                    console.log(t), e(t);
                });
            });
        }
    }
});