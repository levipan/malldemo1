Component({
    externalClasses: [ "image-class", "text-class", "btn-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        type: {
            type: Array,
            value: [ "default", "alert" ],
            observer: function(e) {
                e && e.length && this.setTypeData(e);
            }
        },
        defaultStyle: {
            type: String,
            value: "width: 100%; height: 100%"
        },
        showDefault: {
            type: Boolean,
            value: !1
        },
        defaultImg: {
            type: String,
            value: "https://front-xps-cdn.xsyx.xyz/2021/06/24/1201005482.png"
        },
        defaultText: {
            type: String,
            value: ""
        },
        showRefresh: {
            type: Boolean,
            value: !0
        },
        refreshText: {
            type: String,
            value: "刷新一下试试"
        },
        customDefault: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        wxExparserNodeId: "",
        default: !0,
        alert: !0,
        shareModal: !1
    },
    lifetimes: {
        attached: function() {
            if (this.setTypeData(this.data.type), this.data.shareModal) {
                var e = (getCurrentPages().pop() || {}).__wxExparserNodeId__;
                this.setData({
                    wxExparserNodeId: e
                });
            }
        }
    },
    methods: {
        setTypeData: function(e) {
            var t = e.reduce(function(e, t) {
                return e[t] = !0, e;
            }, {});
            this.setData(t);
        },
        onRefresh: function() {
            this.triggerEvent("refresh");
        }
    }
});