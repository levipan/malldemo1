var e = require("../../../@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../../@babel/runtime/helpers/objectSpread2"), r = require("../../../@babel/runtime/helpers/classCallCheck"), a = require("../../../@babel/runtime/helpers/createClass"), o = e(require("../../../utils/events.js")), n = {
    type: [ "wechart", "poster" ],
    options: {},
    onShare: function() {},
    onPoster: function(e) {}
}, i = new (function() {
    function e() {
        r(this, e);
    }
    return a(e, [ {
        key: "init",
        value: function(e, t) {
            e || (e = this.getPagekey()), o.default.on("share_modal_".concat(e), t);
        }
    }, {
        key: "clear",
        value: function(e) {
            e || (e = this.getPagekey()), o.default.remove("share_modal_".concat(e));
        }
    }, {
        key: "showModal",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = this.getPagekey();
            o.default.emit("share_modal_".concat(r), {
                show: !0,
                options: t(t({}, n), e)
            });
        }
    }, {
        key: "hideModal",
        value: function(e) {
            e || (e = this.getPagekey()), o.default.emit("share_modal_".concat(e), {
                show: !1
            });
        }
    }, {
        key: "getPagekey",
        value: function() {
            return (getCurrentPages().pop() || {}).__wxExparserNodeId__;
        }
    } ]), e;
}())();

exports.default = i;