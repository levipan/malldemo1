var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Objectvalues");

var t = e(require("../../@babel/runtime/regenerator")), o = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), r = (e(require("../../xapp/runtime.js")), 
require("../../api/index.js")), n = require("../../utils/datetime.js"), a = e(require("../../router/index.js")), u = getApp();

Component({
    properties: {
        show: {
            type: Boolean,
            observer: function(e) {
                if (!u.frxs.isLogin() && e) return this.setData({
                    show: !1
                }), u.frxs.toLogin();
            }
        },
        activeCouponInfo: {
            type: Object,
            observer: function(e) {
                e && e.ticketMap && u.frxs.isLogin() ? this.getCouponList(e) : this.init();
            }
        }
    },
    data: {
        showEmpty: !1,
        couponInfoMap: []
    },
    ready: function() {},
    methods: {
        init: function() {
            this.setData({
                showEmpty: !1,
                couponInfoMap: []
            });
        },
        clickCouponBtn: function(e) {
            var t = wx.$._get(e, "currentTarget.dataset.coupon", -1);
            if (-1 != t) switch (t.activityAreaResultEnum) {
              case "USE_UP":
              case "NOT_ACTIVE":
                break;

              case "USABLE":
                this.onClickCoupon(t);
                break;

              case "RECEIVABLE":
                this.reciveCoupon(t);
            }
        },
        toHomeUseCoupon: function(e, t, o) {
            var i = o.activityCode, r = void 0 === i ? "" : i, n = o.ticketId, u = void 0 === n ? "" : n, s = o.activityId, c = void 0 === s ? "" : s, d = o.toolActivityId, p = void 0 === d ? "" : d, f = o.tmExpire, v = void 0 === f ? "" : f, l = o.tmFinish, m = void 0 === l ? "" : l, h = o.toolType, y = void 0 === h ? "" : h, b = o.toolName, I = void 0 === b ? "" : b, g = o.orderAmountLimit, x = void 0 === g ? "" : g, C = o.amount, T = void 0 === C ? "" : C, k = o.orderStep, w = {
                activityCode: r,
                activityId: c,
                toolActivityId: p,
                tmExpire: v,
                tmFinish: m,
                ticketId: u,
                toolType: y,
                toolName: I,
                orderAmountLimit: x,
                amount: T,
                orderStep: void 0 === k ? [] : k
            };
            if (!e) return a.default.navigateTo({
                path: "subTMMain/pages/productList/index",
                query: {
                    coupon: encodeURIComponent(JSON.stringify(w))
                }
            });
            var E = e.split("&"), D = {};
            switch (E.length > 0 && E.forEach(function(e) {
                var t = e.split("=");
                D[t[0]] = t[1];
            }), t) {
              case "H_WINDOW":
                break;

              case "H_INDEX":
                wx.$route.navigateTo({
                    name: "home-subTMMain-index",
                    query: D
                });
                break;

              case "H_CMS":
                a.default.navigateTo({
                    path: "/pages/home/h5Active/index",
                    query: {
                        url: e
                    }
                });
                break;

              case "H_PRODUCT_DETAIL":
                wx.$route.navigateTo({
                    name: "home-goods-detail",
                    query: D
                });
                break;

              case "H_CET_ODR":
                wx.$route.navigateTo({
                    url: e,
                    query: {
                        coupon: encodeURIComponent(JSON.stringify(w))
                    }
                });
            }
        },
        onClickCoupon: function(e) {
            var r = this;
            return i(t.default.mark(function i() {
                var n, u, s, c, d, p, f, v, l, m, h, y, b, I, g, x, C, T, k, w, E, D, O, S, q, A, L;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (n = e.activityCode, u = e.linkUrl, s = e.avatar, c = e.urlType, d = e.ticketId, 
                        p = e.activityId, f = void 0 === p ? "" : p, v = e.toolActivityId, l = void 0 === v ? "" : v, 
                        m = e.tmExpire, h = void 0 === m ? "" : m, y = e.tmFinish, b = void 0 === y ? "" : y, 
                        I = e.toolType, g = void 0 === I ? "" : I, x = e.toolName, C = void 0 === x ? "" : x, 
                        T = e.orderAmountLimit, k = void 0 === T ? "" : T, w = e.amount, E = void 0 === w ? "" : w, 
                        D = e.orderStep, O = {
                            activityCode: n,
                            activityId: f,
                            toolActivityId: l,
                            tmExpire: h,
                            tmFinish: b,
                            ticketId: d,
                            toolType: g,
                            toolName: C,
                            orderAmountLimit: k,
                            amount: E,
                            orderStep: void 0 === D ? [] : D
                        }, -1 === c.indexOf("H_")) {
                            t.next = 5;
                            break;
                        }
                        return r.toHomeUseCoupon(u, c, e), t.abrupt("return");

                      case 5:
                        if (u) {
                            t.next = 10;
                            break;
                        }
                        if ("CET_ODR" != c) {
                            t.next = 8;
                            break;
                        }
                        return t.abrupt("return", a.default.navigateTo({
                            path: "subShopCart/productList/index",
                            query: {
                                coupon: encodeURIComponent(JSON.stringify(O))
                            }
                        }));

                      case 8:
                        return a.default.subSwitchTab({
                            path: "subMain/main/index",
                            query: {
                                tabCode: "home"
                            },
                            isRedirect: !0
                        }), t.abrupt("return");

                      case 10:
                        0 === u.indexOf("@") ? (S = {}, u.substr(1).split("&").forEach(function(e) {
                            var t = e.split("=");
                            S[t[0]] = t[1];
                        }), q = {}, (A = wx.$._get(s, "imgUrl", !1)) && (q.imgUrl = A), a.default.navigateTo({
                            path: "/subProduct/detail/index",
                            query: o(o({}, S || {}), q)
                        })) : 0 === u.indexOf("%windId=") && u.substr(8) ? r.goToWindow(u.substr(8)) : 0 === u.indexOf("%secondWindowId") && u.substr(16) ? a.default.navigateTo({
                            path: "/subProduct/boutique/boutique",
                            query: {
                                secondWindowId: u.substring(16, u.length)
                            }
                        }) : u ? (L = {
                            path: "/pages/home/h5Active/index",
                            query: {
                                url: u
                            }
                        }, "CET_ODR" === c && (L.path = u, L.query = {
                            coupon: encodeURIComponent(JSON.stringify(O))
                        }), a.default.navigateTo(L)) : a.default.subSwitchTab({
                            path: "subMain/main/index",
                            query: {
                                tabCode: "home"
                            },
                            isRedirect: !0
                        }), r.triggerEvent("closePop");

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, i);
            }))();
        },
        reciveCoupon: function(e) {
            var o = this;
            return i(t.default.mark(function i() {
                var n, a;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!o.fetchLock) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return o.fetchLock = !0, t.prev = 3, n = u.frxs.getMOrSData("storeInfo") || {}, 
                        t.next = 7, r.couponApi.receiveTicketNew({
                            code: e.activityId,
                            token: e.ticketKey,
                            storeId: u.frxs.getMOrSData("storeId") || n.storeId || "",
                            blackBox: u.frxs.storage("safe_bb") || "",
                            saleRegionCode: "".concat(n.areaId),
                            provinceCode: n.provinceId,
                            cityCode: n.cityId,
                            areaCode: n.countyId
                        }, {
                            loading: "领取中...",
                            silence: !0,
                            contentType: "application/json"
                        });

                      case 7:
                        (a = t.sent) && (a.applyResult ? (o.fetchLock = !1, o.init(), o.getCouponList(o.data.activeCouponInfo)) : (o.fetchLock = !1, 
                        wx.showToast({
                            title: "领取失败",
                            icon: "error",
                            duration: 2e3
                        }))), t.next = 14;
                        break;

                      case 11:
                        t.prev = 11, t.t0 = t.catch(3), o.fetchLock = !1;

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, i, null, [ [ 3, 11 ] ]);
            }))();
        },
        getCouponList: function(e) {
            var n = this;
            return i(t.default.mark(function i() {
                var a, s, c, d, p, f, v, l, m, h, y;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, a = e.product, s = void 0 === a ? {} : a, c = e.ticketMap, d = u.frxs.getMOrSData("storeInfo") || {}, 
                        s.skuSn) {
                            t.next = 6;
                            break;
                        }
                        return n.setData({
                            showEmpty: !0
                        }), t.abrupt("return");

                      case 6:
                        return p = {
                            cateId: s.secondLevelCategoryId
                        }, f = {
                            cateId: s.firstLevelCategoryId,
                            children: p
                        }, v = {
                            skuSn: s.skuSn,
                            vendor: s.vendorId,
                            spuSn: s.spuSn,
                            category: f
                        }, l = {
                            skuInfoList: [ v ],
                            toolActivityCodes: c,
                            provinceCode: d.provinceId,
                            cityCode: d.cityId,
                            areaCode: d.countyId,
                            saleRegionCode: d.areaId,
                            storeId: d.storeId,
                            userId: u.frxs.getMOrSData("userId") || "",
                            channelUse: "WXAPP"
                        }, t.next = 12, r.couponApi.queryActiveTickets(l, {
                            contentType: "application/json",
                            loading: "加载中",
                            silence: !0
                        });

                      case 12:
                        if (!(m = t.sent)) {
                            t.next = 25;
                            break;
                        }
                        if (h = m.activityPromotionMap || {}, y = [], c.forEach(function(e) {
                            h[e] && y.push(o(o({}, h[e]), {}, {
                                ticketKey: e
                            }));
                        }), n._timer && n.clearTimer(), console.log("-----\x3ecouponInfoMap", y), 0 !== y.length) {
                            t.next = 22;
                            break;
                        }
                        return n.setData({
                            showEmpty: !0
                        }), t.abrupt("return");

                      case 22:
                        n.setData({
                            couponInfoMap: y
                        }, function() {
                            var e = n.data.couponInfoMap, t = [];
                            e.forEach(function(e) {
                                "NOT_ACTIVE" == e.activityAreaResultEnum && t.push(e);
                            }), n.renderTime(t);
                        }, {
                            update: !0
                        }), t.next = 26;
                        break;

                      case 25:
                        n.setData({
                            showEmpty: !0
                        });

                      case 26:
                        t.next = 31;
                        break;

                      case 28:
                        t.prev = 28, t.t0 = t.catch(0), n.setData({
                            showEmpty: !0
                        });

                      case 31:
                      case "end":
                        return t.stop();
                    }
                }, i, null, [ [ 0, 28 ] ]);
            }))();
        },
        renderTime: function(e) {
            var t = this, o = {};
            this._timer = setInterval(function() {
                e.forEach(function(e) {
                    var i = u.frxs.getCountDownTimeToObject(+new Date() + (u.frxs.getMOrSData("timeDiffServerAndClient") || 0), (0, 
                    n.strToTs)(e.tmActive));
                    if (e.timeDownObj = {
                        hours: i.totalHours >= 0 ? i.totalHours : "00",
                        minute: i.minutes >= 0 ? i.minutes : "00",
                        second: i.seconds >= 0 ? i.seconds : "00"
                    }, "00,00,00" == Object.values(e.timeDownObj).join(",")) t.clearTimer(), t.init(), 
                    t.getCouponList(t.data.activeCouponInfo); else {
                        var r = t.data.couponInfoMap.findIndex(function(t) {
                            return t.activityId == e.activityId;
                        });
                        -1 !== r && (o["couponInfoMap[".concat(r, "]")] = wx.$.deepCopy(e));
                    }
                }), t.setData(o);
            }, 1e3);
        },
        clearTimer: function() {
            clearInterval(this._timer);
        },
        onClosePopup: function() {
            this.clearTimer(), this.triggerEvent("closePopup", {
                showPopup: !1
            });
        }
    }
});