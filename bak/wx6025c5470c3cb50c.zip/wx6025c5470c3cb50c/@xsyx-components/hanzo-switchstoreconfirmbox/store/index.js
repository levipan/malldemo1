Component({
    properties: {
        store: Object,
        type: String,
        checked: {
            value: !1,
            type: Boolean
        }
    },
    data: {
        icons: {
            share: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/store/store-share-icon.png",
            history: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/store/store-history-icon.png"
        }
    },
    methods: {
        storeClick: function() {
            this.triggerEvent("storeClick", this.data.store);
        }
    }
});