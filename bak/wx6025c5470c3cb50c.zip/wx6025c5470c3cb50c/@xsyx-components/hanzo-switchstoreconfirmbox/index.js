var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/objectSpread2"), r = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/slicedToArray"), s = require("../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../router/index")), o = require("../../api/index.js"), i = getApp();

Component({
    properties: {
        newStoreId: {
            value: 0,
            type: Number
        },
        query: {
            type: Object,
            value: {}
        },
        oldStoreId: {
            value: 0,
            type: Number
        },
        backPageIdentify: {
            value: "",
            type: String
        },
        ret: {
            value: "",
            type: String
        },
        closeConfirm: {
            value: !1,
            type: Boolean
        },
        desc: {
            type: String,
            value: "当前购物门店与上次自提门店不一致"
        }
    },
    ready: function() {
        var e = this;
        return s(r.default.mark(function t() {
            var s, n, o, u;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        selectIndex: 0
                    }), s = e, i.frxs.showLoading(), "undefined" == e.data.ret && e.setData({
                        ret: ""
                    }), n = function(e) {
                        return "FE04451007002" !== wx.$._get(e, "rspCode", null);
                    }, o = function(t) {
                        try {
                            var r = a(t, 2), s = r[0], o = r[1], u = n(s), d = n(o);
                            if (!u && !d) {
                                var c = wx.$.page();
                                return wx.$.sessionStorage.set("toPageConfig", {
                                    path: c.route,
                                    query: c.options
                                }), wx.redirectTo({
                                    url: "/subPages/users/recommendStore/index"
                                }), i.frxs.hideLoading(), !0;
                            }
                            return (!u || !d) && (e.setData({
                                storeList: [ {}, u ? s : o ]
                            }, function() {
                                i.frxs.hideLoading();
                                var t = u ? s : o, r = t.storeId, a = t.areaId;
                                e.toPath(r, a);
                            }), !0);
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            return console.error(e), !1;
                        }
                    }, t.next = 8, new Promise(function(e) {
                        wx.$CG.getLocation({
                            type: "gcj02",
                            success: e,
                            fail: e.bind({
                                code: -1
                            })
                        });
                    });

                  case 8:
                    -1 !== ((u = t.sent) || {}).code ? e.location = u : e.location = {}, Promise.all([ e.getStoreInfo(e.data.newStoreId), e.getStoreInfo(e.data.oldStoreId) ]).then(function(e) {
                        if (o(e)) return i.frxs.hideLoading();
                        s.setStoreList(e), i.frxs.hideLoading();
                    }).catch(function(e) {
                        i.frxs.hideLoading(), o(e);
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    data: {
        url: i.frxsConfig.userDomain,
        storeList: [],
        selectIndex: 0,
        isShow: !1
    },
    methods: {
        selectStroe: function(e) {
            this.setData({
                selectIndex: e.currentTarget.dataset.index
            });
        },
        confirm: function() {
            if (this.data.selectIndex < 0) i.frxs.alert("亲，请选择您最方便的自提店"); else {
                var e = this, t = this.data.storeList[this.data.selectIndex].storeId, r = this.data.storeList[this.data.selectIndex].areaId, a = i.frxs.getMOrSData("userKey"), s = {
                    newStoreId: t,
                    userKey: a
                }, n = i.frxs.getStorageSync("storeId"), u = i.frxs.getStorageSync("isLogin");
                t != n ? (i.frxs.removeMAndS("isRecommendStore"), i.frxs.clearStoreInfo(t), i.frxs.isNullOrWhiteSpace(a) || 1 != u ? e.toPath(t, r) : o.memberApi.updateCurrStoreId(s, {
                    silence: !0
                }).then(function() {
                    e.toPath(t, r);
                }).catch(function() {
                    e.toPath(t, r);
                })) : e.toPath(t, r);
            }
        },
        getStoreInfoRequest: function(e) {
            var t = i.frxs.extend({
                isShowLoading: !0
            }, e), r = {
                storeId: t.storeId
            };
            "getLocation:ok" === (this.location || {}).errMsg && (r.userMapX = this.location.longitude, 
            r.userMapY = this.location.latitude), o.commonStoreApi.fetchStoreInfo(r, {
                loading: "加载中",
                notRedirect: !0,
                silence: !0
            }).then(function(e) {
                "function" == typeof t.success && (i.frxs.setMAndSData("areaId", e.areaId), t.success(e));
            }).catch(function(e) {
                "function" == typeof t.fail && t.fail(e);
            });
        },
        getStoreInfo: function(e) {
            var t = this;
            return new Promise(function(r) {
                t.getStoreInfoRequest({
                    storeId: e,
                    success: function(e) {
                        r(e);
                    },
                    fail: function(e) {
                        r(e);
                    }
                });
            });
        },
        setStoreList: function(e) {
            var t = this, r = e.find(function(e) {
                return e.storeId == t.data.oldStoreId;
            }) || {}, a = e.find(function(e) {
                return e.storeId == t.data.newStoreId;
            }) || {};
            if (r.storeId > 0 && a.storeId > 0) {
                var s = [];
                s.push(r), s.push(a), this.setData({
                    storeList: s,
                    isShow: !0
                });
            } else this.toPath(this.data.oldStoreId);
        },
        toPath: function(e) {
            var r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (this.data.closeConfirm) return this.triggerEvent("onConfirm", {
                storeId: e,
                areaId: r
            });
            var a = getCurrentPages(), s = this, o = a[a.length - 1], u = {};
            if (o.options.ret && "undefined" != o.options.ret) {
                if (u.url = o.options.ret, 0 == u.url.indexOf("%2F")) {
                    var d = decodeURIComponent(u.url);
                    u.url = d.split("?")[0], u.query = i.frxs.getQuerys(d);
                }
            } else u.url = "/" + o.route, ~u.url.indexOf("/subMain/main/index") && o.options && o.options.tabCode && (o.options.tabCode = wx.getStorageSync("__subMainType") || o.options.tabCode), 
            u.query = o.options || {};
            var c = u.url.indexOf("subPages/pages/switchStoreConfirm/switchStoreConfirm");
            if (0 != c && 1 != c) if (e == this.data.newStoreId) i.frxs.setMAndSData("storeId", e), 
            n.default.reLaunch({
                path: u.url,
                query: u.query
            }); else {
                var h = u.url.split("?"), l = JSON.parse(JSON.stringify(u.query));
                switch (h[0]) {
                  case "subNewUser/active/index":
                  case "/subNewUser/active/index":
                    n.default.reLaunch({
                        path: "/subNewUser/active/index",
                        query: t(t({}, this.data.query), {}, {
                            storeId: e
                        })
                    });
                    break;

                  case "subPages/pages/payPhone/home/index":
                  case "/subPages/pages/payPhone/home/index":
                    n.default.reLaunch({
                        path: "/subPages/pages/payPhone/home/index",
                        query: t(t({}, this.data.query), {}, {
                            storeId: e
                        })
                    });
                    break;

                  case "pages/home/productDetail/productDetail":
                  case "/pages/home/productDetail/productDetail":
                  case "subProduct/detail/index":
                  case "/subProduct/detail/index":
                  case "/subDetail/index":
                  case "subDetail/index":
                    s.toProductDetail(e, i.frxs.getQuerys(u.url) || u.query);
                    break;

                  case "/pages/home/cart/cart":
                  case "pages/home/cart/cart":
                    n.default.reLaunch({
                        path: "/pages/home/cart/cart"
                    });
                    break;

                  case "pages/users/center/center":
                  case "/pages/users/center/center":
                    n.default.reLaunch({
                        path: "/pages/users/center/center"
                    });
                    break;

                  case "pages/home/cateProduct/index":
                  case "/pages/home/cateProduct/index":
                    n.default.reLaunch({
                        path: "/pages/home/cateProduct/index",
                        query: t(t({}, u.query), {}, {
                            storeId: e,
                            windowId: ""
                        })
                    });
                    break;

                  case "subProduct/boutique/boutique":
                  case "/subProduct/boutique/boutique":
                    n.default.reLaunch({
                        path: "/subProduct/boutique/boutique"
                    });
                    break;

                  case "subMain/main/index":
                  case "/subMain/main/index":
                    l && l.scene && delete l.scene, n.default.reLaunch({
                        path: "/subMain/main/index",
                        query: t(t({}, l), {}, {
                            storeId: e,
                            windowId: ""
                        })
                    });
                    break;

                  case "/subActivity/onTimeBuy/index":
                    n.default.reLaunch({
                        path: "/subActivity/onTimeBuy/index",
                        query: t(t({}, u.query), {}, {
                            storeId: e
                        })
                    });
                    break;

                  case "subOld/index/index":
                  case "/subOld/index/index":
                    wx.$CG.$tran.open({
                        moduleName: "old",
                        routerQuery: t(t({}, u.query), {}, {
                            storeId: e
                        })
                    });
                    break;

                  case "pages/home/index/index":
                  default:
                    n.default.reLaunch({
                        path: "/pages/home/index/index"
                    });
                }
            } else this.toTargetPage(e);
        },
        toProductDetail: function(e, t) {
            var r = getCurrentPages(), a = t || r[r.length - 1].options;
            if (a && !i.frxs.isNullOrWhiteSpace(a.scene)) {
                var s = a.scene.split("-");
                3 == s.length && (a.acid = s[0], a.prid = s[1]), delete a.scene;
            }
            a.orderStoreId = this.data.storeList[1].storeId, a.orderAreaId = this.data.storeList[1].areaId, 
            a.storeId = e, n.default.reLaunch({
                path: "/subProduct/detail/index",
                query: a
            });
        },
        toTargetPage: function(e) {
            if (this.data.ret) {
                var t = 0 == this.data.ret.indexOf("/") ? this.data.ret : decodeURIComponent(this.data.ret);
                0 == t.indexOf("/pages/home/productDetail/productDetail") || 0 == t.indexOf("/subProduct/detail/index") ? this.toProductDetail(e, i.frxs.getQuerys(t)) : n.default.reLaunch({
                    path: decodeURIComponent(this.data.ret)
                });
            } else switch (this.data.backPageIdentify) {
              case "cart":
                this.toCart();
                break;

              case "center":
                this.toCenter();
                break;

              default:
                n.default.reLaunch({
                    path: "/pages/home/index/index",
                    query: {
                        storeId: e
                    }
                });
            }
        },
        toCart: function() {
            n.default.reLaunch({
                path: "/pages/home/cart/cart"
            });
        },
        toCenter: function() {
            n.default.reLaunch({
                path: "/pages/users/center/center"
            });
        }
    }
});