var t = require("../../../../../../utils/productLive.js");

Component({
    properties: {
        liveData: {
            type: Object
        }
    },
    data: {},
    methods: {
        onPlayerClick: function() {
            (0, t.isToLive)(this.data.liveData, "");
        }
    }
});