var t, e = require("../../../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../../../@babel/runtime/helpers/objectSpread2"), a = require("../../../../@babel/runtime/helpers/defineProperty"), i = require("../../../../utils/ads.js"), s = e(require("../../../../router/index.js")), o = require("../../../../const/hot-constants.js"), u = require("../../../../utils/product.js"), n = require("../../../../utils/productLive.js"), d = require("../../../../utils/index.js"), c = require("../../../../utils/numberPrecision.js"), p = require("../../../../behavior/productsCount.js"), l = require("../../../../utils/index.js").pk, h = getApp(), m = (a(t = {}, u.PRODUCT_STATUS.WAITING, "提前加购"), 
a(t, u.PRODUCT_STATUS.ACTIVE, "立即加购"), a(t, u.PRODUCT_STATUS.SOLDOUT, "找相似商品"), 
a(t, u.PRODUCT_STATUS.OVER, "找相似商品"), a(t, u.PRODUCT_STATUS.LACK, "找相似商品"), a(t, u.PRODUCT_STATUS.DOWN, "找相似商品"), 
t);

Component({
    properties: {
        product: {
            type: Object,
            value: {},
            observer: function(t) {
                t && (t.key || (t.key = l(t.spuSn, t.skuSn)), void 0 === t.saleRemain && (t.saleRemain = -1), 
                t._status = this.productStatus(t), t.tvLiveDto = (0, n.getLiveInfo)(t.tvLiveDto), 
                t.tmBuyStartText = (0, d.formaterDate)(t.tmBuyStart, "MM月dd日HH:mm开售"), this.setData({
                    product: t
                }), this.data.cartNumber <= 0 && this.onRegisterCart(t.key), this.onExposure());
            }
        },
        saleInfo: {
            type: null,
            value: null,
            observer: function(t) {
                t && t.saleRemain !== this.data.product.saleRemain && this.updataProdcutStatus(t);
            }
        },
        sigleCouponInfo: {
            type: Object,
            observer: function(t) {
                t && this.setSinglePrice(t);
            }
        },
        moduleConfig: Object,
        cartNumber: {
            type: Number,
            value: -1,
            observer: function(t) {
                -1 !== t && (this.cartListeners && this.cartListeners(), this.setData({
                    cartCount: t
                }));
            }
        },
        singleProduct: null,
        isExposure: Boolean,
        from: String,
        type: String
    },
    data: {
        cartCount: 0,
        singlePrice: 0,
        buttonText: m
    },
    lifetimes: {
        detached: function() {
            this.exposureClear && this.exposureClear(), this.onCartListenersClear();
        }
    },
    methods: {
        onRegisterCart: function(t) {
            var e = this;
            this.onCartListenersClear(), this.cartListeners = p.Cart.onRegister(t, function(t) {
                e.data.cartCount !== t.count && e.setData({
                    cartCount: t.count
                });
            });
        },
        onCartListenersClear: function() {
            0 === this.data.cartCount && (this.cartListeners && this.cartListeners(), this.cartListeners = null);
        },
        onAdd: function(t) {
            var e = t.detail.status, a = this.data.product;
            e === u.PRODUCT_STATUS.ACTIVE || e === u.PRODUCT_STATUS.WAITING ? this.triggerEvent("cart-add", r(r({
                product: a
            }, t.detail), {}, {
                type: "store"
            })) : (s.default.navigateTo({
                path: "/subProduct/similarProduct/index",
                query: {
                    spuSn: a.spuSn,
                    areaId: a.areaId,
                    storeId: h.frxs.getMOrSData("storeId") || "",
                    from: this.data.from || ""
                }
            }), this.triggerEvent("card-click", {
                product: a,
                type: "store"
            }));
        },
        onReduce: function(t) {
            this.triggerEvent("cart-reduce", r({
                product: this.data.product
            }, t.detail));
        },
        onReceive: function() {
            this.triggerEvent("cart-recive", {
                product: this.data.product,
                type: "store"
            });
        },
        setSinglePrice: function(t) {
            var e = t || {}, r = e.amount, a = e.orderAmountLimit;
            this.data.product.saleAmt >= a && r > 0 && this.setData({
                singlePrice: (0, c.minus)(this.data.product.saleAmt, r)
            });
        },
        productStatus: function(t, e, r) {
            var a = t.tmBuyStart, i = t.tmBuyEnd, s = t.saleRemain, o = t.saleable;
            return (0, u.getStorePrStatus)({
                tmBuyStart: a,
                tmBuyEnd: i,
                saleable: o,
                saleRemain: r ? r.saleRemain : s,
                moduleConfig: this.data.moduleConfig,
                cartNumber: e || this.data.cartNumber || 0
            });
        },
        onTapCover: function() {
            var t = this.data.product;
            this.onSingleActiveCard() || ((0, n.isToLive)(t.tvLiveDto, "home_product") ? this.triggerEvent("card-click", {
                product: this.data.product,
                type: "store"
            }) : this.onTapCard());
        },
        onTapCard: function() {
            if (!this.onSingleActiveCard()) {
                var t = this.data, e = t.product, r = t.from;
                s.default.navigateTo({
                    path: h.frxsConfig.mall.page.prDetails,
                    query: {
                        spuSn: e.spuSn || "",
                        skuSn: e.skuSn || "",
                        storeId: h.frxs.getMOrSData("storeId"),
                        imgUrl: e.imgUrl || e.adUrl,
                        prName: e.prName,
                        saleAmt: e.saleAmt,
                        orderAreaId: e.areaId,
                        from: r || ""
                    }
                }), this.triggerEvent("card-click", {
                    product: this.data.product,
                    type: "store"
                });
            }
        },
        onSingleActiveCard: function() {
            var t = this.data.singleProduct;
            return !(!t || !t.jumpUrl) && (t.jumpable = !0, (0, i.onToJump)(t), this.triggerEvent("card-click", {
                product: this.data.product,
                type: "store"
            }), !0);
        },
        onToHotList: function() {
            var t = this.data.product.hotFuzzy;
            if (t) {
                var e = t.listId, r = t.listType, a = o.RANK_ROUTER_KEY[r] || "subPages/home/brand/hotlist/index";
                h.router.navigateTo({
                    path: a,
                    query: {
                        listId: e,
                        from: "index",
                        listType: o.CONVERT_HOTLIST_CODE[r] || ""
                    }
                }), this.triggerEvent("rank-click", {
                    product: this.data.product,
                    type: "store"
                });
            }
        },
        updataProdcutStatus: function(t) {
            var e = this.data.product, r = e._status;
            e._status = this.productStatus(e, null, t), r !== e._status && this.setData({
                product: e
            });
        },
        onExposure: function() {
            var t = this;
            this.data.isExposure && (this.exposureClear && this.exposureClear(), this.exposureClear = d.onExposureListen.bind(this)(".product-card-warp", function(e) {
                e.intersectionRatio > 0 ? (t.triggerEvent("exposure", {
                    product: t.data.product,
                    type: "store"
                }), t.updataProdcutStatus(t.data.saleInfo), t.cartListeners || t.onRegisterCart(t.data.product.key)) : t.onCartListenersClear();
            }, {
                relativeToViewportOptions: {
                    bottom: 200,
                    top: 200
                }
            }));
        }
    }
});