var t = require("../../../../utils/productLive.js"), e = require("../../../../utils/index.js");

Component({
    properties: {
        product: {
            type: Object,
            observer: function(e) {
                if (e) {
                    if (e.tvLiveDto = e.utvSimpleDTO, this.setData({
                        recommentTagList: this.setRecommentTag(e.eskuSnFlag),
                        product: e
                    }), e.utvSimpleDTO) {
                        var o = (0, t.getLiveInfo)(e.utvSimpleDTO, {
                            isPreTime: !1
                        });
                        this.setData({
                            liveInfo: o
                        });
                    }
                    this.onExposure();
                }
            }
        },
        isExposure: Boolean,
        from: String,
        type: String
    },
    data: {
        recommentTagList: [],
        liveInfo: null,
        showSkelenton: !1
    },
    lifetimes: {
        detached: function() {
            this.exposureClear && this.exposureClear();
        }
    },
    methods: {
        onTapCard: function() {
            var t = this.data, e = t.product, o = t.from, r = e.spuSn, i = void 0 === r ? "" : r, n = e.eskuSn, s = void 0 === n ? "" : n;
            this.triggerEvent("card-click", {
                type: "home",
                product: this.data.product
            }), wx.$route.navigateTo({
                name: "home-goods-detail",
                query: {
                    spuSn: i,
                    eskuSn: s,
                    from: o || ""
                }
            });
        },
        setRecommentTag: function(t) {
            try {
                if (!t) return [];
                var e = [];
                if (t.couponFlag && e.push("满".concat(t.couponFlag.orderAmountLimit, "立减").concat(t.couponFlag.amount)), 
                t.propertyFlag && (e = e.concat(t.propertyFlag)), t.styleFlag) {
                    var o = (t.styleFlag.split(",") || []).filter(function(t) {
                        return t;
                    });
                    e = e.concat(o);
                }
                return t.serviceFlag && (e = e.concat(t.serviceFlag)), e;
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                return [];
            }
        },
        onExposure: function() {
            var t = this;
            this.data.isExposure && (this.exposureClear && this.exposureClear(), this.exposureClear = e.onExposureListen.bind(this)(".yb-product-card", function(e) {
                e.intersectionRatio > 0 ? (t.triggerEvent("exposure", {
                    product: t.data.product,
                    type: "home"
                }), t.setData({
                    showSkelenton: !1
                })) : t.setData({
                    showSkelenton: !0
                });
            }));
        }
    }
});