Component({
    properties: {
        singleBgUrl: String
    },
    methods: {
        onTapCard: function() {
            this.triggerEvent("tap");
        }
    }
});