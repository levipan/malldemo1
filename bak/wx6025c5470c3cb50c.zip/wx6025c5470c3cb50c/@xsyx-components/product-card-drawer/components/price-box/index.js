var e = require("../../../../utils/numberPrecision.js");

Component({
    externalClasses: [ "price-class", "small-class" ],
    properties: {
        limit: {
            type: Number,
            value: 2
        },
        price: {
            type: Number,
            observer: function(i) {
                if (i) {
                    var s = (0, e.keepDecimal)(i, this.data.limit || 2).split(".");
                    this.setData({
                        priceList: s
                    });
                }
            }
        },
        fsColor: {
            type: String,
            value: "#FF3E3F"
        }
    }
});