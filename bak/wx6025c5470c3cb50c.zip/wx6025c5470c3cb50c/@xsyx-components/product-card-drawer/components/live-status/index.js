var s = {
    NOT_STARTED: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-not_started.png",
    PLAYING: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-playing.gif",
    SUSPEND: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-playing.gif",
    OVER: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-play-back.png",
    EXPIRED: null,
    PLAYBACK: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-play-back.png",
    PRODUCT_EXPLAIN: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/common/live-explain.gif"
};

Component({
    externalClasses: [ "custom-class" ],
    properties: {
        status: {
            type: String,
            observer: function(p) {
                p && s[p] && this.setData({
                    liveUrl: s[p]
                });
            }
        }
    },
    data: {
        liveUrl: ""
    }
});