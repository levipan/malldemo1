var t = "FULL_MINUS", o = "BUY_MINUS";

Component({
    externalClasses: [ "coupon-class" ],
    properties: {
        skuSnCouponList: {
            type: Array,
            observer: function(t) {
                if (t) {
                    var o = this.formatCouponTag(t);
                    this.setData({
                        couponList: o
                    });
                }
            }
        },
        sigleCouponInfo: {
            type: Object,
            observer: function(t) {
                t && this.setData({
                    singleCouponText: "每份立减".concat(t.amount, "元")
                });
            }
        },
        type: String
    },
    data: {
        couponList: []
    },
    methods: {
        formatCouponTag: function(n) {
            return n.map(function(n) {
                var e = "";
                if ("DISCOUNT" === n.toolType) e += "满".concat(n.orderAmountLimit, "元 | ").concat(1 * (n.discount / 10).toFixed(2), "折 | 最高优惠").concat(n.amount, "元"); else if (n.orderStep) {
                    e = n.orderStep.map(function(t) {
                        return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                    }).join(" | ");
                } else e += "满".concat(n.orderAmountLimit, "减").concat(n.amount);
                return {
                    text: e,
                    type: "SINGLE" !== n.rootType ? t : o
                };
            });
        },
        onReceive: function() {
            this.triggerEvent("cart-recive");
        }
    }
});