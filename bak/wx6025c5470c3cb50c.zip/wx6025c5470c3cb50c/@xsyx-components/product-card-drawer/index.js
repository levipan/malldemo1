var t = require("../../@babel/runtime/helpers/objectSpread2");

Component({
    properties: {
        type: {
            type: String,
            value: "BIG"
        },
        storeProduct: Object,
        ybProduct: Object,
        singleProduct: {
            type: null,
            value: null,
            observer: function(t) {
                t && this.setData({
                    storeProduct: t.product.storeProduct,
                    singleProduct: t
                });
            }
        },
        cartNumber: Number,
        skusnStoreCouponMap: Object,
        moduleConfig: Object,
        isExposure: Boolean,
        sort: {
            type: Number,
            value: -1
        },
        from: String,
        saleInfoMap: Object,
        isSuperCard: Boolean
    },
    methods: {
        onAdd: function(e) {
            var r = e.detail.product;
            this.data.sort >= 0 && void 0 === r.sort && (r.sort = this.data.sort), this.triggerEvent("cart-add", t(t({}, e.detail), {}, {
                single: this.data.singleProduct
            }));
        },
        onReduce: function(e) {
            this.triggerEvent("cart-reduce", t(t({}, e.detail), {}, {
                single: this.data.singleProduct
            }));
        },
        onReceive: function(e) {
            var r = e.detail.product;
            this.data.sort >= 0 && void 0 === r.sort && (r.sort = this.data.sort), this.triggerEvent("cart-recive", t(t({}, e.detail), {}, {
                single: this.data.singleProduct
            }));
        },
        onCardClick: function(t) {
            var e = t.detail, r = e.product, o = e.type;
            this.data.sort >= 0 && void 0 === r.sort && (r.sort = this.data.sort), this.triggerEvent("card-click", {
                type: o,
                product: r,
                single: this.data.singleProduct
            });
        },
        onExposure: function(t) {
            var e = t.detail, r = e.product, o = e.type;
            this.data.sort >= 0 && void 0 === r.sort && (r.sort = this.data.sort), this.triggerEvent("exposure", {
                type: o,
                product: r,
                single: this.data.singleProduct
            });
        },
        onRankClick: function(e) {
            this.triggerEvent("rank-click", t(t({}, e.detail), {}, {
                single: this.data.singleProduct
            }));
        }
    }
});