var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/typeof"), r = e(require("../../router/index")), n = require("../../api/index.js"), a = require("../../utils/wx-api.js"), s = getApp();

Component({
    properties: {},
    data: {
        btnDisabled: !1
    },
    methods: {
        onGetPhoneNumber: function(e) {
            (0, a.getPhoneNumberHookFn)(e), this.setData({
                btnDisabled: !1
            });
            var t = this, i = {
                unBind: [ "getPhoneNumber:fail:cancel to bind phone", "getPhoneNumber:fail:user cancel" ],
                cancel: [ "getPhoneNumber:fail:cancel to confirm login" ]
            };
            if ("getPhoneNumber:ok" == e.detail.errMsg) {
                var o = s.frxs.getMOrSData("userKey"), u = s.frxs.getMOrSData("storeId"), g = wx.getSystemInfoSync() || {}, c = {
                    loginMode: "ENCRYPTED_DATA",
                    userKey: o,
                    encryptedData: e.detail.encryptedData,
                    iv: e.detail.iv,
                    item: "WECHAT_MINI_MEMBER",
                    "terminal.devId": "",
                    "terminal.brand": g.brand,
                    "terminal.os": g.system,
                    "terminal.type": g.model,
                    "request.providerName": "TONGDUN",
                    "request.blackBox": s.frxs.storage("safe_bb") || ""
                };
                u && (c.currentStoreId = u), n.authApi.manualLogin(c, {
                    silence: !0
                }).then(function(e) {
                    t.triggerEvent("updatedata", {
                        isShowGetPhoneNumber: !1
                    }), s.frxs.setStorageSync("isLogin", !0);
                    var r = s.frxs.getMOrSData("storeId");
                    s.frxs.isNullOrWhiteSpace(r) && e && e.currentStoreId > 0 && s.frxs.setMAndSData("storeId", e.currentStoreId), 
                    t.triggerEvent("loginsuccess", e);
                }).catch(function(e) {
                    "loginExpire" === e.rspCode ? (s.frxs.removeMAndS("userKey"), s.userSvr.autoLogin()) : s.frxs.alert({
                        content: e.rspDesc,
                        success: function() {}
                    });
                });
            } else if (e.detail.errMsg.indexOf("deny") > 0 || i.cancel.indexOf(e.detail.errMsg) >= 0) {
                t.triggerEvent("updatedata", {
                    isShowGetPhoneNumber: !1
                });
                var l = wx.getStorageSync("storeId");
                !s.frxs.isNullOrWhiteSpace(l) && l > 0 ? r.default.navigateTo({
                    path: "/subPages/users/loginstep2/loginstep2"
                }) : s.userSvr.getWechatLocation(function(e) {
                    r.default.navigateTo({
                        path: "/subPages/users/changdot/changdot",
                        isRedirect: !0,
                        query: {
                            latitude: e.latitude,
                            longitude: e.longitude
                        }
                    });
                });
            } else e.detail.errMsg.indexOf("cancel") > 0 || i.unBind.indexOf(e.detail.errMsg) >= 0 ? s.frxs.alert({
                content: "您取消了微信账号绑定手机号",
                success: function() {
                    t.triggerEvent("updatedata", {
                        isShowGetPhoneNumber: !1
                    }), r.default.navigateTo({
                        path: "/subPages/users/loginstep2/loginstep2"
                    });
                }
            }) : s.frxs.alert({
                content: "如未授权，将不能登陆，我们无法为您提供服务。"
            });
        },
        getPhoneNumberTap: function() {
            this.setData({
                btnDisabled: !0
            });
        },
        toLogin: function() {
            var e = s.userSvr.getLoginSuccessToPageIdentify(), t = {};
            e && (t.ret = this.getLoginBackUrl(e)), 0 == getCurrentPages()[getCurrentPages().length - 1].route.indexOf("pages/users/login") ? r.default.redirectTo({
                path: "/subPages/users/loginstep2/loginstep2",
                query: t
            }) : r.default.navigateTo({
                path: "/subPages/users/loginstep2/loginstep2",
                query: t
            });
        },
        getLoginBackUrl: function(e) {
            if ("object" == t(e)) switch (e.backPageIdentify) {
              case "cart":
                return "/pages/home/cart/cart";

              case "center":
                return "/pages/users/center/center";

              default:
                return "";
            }
            return e;
        }
    }
});