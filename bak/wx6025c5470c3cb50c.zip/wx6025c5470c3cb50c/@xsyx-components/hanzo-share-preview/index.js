Component({
    properties: {
        content: {
            type: String,
            value: "一家有温度的社区电商"
        },
        imgSrc: {
            type: String,
            value: ""
        },
        confirmBtnText: {
            type: String,
            value: "分享"
        },
        cancelBtnText: {
            type: String,
            value: "取消"
        }
    },
    methods: {
        cancelClick: function() {
            this.triggerEvent("cancel-click", {});
        },
        confirmClick: function() {
            this.triggerEvent("confirm-click", {});
        }
    }
});