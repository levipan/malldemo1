var t = require("../../@babel/runtime/helpers/objectSpread2"), e = wx.getSystemInfoSync().windowWidth / 750;

Component({
    properties: {
        showCoupon: {
            type: Boolean,
            value: !1
        },
        estimatedPrice: {
            type: Number,
            value: 0
        },
        modal: {
            type: String,
            value: ""
        },
        canUseMulityCoupon: {
            type: Boolean,
            value: !1
        },
        key: {
            type: String,
            value: ""
        },
        checked: {
            type: Boolean,
            value: !1
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        status: {
            type: String,
            value: "ACTIVE"
        },
        title: {
            type: String,
            value: ""
        },
        cover: {
            type: String,
            value: ""
        },
        info: {
            type: String,
            value: ""
        },
        tag: {
            type: String,
            value: ""
        },
        vendor: {
            type: String,
            value: ""
        },
        amount: Number,
        price: Number,
        marketPrice: Number,
        cartCount: {
            type: Number,
            value: 0
        },
        maxCartCount: {
            type: Number,
            value: 99
        },
        swipeLeftWidth: {
            type: Number,
            value: 0
        },
        swipeRightWidth: {
            type: Number,
            value: 0
        },
        swipeLeftText: {
            type: String,
            value: "选择"
        },
        swipeRightText: {
            type: String,
            value: "删除"
        },
        notSaleInfo: {
            type: String,
            value: ""
        },
        countDown: Object,
        isEdit: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.setData({
                    swipeX: 0
                });
            }
        },
        hasCheckbox: {
            type: Boolean,
            value: !0
        },
        canmove: {
            type: Boolean,
            value: !0
        },
        extendClass: {
            type: String,
            value: ""
        },
        resizeFontsize: {
            type: Boolean,
            value: !1
        },
        editable: {
            type: Boolean,
            value: !0
        },
        productInfo: Object,
        showOnlineReminder: {
            type: Boolean,
            value: !0
        },
        hideMarkingPrice: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        swipeX: 0
    },
    swipePageX: 0,
    swipePageY: 0,
    startTime: 0,
    lastSwipeX: 0,
    methods: {
        touchstart: function(t) {
            this.swipePageX = t.touches[0].pageX, this.swipePageY = t.touches[0].pageY, this.startTime = new Date().getTime();
        },
        touchend: function(t) {
            if (this.data.canmove) {
                var a = t.changedTouches[0].pageX, i = t.changedTouches[0].pageY, n = a - this.swipePageX, s = i - this.swipePageY, o = Math.abs(n), r = o / Math.abs(s), u = 40 * e, d = 100 * e;
                if (this.lastSwipeX = this.data.swipeX, n > 0 && (o > d || o > u && r > 5) && this.setData({
                    swipeX: 0
                }), n < 0 && (o > d || o > u && r > 5) && this.setData({
                    swipeX: -130 * e
                }), o < d && r < 5) {
                    var h = this.lastSwipeX;
                    this.setData({
                        swipeX: h
                    });
                }
            }
        },
        onTap: function(t) {
            this.triggerEvent("onTap", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onCheck: function(t) {
            this.triggerEvent("check", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onAdd: function(t) {
            this.setData({
                swipeX: 0
            }), this.triggerEvent("add", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onReduce: function(t) {
            this.setData({
                swipeX: 0
            }), this.triggerEvent("reduce", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onChange: function(t) {
            var e = t.detail.value;
            this.triggerEvent("change", {
                val: e,
                key: this.data.key,
                item: this.data
            });
        },
        onBlur: function(t) {
            var e = t.detail.value;
            e = !e || e <= 1 ? 1 : e > this.data.maxCartCount ? this.data.maxCartCount : parseInt(e), 
            this.triggerEvent("blur", {
                val: e,
                key: this.data.key,
                item: this.data
            });
        },
        onFocus: function(t) {
            var e = t.detail.value;
            e = !e || e <= 1 ? 1 : e > this.data.maxCartCount ? this.data.maxCartCount : parseInt(e), 
            this.triggerEvent("focus", {
                val: e,
                key: this.data.key,
                item: this.data
            });
        },
        onSwipeLeft: function(t) {
            this.triggerEvent("swipeLeft", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        onSwipeRight: function(t) {
            this.setData({
                swipeX: 0
            }), this.triggerEvent("swipeRight", {
                val: t.detail,
                key: this.data.key,
                item: this.data
            });
        },
        ondrag: function(t) {
            this.triggerEvent("ondrag", {
                swipeDirection: t.detail.swipeDirection
            });
        },
        dragend: function() {
            this.triggerEvent("dragend");
        },
        onlineReminder: function() {
            var e = t(t({}, this.data.productInfo), {}, {
                activityId: this.data.productInfo.acId,
                presaleActivityId: this.data.productInfo.acId,
                productId: this.data.productInfo.prId
            });
            this.triggerEvent("online-reminder", e);
        }
    }
});