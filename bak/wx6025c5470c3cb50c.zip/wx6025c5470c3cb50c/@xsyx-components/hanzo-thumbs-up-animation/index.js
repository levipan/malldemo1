var o = getApp();

Component({
    properties: {
        show: Boolean,
        offset: {
            type: Object,
            value: {}
        }
    },
    data: {
        ossDomain: o.frxsConfig.ossDomain
    },
    ready: function() {},
    methods: {}
});