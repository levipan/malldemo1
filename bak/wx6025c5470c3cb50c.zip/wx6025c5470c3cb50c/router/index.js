var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.routerInit = function(e) {
    return t = n.default.init(e), h;
};

var t, r = require("../@babel/runtime/helpers/objectSpread2"), n = e(require("./router-control")), a = require("../utils/common"), i = [ "/pages/home/index/index", "/pages/home/cateProduct/index", "/pages/users/center/center", "/pages/home/cart/cart" ], u = [ "/subMain/main/index", "/subTMMain/pages/index/index", "/subActive/pages/signActive/index/index" ], o = {
    "/pages/home/index/index": {
        path: "/subMain/main/index",
        query: {
            tabCode: "home"
        }
    },
    "/pages/home/cateProduct/index": {
        path: "/subMain/main/index",
        query: {
            tabCode: "brand"
        }
    },
    "/pages/users/center/center": {
        path: "/subMain/main/index",
        query: {
            tabCode: "center"
        }
    },
    "/pages/home/cart/cart": {
        path: "/subMain/main/index",
        query: {
            tabCode: "cart"
        }
    }
}, d = function(e) {
    return 0 !== e.indexOf("/") ? "/".concat(e) : e;
}, c = function(e) {
    var t = e || {};
    t.path = t.path || "/pages/home/index/index";
    var n = a.getQuerys(t.path) || {}, i = t.path.split("?")[0];
    if (t.path = function(e) {
        return -1 !== [ "/pages/home/productDetail/productDetail", "/subProduct/detail/index" ].indexOf(e) && "A" === wx.$.getTestMeta("detailRewrite") ? "subDetail/index" : e;
    }(i), void 0 === t.query) {
        var u = a.getQuerys(i);
        u && (t.query = u);
    }
    for (var o in t.query = t.query || {}, t.query) if (t.query.hasOwnProperty(o)) {
        var d = t.query[o];
        d && 0 === d.toString().indexOf("%2F") && (d = decodeURIComponent(d)), t.query[o] = encodeURIComponent(d);
    }
    return t.query = r(r({}, n), t.query || {}), t;
}, s = function(e) {
    var t = e.path, n = void 0 === t ? "" : t, a = e.query, i = void 0 === a ? {} : a, u = o[d(n)] || {}, c = u.query ? u.query.tabCode : "home";
    h.subSwitchTab(r(r({}, e), {}, {
        path: "subMain/main/index",
        query: r(r({}, i), {}, {
            tabCode: c
        })
    }));
}, h = {
    navigateTo: function(e) {
        if (e.path = d(e.path), u.findIndex(function(t) {
            return t === e.path;
        }) >= 0) return this.subSwitchTab(e, !0);
        var r = (e = c(e)).path, n = i.findIndex(function(e) {
            return e === r;
        });
        if (!0 === e.isLaunch) return this.reLaunch(e);
        if (-1 !== n) return e.tabCode ? t.switchTab(e) : s(e);
        var a = getCurrentPages();
        if (!0 === e.isRedirect || a.length > 9) return t.redirectTo(e);
        t.navigateTo(e);
    },
    redirectTo: function(e) {
        e = c(e), t.redirectTo(e);
    },
    reLaunch: function(e) {
        if (e = c(e), o[d(e.path)]) {
            var n = o[d(e.path)], a = n.path, i = void 0 === a ? "" : a, u = n.query, s = void 0 === u ? {} : u;
            e.path = i, e.query = r(r({}, e.query || {}), s);
        }
        t.reLaunch(e);
    },
    navigateBack: function(e) {
        t.navigateBack(e);
    },
    switchTab: function(e) {
        var r = e.path, n = void 0 === r ? "" : r;
        e.query;
        n.indexOf("subLive/index/index") > -1 ? t.switchTab(e) : s(e);
    },
    subSwitchTab: function(e) {
        e.path = d(e.path);
        var r = (e = c(e)).path, n = getCurrentPages();
        if (u.findIndex(function(e) {
            return e === r;
        }) >= 0) {
            var a = n.findIndex(function(e) {
                return "/" + e.route == r;
            });
            if (a >= 0) return n[a].receiveSwitchParams && n[a].receiveSwitchParams(e.query), 
            void (a < n.length - 1 && wx.navigateBack({
                delta: n.length - 1 - a
            }));
        }
        if (!0 === e.isRedirect) return t.redirectTo(e);
        t.navigateTo(e);
    },
    navigateToAndBack: function(e) {
        var t = getCurrentPages();
        if (t.length > 1) {
            var r = t[t.length - 2], n = r && Object.keys(r.options).join("") ? a.parseParam(r.options) : "";
            n && (n = "?" + n);
            var i = e.query ? a.parseParam(e.query) : "";
            if (i && (i = (e.path.indexOf("?") > 0 ? "" : "?") + i), e.path + i == "/" + r.route + n) return this.navigateBack();
        }
        this.navigateTo(e);
    },
    refreshPage: function() {
        var e = getCurrentPages(), t = e[e.length - 1], r = t.options || {};
        Object.keys(r).map(function(e) {
            r[e] = decodeURIComponent(r[e]);
        });
        var n = {
            path: "/" + t.route,
            query: r
        };
        -1 !== i.findIndex(function(e) {
            return e === n.path;
        }) ? this.reLaunch(n) : this.redirectTo(n);
    }
};

var p = h;

exports.default = p;