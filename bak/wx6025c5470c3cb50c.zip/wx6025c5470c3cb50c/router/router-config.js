var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../@babel/runtime/helpers/toConsumableArray"), u = e(require("./config-module/tarbar")), o = e(require("./config-module/home")), i = e(require("./config-module/user")), l = e(require("./config-module/order")), a = e(require("./config-module/brand")), d = e(require("./config-module/video")), t = e(require("./config-module/subPackages")), f = e(require("./config-module/game")), n = [].concat(r(u.default), r(o.default), r(l.default), r(i.default), r(a.default), r(d.default), r(t.default), r(f.default));

exports.default = n;