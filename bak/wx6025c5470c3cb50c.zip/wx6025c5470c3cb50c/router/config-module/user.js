Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/subPages/users/changdot/changdot",
    meta: {
        title: "添加自提店"
    }
}, {
    path: "/subPages/users/loginstep1/loginstep1",
    meta: {
        title: "授权登录"
    }
}, {
    path: "/subPages/users/loginstep2/loginstep2",
    meta: {
        title: "登录选择"
    }
}, {
    path: "/subPages/users/loginstep3/loginstep3",
    meta: {
        title: "验证码登录"
    }
}, {
    path: "/pages/users/orderDetail/orderDetail",
    meta: {
        title: "订单详情",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/orderDetail/orderDetail",
    meta: {
        title: "订单详情",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/orderList/orderList",
    meta: {
        title: "订单列表",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/reposition/reposition",
    meta: {
        title: "重新定位"
    }
}, {
    path: "/subPages/users/selfdot/mydot/mydot",
    meta: {
        title: "我的自提店",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/selfdot/updatedot/updatedot",
    meta: {
        title: "修改自提店",
        verifyLogin: !0
    }
}, {
    path: "/pages/users/shareOrder/shareOrder",
    meta: {
        title: "订单分享"
    }
}, {
    path: "/subPages/users/shareOrder/shareOrder",
    meta: {
        title: "订单分享"
    }
}, {
    path: "/pages/users/yearBill/index",
    meta: {
        title: "年度账单",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/changeCenterStore/index",
    meta: {
        title: "中心店",
        verifyLogin: !0
    }
}, {
    path: "/pages/users/h5url/index",
    meta: {
        title: "打开H5地址"
    }
}, {
    path: "/pages/users/h5authurl/index",
    meta: {
        title: "打开H5地址",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/map/map/index",
    meta: {
        title: "选择自提门店"
    }
}, {
    path: "/subPages/users/map/search/index",
    meta: {
        title: "选择自提门店"
    }
}, {
    path: "/pages/users/sysSetting/updateUserInfo/index",
    meta: {
        title: "个人信息",
        verifyLogin: !0
    }
} ];

exports.default = e;