Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/pages/order/confirmOrder/confirmOrder",
    meta: {
        title: "确认订单",
        verifyLogin: !0
    }
}, {
    path: "/pages/order/pay/pay",
    meta: {
        title: "支付",
        verifyLogin: !0
    }
}, {
    path: "/pages/order/apppay/apppay",
    meta: {
        title: "APP支付",
        verifyLogin: !1
    }
}, {
    path: "/pages/order/paySuccess/paySuccess",
    meta: {
        title: "支付成功",
        verifyLogin: !0
    }
}, {
    path: "/pages/order/uyingDirect/uyingDirect",
    meta: {
        title: "立即购买",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/orderSearch/index",
    meta: {
        title: "订单搜索",
        verifyLogin: !0
    }
} ];

exports.default = e;