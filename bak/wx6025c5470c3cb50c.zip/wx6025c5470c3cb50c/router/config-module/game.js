Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/subPages/game/xiaoxiaole/index",
    meta: {
        title: "订单详情",
        verifyLogin: !0
    }
}, {
    path: "/subPages/game/index/index",
    meta: {
        title: "游戏中心"
    }
} ];

exports.default = e;