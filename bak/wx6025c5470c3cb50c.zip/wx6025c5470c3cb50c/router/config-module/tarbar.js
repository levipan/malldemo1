Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/pages/home/index/index",
    meta: {
        title: "商品首页"
    }
}, {
    path: "/pages/home/cateProduct/index",
    meta: {
        title: "分类"
    }
}, {
    path: "/pages/video/index/index",
    meta: {
        title: "兴盛优视"
    }
}, {
    path: "/pages/home/cart/cart",
    meta: {
        title: "我的购物车"
    }
}, {
    path: "/pages/users/center/center",
    meta: {
        title: "个人中心"
    }
} ];

exports.default = e;