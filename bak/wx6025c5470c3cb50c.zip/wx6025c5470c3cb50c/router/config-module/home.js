Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/pages/home/productDetail/productDetail",
    meta: {
        title: "商品详情"
    }
}, {
    path: "/subProduct/detail/index",
    meta: {
        title: "商品详情"
    }
}, {
    path: "/pages/home/urltoapplet/urltoapplet",
    meta: {
        title: "urltoapplet"
    }
}, {
    path: "/subPages/home/wxgoup/wxgoup",
    meta: {
        title: "微信版本更新"
    }
}, {
    path: "/subPages/pages/switchStoreConfirm/switchStoreConfirm",
    meta: {
        title: "切换门店确认",
        verifyLogin: !0
    }
}, {
    path: "/subPages/home/qualifications/index",
    meta: {
        title: "供应商资质"
    }
}, {
    path: "/pages/home/live/index",
    meta: {
        title: "在线直播"
    }
}, {
    path: "/subPages/pages/signUp/index/index",
    meta: {
        title: "门店报名申请",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/signUp/reposition/reposition",
    meta: {
        title: "重新定位"
    }
}, {
    path: "/pages/home/newUser/index",
    meta: {
        title: "新客专享",
        verifyLogin: !0
    }
}, {
    path: "/subProduct/newUser/index",
    meta: {
        title: "新客专享",
        verifyLogin: !0
    }
}, {
    path: "/pages/home/h5Active/index",
    meta: {
        title: "h5活动页cms"
    }
}, {
    path: "/pages/home/newUser/locationError/index",
    meta: {
        title: "新客专享不在购买范围页面",
        verifyLogin: !0
    }
}, {
    path: "/subProduct/newUser/locationError/index",
    meta: {
        title: "新客专享不在购买范围页面",
        verifyLogin: !0
    }
}, {
    path: "/subProduct/similar/index",
    meta: {
        title: "相似商品",
        verifyLogin: !0
    }
} ];

exports.default = e;