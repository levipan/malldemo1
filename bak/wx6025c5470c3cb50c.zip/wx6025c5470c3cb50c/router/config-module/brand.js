Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/pages/brand/lottery/lottery",
    meta: {
        title: "抽奖"
    }
}, {
    path: "/pages/brand/search/search",
    meta: {
        title: "搜索"
    }
}, {
    path: "/pages/brand/hotlist/index",
    meta: {
        title: "热销榜"
    }
}, {
    path: "/subPages/home/brand/offerList/index",
    meta: {
        title: "199特惠榜",
        verifyLogin: !0
    }
}, {
    path: "/pages/brand/story/story",
    meta: {
        title: "查看品牌商品"
    }
}, {
    path: "/pages/brand/zone/zone",
    meta: {
        title: "猜您喜欢的品牌"
    }
} ];

exports.default = e;