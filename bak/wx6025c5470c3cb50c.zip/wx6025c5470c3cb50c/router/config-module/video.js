Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/pages/video/game/index",
    meta: {
        title: "游戏中心"
    }
} ];

exports.default = e;