Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ {
    path: "/subPages/pages/productSubscribe/index/index",
    meta: {
        title: "我的商品上线提醒",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/productSubscribe/help/index",
    meta: {
        title: "帮助"
    }
}, {
    path: "/subPages/pages/sysSetting/index/index",
    meta: {
        title: "设置"
    }
}, {
    path: "/subPages/pages/sysSetting/qualifications/index",
    meta: {
        title: "平台资质"
    }
}, {
    path: "/subPages/pages/sysSetting/serviceAgreement/index",
    meta: {
        title: "用户服务协议"
    }
}, {
    path: "/subPages/pages/sysSetting/privacyProtocol/index",
    meta: {
        title: "隐私政策"
    }
}, {
    path: "/subPages/pages/sysSetting/updateUserInfo/index",
    meta: {
        title: "个人信息",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/coupon/list/index",
    meta: {
        title: "优惠券列表",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/star/detail/index",
    meta: {
        title: "小兴兴",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/xing/detail/index",
    meta: {
        title: "兴币页面",
        verifyLogin: !0
    }
}, {
    path: "/subPages/pages/coupon/list1/index",
    meta: {
        title: "优惠券历史列表",
        verifyLogin: !0
    }
}, {
    path: "/subPages/users/checkCity/index",
    meta: {
        title: "选择城市页"
    }
}, {
    path: "/subPages/users/searchCity/index",
    meta: {
        title: "城市搜索页"
    }
}, {
    path: "/subPages/users/otherAddress/index",
    meta: {
        title: "其他地址页"
    }
}, {
    path: "/subPages/home/brand/search/search",
    meta: {
        title: "搜索"
    }
}, {
    path: "/subPages/pages/payPhone/home/index",
    meta: {
        title: "话费充值"
    }
}, {
    path: "/subPages/users/suggestList/index",
    meta: {
        title: "消息列表"
    }
} ];

exports.default = e;