Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    prIndex: "首页",
    prCate: "分类页",
    prSearch: "商品搜索页"
};