var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("./router-config")), t = require("../@xsyx-util/easy-route"), a = require("../utils/common"), o = require("../utils/userdata"), u = function(e, r, t) {
    var u, l, i = getApp();
    if ((i.globalData.preUrl ? i.globalData.preUrl : "") === e.path) return !1;
    i.globalData.preUrl = e.path, i.globalData.preUrlTmr && clearTimeout(i.globalData.preUrlTmr), 
    i.globalData.preUrlTmr = setTimeout(function() {
        i.globalData.preUrl = "";
    }, 500), e.meta && !0 === e.meta.verifyLogin ? (u = a.getMOrSData("userKey"), l = a.getStorageSync("isLogin"), 
    a.isNullOrWhiteSpace(u) || !l ? o.autoLogin({
        path: e.path,
        query: e.query || {},
        success: function(e, r) {
            var o = a.getMOrSData("storeId"), u = getCurrentPages();
            "boolean" == typeof u[u.length - 1].data.isShowBall && r.currentStoreId > 0 && a.isNullOrWhiteSpace(o) && a.setMAndSData("storeId", r.currentStoreId), 
            t();
        },
        showGetPhoneNumber: e.meta.showGetPhoneNumber || ""
    }) : t()) : t();
}, l = function(e, r) {}, i = {
    init: function(e) {
        return e.globalData.router = r.default, t.init({
            beforeRoute: u,
            afterRoute: l
        }), t;
    }
};

exports.default = i;