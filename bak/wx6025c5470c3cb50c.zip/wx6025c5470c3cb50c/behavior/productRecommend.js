Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../api/index.js"), t = getApp(), s = {
    getProductRecommendList: function() {
        try {
            if ("subPages/home/brand/search/search" === this.route) return void this.getSearchRecommendSpuSns();
            var e = this.selectComponent("#product-recommend");
            e.getList && e.getList();
        } catch (e) {}
    },
    clearProductRecommendList: function() {
        try {
            if ("subPages/home/brand/search/search" === this.route) return void this.getSearchRecommendSpuSns();
            if ("cart" === this.data.pageType) {
                if (this.isFirstInitProduct) return;
                this.isFirstInitProduct = !0;
            }
            var e = this.selectComponent("#product-recommend");
            e.clear && e.clear().getList();
        } catch (e) {}
    },
    resetSearchRecommend: function() {
        var e = this.selectComponent("#product-recommend");
        e && e.clear();
    },
    onScrollBottom: function() {
        this.getProductRecommendList();
    },
    onReachBottom: function() {
        this.getProductRecommendList();
    },
    getSearchRecommendSpuSns: function() {
        var s = this, r = this.selectComponent("#product-recommend");
        if (this.searchRecommendSpuSnsLoaded) r && r.getSearchRecommendProductDetails(); else {
            var c = {};
            c.uid = t.frxs.getMOrSData("userId"), c.userKey = t.frxs.getMOrSData("userKey"), 
            c.guId = t.frxs.getMOrSData("_xsm_g"), c.storeId = t.frxs.getMOrSData("storeId"), 
            c.keyWord = this.data.searchInputText, c.areaId = t.frxs.getMOrSData("areaId"), 
            c.firstSkusn = this.firstSkusn || "", c.searchSpusns = [], c.searchProductIds = [], 
            (this.searchResultPageCaches || []).forEach(function(e) {
                e && e.length && e.forEach(function(e) {
                    "string" == typeof e ? c.searchSpusns.push(e) : c.searchProductIds.push(e);
                });
            }), this.data.isPagerFinished && e.searchApi.searchQueryRecommendSpuSns(c, {
                contentType: "application/json"
            }).then(function(e) {
                s.searchRecommendSpuSnsLoaded = !0, r && (r.searchParamSpuSn = e.spnInfos || []), 
                s.setData({
                    searchRecommendHasSpuSns: !!(e.spnInfos || []).length
                }), r && r.setData({
                    isSearchEmpty: !e.spnInfos || !e.spnInfos.length
                }), r && r.getSearchRecommendProductDetails();
            });
        }
    },
    onProductRecommendAttached: function(e) {}
};

exports.default = s;