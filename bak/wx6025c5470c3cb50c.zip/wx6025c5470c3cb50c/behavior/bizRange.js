var e = require("../@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            bizLoadStatus: !1,
            isSelfInBiz: !0,
            realTimeBiz: !0,
            initBizStatus: !0,
            pageErrorMsg: {
                title: "亲，兴盛优选营业时间:",
                desc: "现在是非营业时间",
                displayTime: "00:00 - 23:00"
            },
            bizCountDown: {
                title: "",
                hours: 0,
                minute: 0,
                second: 0
            },
            showTomorrowPopup: !1,
            ifShowTomorrowPopup: !1,
            isCanTomorrowPopup: !1,
            beginPreSale: !0,
            isBeginPreSale: !1,
            beginPreSaleTime: "",
            saleDate: "",
            beginPreSalePickDate: ""
        },
        members: {
            bizRange: "",
            realTimeBiz: !0,
            timeOffset: 0,
            upBizTimeOut: null,
            waitTwoProduct: !1,
            now: function(e) {
                return Date.now() + (e || this.timeOffset || o.timeOffset || 0);
            },
            refreshBizStatus: function(e, r) {
                var i = this;
                return (e = e || o.frxs.getMOrSData("areaId")) > 0 ? new Promise(function(r) {
                    try {
                        a.commonStoreApi.fetchSysParam({
                            codes: "7Z_LIMIT_TIME",
                            areaId: e
                        }).then(function(e) {
                            i.getBeginPreSale({
                                success: function() {
                                    var a = e.bizRange, s = e.offset;
                                    i.timeOffset = s, i.bizRange = e.bizRange;
                                    var n = i.getBizRangeInfo(i.now(), a), m = n.realTimeBiz;
                                    o.globalData.realTimeBiz = m, i.realTimeBiz = m;
                                    var f = i.data.beginPreSale && o.frxs.formaterDate(i.now(), "dd") == o.frxs.formaterDate(n.startTime, "dd");
                                    m && !f || (i.waitTwoProduct = !1, i.setTomorrowPopupStatus({
                                        isBeginPreSale: !0
                                    }));
                                    var l = n.endTime < i.now() ? +n.endTime + 864e5 : n.endTime, u = "".concat(o.frxs.formaterDate(n.startTime, "HH:mm"), "-24:00"), d = "".concat(o.frxs.formaterDate(+l, "MM月dd日")), c = "".concat(o.frxs.formaterDate(+l + 864e5, "MM月dd日"));
                                    i.setData(t({
                                        isSelfInBiz: m,
                                        realTimeBiz: m,
                                        isBeginPreSale: f,
                                        beginPreSaleTime: u,
                                        saleDate: d,
                                        beginPreSalePickDate: c,
                                        bizLoadStatus: !0
                                    }, "pageErrorMsg.displayTime", e.bizRange)), i.upBizTimeOut = i.$setInterval(function() {
                                        i.timeUpdateRealTimeBizStatus();
                                    }, 1e3), r(m);
                                }
                            });
                        }).catch(function() {
                            r(i.data.isSelfInBiz);
                        });
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        r(i.data.isSelfInBiz);
                    }
                }) : this.data.isSelfInBiz;
            },
            getBeginPreSale: function(e) {
                this.setData({
                    beginPreSale: !0
                }, function() {
                    e.success(!0);
                });
            },
            fetchSelectByTime: function() {
                var e = this;
                this.setData({
                    isSelfInBiz: !1
                });
                var r = this.storeInfo.areaId || o.frxs.getMOrSData("areaId");
                r && a.commonStoreApi.fetchSelectByTime({
                    areaId: r
                }).then(function(a) {
                    if (null != a && "NORMAL" == a.status) {
                        var r = o.frxs.strToDate(a.tmDisplayStart), i = o.frxs.strToDate(a.tmDisplayEnd), s = {
                            show: !0,
                            title: a.content,
                            desc: a.reminder
                        }, n = "HH:mm";
                        o.frxs.formaterDate(r, "yyyyMMdd") != o.frxs.formaterDate(i, "yyyyMMdd") && (n = "M月d日 HH:mm"), 
                        s.displayTime = o.frxs.formaterDate(r, n) + " - " + o.frxs.formaterDate(i, n), e.setData({
                            pageErrorMsg: s
                        });
                    } else e.setData(t({}, "pageErrorMsg.show", !0));
                }).catch(function(a) {
                    e.setData(t({}, "pageErrorMsg.show", !0));
                });
            },
            timeUpdateRealTimeBizStatus: function() {
                var e = this;
                try {
                    var t = this.getBizRangeInfo();
                    if (t) {
                        if (!t.realTimeBiz) {
                            var a = +t.startTime + 24 * (t.startTime > this.now() ? 0 : 1) * 60 * 60 * 1e3, r = o.frxs.formaterDate(a, "M月d日H点"), s = o.frxs.getCountDownTimeToObject(this.now(), a);
                            this.setData({
                                bizCountDown: {
                                    title: "距".concat(r, "开售倒计时"),
                                    hours: s.totalHours >= 0 ? s.totalHours : "00",
                                    minute: s.minutes >= 0 ? s.minutes : "00",
                                    second: s.seconds >= 0 ? s.seconds : "00"
                                }
                            });
                        }
                        var n = this.now(), m = +t.startTime <= n && n <= +t.endTime, f = {}, l = this.data.beginPreSale && o.frxs.formaterDate(n, "dd") == o.frxs.formaterDate(t.startTime, "dd");
                        m != this.realTimeBiz && (o.globalData.realTimeBiz = m, this.realTimeBiz = m, f.realTimeBiz = this.realTimeBiz), 
                        l != this.data.isBeginPreSale && (f.isBeginPreSale = l, f.saleDate = "".concat(o.frxs.formaterDate(+t.endTime, "MM月dd日")), 
                        f.beginPreSalePickDate = "".concat(o.frxs.formaterDate(+t.endTime + 864e5, "MM月dd日"))), 
                        Object.keys(f).length > 0 && this.setData(f, function() {
                            f.hasOwnProperty("realTimeBiz") ? 0 == m && (e.waitTwoProduct = !0, e.setTomorrowPopupStatus({
                                showPopup: !0,
                                showBeginPreSaleMask: l
                            })) : f.hasOwnProperty("isBeginPreSale") && f.isBeginPreSale && (e.waitTwoProduct = !0, 
                            e.setTomorrowPopupStatus({
                                showPopup: !0,
                                showBeginPreSaleMask: !0
                            }));
                        }), f.hasOwnProperty("realTimeBiz") && i.default.emit(i.EVENTS.UPDATE_BIZ_STATUS, m);
                    }
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            setPageErrorMsg: function(e) {
                this.setData({
                    "pageErrorMsg.show": !0,
                    "pageErrorMsg.title": e.title,
                    "pageErrorMsg.desc": e.desc || "",
                    "pageErrorMsg.displayTime": ""
                });
            },
            getBizRangeInfo: function() {
                var e = this.bizRange || (o.globalData || {}).bizRange;
                return (0, r.getBizRangeInfo)(e);
            },
            getRealTimeBizStatus: function() {
                var e = this.getBizRangeInfo();
                return e && !e.realTimeBiz;
            },
            setTomorrowPopupStatus: function(e) {
                e = e || {};
                var t = o.frxs.formaterDate(this.now(), "yyyy-MM-dd");
                (e.showPopup || (!this.realTimeBiz || e.isBeginPreSale) && t != o.frxs.getMOrSData("openTomorrowPopupDate")) && (this.setData({
                    showTomorrowPopup: !0,
                    ifShowTomorrowPopup: !0,
                    showBeginPreSaleMask: e.showBeginPreSaleMask
                }), o.frxs.setMAndSData("openTomorrowPopupDate", t));
            },
            closeTomPreviewConfirm: function() {
                this.waitTwoProduct ? wx.reLaunch({
                    url: o.frxsConfig.mall.page.prIndex + "?origin=tompreview"
                }) : this.setData({
                    showTomorrowPopup: !1
                });
            },
            initSysBiz: function() {
                var e = this.getBizRangeInfo();
                e && this.setData({
                    initBizStatus: e.realTimeBiz
                });
            },
            loadTwoProduct: !1,
            showPageLoadTwoProduct: function() {
                this.loadTwoProduct = !0;
            },
            updateRealTimeBizStatus: function() {
                var e = this.getBizRangeInfo(), t = e.realTimeBiz, a = e.beginPreSale && o.frxs.formaterDate(this.now(), "dd") == o.frxs.formaterDate(e.startTime, "dd");
                this.setData({
                    isBeginPreSale: a,
                    isSelfInBiz: t,
                    realTimeBiz: t,
                    beginPreSaleTime: "".concat(o.frxs.formaterDate(e.startTime, "HH:mm"), "-24:00"),
                    saleDate: "".concat(o.frxs.formaterDate(+e.endTime, "MM月dd日")),
                    beginPreSalePickDate: "".concat(o.frxs.formaterDate(+e.endTime + 864e5, "MM月dd日"))
                });
            },
            clearUpdateRealTimeBizStatus: function() {
                clearInterval(this.upBizTimeOut);
            }
        }
    };
};

var t = require("../@babel/runtime/helpers/defineProperty"), a = require("../api/index.js"), r = require("../utils/index"), i = e(require("../utils/events.js")), o = getApp() || {};