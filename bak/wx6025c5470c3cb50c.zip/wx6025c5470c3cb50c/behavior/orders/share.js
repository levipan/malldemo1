var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../api/index.js");

module.exports = function() {
    return {
        data: {},
        defShareTitle: "刚刚又下单啦！快来看我买了哪些宝贝~~",
        receiver: "",
        generatePoster: function() {
            var e = this.getOrderShareInfo(), t = e.prImg, r = e.discountAmt;
            if (!(t = decodeURIComponent(t || "")) || !r) {
                var n = this.data.orderDetails;
                if (!(this.data.orderDetails || {}).orderId) return;
                t = n.itemList[0].thumbnailsUrl, r = 0, n.itemList.map(function(e) {
                    r += e.itemListPrice * e.qty;
                }), r = (r -= n.totalCashAmt || 0) >= 1e3 ? Math.floor(r).toFixed(0) : parseFloat(r.toFixed(2)) + "";
            }
            t = this.convertImgUrl(t), this.getOldOrderShareImage({
                prImg: t,
                discountAmt: r
            });
        },
        convertImgUrl: function(e) {
            return e.replace(/http:\/\//, "https://");
        },
        getOrderShareInfo: function() {
            var e = this.options.prImg || "", t = this.options.discountAmt || "0";
            return {
                prImg: decodeURIComponent(e),
                discountAmt: t
            };
        },
        getOldOrderShareImage: function(e) {
            var r = this, n = e.prImg, i = e.discountAmt;
            t.commonPromotionApi.oldOrderDetailShareImage({
                productImg: decodeURIComponent(decodeURIComponent(n)),
                price: i
            }, {
                contentType: "application/json",
                silence: !0
            }).then(function(e) {
                r.shareAppMessage.imageUrl = e.img;
            }).catch(function() {
                r.shareAppMessage.imageUrl = n;
            });
        },
        getOrderShareImage: function(r) {
            var n = this;
            t.commonPromotionApi.newOrderDetailShareImage(e({}, r), {
                contentType: "application/json",
                silence: !0
            }).then(function(e) {
                n.shareAppMessage.imageUrl = e.img, n.shareTitle = e.content, e.sign && (n.sign = e.sign);
            }).catch(function() {});
        },
        shareImage: function(e) {
            wx.hideLoading();
        },
        getOrderShareTitle: function() {
            var e = this;
            return new Promise(function(r, n) {
                t.brandHousePromotionApi.getOrderShareTitle().then(function(t) {
                    e.shareTitle = t || "", r();
                }).catch(function() {
                    r();
                });
            });
        }
    };
};