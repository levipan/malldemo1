var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/defineProperty"), r = require("../../@babel/runtime/helpers/objectSpread2"), s = e(require("../../router/index")), o = require("../../api/index.js"), a = (require("../../utils/index.js"), 
getApp());

module.exports = function() {
    return {
        data: {},
        onPay: function(e) {
            var t = this, o = e;
            this.weiXinPay({
                orderId: e.detail.orderId,
                userId: a.frxs.getMOrSData("userId"),
                success: function() {
                    try {
                        var o = e.detail.orderId, i = (t.data.orderList || []).find(function(e, t) {
                            return t, e.orderId == o;
                        }) || null;
                        i && i.first && a.frxs.setMData("nextFNameOnLoad", {
                            name: "getNewUserCoupon",
                            data: {
                                orderId: i.orderId,
                                orderTotal: i.orderTotal + "",
                                totalCashAmt: i.totalCashAmt + "",
                                orderDate: a.frxs.formaterDate(i.orderTimer, "yyyy-MM-dd HH:mm:ss")
                            }
                        });
                        try {
                            for (var d = [], n = [], u = i.itemList, c = 0; c < u.length; c++) d.push(u[c].skuSn), 
                            n.push(u[c].sku);
                            var l = i.totalCashAmt || "";
                            a.frxs.XSMonitor.sendEvent("pay_success", {
                                order_id: i.orderId,
                                order_total: l,
                                number: i.totalQty,
                                sku_sn: d.join(","),
                                sku: n.join(","),
                                mkt_acid: "",
                                is_first_order: i.first
                            }, ""), a.frxs.XSMonitor.sendTestEvent("pay_success", {
                                slot: "支付成功",
                                amount: i.totalCashAmt || ""
                            });
                        } catch (e) {}
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        console.error(e);
                    }
                    s.default.navigateTo({
                        path: "/subPages/users/orderList/orderList",
                        isRedirect: !0,
                        query: r(r({}, t.options), {}, {
                            t: +new Date()
                        })
                    });
                },
                fail: function(e) {
                    try {
                        var r = o.detail.orderId, s = (t.data.orderList || []).find(function(e, t) {
                            return t, e.orderId == r;
                        }) || null;
                        "FE07231002002" === e.rspCode && t.onAddOrderProduct2Cart(wx.$._get(s, "itemList", []));
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        console.error(e);
                    }
                    console.error(e), t.setData({
                        btnDisabled: !1
                    }), wx.showModal({
                        title: "温馨提示",
                        content: e.rspDesc || "未获取到支付成功信息，请在10分钟内到订单中继续支付，逾时订单将自动关闭！",
                        showCancel: !1
                    });
                }
            });
        },
        toDetails: function(e) {
            console.log(e.detail);
            var t = e.detail.orderId, r = -1, o = (this.data.orderList.find(function(e, s) {
                return e.orderId == t && (r = s), e.orderId == t;
            }), {
                orderId: t,
                orderListIndex: r
            });
            "refund" === e.detail.type && (o.jumpType = "refund"), s.default.navigateTo({
                path: "/subPages/users/orderDetail/orderDetail",
                query: o
            });
        },
        onDelete: function(e) {
            var r = e.detail.orderId, s = -1, i = (this.data.orderList.find(function(e, t) {
                return e.orderId == r && (s = t), e.orderId == r;
            }), this);
            wx.showModal({
                title: "确认删除",
                content: "您确定删除订单吗?",
                success: function(e) {
                    if (e.confirm) {
                        var d = {
                            userKey: wx.getStorageSync("userKey"),
                            orderId: r,
                            memberIsShow: !1,
                            areaId: i.data.orderList[s].areaId
                        };
                        o.tradeApi.delOrder(d).then(function(e) {
                            wx.showModal({
                                title: "温馨提示",
                                content: "订单删除成功",
                                showCancel: !1,
                                success: function() {
                                    i.setData(t({}, "orderList[" + s + "].isShow", !1));
                                }
                            }), a.aldstat.sendEvent("删除订单", "列表页");
                        }).catch(function(e) {
                            a.frxs.alert({
                                content: e && e.rspDesc || "删除订单失败，请稍候重试..."
                            });
                        });
                    }
                }
            });
        },
        cancalTuan: function(e) {
            var r = e.detail.orderId, s = -1, i = this.data.orderList.find(function(e, t) {
                return e.orderId == r && (s = t), e.orderId == r;
            }), d = this;
            wx.showModal({
                title: "确认操作",
                content: "您确定取消跟团吗?",
                success: function(e) {
                    if (e.confirm) {
                        var r = {
                            userKey: wx.getStorageSync("userKey"),
                            oi: i.orderId,
                            gi: i.groupId,
                            ils: {
                                ess: (i.itemList[0] || {}).eSkuSn,
                                q: i.totalQty
                            }
                        };
                        o.tradeApi.closeGroupOrder(r, {
                            contentType: "application/json"
                        }).then(function(e) {
                            wx.showModal({
                                title: "温馨提示",
                                content: "取消跟团成功",
                                showCancel: !1,
                                success: function() {
                                    d.setData(t({}, "orderList[" + s + "].isShow", !1));
                                }
                            }), a.aldstat.sendEvent("删除订单", "列表页");
                        }).catch(function(e) {
                            a.frxs.alert({
                                content: e && e.rspDesc || "取消跟团失败，请稍候重试..."
                            });
                        });
                    }
                }
            });
        },
        goIndex: function() {
            s.default.switchTab({
                path: "/pages/home/index/index"
            });
        },
        updateOrderStatus: function(e, r) {
            for (var s = -1, o = this.data.orderList, a = 0; a < o.length; a++) if (o[a].orderId == e) {
                s = 1;
                break;
            }
            s >= 0 && (this.data.orderStatus != r && "all" != this.data.orderStatus ? (o.splice(a, 1), 
            this.setData({
                orderList: o
            })) : this.setData(t({}, "orderList[" + a + "].orderStatus", r)));
        },
        getUserKey: function(e) {
            var t = this, r = a.frxs.getMOrSData("userKey");
            return a.frxs.isNullOrWhiteSpace(r) ? (a.userSvr.autoLogin({
                success: function(r) {
                    t.getOrderData(e);
                },
                fail: function(e) {
                    a.frxs.showModal({
                        title: "验证登录信息失败，请稍候重试...",
                        showCancel: !1
                    });
                }
            }), "") : r;
        },
        toIndex: function() {
            s.default.switchTab({
                path: "/pages/home/index/index"
            });
        },
        loadOrderList: function(e, t) {
            for (var r = e.data, s = r.length, o = 0; o < r.length; o++) {
                r[o].orderTimer = r[o].orderDate, r[o].orderDate = a.frxs.formaterDate(r[o].orderDate, "yyyy-MM-dd HH:mm:ss"), 
                r[o].isZero = (wx.$._get(r, "".concat(o, ".tags"), []) || []).indexOf("FREE_PURCHASE") > -1 || (wx.$._get(r, "".concat(o, ".tags"), []) || []).indexOf("POINT_EXCHANGE_SHOPPING") > -1;
                var i = 0;
                if (null != r[o].itemList) for (var d = 0; d < r[o].itemList.length; d++) i += r[o].itemList[d].qty, 
                r[o].itemList[d].isZero = r[o].isZero, r[o].itemList[d].deliveryTimeMS = r[o].itemList[d].deliveryTime || "", 
                r[o].itemList[d].deliveryTime = a.frxs.formaterDate(r[o].itemList[d].deliveryTime, "MM月dd日 HH:mm ");
                r[o].itemCount = i, r[o].isShow = !0, this.setDataOrderList(r[o], this.data.orderList.length, s);
            }
            this.isLoad = !1;
        },
        setDataOrderList: function(e, r, s) {
            var o = this;
            o.setData(t({}, "orderList[" + r + "]", e), function() {
                s.length - 1 == r && o.pageDestroy();
            }), s.length - 1 == r && -1 == a.frxs.compareVersion("1.5.0") && o.pageDestroy();
        }
    };
};