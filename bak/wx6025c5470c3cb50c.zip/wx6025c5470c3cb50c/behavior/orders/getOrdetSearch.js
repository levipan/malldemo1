var e = require("../../api/index.js");

module.exports = function() {
    return {
        getOrdetSeachTitle: function() {
            var t = this;
            e.newNoticeApi.getOrderSearchPlaceholder({}, {
                contentType: "application/json",
                slience: !0
            }).then(function(e) {
                e ? t.setData({
                    orderSearchTitle: "商品名称（".concat(e, "）")
                }) : t.setData({
                    orderSearchTitle: "商品名称（仅支持两年以内的订单）"
                });
            }).catch(function(e) {
                t.setData({
                    orderSearchTitle: "商品名称（仅支持两年以内的订单）"
                }), console.log(e);
            });
        }
    };
};