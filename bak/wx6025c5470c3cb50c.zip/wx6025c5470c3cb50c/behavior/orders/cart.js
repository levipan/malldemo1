var t = require("../../@babel/runtime/helpers/interopRequireWildcard"), e = require("../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../api/index.js"), n = e(require("../../utils/cartService.js")), s = require("../../utils/index.js"), a = t(require("../../utils/events.js")), u = e(require("../../router/index.js")), o = (e(require("../../@xsyx-components/hanzo-dialog/dialog.js")), 
e(require("../../@xsyx-components/hanzo-page-loading/loading.js"))), i = e(require("../../utils/outBuisness-store-dialog")), c = (e(require("../video/product.js")), 
getApp());

c.frxsConfig.ossDomain;

module.exports = function() {
    return {
        data: {
            addCartAnimate: {},
            runAnimate: !1
        },
        lastSubProduct: {},
        onBuyAgain: function(t) {
            var e = this;
            if ("PHONE" !== t.currentTarget.dataset.orderType) {
                if (i.default.showoutBuisnessDialog()) return !1;
                var s = t.detail.productDetails;
                if (!s.showBuy) return this.addProductSub(s);
                var u = {
                    areaId: c.frxs.getMOrSData("areaId"),
                    sku: s.sku,
                    skuSn: s.skuSn,
                    storeId: c.frxs.getMOrSData("storeId")
                };
                r.brandHousePromotionApi.queryProductBySkuSnOrSku(u, {
                    loading: "加购中...",
                    contentType: "application/json"
                }).then(function(r) {
                    if (r.sku) {
                        r.prName = s.productName;
                        var u = n.default.addCart(r, 1, e);
                        if ("success" != u.rspCode) {
                            if ("max" == u.rspCode) return c.frxs.alert({
                                content: u.info
                            });
                            o.default.showToast({
                                title: u.info,
                                icon: "info",
                                mask: !0
                            });
                        } else e.addCartSuccess({
                            position: t.detail.position,
                            product: s
                        }), a.default.emit(a.EVENTS.REFRESH_CART);
                        c.frxs.XSMonitor.sendEvent("re_add_product", {
                            sku: s.sku || "",
                            skuSn: s.skuSn || "",
                            add_sku_sn: r.skuSn || "",
                            add_sku: r.sku || "",
                            code: "success" == u.rspCode ? "success" : "fail"
                        }, "再次购买");
                    } else c.frxs.alert({
                        content: "当前商品暂时不可购买，我们已经收到亲亲强烈的购买意愿了，会尽快为您上架该商品哦~",
                        confirmText: "知道了"
                    }), c.frxs.XSMonitor.sendEvent("re_add_product", {
                        sku: s.sku || "",
                        skuSn: s.skuSn || "",
                        add_sku_sn: "",
                        add_sku: "",
                        code: "fail"
                    }, "再次购买");
                }).catch(function(t) {});
            } else wx.navigateTo({
                url: "/subPages/pages/payPhone/home/index?storeId=".concat(t.currentTarget.dataset.storeId, "&phone=").concat(t.currentTarget.dataset.orderPhone)
            });
        },
        refreshCartNum: function() {
            this.setData({
                cartCount: n.default.getCartNum()
            });
        },
        refreshPageCartData: function() {
            var t = {};
            try {
                n.default.getCartList().map(function(e) {
                    e.preacId, e.productId;
                    var r = e.skuSn, n = e.spuSn;
                    t[(0, s.pk)(n, r)] = e.cartQuantity;
                }), this.setData({
                    cartNumberMap: t
                });
            } catch (t) {}
        },
        addEventRefreshCartNum: function() {
            a.default.on(a.EVENTS.ADD_CART, this.refreshCartNum, this), a.default.on(a.EVENTS.REFRESH_CART, this.execRefreshCart, this);
        },
        execRefreshCart: function() {
            this.refreshCartNum(), this.refreshCartQuantity && this.refreshCartQuantity(), this.refreshPageCartData();
        },
        removeEventRefreshCartNum: function() {
            a.default.remove(a.EVENTS.ADD_CART, this.refreshCartNum, this), a.default.remove(a.EVENTS.REFRESH_CART, this.execRefreshCart, this);
        },
        toCart: function() {
            u.default.navigateTo({
                path: "/pages/home/cart/cart"
            });
        },
        getOrderProductShareInfo: function(t) {
            var e = t[0].thumbnailsUrl || "", r = 0;
            return t.map(function(t) {
                r += (t.itemListPrice - t.itemAdjustedPrice) * t.qty;
            }), {
                prImg: e,
                discountAmt: r = r.toFixed(2)
            };
        },
        getProductSaleStatus: function(t) {
            if (0 == (t.orderList || []).length) return t.callback(t.orderList);
            var e = this.areaId || c.frxs.getMOrSData("areaId") || 0, n = this.storeId || c.frxs.getMOrSData("storeId") || 0, s = this.userKey || c.frxs.getMOrSData("userKey");
            if (0 == e || 0 == n) return t.callback(t.orderList);
            var a = [];
            if (t.orderList.map(function(t) {
                return t.orderTimer = t.orderDate, (t.itemList || []).map(function(t) {
                    return t.buyText = "", t.spuSn && t.sku && a.push({
                        spuSn: t.spuSn,
                        sku: t.sku
                    }), t;
                });
            }), 0 == a.length) return t.callback(t.orderList);
            if (a = c.frxs.unique(a), t.showBuyInfo) {
                var u = (t.showBuyInfo || {}).spuSnShowBuyDtos;
                t.orderList.map(function(t) {
                    t.itemList.map(function(e) {
                        if (e.spuSn) {
                            var r = (u.find(function(t) {
                                return t.spuSn == e.spuSn;
                            }) || {}).showBuy;
                            e.showBuy = r, e.buyText = r ? "再次购买" : "要求再次上线";
                        }
                        "GROUPBUY" == t.scene && (e.scene = t.scene, e.textInfo = t.textInfo, e.groupBuyStatus = t.groupBuyStatus, 
                        e.groupId = t.groupId);
                    });
                }), t.callback(t.orderList);
            } else r.brandHousePromotionApi.batchQueryCanBuy({
                spuSns: a,
                areaId: e,
                storeId: n,
                userKey: s
            }, {
                contentType: "application/json"
            }).then(function(e) {
                var r = e || [];
                t.orderList.map(function(t) {
                    t.itemList.map(function(e) {
                        if (e.spuSn) {
                            var n = (r.find(function(t) {
                                return t.spuSn == e.spuSn;
                            }) || {}).showBuy;
                            e.showBuy = n, e.buyText = n ? "再次购买" : "要求再次上线";
                        }
                        "GROUPBUY" == t.scene && (e.scene = t.scene, e.textInfo = t.textInfo, e.groupBuyStatus = t.groupBuyStatus, 
                        e.groupId = t.groupId);
                    });
                }), t.callback(t.orderList);
            }).catch(function(e) {
                t.callback(t.orderList);
            });
        },
        btnToCartPosition: null,
        onToCartTouchend: function(t) {
            this.btnToCartPosition = {
                clientX: t.changedTouches[0].clientX,
                clientY: t.changedTouches[0].clientY
            };
        },
        onAnimationEnd: function() {
            this.setData({
                runAnimate: !1
            });
        },
        getCartPosition: function(t) {
            var e = this;
            wx.createSelectorQuery().selectAll("#btn-move-cart").boundingClientRect(function(r) {
                (r || []).length > 0 && (e.btnToCartPosition = {
                    clientX: r[0].left,
                    clientY: r[0].top
                }), t();
            }).exec();
        }
    };
};