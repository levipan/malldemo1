var t = require("../../@babel/runtime/helpers/interopRequireDefault"), o = require("../../@babel/runtime/helpers/defineProperty"), e = t(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../@babel/runtime/helpers/objectSpread2"), u = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../api/index.js"), a = (t(require("../../xapp/runtime")), 
t(require("../../@xsyx-components/hanzo-page-loading/loading")), getApp());

module.exports = function() {
    return {
        data: {
            couponList: [],
            currCoupon: {},
            xingTotal: 0,
            totalAmount: 0,
            showErrorCoupon: !1
        },
        members: {
            cartPathArray: [ "subOrder/cart/cart", "pages/home/cart/cart", "subMain/main/index?tabCode=cart" ],
            getCouponList: function() {
                var t = arguments, o = this;
                return u(e.default.mark(function u() {
                    var c, s, p, d, l, h, f, m, S, g;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (c = t.length > 0 && void 0 !== t[0] ? t[0] : {}, s = t.length > 1 ? t[1] : void 0, 
                            e.prev = 2, p = a.frxs.getMOrSData("storeInfo") || {}, !o.isHide && p.provinceId) {
                                e.next = 6;
                                break;
                            }
                            return e.abrupt("return", []);

                          case 6:
                            if (a.frxs.getMOrSData("userKey") && a.frxs.getMOrSData("isLogin")) {
                                e.next = 9;
                                break;
                            }
                            return r.couponApi.queryNoLoginRecommendTickets({
                                provinceCode: p.provinceId,
                                cityCode: p.cityId,
                                areaCode: p.countyId,
                                saleRegionCode: a.frxs.getMOrSData("areaId") || p.areaId,
                                storeId: a.frxs.getMOrSData("storeId") || p.storeId,
                                channelUse: "WXAPP",
                                userScopeTypes: [ "NO_LOGIN" ]
                            }, {
                                contentType: "application/json",
                                silence: !0
                            }).then(function(t) {
                                var e = {};
                                (t = t || []).forEach(function(t) {
                                    if ("SINGLE" === t.rootType && "PRICE" === t.toolType) {
                                        var n = o._get(t, "skus.0", !1) || !1;
                                        t.showTicketPrice = !0, n && (e[t.skus[0]] = t);
                                    }
                                }), o.setData({
                                    newUserCouponMap: e
                                }, function() {
                                    s && s();
                                });
                            }).catch(function(t) {}), e.abrupt("return", []);

                          case 9:
                            if (d = function() {
                                switch (o.route) {
                                  case "subMain/main/index?tabCode=home":
                                  case "subMain/main/index?tabCode=brand":
                                  case "pages/home/index/index":
                                  case "pages/home/cateProduct/index":
                                  case "subPages/home/brand/search/search":
                                  case "pages/brand/search/search":
                                  case "subProduct/detail/index":
                                  case "subNewUser/active/index":
                                    return c.recommendType = "QUERY_V2", !1;

                                  case "pages/home/cart/cart":
                                  case "subOrder/cart/cart":
                                  case "subMain/main/index?tabCode=cart":
                                  case "subOrder/uyingDirect/uyingDirect":
                                  case "pages/order/uyingDirect/uyingDirect":
                                    return c.recommendType = "RECOMMEND_V2", !1;

                                  default:
                                    return !0;
                                }
                            }(), l = {}, "pages/order/uyingDirect/uyingDirect" === o.route && (l = {
                                loading: "加载中"
                            }), a.frxs.getMData("isNewUser") && (c.blackbox = a.frxs.storage("safe_bb") || ""), 
                            !c.hasOwnProperty("skuInfoList") || !Array.isArray(c.skuInfoList) || 0 !== c.skuInfoList.length) {
                                e.next = 15;
                                break;
                            }
                            return e.abrupt("return", []);

                          case 15:
                            return e.next = 17, r.couponApi.queryRecommendTickets(i({
                                provinceCode: p.provinceId,
                                cityCode: p.cityId,
                                areaCode: p.countyId,
                                saleRegionCode: a.frxs.getMOrSData("areaId") || p.areaId,
                                storeId: a.frxs.getMOrSData("storeId") || p.storeId,
                                channelUse: "WXAPP",
                                userScopeTypes: [ a.frxs.getMData("isNewUser") ? "NEW_USER" : "NORMAL" ]
                            }, c), i({
                                contentType: "application/json",
                                silence: !0,
                                loginVerify: d
                            }, l));

                          case 17:
                            return h = (h = e.sent) || [], (c.skuInfoList || []).forEach(function(t) {
                                t.discount = t.discount || 100, h = h.map(function(o) {
                                    if (o.notSupportSkuSet = o.notSupportSkuSet || [], o.supportSkuSet = o.supportSkuSet || [], 
                                    !o.isAvailable) return o;
                                    if ("DISCOUNT" === o.toolType && [ "MULTIPLE", "GLOBAL" ].indexOf(o.rootType) > -1) {
                                        if (100 === t.discount) {
                                            if (0 === o.supportSkuStatus) return o.supportSkuStatus = 2, o.notSupportSkuSet = n(new Set([].concat(n(o.notSupportSkuSet), [ t.skuSn ]))), 
                                            o;
                                            if (1 === o.supportSkuStatus) {
                                                var e = o.supportSkuSet.indexOf(t.skuSn);
                                                if (e > -1) return o.supportSkuSet.splice(e, 1), o;
                                            }
                                            return 2 === o.supportSkuStatus ? (o.notSupportSkuSet = n(new Set([].concat(n(o.notSupportSkuSet), [ t.skuSn ]))), 
                                            o) : o;
                                        }
                                        if (0 === o.supportSkuStatus && t.discount > o.minDiscount) return o.supportSkuStatus = 2, 
                                        o.notSupportSkuSet = n(new Set([].concat(n(o.notSupportSkuSet), [ t.skuSn ]))), 
                                        o;
                                        if (1 === o.supportSkuStatus) {
                                            var i = o.supportSkuSet.indexOf(t.skuSn);
                                            if (i > -1 && t.discount > o.minDiscount) return o.supportSkuSet.splice(i, 1), o;
                                        }
                                        if (2 === o.supportSkuStatus) return t.discount > o.minDiscount && (o.notSupportSkuSet = n(new Set([].concat(n(o.notSupportSkuSet), [ t.skuSn ])))), 
                                        o;
                                    }
                                    return o;
                                });
                            }), (o.cartPathArray.indexOf(o.route) > -1 || "subOrder/uyingDirect/uyingDirect" === o.route) && (f = {
                                amount: 0
                            }, h.forEach(function(t) {
                                "PRICE" === t.toolType && "SINGLE" === t.rootType && f.amount < t.amount && (f = t);
                            }), f.ticketId && (h = h.filter(function(t) {
                                return ("SINGLE" !== t.rootType || t.supportSkuSet[0] !== f.supportSkuSet[0] || f.ticketId === t.ticketId) && ("PRICE" !== t.toolType || t.ticketId === f.ticketId);
                            }))), m = JSON.parse(JSON.stringify(h || [])), S = [], g = [], h.forEach(function(t, o) {
                                [ "ORDER_STEP_GLOBAL", "ORDER_STEP_MULTIPLE" ].indexOf(t.ticketType) > -1 && (g.push(o), 
                                t.orderStep.forEach(function(o) {
                                    var e = i({}, t);
                                    delete e.orderStep, e.orderAmountLimit = o.useOrderAmountLimit, e.maxAmount = e.amount = o.singleToolAmount, 
                                    S.push(e);
                                }));
                            }), g.forEach(function(t, o) {
                                h.splice(t - o, 1);
                            }), h = (h = S.concat(h)).sort(function(t, o) {
                                return +new Date(t.tmExpire.replace(/-/gi, "/")) - +new Date(o.tmExpire.replace(/-/gi, "/"));
                            }).map(function(t) {
                                return t.categoryMap = {}, (t.categoryList || []).forEach(function(o) {
                                    t.categoryMap[o.cateId] = t.categoryMap[o.cateId] || [], o.children && t.categoryMap[o.cateId].push(o.children.cateId);
                                }), "SINGLE" === t.rootType && "PRICE" === t.toolType && (t.showTicketPrice = !0), 
                                t;
                            }).sort(function(t, o) {
                                return o.amount - t.amount;
                            }), e.abrupt("return", {
                                dbCouponList: m,
                                couponList: h
                            });

                          case 31:
                            return e.prev = 31, e.t0 = e.catch(2), console.log(e.t0), e.abrupt("return", []);

                          case 35:
                          case "end":
                            return e.stop();
                        }
                    }, u, null, [ [ 2, 31 ] ]);
                }))();
            },
            getNoUseCoupon: function(t, o) {
                var e = this;
                t = t.sort(function(t, o) {
                    return t.orderAmountLimit - o.orderAmountLimit;
                });
                var n = null, i = {};
                try {
                    t.forEach(function(t) {
                        var u = 0;
                        if (o.forEach(function(o) {
                            e.cartPathArray.indexOf(e.route) > -1 && (1 !== parseInt(o.checkbox) || o.isDelete) || 3 !== o.changeCodeType && e.getCouponByLocal(o, [ t ], !0).length > 0 && (u += 1 * o.actualPrice);
                        }), 0 !== u) {
                            var r = t.orderAmountLimit - u;
                            r = 1 * r.toFixed(2), (null === n || n > r) && (n = r, i = t);
                        }
                    });
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.error(t);
                }
                return console.log(n, "minPriceminPrice", i), this.setData({
                    noUseCoupon: i
                }), {
                    remark: n < 0 ? i.display : n
                };
            },
            initCoupon: function(t) {
                var o = this, e = t.couponList, n = t.productList, u = t.callback, r = t.beforeSetData;
                e || (e = []), n = n || [], this.switchCouponList(e, n);
                var a = this.linkProductAndCoupon(n), c = this.computePrice(a.totalAmount, a.productList), s = c.totalAmount, p = c.totalPrice, d = c.checkedCoupon;
                console.log("所有优惠券：", e), console.log("可用的多品券：", this.multiCouponList), console.log("推荐的单品券：", n), 
                console.log("推荐的多品券：", d), console.log(s, p), d.hasOwnProperty("ticketId") || (d = i(i({}, d), this.getNoUseCoupon(this.multiCouponList, n)));
                var l = {
                    xingCouponList: this.xingCouponList,
                    multiCouponList: this.multiCouponList,
                    products: a.productList,
                    originalTotalPrice: 1 * s + 1 * p,
                    totalPrice: p,
                    totalAmount: s,
                    checkedCoupon: d
                }, h = function(t) {
                    o.setData(i({}, t), function() {
                        u && u({
                            totalPrice: p,
                            totalAmount: s
                        });
                    });
                };
                r ? l = r(l, h) : h(l);
            },
            switchCouponList: function(t, o) {
                var e = this;
                this.singleCouponList = [], this.multiCouponList = [], this.xingCouponList = [];
                var n = [];
                this.cartPathArray.indexOf(this.route) > -1 && o.forEach(function(t) {
                    1 !== parseInt(t.checkbox) || t.isDelete || n.push(t.skuSn);
                }), t.forEach(function(t) {
                    if ("SINGLE" === t.ticketType) return e.singleCouponList.push(t);
                    if ("X_COIN" === t.ticketType) return e.xingCouponList.push(t);
                    if (e.cartPathArray.indexOf(e.route) > -1) {
                        if (!t.isAvailable) return !1;
                        if (0 === t.supportSkuStatus) return e.multiCouponList.push(t);
                        1 === t.supportSkuStatus && wx.$.forEach(n, function(o) {
                            if (t.supportSkuSet.indexOf(o) > -1) return e.multiCouponList.push(t), !0;
                        }), 2 === t.supportSkuStatus && wx.$.forEach(n, function(o) {
                            if (!(t.notSupportSkuSet.indexOf(o) > -1)) return e.multiCouponList.push(t), !0;
                        });
                    } else e.multiCouponList.push(t);
                });
            },
            linkProductAndCoupon: function(t) {
                var o = this, e = 0;
                return this.singleCouponList = this.singleCouponList.map(function(t) {
                    return t.checked = !1, t;
                }), {
                    productList: t = t.map(function(t) {
                        if (o.cartPathArray.indexOf(o.route) > -1 && (1 !== parseInt(t.checkbox) || t.isDelete)) return t.couponList = [], 
                        t.coupon = null, t;
                        if (3 === t.changeCodeType) return t.couponList = [], t.coupon = null, t;
                        t.couponList = o.getCouponByLocal(t, o.singleCouponList);
                        var n = o.getCouponByLocal(t, o.singleCouponList, !0);
                        try {
                            if (0 === t.couponList.length) return t;
                            if (t.couponList = n.map(function(o) {
                                if (o.canUse = (t.saleAmt * t.cartQuantity).toFixed(2) >= o.orderAmountLimit, !o.canUse) return o;
                                var e = o.discountNumber || 1, n = t.cartQuantity, i = n > e ? e : n;
                                return o.discountPrice = 1 * (i * o.amount).toFixed(2), o;
                            }), t.coupon = n.filter(function(t) {
                                return t.canUse;
                            }).sort(function(t, o) {
                                return o.discountPrice - t.discountPrice;
                            })[0] || [], t.coupon) t.coupon.isMax = !0, t.coupon.checked = !0; else {
                                t.coupon = {};
                                var i = n.sort(function(t, o) {
                                    return t.orderAmountLimit - o.orderAmountLimit;
                                }), u = null;
                                i.forEach(function(o) {
                                    var e = o.orderAmountLimit - (t.saleAmt * t.cartQuantity).toFixed(2);
                                    e = e.toFixed(2), (null === u || u > e) && (u = e);
                                }), t.coupon.remark = u;
                            }
                        } catch (o) {
                            o = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(o);
                            t.coupon = null;
                        } finally {
                            var r = t.coupon && t.coupon.discountPrice && "PRICE" !== t.coupon.toolType ? t.coupon.discountPrice : 0;
                            t.actualPrice = (t.saleAmt * t.cartQuantity - (t.coupon && t.coupon.discountPrice ? t.coupon.discountPrice : 0)).toFixed(2), 
                            t.actualPrice = t.actualPrice > 0 ? t.actualPrice : 0, e += r;
                        }
                        return t;
                    }),
                    totalAmount: e = e.toFixed(2)
                };
            },
            computePrice: function(t, o) {
                var e = this, n = this.getMultiCoupon(this.multiCouponList, o, !0), i = 0;
                return o.forEach(function(t) {
                    e.cartPathArray.indexOf(e.route) > -1 && (1 !== parseInt(t.checkbox) || t.isDelete) || 3 !== t.changeCodeType && (i += 1 * t.actualPrice);
                }), this.getDataByMultiCoupon(n, i, t);
            },
            getDataByMultiCoupon: function(t, o, e) {
                var n = t.hasOwnProperty("discountPrice") ? "SINGLE" !== t.rootType ? t.useAmount : t.discountPrice : 0;
                return e = (1 * e + 1 * n).toFixed(2), {
                    totalPrice: o = (1 * (o = (o -= n) > 0 ? o.toFixed(2) : 0)).toFixed(2),
                    totalAmount: e = (1 * e).toFixed(2),
                    checkedCoupon: t
                };
            },
            getMultiCoupon: function(t, o, e) {
                var n, i = this, u = {}, r = [];
                return this.multiCouponList = t.sort(function(t, o) {
                    return o.amount - t.amount;
                }).map(function(t) {
                    if (t.useAmount = t.amount, t.discountPrice = 1 * t.amount, "DISCOUNT" === t.toolType) {
                        var n = 0, a = 1 * t.amount;
                        o.forEach(function(o) {
                            if (o.discount = o.discount || 100, !(i.cartPathArray.indexOf(i.route) > -1 && (1 !== parseInt(o.checkbox) || o.isDelete) || 3 === o.changeCodeType || 0 === a)) {
                                var r = 0;
                                if (o.discount < t.maxDiscount && (r = t.maxDiscount), o.discount >= t.maxDiscount && o.discount <= t.minDiscount && (r = o.discount), 
                                o.discount > t.minDiscount && (r = 0), r) {
                                    r = 1 * (r / 100).toFixed(2);
                                    var c = 1 * (1 * ((o.saleAmt - r * o.saleAmt) * o.cartQuantity).toFixed(2) - (o.saleAmt * o.cartQuantity - o.actualPrice)).toFixed(2);
                                    i.getCouponByLocal(o, [ t ], e).length > 0 && (c > 0 && (a <= c && (u[t.ticketId] || (u[t.ticketId] = {}), 
                                    u[t.ticketId][o.skuSn] = a, a = 0), a > c && (u[t.ticketId] || (u[t.ticketId] = {}), 
                                    u[t.ticketId][o.skuSn] = c, a = 1 * (a - c).toFixed(2)), t.multiRemainAmount = a, 
                                    t.useAmount = 1 * (t.amount - a).toFixed(2)), n += 1 * o.actualPrice);
                                }
                            }
                        }), t.checked = !1, t.isMax = !1, n = 1 * n.toFixed(2), t.orderAmountLimit = 1 * t.orderAmountLimit.toFixed(2), 
                        n >= t.orderAmountLimit ? (r.push(t), t.canUse = !0, t.disparity = 0) : (t.canUse = !1, 
                        t.disparity = 1 * (t.orderAmountLimit - n).toFixed(2));
                    } else {
                        var c = 0;
                        o.forEach(function(o) {
                            i.cartPathArray.indexOf(i.route) > -1 && (1 !== parseInt(o.checkbox) || o.isDelete) || 3 !== o.changeCodeType && i.getCouponByLocal(o, [ t ], e).length > 0 && (c += 1 * o.actualPrice);
                        }), t.checked = !1, t.isMax = !1, c = 1 * c.toFixed(2), t.orderAmountLimit = 1 * t.orderAmountLimit.toFixed(2), 
                        c >= t.orderAmountLimit ? (r.push(t), t.canUse = !0, t.disparity = 0) : (t.canUse = !1, 
                        t.disparity = 1 * (t.orderAmountLimit - c).toFixed(2));
                    }
                    return t;
                }), n = r.sort(function(t, o) {
                    return o.useAmount - t.useAmount;
                })[0] || {}, this.multiCouponList.map(function(t) {
                    return t.ticketId === n.ticketId && (t.discountPrice = n.useAmount, t.checked = !0, 
                    t.isMax = !0), t;
                }), this.setData({
                    productMultDiscountMap: "DISCOUNT" === n.toolType ? u[n.ticketId] : {}
                }), n;
            },
            getCouponByLocal: function(t, o, e) {
                return o.filter(function(o) {
                    return !(e && !o.isAvailable) && (0 === o.supportSkuStatus || (1 === o.supportSkuStatus ? o.supportSkuSet.indexOf(t.skuSn) > -1 : 2 === o.supportSkuStatus && -1 === o.notSupportSkuSet.indexOf(t.skuSn)));
                });
            },
            onPopupAnimationShowEnd: function() {
                this.setData({
                    isShowCouponList: !0
                });
            },
            onPopupAnimationCloseEnd: function() {
                this.setData({
                    isShowCouponList: !1
                });
            },
            getSingleAmountTotal: function(t) {
                var o = 0, e = 0;
                return t = t.map(function(t) {
                    var n = t.coupon && t.coupon.discountPrice && "PRICE" !== t.coupon.toolType ? t.coupon.discountPrice : 0;
                    return t.actualPrice = (t.saleAmt * t.cartQuantity - (t.coupon && t.coupon.discountPrice ? t.coupon.discountPrice : 0)).toFixed(2), 
                    t.actualPrice = t.actualPrice > 0 ? t.actualPrice : 0, e += 1 * t.actualPrice, o += n, 
                    t;
                }), e = 1 * e.toFixed(2), {
                    amount: o = 1 * o.toFixed(2),
                    totalPrice: e,
                    products: t
                };
            },
            initMultiCoupon: function() {
                var t = this, o = this.getSingleAmountTotal(this.data.products), e = o.amount, n = o.products, u = this.computePrice(e, this.data.products), r = u.totalAmount, a = u.totalPrice, c = u.checkedCoupon;
                this.setData({
                    noUseCoupon: {}
                }), c.hasOwnProperty("ticketId") || (c = i(i({}, c), this.getNoUseCoupon(this.multiCouponList, this.data.products))), 
                console.log("推荐的单品券：", this.data.products), console.log("推荐的多品券：", c), console.log(r, a), 
                this.setData({
                    products: n,
                    multiCouponList: this.multiCouponList,
                    totalPrice: a,
                    totalAmount: r,
                    checkedCoupon: c
                }, function() {
                    t.initXing && t.initXing();
                });
            },
            initXing: function(t) {
                var o = this, e = [], n = 1, i = function(t) {
                    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, e = o, n = (1 * t + "").split(".");
                    if (n.length > 1) {
                        var i = (n[1] + "").length;
                        e = i > o ? i : o;
                    }
                    return e;
                }, u = this.data.originalTotalPrice - this.data.totalAmount;
                (this.data.xingCouponList || []).forEach(function(t) {
                    n = i(t.amount, n), e.push(1 * t.amount);
                });
                var r = 1 * ((u || 0) - .01).toFixed(2);
                if (r <= 0) return this.setData({
                    xingTotal: 0,
                    totalPrice: (1 * (u || 0)).toFixed(2)
                }, function() {
                    t && t();
                });
                n = i(r = r <= .01 ? .01 : r, n);
                var c = Math.pow(10, n);
                e = e.map(function(t) {
                    return 1 * (t * c).toFixed(2);
                }), this.xingResult = a.frxs.knapsack(e, e, 1 * (r * c).toFixed(2));
                var s = this.xingResult.reduce(function(t, e) {
                    return t + 1 * o.data.xingCouponList[e.index].amount;
                }, 0).toFixed(2);
                this.setData({
                    xingTotal: s,
                    totalPrice: (1 * (u || 0) - 1 * s).toFixed(2)
                }, function() {
                    t && t();
                });
            },
            onTapCoupon: function(t) {
                var e = this;
                if ("radio-disable" !== t.detail.type) {
                    var n = t.detail.store, u = t.currentTarget.dataset.list, r = this.updatedCoupon, a = r.type, c = r.key, s = r.index, p = {
                        userSelected: !0
                    }, d = {};
                    if (u = u.map(function(t) {
                        return t.ticketId === n.ticketId ? (t.checked = !t.checked, t.checked && (p = t)) : t.checked = !1, 
                        t;
                    }), "multi" === a && (d = {
                        multiCouponList: u,
                        checkedCoupon: p,
                        coupon: p
                    }), "single" === a) {
                        var l = this.data[c][s];
                        l.coupon = p, l.couponList = u, d = o({}, "".concat(c, "[").concat(s, "]"), l);
                    }
                    this.setData(i({
                        currCoupon: p,
                        couponList: u
                    }, d), function() {
                        if ("single" === a && e.initMultiCoupon(), "multi" === a) {
                            var t = e.getSingleAmountTotal(e.data.products), o = t.amount, n = t.totalPrice, i = u.filter(function(t) {
                                return t.checked;
                            })[0] || {}, r = e.getDataByMultiCoupon(i, n, o), c = r.totalAmount;
                            n = r.totalPrice, e.setData({
                                multiCouponList: u,
                                originalTotalPrice: 1 * c + 1 * n,
                                totalPrice: n,
                                totalAmount: c
                            }, function() {
                                e.initXing && e.initXing();
                            });
                        }
                    });
                }
            }
        }
    };
};