Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    _onCallVirtualPhone: function(e) {
        try {
            var o = this.selectComponent("#virtual-phone");
            o.getPhone && o.getPhone(e);
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    virtualPhoneShow: function(e) {},
    virtualPhoneClose: function(e) {},
    virtualPhoneCancel: function(e) {},
    virtualPhoneOk: function(e) {},
    virtualPhoneError: function(e) {}
};

exports.default = e;