var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            bannerList: [],
            bannerCurrent: 0,
            swiperAutoPlay: !0
        },
        members: {
            bannerZid: 1,
            getBannerList: function(e) {
                var n = this;
                if (!i.frxsConfig.mall.showBanner) return new Promise(function(e, n) {
                    e([]);
                });
                var r = {
                    mediaType: 2,
                    zid: e.zid,
                    areaId: e.areaId || 0,
                    cityId: e.cityId || 0,
                    storeId: e.storeId || 0
                };
                return 1 * e.zid == 1 && (r.loc = i.frxs._get(this, "storeInfo.detailAddress", "")), 
                this.bannerZid = e.zid, new Promise(function(e, i) {
                    t.homePromotionApi.fetchIndexBannerList(r, {
                        silence: !0
                    }).then(function(t) {
                        var r = (t || {}).data || [];
                        n.setData({
                            bannerList: r
                        }), n.bannerMd(r), e(r);
                    }).catch(function(n) {
                        e([]);
                    });
                }).catch(function(e) {
                    reject(e);
                });
            },
            bannerMd: function(e) {
                (e || []).length > 0 && this.bannerSendEvent(0);
            },
            bannerSendEvent: function(e) {
                var n = this, t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                try {
                    var r = function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "slot_show";
                        n.pointArray[e] = 1, i.frxs.XSMonitor.sendEvent(t, {
                            slot: "横幅广告",
                            banner_id: n.data.bannerList[e].id,
                            sort: e,
                            url: n.data.bannerList[e].linkUrl
                        }, "");
                    };
                    if (t) return r("slot_click");
                    !this.pointArray[e] && this.scrollTop < 500 && r();
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            pointArray: [],
            bannerExposure: [],
            bannerChange: function(e) {
                var n = e.detail.current;
                this.setData({
                    bannerCurrent: n
                }), this.bannerSendEvent(n);
            },
            centerExposure: function(e) {
                var n = this.data.bannerList[this.data.bannerCurrent], t = n.windId || n.id || 0;
                if (!this.bannerExposure[this.data.bannerCurrent]) {
                    this.bannerExposure[this.data.bannerCurrent] = 1;
                    try {
                        i.frxs.XSMonitor.sendEvent("slot_show", {
                            slot: "横幅广告",
                            banner_id: t,
                            url: n.linkUrl
                        });
                    } catch (e) {}
                }
            },
            onCloseActiveMovable: function() {
                var e = this;
                this.setData({
                    hideActiveMovable: !0
                }, function() {
                    e.$store.commit({
                        hideActiveMovable: !0
                    });
                    var n = 1 * wx.$.sessionStorage.get("activeCloseTime");
                    n = !wx.$.isNumber(n) || n <= 0 ? 6 : n, wx.$.storage.set("hideActiveMovable", !0, i.frxs.getFormatTime2Close(n) / 1e3);
                }), i.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "关闭优惠券浮标"
                });
            },
            xssActivityExposure: function(e) {
                var n = e.currentTarget.dataset.item;
                try {
                    i.frxs.XSMonitor.sendEvent("slot_show", {
                        slot: "B_C活动浮标",
                        url: n.linkUrl || "",
                        id: n.windowId || n.id || 0
                    }, "");
                } catch (e) {}
            },
            bannerTap: function(e) {
                var t = e.currentTarget.dataset.item;
                if ("realy-active" === e.currentTarget.dataset.type && i.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "B_C活动浮标",
                    url: t.linkUrl || "",
                    id: t.windowId || t.id || 0
                }, ""), e.cmsType ? i.frxs.XSMonitor.sendEvent("slot_click", {
                    cateId: t.windowId || t.id || 0,
                    cateName: t.name,
                    cateIndex: t.index,
                    slot: "橱窗",
                    type: "icon-cms"
                }, "橱窗") : "SUSPENSION" !== t.adType && this.bannerSendEvent(this.data.bannerCurrent, !0), 
                1 == t.link) switch (t.linkType) {
                  case "WINDOW":
                    var s = parseInt(t.linkUrl || t.windowId || "");
                    1 == this.bannerZid && this.billToWindow && this.billToWindow({
                        detail: {
                            windId: s
                        }
                    }), 2 == this.bannerZid && this.bannerToWindow && this.bannerToWindow(s);
                    break;

                  case "PRODUCT":
                    this.gotoBaner && this.gotoBaner(e);
                    break;

                  case "PROGRAM":
                    if (a === t.mpTypeAppid) {
                        var o = t.linkUrl, d = {};
                        if (o.indexOf("pages/home/h5Active/index?url=") > -1) try {
                            d.url = o.substr(0 == o.indexOf("/") ? 31 : 30);
                        } catch (e) {} else d = i.frxs.getQuerys(t.linkUrl) || {};
                        return r.default.navigateTo({
                            path: t.linkUrl.split("?")[0],
                            query: n({}, d)
                        });
                    }
                    wx.navigateToMiniProgram({
                        appId: t.mpTypeAppid,
                        path: t.linkUrl || "pages/home/index/index",
                        envVersion: "trial",
                        success: function(e) {}
                    });
                    break;

                  case "H5":
                    r.default.navigateTo({
                        path: "/pages/users/h5url/index",
                        query: {
                            url: t.linkUrl
                        }
                    });
                }
            }
        }
    };
};

var n = require("../@babel/runtime/helpers/objectSpread2"), t = require("../api/index.js"), r = e(require("../router/index")), i = getApp(), a = (i.frxsConfig.otherAppId.sma, 
i.frxsConfig.otherAppId.vendor, i.frxsConfig.otherAppId.youdao, i.frxsConfig.appId);