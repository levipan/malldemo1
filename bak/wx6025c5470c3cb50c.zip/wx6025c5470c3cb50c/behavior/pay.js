var e = require("../@babel/runtime/helpers/interopRequireWildcard"), r = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/defineProperty"), s = r(require("../@babel/runtime/regenerator")), n = require("../@babel/runtime/helpers/asyncToGenerator"), o = require("../api/index.js"), u = (r(require("../xapp/runtime")), 
r(require("../router/index.js"))), i = r(require("../utils/cartService")), d = (r(require("../@xsyx-components/hanzo-page-loading/loading")), 
e(require("../utils/events"))), c = getApp();

exports.default = function() {
    return {
        data: {
            cancelOrderVisible: !1
        },
        clickOrderId: "",
        clickOrderProducts: [],
        closeOrder: function(e) {
            var r = this;
            return n(s.default.mark(function t() {
                var a;
                return s.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, o.tradeApi.closeOrder(e, {
                            loading: "取消中",
                            silence: !0
                        });

                      case 3:
                        return a = [], r.clickOrderProducts.forEach(function(e) {
                            a.push(e.skuSn);
                        }), c.frxs.XSMonitor.sendEvent("cancel_order", {
                            order_id: e.orderId,
                            sku_sn: a.join(","),
                            cancel_type: 2 === r.cancelOrderType ? "加购且取消" : "不加购仅取消"
                        }, ""), t.abrupt("return", !0);

                      case 9:
                        return t.prev = 9, t.t0 = t.catch(0), console.error(t.t0), c.frxs.alert({
                            content: r._get(t.t0, "rspDesc", "取消订单繁忙，请稍后重试")
                        }), t.abrupt("return", !1);

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 0, 9 ] ]);
            }))();
        },
        onHideCancelOrderModal: function() {
            this.setData({
                cancelOrderVisible: !1
            }), c.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "取消订单弹窗关闭"
            }, "");
        },
        onCloseCancelOrderModal: function() {
            var e = this;
            return n(s.default.mark(function r() {
                return s.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return e.cancelOrderType = 1, e.onHideCancelOrderModal(), r.next = 4, e.closeOrder({
                            orderId: e.clickOrderId
                        });

                      case 4:
                        r.sent && e.updatePageList(), u.default.navigateTo({
                            path: "/subPages/users/orderDetail/orderDetail",
                            isRedirect: !0,
                            query: {
                                orderId: e.clickOrderId
                            }
                        });

                      case 7:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        updatePageList: function() {
            try {
                var e, r = getCurrentPages();
                if (r.length > 1 && r[r.length - 2].route.indexOf("subPages/users/orderList/orderList") >= 0) if (this.data.orderListIndex >= 0) r[r.length - 2].setData((a(e = {}, "orderList[" + this.data.orderListIndex + "].orderStatus", "SHUTDOWN"), 
                a(e, "orderList[" + this.data.orderListIndex + "].orderStatusDescription", "交易关闭"), 
                e));
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.error(e);
            }
        },
        onAddOrderProduct2Cart: function() {
            var e = arguments;
            return n(s.default.mark(function r() {
                var t, a;
                return s.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (0 !== (t = e.length > 0 && void 0 !== e[0] ? e[0] : []).length) {
                            r.next = 3;
                            break;
                        }
                        return r.abrupt("return");

                      case 3:
                        return r.prev = 3, a = [], t.forEach(function(e) {
                            a.push(e.skuSn);
                        }), r.next = 8, o.tradeCartApi.orderCancel({
                            areaId: c.frxs.getMOrSData("areaId"),
                            storeId: c.frxs.getMOrSData("storeId"),
                            skuSns: a
                        }, {
                            silence: !0,
                            contentType: "application/json"
                        });

                      case 8:
                        r.sent, d.default.emit(d.EVENTS.REFRESH_CART, null), r.next = 15;
                        break;

                      case 12:
                        r.prev = 12, r.t0 = r.catch(3), console.error(r.t0);

                      case 15:
                      case "end":
                        return r.stop();
                    }
                }, r, null, [ [ 3, 12 ] ]);
            }))();
        },
        onAddOrder2Car: function() {
            var e = this;
            return n(s.default.mark(function r() {
                var t, a, n;
                return s.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return e.cancelOrderType = 2, e.onHideCancelOrderModal(), r.next = 4, e.closeOrder({
                            orderId: e.clickOrderId
                        });

                      case 4:
                        if (r.sent) {
                            r.next = 7;
                            break;
                        }
                        return r.abrupt("return");

                      case 7:
                        return e.updatePageList(), r.prev = 8, t = [], e.clickOrderProducts.forEach(function(e) {
                            t.push(e.skuSn);
                        }), r.next = 13, o.tradeCartApi.orderCancel({
                            areaId: c.frxs.getMOrSData("areaId"),
                            storeId: c.frxs.getMOrSData("storeId"),
                            skuSns: t
                        }, {
                            loading: "加购中...",
                            contentType: "application/json"
                        });

                      case 13:
                        a = r.sent, n = [], a.forEach(function(r) {
                            var t = e.clickOrderProducts.find(function(e) {
                                return e.skuSn === r.skuSn;
                            });
                            t && (t.eskuSn = r.eskuSn, n.push(t.skuSn), i.default.addCart(t, 1, e));
                        }), c.frxs.XSMonitor.sendEvent("add_product", {
                            list: n
                        }, ""), d.default.emit(d.EVENTS.REFRESH_CART, null), c.frxs.showToast({
                            title: "加购成功～"
                        }), r.next = 25;
                        break;

                      case 21:
                        r.prev = 21, r.t0 = r.catch(8), console.error(r.t0), c.frxs.showToast({
                            title: "加购失败～"
                        });

                      case 25:
                        return r.prev = 25, setTimeout(function() {
                            u.default.navigateTo({
                                path: "/subPages/users/orderDetail/orderDetail",
                                isRedirect: !0,
                                query: {
                                    orderId: e.clickOrderId
                                }
                            });
                        }, 300), r.finish(25);

                      case 28:
                      case "end":
                        return r.stop();
                    }
                }, r, null, [ [ 8, 21, 25, 28 ] ]);
            }))();
        },
        toPaySuccess: function(e) {
            var r = this;
            e = t(t({}, e), function() {
                try {
                    var e = r.data.products[0].imgUrl || r.data.products[0].primaryUrls[0];
                    e || (e = r.data.products[0].primaryUrl);
                    var t = 0;
                    return r.data.products.map(function(e) {
                        t += (e.marketAmt - e.saleAmt) * e.cartQuantity;
                    }), {
                        prImg: e,
                        discountAmt: t = t.toFixed(2)
                    };
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    return {};
                }
            }()), setTimeout(function() {
                u.default.navigateTo({
                    path: "/subOrder/paySuccess/paySuccess",
                    isRedirect: !0,
                    query: e
                });
            }, 500);
        },
        wxRequestPayment: function(e, r) {
            var a = this;
            wx.requestPayment(c.frxs.extend({
                success: function(r) {
                    c.frxs.getMOrSData("isNewUser") && d.default.emit(d.EVENTS.SHOW_NEW_USER_MODULE, null), 
                    c.frxs.setMAndSData("isNewUser", !1), a.wxPayParams.success && a.wxPayParams.success(t(t({}, r), {}, {
                        mkParam: e.mkParam,
                        querySome: e
                    }));
                },
                fail: function(r) {
                    a.wxPayParams.fail && a.wxPayParams.fail(t(t({}, r), {}, {
                        mkParam: e.mkParam,
                        querySome: e
                    }));
                }
            }, e));
        },
        requestOrderPayment: function(e, r) {
            var a = this;
            wx.requestOrderPayment(c.frxs.extend({
                success: function(r) {
                    c.frxs.getMOrSData("isNewUser") && d.default.emit(d.EVENTS.SHOW_NEW_USER_MODULE, null), 
                    c.frxs.setMAndSData("isNewUser", !1), a.wxPayParams.success && a.wxPayParams.success(t(t({}, r), {}, {
                        mkParam: e.mkParam,
                        querySome: e
                    }));
                },
                fail: function(r) {
                    a.wxPayParams.fail && a.wxPayParams.fail(t(t({}, r), {}, {
                        mkParam: e.mkParam,
                        querySome: e
                    }));
                }
            }, e));
        },
        getUserKey: function(e) {
            var r = this, a = c.frxs.isLogin();
            return a || (c.userSvr.getUserInfo({
                success: function(e, a) {
                    var s = function(e, r) {
                        var t = "", a = "";
                        r ? (t = e, a = wx.$.deepCopy(r)) : (t = c.frxs.isLogin(), a = wx.$.deepCopy(e));
                        var s = wx.$.deepCopy(a) || {};
                        c.frxs.XSMonitor.sendEvent("getUserInfoData", {
                            slot: "getUserInfo",
                            user: JSON.stringify(s)
                        });
                        var n = s.wechatNickName, o = s.nickName, u = c.frxs.getStorageSync("wechat-nickName") || !1;
                        return s.nickName = u && 0 !== u.length ? u : n || o, s.mobileNo = c.frxs.getMOrSData("user-mobileNo") || s.mobileNo, 
                        s.userId = s.userId || c.frxs.getMOrSData("userId"), s.userKey = t, s;
                    }(e, a);
                    r._user = wx.$.deepCopy(s), r.setData({
                        userId: s.userId
                    }, function() {
                        r.weiXinPay(t(t({}, r.wxPayParams), {}, {
                            userId: s.userId
                        }));
                    });
                },
                fail: function(t) {
                    e && e.fail && e.fail(), r.setData({
                        isSureOrder: !1
                    });
                }
            }), "");
        },
        onClickCouponErrorCancel: function() {
            this.setData({
                showErrorCoupon: !1
            }), c.router.navigateTo({
                path: "/subPages/pages/coupon/list/index"
            });
        },
        onClickCouponErrorMask: function() {
            this.setData({
                showErrorCoupon: !1
            });
        },
        onClickCouponErrorOk: function() {
            this.errorCouponPattern = !0, this.weiXinPay(this.wxPayParams);
        },
        wxPayParams: {},
        weiXinPay: function() {
            var e = arguments, r = this;
            return n(s.default.mark(function t() {
                var a, n, u, i, d, l, f, p, x;
                return s.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (a = e.length > 0 && void 0 !== e[0] ? e[0] : {}, c.frxs.XSMonitor.sendEvent("wantPay", {
                            slot: "userWantPay",
                            orderId: (a || {}).orderId,
                            userId: (a || {}).userId
                        }), t.prev = 2, r.wxPayParams = a, n = r.getUserKey(a), !c.frxs.isNullOrWhiteSpace(n)) {
                            t.next = 7;
                            break;
                        }
                        return t.abrupt("return");

                      case 7:
                        if (a.orderId && a.userId) {
                            t.next = 11;
                            break;
                        }
                        return r.setData({
                            isSureOrder: !1
                        }), a.fail && a.fail(), t.abrupt("return");

                      case 11:
                        if (u = c.enterAppOptions || {}, i = {
                            orderId: a.orderId,
                            userId: a.userId,
                            clientType: "MINI_PROGRAM",
                            paySrcType: "USER",
                            userKey: n,
                            blackbox: c.frxs.storage("safe_bb") || ""
                        }, !0 !== r.data.btnDisabled) {
                            t.next = 15;
                            break;
                        }
                        return t.abrupt("return");

                      case 15:
                        return r.errorCouponPattern && (i.ticketExp = !0), d = [ 1175, 1177, 1195, 1208, 1176 ], 
                        console.log("场景值", u.scene), -1 !== d.indexOf(u.scene) && (i.scene = "VIDEO"), r.setData({
                            btnDisabled: !0
                        }), c.frxs.XSMonitor.sendEvent("lastPay", {
                            slot: "lastPay",
                            orderId: (a || {}).orderId,
                            userId: (a || {}).userId
                        }), t.next = 23, wx.$.getNewPayApi(o.payApi, o.newPayApi)(i, {
                            loading: "加载中",
                            silence: !0
                        });

                      case 23:
                        l = t.sent;
                        try {
                            c.frxs.XSMonitor.sendEvent("payResult", {
                                slot: "payResult",
                                orderId: (a || {}).orderId,
                                userId: (a || {}).userId,
                                payRes: l
                            });
                        } catch (e) {}
                        if (!(c.frxs.trim(l).length > 0)) {
                            t.next = 35;
                            break;
                        }
                        if (f = JSON.parse(l), p = f.bankOrderId, -1 === d.indexOf(u.scene)) {
                            t.next = 31;
                            break;
                        }
                        return r.requestOrderPayment(f), t.abrupt("return");

                      case 31:
                        return r.wxRequestPayment(f, p), t.abrupt("return");

                      case 35:
                        r.setData({
                            btnDisabled: !1,
                            isSureOrder: !1
                        });

                      case 36:
                        wx.showToast({
                            title: c.frxs._get(l, "rspDesc", "发起支付失败，请稍候重试！"),
                            duration: 5e3,
                            icon: "none"
                        }), t.next = 46;
                        break;

                      case 39:
                        t.prev = 39, t.t0 = t.catch(2), c.frxs.XSMonitor.sendEvent("payError", {
                            slot: "payError",
                            orderId: (a || {}).orderId,
                            userId: (a || {}).userId,
                            payRes: t.t0
                        }), console.error(t.t0, "weiXinPay-1"), x = c.frxs._get(t.t0, "rspCode", ""), c.frxs._get(t.t0, "rspDesc", "发起支付失败，请稍候重试！"), 
                        "FE07251031003" === x ? r.setData({
                            showErrorCoupon: !0,
                            isSureOrder: !1,
                            errorCouponText: c.frxs._get(t.t0, "rspDesc", "优惠券使用失败，建议您进入优惠中心，查看优惠券使用状态哦～")
                        }) : (r.setData({
                            isSureOrder: !1
                        }), a.fail && a.fail(t.t0));

                      case 46:
                        r.setData({
                            btnDisabled: !1
                        });

                      case 47:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 39 ] ]);
            }))();
        }
    };
};