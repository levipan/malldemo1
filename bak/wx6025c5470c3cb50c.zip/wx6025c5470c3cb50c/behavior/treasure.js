var e = require("../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = (e(require("../xapp/runtime")), 
require("../api/index")), a = getApp(), i = 0, s = 1, o = 2, u = 0, f = 1, c = 2, p = 1, m = 2;

module.exports = function() {
    var e, l, d, x;
    return {
        boxOpenedConfig: {},
        waitTimeCount: 0,
        data: {
            moveX: 300,
            moveY: 400,
            showTreasurePop: !1,
            treasureStatus: 0,
            openBoxStatus: 0,
            treasureConfig: {},
            countTime: {
                time: 0,
                timearr: [ [ 0, 0 ], [ 0, 0 ] ],
                minute: "00",
                second: "00"
            }
        },
        onLoad: function() {},
        onShow: function() {},
        onHide: function() {},
        onUnload: function() {},
        initDate: function(e) {
            this.setData({
                showTreasurePop: !1,
                treasureStatus: 0,
                openBoxStatus: 0,
                treasureConfig: {},
                countTime: {
                    time: 0,
                    timearr: [ [ 0, 0 ], [ 0, 0 ] ],
                    minute: "00",
                    second: "00"
                }
            }, e);
        },
        initBox: function() {
            var n = this;
            return r(t.default.mark(function r() {
                var a, i, s, o, u, f;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return e && clearTimeout(e), t.next = 3, n.getBoxConfig();

                      case 3:
                        if (!(a = t.sent) || !a.exposureTime) {
                            t.next = 13;
                            break;
                        }
                        if (s = (i = a || {}).exposureTime, o = i._difftime, u = void 0 === o ? 0 : o, f = Date.now() + u, 
                        !(s < f)) {
                            t.next = 13;
                            break;
                        }
                        if (!(s - f > 36e5)) {
                            t.next = 11;
                            break;
                        }
                        return console.warn("如果距离活动开始时间大于一小时，没必要做定时器"), t.abrupt("return");

                      case 11:
                        return n.runingBox(a), t.abrupt("return");

                      case 13:
                        e = setTimeout(function() {
                            return n.initBox();
                        }, 3e3);

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        runingBox: function(e) {
            var n = this;
            return r(t.default.mark(function r() {
                var f, c, p, d, x, h, T, v, g, b, w;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, l && clearTimeout(l), c = (f = e || {}).beginTime, p = f.endTime, 
                        d = f.exposureTime, f.sessions, x = f._difftime, h = void 0 === x ? 0 : x, T = f.delayShowTime, 
                        v = void 0 === T ? 0 : T, !((g = Date.now() + h) > p || g < d)) {
                            t.next = 8;
                            break;
                        }
                        return n.initDate(), l = setTimeout(function() {
                            return n.initBox();
                        }, 3e3), t.abrupt("return");

                      case 8:
                        if (b = {
                            treasureConfig: e,
                            openBoxStatus: u
                        }, !(d < g && Math.floor((c - g) / 1e3) > 0)) {
                            t.next = 15;
                            break;
                        }
                        n.waitTimeCount = Math.floor((c - g) / 1e3), b.treasureStatus = s, a.frxs.XSMonitor.sendEvent("slot_show", {
                            slot: "开宝箱倒计时弹窗"
                        }, ""), t.next = 24;
                        break;

                      case 15:
                        if (!(Math.floor((g - c) / 1e3) >= 0 && p > g)) {
                            t.next = 24;
                            break;
                        }
                        return t.next = 18, n.getCurrentSession(e, g);

                      case 18:
                        if (!t.sent) {
                            t.next = 22;
                            break;
                        }
                        return n.setData({
                            treasureStatus: i
                        }), l = setTimeout(function() {
                            return n.initBox();
                        }, 3e3), t.abrupt("return");

                      case 22:
                        n.waitTimeCount = Math.floor((p - g) / 1e3), n.waitTimeCount > 0 && (b.treasureStatus = o, 
                        (w = Math.random() * v) + g > p - 3e3 && (w = 0), setTimeout(function() {
                            n.setVideoStatus(m), n.pointOpening(), n.setData({
                                showTreasurePop: !0
                            });
                        }, w));

                      case 24:
                        n.setTreasureTime(e), n.setData(b), n.pointfloating("show"), t.next = 32;
                        break;

                      case 29:
                        t.prev = 29, t.t0 = t.catch(0), console.log(t.t0);

                      case 32:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 29 ] ]);
            }))();
        },
        onOpeningBox: function(e) {
            var t = this, r = e.detail.status ? f : c;
            this.setData({
                openBoxStatus: r
            }), d && clearTimeout(d), d = setTimeout(function() {
                return t.initBox();
            }, 5e3);
        },
        setTreasureTime: function(e) {
            var t = this;
            if (x && clearInterval(x), this.waitTimeCount > 0) x = setInterval(function() {
                t.waitTimeCount = t.waitTimeCount - 1;
                var r = t.getMinuteAndSecond(t.waitTimeCount);
                t.setData({
                    countTime: r
                }), t.waitTimeCount <= 0 && t.setTreasureTime(e);
            }, 1e3); else {
                if (clearInterval(x), this.data.treasureStatus === i) return void this.initBox();
                if (this.data.treasureStatus === s) return void this.initBox();
                this.data.treasureStatus === o && this.initDate(this.initBox);
            }
        },
        getMinuteAndSecond: function(e) {
            var t = this.prefixZero(Math.floor(e / 60 % 60), 2), r = this.prefixZero(Math.floor(e % 60), 2);
            return {
                minute: t,
                second: r,
                timearr: [ t.split(""), r.split("") ],
                time: e
            };
        },
        isOpened: function(e, t) {
            var r = this.boxOpenedConfig[e] || a.frxs.getMOrSData("treasure")[e];
            return !(!r || !r.status || r.time !== a.frxs.formaterDate(t, "yyyy-MM-dd"));
        },
        getNowTime: function() {
            return 1e3 * Math.ceil(Date.now() / 1e3);
        },
        getBoxConfig: function() {
            var e = this;
            return r(t.default.mark(function r() {
                var i, s, o, u, f, c, p, m, l, d;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, !((i = a.frxs.getMData("treasureConfig")) && i.time > Date.now())) {
                            t.next = 9;
                            break;
                        }
                        if (!i.data || i.data.systemTimestamp) {
                            t.next = 5;
                            break;
                        }
                        return t.abrupt("return", i.data);

                      case 5:
                        if (s = i.data || {}, o = s.sessions, u = s.endTime, f = s._difftime, c = void 0 === f ? 0 : f, 
                        p = s.systemTimestamp, !(u > Date.now() + c)) {
                            t.next = 9;
                            break;
                        }
                        if (e.isOpened(o, p)) {
                            t.next = 9;
                            break;
                        }
                        return t.abrupt("return", i.data);

                      case 9:
                        if (a.frxs.getMOrSData("userKey")) {
                            t.next = 12;
                            break;
                        }
                        return t.abrupt("return", null);

                      case 12:
                        return t.next = 14, n.couponApi.getTreasureInfo({
                            activityScene: "CBX"
                        }, {
                            contentType: "application/json",
                            silence: !0,
                            loginVerify: !1
                        });

                      case 14:
                        return m = t.sent, l = Date.now(), d = {}, m && m.length && (d = m[0], e.isOpened(d.sessions, d.systemTimestamp) && (d = m[1]), 
                        d._difftime = d.systemTimestamp - l), a.frxs.setMData("treasureConfig", {
                            time: l + 3e5,
                            data: d
                        }), t.abrupt("return", d);

                      case 22:
                        return t.prev = 22, t.t0 = t.catch(0), a.frxs.setMData("treasureConfig", {
                            time: Date.now() + 6e4,
                            data: null
                        }), t.abrupt("return", null);

                      case 26:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 22 ] ]);
            }))();
        },
        getCurrentSession: function(e, s) {
            var o = this;
            return r(t.default.mark(function r() {
                var u, f, c, p, m;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, u = e.beginTime, f = e.mktActivityCode, c = e.sessions, e.systemTimestamp, 
                        !(s < u)) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", !1);

                      case 4:
                        if (p = a.frxs.getMOrSData("userKey")) {
                            t.next = 7;
                            break;
                        }
                        return t.abrupt("return", !1);

                      case 7:
                        return t.next = 9, n.couponApi.getTreasureInfoItem({
                            userKey: p,
                            activityCode: f,
                            sessions: c
                        }, {
                            contentType: "application/json",
                            silence: !0
                        });

                      case 9:
                        if (!(m = t.sent).participation) {
                            t.next = 14;
                            break;
                        }
                        return o.setData({
                            treasureStatus: i
                        }), o.setBoxOpenedConfig(!0, e), t.abrupt("return", !0);

                      case 14:
                        return o.setBoxOpenedConfig(m.participation, e), t.abrupt("return", !1);

                      case 18:
                        return t.prev = 18, t.t0 = t.catch(0), t.abrupt("return", !1);

                      case 21:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 18 ] ]);
            }))();
        },
        setBoxOpenedConfig: function(e, t) {
            var r = t.sessions, n = t.systemTimestamp, i = a.frxs.getMOrSData("treasure") || {};
            i[r] = {
                status: e,
                time: a.frxs.formaterDate(n, "yyyy-MM-dd")
            }, this.boxOpenedConfig = i, a.frxs.setMAndSData("treasure", i);
        },
        onTapTreasureFloating: function() {
            this.setData({
                showTreasurePop: !0
            }), this.setVideoStatus(m), this.pointfloating("click");
        },
        onCloseTreasurePop: function() {
            this.setData({
                showTreasurePop: !1
            });
            var e = this.data.treasureStatus;
            this.setVideoStatus(p), 1 === e && a.frxs.XSMonitor.sendEvent("slot_click", {
                slot: "关闭开宝箱倒计时弹窗"
            }, "");
        },
        prefixZero: function(e, t) {
            return (Array(t).join(0) + e).slice(-t);
        },
        pointfloating: function(e) {
            var t = this.data.treasureStatus, r = "show" === e ? "slot_show" : "slot_click";
            t === s && a.frxs.XSMonitor.sendEvent(r, {
                slot: "即将开启抢兴币宝箱"
            }, ""), t === o && a.frxs.XSMonitor.sendEvent(r, {
                slot: "抢兴币宝箱"
            }, "");
        },
        pointOpening: function() {
            a.frxs.XSMonitor.sendEvent("slot_show", {
                slot: "抢兴币宝箱弹窗"
            }, "");
        },
        setVideoStatus: function(e) {},
        onChangeMovable: function(e) {
            var t = this;
            this.changeMoveTimer && clearTimeout(this.changeMoveTimer), this.changeMoveTimer = setTimeout(function() {
                if (e && e.detail) {
                    var r = e.detail, n = r.x, a = r.y;
                    t.setData({
                        moveX: n,
                        moveY: a
                    });
                }
            }, 120);
        }
    };
};