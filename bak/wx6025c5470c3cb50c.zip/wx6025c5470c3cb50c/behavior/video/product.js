var t = require("../../@babel/runtime/helpers/interopRequireWildcard"), e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: i(i(i({}, h.data), f.data), {}, {
            productList: [],
            showProducts: !1
        }),
        members: i(i(i({}, h.members), f.members), {}, {
            productPageIndex: 1,
            productPageSize: 10,
            skuSnList: [],
            handleShowProduct: function(t) {
                var e = this, i = t.detail.current, r = i.spuSns, u = i.from, n = void 0 === u ? "video" : u, d = i.liveId, c = void 0 === d ? "" : d, p = i.id, h = i.fromType, f = void 0 === h ? "" : h, v = t.detail.showProducts, S = void 0 === v || v, m = l.frxs.getMOrSData("areaId") || this.params.areaId || "", y = (this.params || {}).storeId || l.frxs.getMOrSData("storeId") || null, I = "live" == n ? {
                    skuSnList: r,
                    areaId: m,
                    storeId: y,
                    firstPageSize: this.productPageSize,
                    liveId: c
                } : {
                    spuSns: r,
                    areaId: m,
                    storeId: y
                }, g = "live" == n ? "fetchLiveProductList" : "fetchProductList";
                if ((r && r.length || "live" == n) && (s.videoApi[g](I, {
                    contentType: "application/json"
                }).then(function(t) {
                    var i, s = "live" == n ? t.products : t;
                    "live" == n ? (e.liveId = c, e.productPageIndex = 1, e.skuSnList = t.skuSnList || []) : e.videoId = parseInt(p || 0), 
                    s = (0, o.formatProductsData)(s || []), s = e.productManagte(s), e.setData((a(i = {
                        productList: s
                    }, "videoDataMap.video_".concat(p, ".productList"), s), a(i, "showProducts", S), 
                    i), function() {
                        console.log("商品", s), e.updateProductSaleStatus();
                    });
                }), "video" == n && S)) {
                    if ("menu" == f) return void l.frxs.XSMonitor.sendEvent("slot_click", {
                        list: r,
                        videoId: p,
                        slot: "买食材"
                    });
                    l.frxs.XSMonitor.sendEvent("video_cart_list", {
                        list: r,
                        videoId: p,
                        ab: l.frxs.getMOrSData("viedeo_abFlag") || "c"
                    });
                }
            },
            hideProduct: function() {
                this.data.showProducts && this.setData({
                    showProducts: !1
                });
            },
            goCartPage: function(t) {
                var e = t.currentTarget.dataset.slot, a = void 0 === e ? "" : e;
                this.hideProduct();
                try {
                    l.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "去买单".concat(a)
                    });
                } catch (t) {}
                r.default.navigateTo({
                    path: "/pages/home/cart/cart"
                });
            },
            addCart: function(t) {
                var e = this, s = t.detail.key, r = this.data.productList, o = r[parseInt(s)];
                o.cartQuantity = parseInt(o.cartQuantity) || 0;
                var u = o.cartQuantity + 1, n = {}, d = this.data.videoDataMap, h = void 0 === d ? {} : d, f = t.detail.activeId, v = void 0 === f ? null : f;
                if (v = v || this.currentVideoId || null, "success" == (n = u > 1 ? p.setCartNum(i(i({}, o), {}, {
                    usaleQty: 0
                }), u, "该") : p.addCart(i(i({}, o), {}, {
                    usaleQty: 0
                }), u)).rspCode) try {
                    r[s].cartQuantity = n.cartQuantity, this.setData(a({}, "productList[" + s + "].cartQuantity", n.cartQuantity)), 
                    v && (h["video_".concat(v)].productList = r, this.setData({
                        videoDataMap: h
                    })), "addgoods" === t.type ? (this.pageNameCode = "xsvideo_bottom", (t.detail || {}).cb && t.detail.cb(), 
                    l.frxs.toptip("已成功加入购物车"), wx.vibrateShort({
                        type: "heavy"
                    })) : this.pageNameCode = "xsvideo_samekind", o.sort = s, this.xsSendEvent_addCart(o);
                } catch (t) {} else 0 == n.cartQuantity ? l.frxs.alert(n.info, function() {
                    p.deleteCart(o), e.onShow();
                }) : ("" !== n.info && wx.showToast({
                    title: n.info,
                    icon: "none",
                    duration: 3e3
                }), this.setData(a({}, "productList[" + s + "].cartQuantity", n.cartQuantity || o.cartQuantity)));
                c.default.emit(c.EVENTS.ADD_CART, null);
            },
            reduceCart: function(t) {
                var e = t.detail.key, i = this.data.productList, s = i[parseInt(e)];
                if (s.cartQuantity = parseInt(s.cartQuantity), !(s.cartQuantity <= 0)) {
                    if (this.setData(a({}, "productList[" + e + "].cartQuantity", s.cartQuantity - 1)), 
                    this.currentVideoId) try {
                        var r = this.data.videoDataMap;
                        i[e].cartQuantity = s.cartQuantity, r["video_".concat(this.currentVideoId)].productList = i, 
                        this.setData({
                            videoDataMap: r
                        });
                    } catch (t) {}
                    p.reduceCart(s), c.default.emit(c.EVENTS.ADD_CART, null);
                }
            },
            toProductDetail: function(t) {
                var e = this, a = this.activeUtvId || "", i = t.type, s = void 0 === i ? "" : i;
                this.hideProduct();
                var o = t.detail.key, u = this.data.productList[o];
                if (r.default.navigateTo({
                    path: l.frxsConfig.mall.page.prDetails,
                    query: {
                        prType: u.productType,
                        acid: u.acId,
                        prid: u.prId,
                        spuSn: u.spuSn,
                        skuSn: u.skuSn,
                        storeId: l.frxs.getMOrSData("storeId")
                    }
                }), "menulist" == this.from) {
                    var n = this.data.tabsList.find(function(t) {
                        return t.id == e.menu1Id;
                    }), d = this.lastShowIngredients;
                    l.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "商品卡片",
                        sku: u.sku,
                        sku_sn: u.skuSn,
                        rsort: parseInt(u.sort || 0),
                        sort: d.sort,
                        video_id: d.id,
                        source: "menu_pop",
                        menu_catid: n.id,
                        menu_cat: n.label,
                        from: this.from
                    });
                } else l.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "商品卡片",
                    sku_sn: u.skuSn,
                    videoId: a,
                    source: "clickproduct" === s ? "xsvideo_bottom" : "xsvideo_samekind"
                });
            },
            productManagte: function(t) {
                var e = this;
                if (0 == t.length) return t;
                var a = this.getCacheCartProducts({
                    isGetProducts: !0
                }), i = this.now();
                return a.length > 0 && t.map(function(t) {
                    var e = a.find(function(e) {
                        return e.spuSn && e.spuSn == t.spuSn || e.preproductId == t.preId;
                    }) || {};
                    t.cartQuantity = e.cartQuantity || 0;
                }), t.map(function(t) {
                    t.canSale = !0, t.isBuy = 1, +i < t.tsBuyStart ? (t.isNoSale = !0, t.dailySaleTime = (0, 
                    u.timeName2)(+i, t.tsBuyStart), e.waitRefreshSaleTimes.push(t.tsBuyStart)) : +i > t.tsBuyEnd && (t.isOver = !0, 
                    t.isBuy = 0), (t.isOver || t.isNoSale) && (t.isBuy = 0), 0 === t.saleRemain ? (t.isBuy = 0, 
                    t.isNone = !0) : t.cartQuantity > t.saleRemain && -1 !== t.saleRemain && (t.isBuy = 0, 
                    t.isUnderStock = !0), e.setVideoProductStatus(t);
                }), t;
            },
            setVideoProductStatus: function(t) {
                t.status = "ACTIVE", !0 === t.isOver && (t.status = "OVER"), 1 == t.isUnderStock && 1 != t.isOver && 1 != t.isClose && 1 != t.isNone && (t.status = "LACK"), 
                1 == t.isNone && 1 != t.isOver && 1 != t.isClose && (t.status = "SOLDOUT"), 1 == t.dirMin && (t.tag = l.frxsConfig.ossDomain + "/2020/01/10/1308373990.png"), 
                t.canSale || (t.info = "当前门店不可购买"), t.isNoSale && (t.status = "WAITING", t.canSale && (t.info = "该商品将于".concat(t.dailySaleTime, "开售")), 
                this.addTsBuyStart([ t ]), this.refreshProductCountDownMap(t.tsBuyStart));
            },
            waitRefreshSaleTimes: [],
            clearTimeoutSaleTime: null,
            updateProductSaleStatus: function() {
                var t = this;
                if (0 != this.waitRefreshSaleTimes.length) {
                    var e = this.now();
                    if (this.clearTimeoutSaleTime) {
                        clearTimeout(this.clearTimeoutSaleTime);
                        var a = [], i = {};
                        this.data.productList.map(function(t, s) {
                            1 == t.isNoSale && (+e > t.tsBuyStart && "WAITING" == t.status ? (i["productList[" + s + "].isNoSale"] = !1, 
                            i["productList[" + s + "].status"] = "ACTIVE", i["productList[" + s + "].info"] = "") : a.push(t.tsBuyStart));
                        }), Object.keys(i).length > 0 && this.setData(i, function() {}), a.length > 0 && (this.waitRefreshSaleTimes = a, 
                        this.clearTimeoutSaleTime = setTimeout(function() {
                            t.updateProductSaleStatus();
                        }, a.sort()[0] - +e));
                    } else this.clearTimeoutSaleTime = setTimeout(function() {
                        t.updateProductSaleStatus();
                    }, this.waitRefreshSaleTimes.sort()[0] - +e);
                }
            },
            refreshCartQuantity: function() {
                var t = this, e = this.data.productList || [];
                if (e.length > 0) {
                    var i = this.getCacheCartProducts({
                        isSendEvt: !1
                    }) || [];
                    i.length > 0 ? e.map(function(e, s) {
                        var r = (i.find(function(t) {
                            return t.skuSn && t.skuSn == e.skuSn || t.preproductId == e.preId;
                        }) || {}).cartQuantity || 0;
                        e.cartQuantity != r && t.setData(a({}, "productList[".concat(s, "].cartQuantity"), r));
                    }) : e.map(function(e, i) {
                        e.cartQuantity > 0 && t.setData(a({}, "productList[".concat(i, "].cartQuantity"), 0));
                    });
                }
            },
            fetchMoreProduct: function() {
                var t = this;
                if (this.skuSnList.length) {
                    var e = this.data.productList, a = l.frxs.getMOrSData("areaId") || this.params.areaId || "", i = (this.params || {}).storeId || l.frxs.getMOrSData("storeId") || null, r = this.skuSnList.slice(this.productPageSize * this.productPageIndex, this.productPageSize * (this.productPageIndex + 1));
                    if (console.log(r), r && r.length) {
                        var u = {
                            skuSnList: r,
                            areaId: a,
                            storeId: i,
                            firstPageSize: this.productPageSize,
                            liveId: this.liveId
                        };
                        s.videoApi.fetchLiveProductList(u, {
                            contentType: "application/json",
                            silence: !0
                        }).then(function(a) {
                            var i = a.products;
                            i = (0, o.formatProductsData)(i || []), i = t.productManagte(i), e = e.concat(i), 
                            t.setData({
                                productList: e
                            }, function() {
                                t.updateProductSaleStatus();
                            }), t.productPageIndex++;
                        });
                    }
                }
            },
            xsSendEvent_addCart: function(t) {
                var e = this, a = {
                    sku_sn: t.skuSn,
                    sort: t.sort || 0
                };
                if ("menulist" == this.from) {
                    var s = this.data.tabsList.find(function(t) {
                        return t.id == e.menu1Id;
                    }), r = this.lastShowIngredients;
                    a = i(i({}, a), {}, {
                        extra_operate: t.tsBuyStart > this.now() ? "wantBuy" : "",
                        slot: "加车",
                        sku: t.sku,
                        sku_sn: t.skuSn,
                        rsort: parseInt(t.sort || 0),
                        sort: r.sort,
                        video_id: r.id,
                        source: "menu_pop",
                        menu_catid: s.id,
                        menu_cat: s.label
                    });
                } else (a = i(i({}, a), {}, {
                    source: this.pageNameCode || "",
                    ab: l.frxs.getMOrSData("viedeo_abFlag") || "c"
                })).extra_operate = t.tsBuyStart < this.now() ? "" : "wantBuy", "xsvideo_samekind" == this.pageNameCode || "xsvideo_bottom" == this.pageNameCode ? a.videoId = this.videoId || 0 : a.live_id = this.liveId || 0;
                this.from && (a.from = this.from), "RECOMMEND" === t._type && (a.source = "recommend_sharelink"), 
                l.frxs.XSMonitor.sendEvent("add_product", a);
            }
        })
    };
};

var a = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../@babel/runtime/helpers/objectSpread2"), s = require("../../api/index.js"), r = e(require("../../router/index")), o = require("../../api/formatData/product"), u = require("../../utils/index"), n = e(require("../cart.js")), d = e(require("../productCountDown.js")), c = t(require("../../utils/events.js")), l = getApp(), p = require("../../utils/cartService.js"), h = (0, 
n.default)(), f = (0, d.default)();