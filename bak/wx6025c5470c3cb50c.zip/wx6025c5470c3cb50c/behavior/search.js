var e = require("../api/index.js"), a = require("../const/storage.key.js"), t = getApp();

module.exports = function() {
    return {
        data: {
            searchPlaceHold: [],
            searchPlaceHoldInterval: 3
        },
        methods: {
            searchPlaceHoldAb: {},
            searchPageSid: "",
            placeHoldCurIndex: 0,
            getSearchPlaceHold: function(r, c) {
                var s = this, l = t.frxs.format(a.STORAGE_KEY.SEARCH_PLACE_HOLD, c), n = t.frxs.getStorageSync(l) || {};
                if (n.data && n.areaId == c && (n.time || 0) + 2592e5 > +new Date()) return this.searchPlaceHoldAb = n.ab, 
                this.setData({
                    searchPlaceHold: searchPlaceHold.data,
                    searchPlaceHoldInterval: searchPlaceHold.interval || 3
                });
                var o = t.frxs.getStorageSync(a.STORAGE_KEY.SEARCH_HISTORY_KEY) || [], d = {
                    storeId: r,
                    areaId: c,
                    guId: t.frxs.getMOrSData("_xsm_g") || "",
                    lastKeyword: o.length > 0 ? [ o[0] ] : []
                };
                e.searchApi.fetchPlaceHold(d, {
                    silence: !0
                }).then(function(e) {
                    (e.rows || []).length > 0 && (s.setData({
                        searchPlaceHold: e.rows,
                        searchPlaceHoldInterval: e.changeTime || 3
                    }), s.searchPlaceHoldAb = e.ab || {}, t.frxs.setStorageSync(l, {
                        data: e.hotWord,
                        interval: e.changeTime || 0,
                        ab: s.searchPlaceHoldAb
                    }));
                });
            },
            addLastSearchHistoryKey: function(e) {
                this.addSearchKey(a.STORAGE_KEY.SEARCH_HISTORY_KEY_DESC, e);
            },
            addSearchHistoryKey: function(e) {
                this.addSearchKey(a.STORAGE_KEY.SEARCH_HISTORY_KEY, e);
            },
            addSearchKey: function(e, a) {
                if (a = t.frxs.trim(a), !t.frxs.isNullOrWhiteSpace(a)) {
                    var r = t.frxs.getStorageSync(e) || [], c = r.indexOf(a);
                    c >= 0 && r.splice(c, 1), r.unshift(a), r.length > (this.maxHistoryLength || 30) && r.splice(this.maxHistoryLength || 30, 1), 
                    t.frxs.setStorageSync(e, r);
                }
            },
            placeHoldChange: function(e) {
                var a = e.detail.current;
                this.placeHoldCurIndex = a;
            },
            getListKeyWord: function() {
                var e = t.frxs.getStorageSync(a.STORAGE_KEY.SEARCH_HISTORY_KEY_DESC) || [];
                return console.log(3333, e, e.length > 0 ? e[0] : ""), e.length > 0 ? e[0] : "";
            }
        }
    };
};