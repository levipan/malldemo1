var t = require("../@babel/runtime/helpers/interopRequireWildcard"), e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.Cart = void 0;

var r = require("../@babel/runtime/helpers/classCallCheck"), a = require("../@babel/runtime/helpers/defineProperty"), s = require("../utils/index"), i = e(require("../utils/cartService.js")), u = t(require("../utils/events.js")), n = require("../utils/subscribe-message"), o = e(require("../utils/sample-store-dialog.js")), c = getApp();

exports.default = function() {
    return {
        data: {
            cartNumberMap: {},
            showSalesReminderGuid: !1
        },
        members: {
            initPageCartData: function() {
                var t = {};
                i.default.getCartList().map(function(e) {
                    var r = e.skuSn, a = e.spuSn;
                    t[(0, s.pk)(a, r)] = e.cartQuantity;
                }), this.setData({
                    cartNumberMap: t
                });
            },
            addCart: function(t) {
                var e = c.frxs.getMOrSData("storeInfo") || {};
                if (e.storeId != c.frxsConfig.tempStoreId) {
                    var r = t.detail || {}, a = r.product, u = r.status;
                    a.key || (a.key = (0, s.pk)(a.spuSn, a.skuSn));
                    var p = i.default.addCart(a);
                    if ("success" !== p.rspCode) return "max" == p.rspCode ? c.frxs.alert({
                        content: p.info
                    }) : void ("" !== p.info && (0, s.showToast)({
                        title: p.info
                    }));
                    if ("WAITING" === u) {
                        this.lastWaitingProduct = a;
                        var d = c.frxsConfig.tmplIds, l = [];
                        d.salesReminder && l.push(d.salesReminder), d.productBuy && l.push(d.productBuy), 
                        d.activityStart && l.push(d.activityStart), (0, n.onRequestSubscribeMessage)(l, (0, 
                        n.getViceSubscribeIds)(n.SubscribeKey.wantAddCard, this.lastWaitingProduct.spuSn), "提前加入购物车", this);
                    }
                    this.updateCart(a.key, p.cartQuantity), this.behavior_convenient_getCart && this.behavior_convenient_getCart({
                        cartSkus: [ {
                            skuSn: a.skuSn,
                            eskuSn: a.eskuSn,
                            areaId: e.areaId,
                            qty: p.cartQuantity,
                            optype: a.optype || "manual"
                        } ],
                        issue: 1 == p.cartQuantity
                    });
                } else o.default.showSampleDialog();
            },
            reduceCart: function(t) {
                var e = t.detail.product || {};
                e.key || (e.key = (0, s.pk)(e.spuSn, e.skuSn));
                var r = i.default.reduceCart(e);
                if ("success" !== r.rspCode) return "max" == r.rspCode ? c.frxs.alert({
                    content: r.info
                }) : void ("" !== r.info && (0, s.showToast)({
                    title: r.info
                }));
                if (this.updateCart(e.key, r.cartQuantity), this.behavior_convenient_getCart) {
                    var a = c.frxs.getMOrSData("storeInfo") || {};
                    this.behavior_convenient_getCart({
                        cartSkus: [ {
                            skuSn: e.skuSn,
                            eskuSn: e.eskuSn,
                            areaId: a.areaId,
                            qty: r.cartQuantity,
                            optype: e.optype || "manual"
                        } ]
                    });
                }
            },
            updateCart: function(t, e) {
                wx.vibrateShort(), this.setData(a({}, "cartNumberMap.".concat(t), e)), this.data.cartNumberMap[t] >= 0 && u.default.emit(u.EVENTS.REFRESH_CART);
            },
            popupSailsReminderSubMsg: function() {
                var t = c.frxsConfig.tmplIds, e = [];
                t.salesReminder && e.push(t.salesReminder), t.productBuy && e.push(t.productBuy), 
                t.activityStart && e.push(t.activityStart), this.setData({
                    showSalesReminderGuid: !1
                }), (0, n.onRequestSubscribeMessage)(e, (0, n.getViceSubscribeIds)(n.SubscribeKey.wantAddCard, this.lastWaitingProduct.spuSn), "提前加入购物车");
            },
            pageListAddEventRefreshCartNum: function() {
                u.default.on(u.EVENTS.REFRESH_CART, this.refreshPageCartData, this);
            },
            pageListRemoveEventRefreshCartNum: function() {
                u.default.remove(u.EVENTS.REFRESH_CART, this.refreshPageCartData, this);
            }
        }
    };
};

var p = new function t() {
    var e = this;
    r(this, t), this.refreshCartCount = function() {
        var t = i.default.getCartList() || [];
        if (!t.length) return Object.keys(e.cartNumberMap).forEach(function(t) {
            e.cartNumberMap[t] > 0 && e.updataKeyCart(t, 0);
        }), void e.updataCartMap({
            cartNumberMap: {}
        });
        Object.keys(e.cartNumberMap).forEach(function(t) {
            e.cartNumberMap[t] = 0;
        }), t.forEach(function(t) {
            var r = t.skuSn, a = t.spuSn, i = t.cartQuantity, u = (0, s.pk)(a, r);
            e.cartNumberMap[u] = i;
        }), Object.keys(e.cartNumberMap).forEach(function(t) {
            return e.updataKeyCart(t, e.cartNumberMap[t]);
        }), e.updataCartMap({
            cartNumberMap: e.cartNumberMap
        });
    }, this.updataCartMap = function(t) {
        var r = t.cartNumberMap, a = t.product, s = t.type;
        e.cartNumberMap = r, e.registerAllLists.length && e.registerAllLists.forEach(function(t) {
            return t && t({
                cartNumberMap: r,
                product: a,
                type: s
            });
        });
    }, this.updataKeyCart = function(t, r) {
        e.cartNumberMap[t] = r, e.registerSigleLists && void 0 !== e.registerSigleLists[t] && e.registerSigleLists[t].forEach(function(t) {
            return t && t({
                count: r,
                cartNumberMap: e.cartNumberMap
            });
        });
    }, this.onRegister = function(t, r) {
        if (t) {
            void 0 !== e.cartNumberMap[t] && r({
                count: e.cartNumberMap[t],
                cartNumberMap: e.cartNumberMap
            }), e.registerSigleLists[t] || (e.registerSigleLists[t] = []);
            var a = e.registerSigleLists[t].push(r);
            return function() {
                e.cartNumberMap[t] > 0 && console.warn("当前商品购物车数量大于0，取消监听会导致无法监听变化"), 1 !== e.registerSigleLists[t].length ? (e.registerSigleLists[t][a - 1] = null, 
                e.registerSigleLists[t].some(function(t) {
                    return t;
                }) || delete e.registerSigleLists[t]) : delete e.registerSigleLists[t];
            };
        }
        "{}" !== JSON.stringify(e.cartNumberMap) && r({
            cartNumberMap: e.cartNumberMap
        });
        var s = e.registerAllLists.push(r);
        return function() {
            e.registerAllLists[s - 1] = null;
        };
    }, this.addCart = function(t, r) {
        if ((c.frxs.getMOrSData("storeInfo") || {}).storeId != c.frxsConfig.tempStoreId) {
            t.key || (t.key = (0, s.pk)(t.spuSn, t.skuSn));
            var a = i.default.addCart(t);
            if ("success" !== a.rspCode) return "max" == a.rspCode ? c.frxs.alert({
                content: a.info
            }) : void ("" !== a.info && (0, s.showToast)({
                title: a.info
            }));
            if ("WAITING" === r) {
                e.lastWaitingProduct = t;
                var p = c.frxsConfig.tmplIds, d = [];
                p.salesReminder && d.push(p.salesReminder), p.productBuy && d.push(p.productBuy), 
                p.activityStart && d.push(p.activityStart), (0, n.onRequestSubscribeMessage)(d, (0, 
                n.getViceSubscribeIds)(n.SubscribeKey.wantAddCard, e.lastWaitingProduct.spuSn), "提前加入购物车", e);
            }
            e.updataKeyCart(t.key, a.cartQuantity), e.updataCartMap({
                cartNumberMap: e.cartNumberMap,
                product: t,
                type: "add"
            }), e.cartNumberMap[t.key] >= 0 && u.default.emit(u.EVENTS.REFRESH_CART);
        } else o.default.showSampleDialog();
    }, this.reduceCart = function(t) {
        t.key || (t.key = (0, s.pk)(t.spuSn, t.skuSn));
        var r = i.default.reduceCart(t);
        if ("success" !== r.rspCode) return "max" == r.rspCode ? c.frxs.alert({
            content: r.info
        }) : void ("" !== r.info && (0, s.showToast)({
            title: r.info
        }));
        e.updataKeyCart(t.key, r.cartQuantity), e.updataCartMap({
            cartNumberMap: e.cartNumberMap,
            product: t,
            type: "reduce"
        }), e.cartNumberMap[t.key] >= 0 && u.default.emit(u.EVENTS.REFRESH_CART);
    }, this.cartNumberMap = {}, this.registerSigleLists = {}, this.registerAllLists = [], 
    this.refreshCartCount();
}();

exports.Cart = p;