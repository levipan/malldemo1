var s = require("../@babel/runtime/helpers/objectSpread2"), e = getApp();

module.exports = function() {
    return {
        guessConfig: s(s({}, e.frxsConfig.temp.productGuess), {}, {
            refreshNum: 0,
            refreshStatus: "wait"
        }),
        refreshGuessProducts: function() {
            var s = e.frxs.getMOrSData("areaId"), t = this.guessConfig.areaMap["".concat(s)];
            t && (this.pageLoading || [ "refreshing", "success" ].indexOf(this.guessConfig.refreshStatus) >= 0 || this.guessConfig.refreshNum > 1 || this.now() < +e.frxs.strToDate(e.frxs.formaterDate(this.now(), "yyyy-MM-dd ") + this.guessConfig.refreshTime) + 1e4 * this.guessConfig.refreshNum || 0 != (this.data.tabsList || []).length && (this.data.tabsList[this.tabsSelectIndex] || {}).windowId == t && (this.guessConfig.refreshStatus = "refreshing", 
            this.tabsChange({
                detail: {
                    windowId: t
                }
            }), console.warn("刷新竞猜商品列表", e.frxs.formaterDate(this.now(), "HH:mm:ss"))));
        },
        refreshGuessProductsLoadStatus: function(s) {
            var t = e.frxs.getMOrSData("areaId"), r = this.guessConfig.areaMap["".concat(t)];
            r && s.param.windowId == r && "TRUE" == s.param.isFirstRefresh && this.now() > +e.frxs.strToDate(e.frxs.formaterDate(this.now(), "yyyy-MM-dd ") + this.guessConfig.refreshTime) && (s.products.length > 0 ? this.guessConfig.refreshStatus = "success" : "refreshing" == this.guessConfig.refreshStatus && (this.guessConfig.refreshStatus = "fail", 
            this.guessConfig.refreshNum += 1));
        }
    };
};