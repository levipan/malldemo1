var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../@babel/runtime/helpers/objectSpread2"), o = t(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/toConsumableArray"), i = require("../@babel/runtime/helpers/asyncToGenerator"), n = (t(require("../xapp/runtime")), 
t(require("../xapp/utils"))), u = require("../api/index.js"), a = getApp(), s = {
    getPromotionCenter: function() {
        var t = this;
        return i(o.default.mark(function e() {
            var i, n, s, p, c, l, m;
            return o.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, i = a.frxs.getMOrSData("storeId"), a.frxs.isLogin() && i) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    return n = wx.$._get(t, "data.moduleConfig.activeAll", !0), e.next = 7, u.couponApi[n ? "newBottomCarouselList" : "bottomCarouselList"]({
                        storeId: i
                    }, {
                        silence: !0,
                        contentType: "application/json"
                    });

                  case 7:
                    s = e.sent, p = JSON.parse(JSON.stringify(s)), c = 1 * wx.$._get(p, "bottomTime", 6), 
                    (c = isNaN(c) ? 6 : c) < 0 && (c = 6), wx.$.sessionStorage.set("activeCloseTime", c), 
                    p.multipleCategoryActivity = p.multipleCategoryActivity || [], p.multipleCategoryActivity.map(function(t) {
                        return t.rootType = "MULTIPLE", t;
                    }), l = (l = [].concat(r(p.allCategoryActivity || []), r(p.multipleCategoryActivity))).map(function(t) {
                        return t.orderAmountLimit = 1 * (t.orderAmountLimit / 100).toFixed(2), t.amount = 1 * (t.amount / 100).toFixed(2), 
                        (t.orderStep || []).map(function(t) {
                            return t.useOrderAmountLimit = 1 * (t.useOrderAmountLimit / 100).toFixed(2), t.singleToolAmount = 1 * (t.singleToolAmount / 100).toFixed(2), 
                            t;
                        }), t;
                    }), p.hotActivity && p.hotActivity.length > 0 && (m = [], p.hotActivity.forEach(function(t) {
                        t.use || (t.rootType = "oneCoupon", t.orderAmountLimit = 1 * (t.orderAmountLimit / 100).toFixed(2), 
                        t.amount = 1 * (t.amount / 100).toFixed(2), m.push(t));
                    }), l = [].concat(m, r(l))), t.setData({
                        couponTipsList: l,
                        couponTipsStatus: wx.$._get(s, "receivingFlag", !1)
                    }), e.next = 26;
                    break;

                  case 21:
                    e.prev = 21, e.t0 = e.catch(0), wx.$.sessionStorage.set("activeCloseTime", 6), console.error(e.t0), 
                    t.setData({
                        couponTipsList: [],
                        couponTipsStatus: !1
                    });

                  case 26:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 21 ] ]);
        }))();
    },
    getAllCouponList: function() {
        var t = this;
        return i(o.default.mark(function r() {
            var i, u, a, s, p, c, l, m;
            return o.default.wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    return (i = !0) && t.getPromotionCenter(), o.prev = 2, o.next = 5, t.getCouponList();

                  case 5:
                    if (u = o.sent, a = n.default._get(u, "couponList", []) || [], s = n.default._get(u, "dbCouponList", []) || [], 
                    a) {
                        o.next = 10;
                        break;
                    }
                    return o.abrupt("return", t.setData({
                        ticketsMap: {}
                    }));

                  case 10:
                    p = {}, c = [], l = [], a.forEach(function(t) {
                        "SINGLE" === t.rootType && t.isAvailable && t.showTicketPrice && (t.ticketAmt = t.amount, 
                        p[t.supportSkuSet[0]] ? p[t.supportSkuSet[0]].ticketAmt < t.ticketAmt && (p[t.supportSkuSet[0]] = t) : p[t.supportSkuSet[0]] = t), 
                        "GLOBAL" === t.rootType && c.push(t), "MULTIPLE" === t.rootType && l.push(t);
                    }), m = {}, i || (m.couponTipsList = s.filter(function(t) {
                        return ("GLOBAL" === t.rootType || "MULTIPLE" === t.rootType) && t;
                    })), t.setData(e(e({}, m), {}, {
                        ticketsMap: p,
                        globalCouponList: c,
                        multipleCouponList: l,
                        recommendCouponList: s
                    })), o.next = 23;
                    break;

                  case 19:
                    o.prev = 19, o.t0 = o.catch(2), console.log(o.t0), t.setData({
                        recommendCouponList: [],
                        ticketsMap: {},
                        globalCouponList: [],
                        multipleCouponList: [],
                        isShowBottomTips: !1
                    });

                  case 23:
                  case "end":
                    return o.stop();
                }
            }, r, null, [ [ 2, 19 ] ]);
        }))();
    }
};

exports.default = s;