var t = require("../@babel/runtime/helpers/interopRequireWildcard"), e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            cartNumberMap: {},
            productStatusMap: {},
            waitingTextMap: {},
            marketingDataMap: {},
            consumersMap: {},
            consumersPageMap: {},
            playerVideoMap: {},
            wantBuyQtyMap: {},
            salesCutOffMap: {},
            saleDurationMap: {}
        },
        members: {
            timeOffset: 0,
            originProductsMap: {},
            cmsOriginProductsMap: {},
            indexWindowOriginProductsMap: {},
            productKeyPreIdMap: {},
            spuSnKeyMap: {},
            refreshOriginProductsMap: function(t) {
                var e = this;
                (t || []).forEach(function(t) {
                    e.originProductsMap[t.key] = s(s({}, e.originProductsMap[t.key]), t);
                });
            },
            refreshCmsOriginProductsMap: function(t) {
                var e = this;
                (t || []).forEach(function(t) {
                    return e.cmsOriginProductsMap[t.key] = t;
                });
            },
            refreshIndexWindowsOriginProductsMap: function(t) {
                var e = this;
                (t || []).forEach(function(t) {
                    return e.indexWindowOriginProductsMap[t.key] = t;
                });
            },
            refreshProductKeyPreIdMap: function(t) {
                var e = this;
                t && t.map(function(t) {
                    var a = t.key, s = t.preId;
                    e.productKeyPreIdMap[a] = s;
                });
            },
            updateCart: function(t, e) {
                this.setData(a({}, "cartNumberMap.".concat(t), e)), this.data.cartNumberMap[t] >= 0 && o.default.emit(o.EVENTS.REFRESH_CART);
                try {
                    this.originProductsMap[t] && this.refreshProductsStatus([ this.originProductsMap[t] ]);
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.error(t);
                }
            },
            reduceCart: function(t) {
                var e = t.detail.key, a = this.originProductsMap[e], s = r.default.reduceCart(a);
                if ("success" !== s.rspCode) return (0, i.showToast)({
                    title: s.info
                });
                this.updateCart(e, s.cartQuantity), this.behavior_convenient_getCart && this.behavior_convenient_getCart({
                    cartSkus: [ {
                        skuSn: a.skuSn,
                        eskuSn: a.eskuSn,
                        areaId: this.areaId,
                        qty: s.cartQuantity,
                        optype: a.optype || "manual"
                    } ]
                });
            },
            addCart: function(t) {
                var e = this, a = (t.detail || {}).key, o = t.currentTarget.dataset, n = (t.detail.item || {}).product, d = this.originProductsMap[a];
                if (this.checkTempStore(d)) u.default.showSampleDialog(); else {
                    var l = JSON.parse(JSON.stringify(r.default.getCartList()));
                    if (this.getProductStatus(a) === g) return (0, i.showToast)("商品活动已结束");
                    var p = this.data.marketingDataMap[a], m = r.default.addCart(s(s({}, d), p), 1, this);
                    if ("success" !== m.rspCode) return "max" == m.rspCode ? h.frxs.alert({
                        content: m.info
                    }) : void ("" !== m.info && (0, i.showToast)({
                        title: m.info
                    }));
                    if (this.newUserActiveAddCarToast && this.newUserActiveAddCarToast({
                        product: d,
                        ticketsMap: this.data.newUserCouponMap || this.data.ticketsMap || {},
                        cartList: l
                    }), this.addWantBuyQty(t, m, function() {
                        "prSearch" !== e.data.pageType && e.addEvt_add_cart_product(a, n, o);
                    }), "WAITING" === this.data.productStatusMap[d.key]) {
                        this.lastWaitingProduct = d;
                        var f = h.frxsConfig.tmplIds, y = [];
                        f.salesReminder && y.push(f.salesReminder), f.productBuy && y.push(f.productBuy), 
                        f.activityStart && y.push(f.activityStart), (0, c.onRequestSubscribeMessage)(y, (0, 
                        c.getViceSubscribeIds)(c.SubscribeKey.wantAddCard, this.lastWaitingProduct.spuSn), "提前加入购物车", this);
                    }
                    this.behavior_convenient_getCart && this.behavior_convenient_getCart({
                        cartSkus: [ {
                            skuSn: s(s({}, d), p).skuSn,
                            eskuSn: s(s({}, d), p).eskuSn,
                            areaId: this.areaId,
                            qty: m.cartQuantity,
                            optype: s(s({}, d), p).optype || "manual"
                        } ],
                        issue: 1 == m.cartQuantity
                    });
                    try {
                        var v = t.currentTarget.dataset.index;
                        this.showTogetherBuyProductDescs && this.showTogetherBuyProductDescs(v);
                    } catch (t) {}
                    this.updateCart(a, m.cartQuantity), wx.vibrateShort(), this.initTkSubscribeMessage && this.initTkSubscribeMessage();
                }
            },
            popupSailsReminderSubMsg: function(t) {
                var e = h.frxsConfig.tmplIds, a = [];
                e.salesReminder && a.push(e.salesReminder), e.productBuy && a.push(e.productBuy), 
                e.activityStart && a.push(e.activityStart), (0, c.onRequestSubscribeMessage)(a, (0, 
                c.getViceSubscribeIds)(c.SubscribeKey.wantAddCard, this.lastWaitingProduct.spuSn), "提前加入购物车");
            },
            refreshPageCartData: function() {
                var t = {};
                r.default.getCartList().map(function(e) {
                    e.preacId, e.productId;
                    var a = e.skuSn, s = e.spuSn;
                    t[(0, i.pk)(s, a)] = e.cartQuantity;
                }), this.setData({
                    cartNumberMap: t
                });
            },
            pageListAddEventRefreshCartNum: function() {
                o.default.on(o.EVENTS.REFRESH_CART, this.refreshPageCartData, this);
            },
            pageListRemoveEventRefreshCartNum: function() {
                o.default.remove(o.EVENTS.REFRESH_CART, this.refreshPageCartData, this);
            },
            refreshProductsStatus: function(t) {
                var e = this, a = this.data.productStatusMap, s = this.data.waitingTextMap, i = {}, r = !1;
                t && ((t || []).forEach(function(t) {
                    if (t) {
                        var o = t.key;
                        if (o) {
                            var n = e.getProductStatus(o);
                            n = e.setAssignTimeBuyAssignDatePickUp(o, n);
                            var d = e.getProductWaitingText(o);
                            n === m && s[o] !== d && (i["productStatusMap.".concat(o)] = d, i["waitingTextMap.".concat(o)] = d, 
                            r = !0), a[o] != n && (i["productStatusMap.".concat(o)] = n, r = !0);
                        }
                    }
                }), r && Object.keys(i).length > 0 && this.setData(i));
            },
            getProductStatus: function(t) {
                try {
                    var e = this.now();
                    if (!t || !this.originProductsMap[t]) return f;
                    var a = this.originProductsMap[t], s = a.tsBuyStart, i = a.tsBuyEnd, r = (a.limitQty, 
                    a.prType, a.saleRemain), o = a.marketingDataDto, n = void 0 === o ? {} : o, d = this.data.cartNumberMap[t] || 0, u = this.data.marketingDataMap[t] || {};
                    return 0 === (r = u.hasOwnProperty("saleRemain") ? u.saleRemain : r) || r || (r = n.saleRemain), 
                    e > i ? g : e < s ? m : -1 === r ? f : 0 === r ? y : -1 !== r && 0 !== r && r < d ? v : f;
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.error(t);
                }
            },
            getProductWaitingText: function(t) {
                var e = this.now(), a = (this.originProductsMap[t] || {}).tsBuyStart;
                return a ? (0, i.timeName)(e, a) : "";
            },
            setAssignTimeBuyAssignDatePickUp: function(t, e) {
                var a = this.originProductsMap[t] || {}, s = a.tsBuyStart, r = a.tsBuyEnd, o = a.assignType, n = a.isNextDayPickUp, d = a.tsShowEnd;
                if (1 == o && !n) {
                    var u = this.now(), c = (0, i.formaterDate)(u, "yyyy-M-d"), l = (0, i.formaterDate)(u, "M月d日"), p = (0, 
                    i.formaterDate)(d, "M月d日");
                    if (u >= r && u < d && p != l) {
                        var h = (0, i.strToTs)(c + (0, i.formaterDate)(s, " HH:mm:ss")) + 864e5, f = (0, 
                        i.strToTs)(c + (0, i.formaterDate)(r, " HH:mm:ss")) + 864e5;
                        this.originProductsMap[t].tsBuyStart = h, this.originProductsMap[t].tsBuyEnd = f, 
                        e = m;
                    }
                }
                return e;
            },
            handleProductDetailGo: function(t) {
                var e = t.detail.key || t.detail, a = this.originProductsMap[e], s = t.currentTarget.dataset.windid || "";
                t.notSendEvent && (a.notSendEvent = !0);
                try {
                    this.clickProductIndex = t.currentTarget.dataset.index;
                } catch (t) {}
                var i = {
                    prType: a.prType || ""
                };
                s > 0 && (i.window_id = s), this.productDetailGo(a, i);
            },
            handleCmsProductDetailGo: function(t) {
                var e = t.detail, a = e.key, i = (e.item, (t.detail.item || {}).product || this.originProductsMap[a]);
                try {
                    var r = i.positionDetails.position, o = {
                        sku: i.sku,
                        skuSn: i.skuSn,
                        sort: i.cmsProductIndex,
                        from: t.currentTarget.dataset.cmsSource
                    };
                    if (r) {
                        var n = (t.currentTarget.dataset || {}).cmsAb;
                        o = s({
                            slot: l.CMS_POSTIONS_NAME[r],
                            position: r,
                            ab: n || ""
                        }, o);
                    }
                    h.frxs.XSMonitor.sendEvent("slot_click", o);
                } catch (t) {}
                this.productDetailGo(i, {
                    prType: i.prType || "",
                    from: t.currentTarget.dataset.cmsSource
                }, {
                    isCmsProduct: !0
                });
            },
            handleIndexWindowProductDetailGo: function(t, e) {
                var a = t.detail, i = a.key, r = (a.item, this.originProductsMap[i]);
                try {
                    var o = {
                        slot: "超级爆品",
                        sku: r.sku,
                        skuSn: r.skuSn
                    };
                    if (e) {
                        var n = this.getClientProductLive(r);
                        n && (o.live_id = n.liveId);
                    }
                    h.frxs.XSMonitor.sendEvent("slot_click", o);
                } catch (t) {}
                this.productDetailGo(s(s({}, r), {}, {
                    notSendEvent: !0
                }), {
                    prType: r.prType || "",
                    from: "super_product"
                });
            },
            handleWechatDetailGo: function(t) {
                var e = this.originProductsMap[t.detail], a = t.currentTarget.dataset.windid || "", s = {
                    prType: e.prType || "",
                    anchor: "buyer"
                };
                a > 0 && (s.window_id = a), this.productDetailGo(e, s);
            },
            handleLiveProductDetailGo: function(t) {
                if (!this.checkLiveStatusToLive()) {
                    var e = this.originProductsMap[t.detail];
                    this.productDetailGo(e, {
                        prType: e.prType || ""
                    });
                }
            },
            handleLiveWechatDetailGo: function(t) {
                if (!this.checkLiveStatusToLive()) {
                    var e = this.originProductsMap[t.detail];
                    this.productDetailGo(e, {
                        prType: e.prType || "",
                        anchor: "buyer"
                    });
                }
                h.aldstat.sendEvent("首页商品页卡购买人数的点击", {
                    areaId: h.frxs.getMOrSData("areaId"),
                    storeId: h.frxs.getMOrSData("storeId")
                });
            },
            handlePrCoverClick: function(t) {
                var e = this.originProductsMap[t.detail];
                if (this.__liveProduct = e, "prSearch" === this.data.pageType && this.searchGoodsEvent) try {
                    this.searchGoodsEvent("slot_click", {
                        product: e,
                        sort: t.currentTarget.dataset.index
                    });
                } catch (t) {}
                this.isToLive(e, t) || this.handleProductDetailGo(t);
            },
            handleIndexWindowCoverClick: function(t) {
                var e = this.originProductsMap[t.detail.key];
                this.__liveProduct = e, this.isToLive(e, t) || this.handleIndexWindowProductDetailGo(t, !0);
            },
            productDetailGo: function(t, e, a) {
                this.taskerPause && this.taskerPause(), this.onHide && this.onHide(!0);
                var i = {
                    spuSn: t.spuSn || "",
                    skuSn: t.skuSn || "",
                    acid: t.acId || "",
                    prid: t.prId || "",
                    storeId: this.data.storeId || h.frxs.getMOrSData("storeId"),
                    imgUrl: t.imgUrl || t.adUrl,
                    prName: t.prName,
                    saleAmt: t.saleAmt
                };
                switch (this.data.pageType) {
                  case "home":
                    -2 == t.window_id ? (i.from = "recommend_home", e.window_id = -2) : i.from = "operation_home";
                    break;

                  case "brand":
                    i.from = "recommend_cate";
                    break;

                  case "prSearch":
                    i.from || (i.from = "search"), t.notSendEvent = !0;
                }
                "brand" === this.data.pageType && "RECOMMEND" === t._type && (i.orderAreaId = t.areaId, 
                i.from = t.slot || "recommend_sharelink"), t.martketActivity && t.martketActivity.productDetailImg && (i.active_name = "marketing_promotion"), 
                wx.$.getTestMeta("productAdsText") && t.productTitle ? i.ab = wx.$.getTestMeta("productAdsText") : i.ab = "D", 
                setTimeout(function() {
                    d.default.navigateTo({
                        path: h.frxsConfig.mall.page.prDetails,
                        query: s(s({}, i), e || {})
                    });
                }, 100);
                var r = {
                    window_id: t.window_id,
                    gsort: t.gsort,
                    rsort: t.rsort,
                    window_sort: t.window_sort,
                    queryId: t.queryId || -1,
                    ab: t.ab || {},
                    ad_id: t.adId || ""
                };
                if ("直播商品卡片" === t.slot && this.livePalyerTimes.length > 0) {
                    var o = this.livePalyerTimes.find(function(e) {
                        return e.spuSn === t.spuSn;
                    });
                    o && (r.live_id = o.liveId), r.hasNewLive = t.hasNewLive;
                }
                if ("brand" === this.data.pageType) {
                    var n = this.data, u = n.tabsList[n.tabsSelectIndex];
                    r = {
                        slot: "RECOMMEND" === t._type ? "recommend_sharelink" : "分类页商品卡片",
                        cat_id: u.windowId,
                        sec_cat_id: t.pointSecondWindowId,
                        cat_name: u.windowName,
                        sort: this.clickProductIndex ? this.clickProductIndex : 0,
                        ab: t.ab || {},
                        ad_id: t.adId || "",
                        from: "recommend_cate"
                    };
                } else if ("prSearch" == this.data.pageType) r = s(s({}, this.getPageEvtFiled() || {}), {}, {
                    slot: (this.productHasLive(t.key) ? "直播" : t.videoUrl ? "视频" : "") + "商品卡片",
                    sort: t.prIndex,
                    card_type: [ "medium", "big" ][+("bigCard" === this.data.searchResultCardType)]
                }); else if ("home" == this.data.pageType) {
                    var c = t.window_name || "每日一品";
                    r.window_name = -2 === t.window_id ? "首页瀑布流" : c, r.window_id = t.window_id, r.from = -2 == t.window_id ? "recommend_home" : "operation_home";
                }
                "RECOMMEND" === t._type && (r.recommend_sid = this._guid, r.from = t.slot || "recommend_sharelink", 
                r.slot = t.slot);
                var l = s({}, r.ab || {});
                wx.$.getTestMeta("productAdsText") && t.productTitle ? (l.productAdsText = wx.$.getTestMeta("productAdsText"), 
                r = s(s({}, r), {}, {
                    ab: l
                })) : (l.productAdsText = "D", r = s(s({}, r), {}, {
                    ab: l
                }));
                var p = s({
                    ad_id: t.ad_id || "",
                    slot: t.slot,
                    sku_sn: t.skuSn
                }, r);
                (a || {}).isCmsProduct || t.notSendEvent || h.frxs.XSMonitor.sendEvent("slot_click", p, ""), 
                wx.$.getTestMeta("fuzzy") && h.frxs.XSMonitor.sendTestEvent("slot_click", s(s({}, p), {}, {
                    slot: "销量模糊-商品卡片点击"
                }), "点击");
            },
            tapCloseVideo: function(t) {
                var e = t.detail.videoShow;
                this.setData({
                    videoShow: e
                });
            },
            tapCartVideo: function(t) {
                var e = t.detail.item.key, s = t.detail.item.cartQuantity;
                this.setData(a({}, "cartNumberMap.".concat(e), s));
            },
            tapUpdateCartVideo: function(t) {
                var e = t.detail.product.key;
                this.setData(a({}, "cartNumberMap.".concat(e), t.detail.quantity));
            },
            checkTempStore: function(t) {
                if (h.frxs.getMOrSData("storeId") == h.frxsConfig.tempStoreId) {
                    var e = (h.frxs.getMOrSData("cart") || []).find(function(e) {
                        return e.preproductId == t.preId;
                    });
                    return null == e || e.cartQuantity <= 0;
                }
                return !1;
            },
            getSalePctText: function(t, e) {
                var a = "";
                if (0 == t) a = "已抢光", e = 1; else if (t > 0) a = "即将抢光(仅剩".concat(t, "份)"), e = .9; else if (e < .1) a = "刚刚开抢", 
                e = .1; else if (e >= .95) a = "即将抢光", e = .95; else {
                    var s = parseFloat((100 * e).toFixed(2));
                    a = "已抢".concat(s, "%");
                }
                return {
                    salePctText: a,
                    salePct: e
                };
            },
            setSaleData: function(t) {
                var e = this, a = {};
                t.data.map(function(s) {
                    var i = s.marketingDataDto || s, r = (i.acId, i.prId, i.productId, i.limitQty, i.saleQty), o = i.folQty, d = i.saleRemain, u = i.dailySaleQtyTotal, c = i.salePct, l = i.saleQtyTotal, p = i.wantBuyQtyTotal, h = i.consumers, m = i.spuSn, f = i.wantBuyQty, y = i.saleLimitType, g = i.hotListDesc, v = (i.nearBy, 
                    e.spuSnKeyMap["".concat(m)]);
                    t.hasOwnProperty("page") || (e.data.consumersMap[v] || []).length < 3 && (a["consumersMap.".concat(v)] = (h || []).slice(0, 3));
                    a["followsMap.".concat(v)] = o, e.data.moduleConfig.fuzzySalesData ? a["wantBuyQtyMap.".concat(v)] = f : a["wantBuyQtyMap.".concat(v)] = f > 0 ? n.default.calculateSum(f) : "";
                    var _ = a["marketingDataMap.".concat(v)] || {}, w = e.getSalePctText(d, c), S = {
                        saleRemain: d,
                        dailySaleQtyTotal: u || _.dailySaleQtyTotal,
                        salePct: w.salePct || _.salePct,
                        saleQty: r || _.saleQty,
                        saleQtyTotal: l || _.saleQtyTotal,
                        wantBuyQtyTotal: p || _.wantBuyQtyTotal,
                        saleLimitType: y || _.saleLimitType,
                        hotListDesc: g || _.hotListDesc || "",
                        salePctText: w.salePctText || _.salePctText
                    };
                    a["marketingDataMap.".concat(v)] = S, a["videoDataMap." + v] = {
                        likeNum: i.likeNum || "",
                        viewNum: i.viewNum || ""
                    };
                }), this.setData(a, function() {
                    t.success && t.success();
                });
            },
            addWantBuyQty: function(t, e, a) {
                if (1 == e.cartQuantity) {
                    var s = {}, i = (t.detail || {}).key, r = t.currentTarget.dataset, o = (t.detail.item || {}).product;
                    if (!this.data.moduleConfig.fuzzySalesData) {
                        var d = this.data.wantBuyQtyMap[i] || 0;
                        "number" == typeof d && (d += 1, s["wantBuyQtyMap.".concat(i)] = d > 0 ? n.default.calculateSum(d) : "", 
                        this.setData(s));
                    }
                    "prSearch" !== this.data.pageType && this.addEvt_add_cart_product(i, o, r);
                } else a && a();
            },
            onProductExposure: function(t) {
                var e = t.currentTarget.dataset.product, a = t.detail.status, i = void 0 === a ? "" : a, r = {};
                if ("直播商品卡片" === e.slot && this.livePalyerTimes.length > 0 || e.hasNewLive) {
                    var o = this.livePalyerTimes.find(function(t) {
                        return t.spuSn === e.spuSn;
                    });
                    o && (r.live_id = o.liveId), r.hasNewLive = e.hasNewLive;
                }
                switch (e.utvList && e.utvList.length && (e.slot = "菜谱入口"), this.data.pageType) {
                  case "home":
                    r = s(s({}, r), {}, {
                        window_id: e.window_id,
                        gsort: e.gsort,
                        rsort: e.rsort,
                        window_sort: e.window_sort,
                        ab: e.ab || {},
                        ad_id: e.adId || "",
                        window_name: -2 === e.window_id ? "首页瀑布流" : e.window_name || ""
                    });
                    break;

                  case "brand":
                    if ((r = s(s({}, r), {}, {
                        sort: t.currentTarget.dataset.index,
                        cat_id: this.data.selectCateDetails.windowId || null,
                        sec_cat_id: e.pointSecondWindowId,
                        ab: e.ab || {},
                        ad_id: e.adId || ""
                    })).cat_name = "RECOMMEND" === e._type ? "推荐" : e.window_name, "SOLDOUT" === i) {
                        var n = {
                            slot: "看相似商品",
                            sku_sn: e.skuSn,
                            cat_id: this.data.selectCateDetails.windowId || null,
                            sec_cat_id: e.secondWindowId
                        };
                        h.frxs.XSMonitor.sendEvent("slot_show", n, "");
                    }
                    "RECOMMEND" === e._type && (r = s(s({}, r), {}, {
                        slot: e.slot,
                        recommend_sid: this._guid
                    }));
                    break;

                  case "prSearch":
                    if (r = s(s(s({}, r), this.getPageEvtFiled()), {}, {
                        card_type: [ "medium", "big" ][+("bigCard" === this.data.searchResultCardType)],
                        ad_id: e.ad_id || "",
                        sort: e.prIndex
                    }), "SOLDOUT" === i) {
                        var d = {
                            slot: "看相似商品",
                            sku_sn: e.skuSn
                        };
                        h.frxs.XSMonitor.sendEvent("slot_show", d, "");
                    }
                }
                var u = s({
                    sku_sn: e.skuSn,
                    slot: e.slot,
                    queryId: e.queryId || -1
                }, r), c = s({}, u.ab || {});
                wx.$.getTestMeta("productAdsText") && e.productTitle ? (c.productAdsText = wx.$.getTestMeta("productAdsText"), 
                u = s(s({}, u), {}, {
                    ab: c
                })) : (c.productAdsText = "D", u = s(s({}, u), {}, {
                    ab: c
                })), h.frxs.XSMonitor.sendEvent("slot_show", u, ""), wx.$.getTestMeta("fuzzy") && h.frxs.XSMonitor.sendTestEvent("slot_show", s(s({}, u), {}, {
                    slot: "销量模糊-商品卡片曝光"
                }), "商品卡片曝光");
            },
            addEvt_add_cart_product: function(t, e, a) {
                try {
                    var i = this.originProductsMap[t];
                    if ("super_product" == ((a || {}).extend || {}).module) {
                        var r = a.evtExtend, o = void 0 === r ? {} : r, n = s({
                            sku_sn: i.skuSn,
                            extra_operate: i.tsBuyStart - new Date().getTime() > 0 ? "wantBuy" : ""
                        }, o || {});
                        "RECOMMEND" === i._type && (n.source = i.slot || "recommend_sharelink", n.recommend_sid = this._guid), 
                        h.frxs.XSMonitor.sendEvent("add_product", n, "加车");
                    } else if (e) {
                        var d = e.positionDetails;
                        if (Object.keys(l.CMS_POSTIONS_NAME).findIndex(function(t) {
                            return t == d.position;
                        }) > -1) {
                            var u = {
                                TOPTEN: "thot",
                                THANKSFEEDBACK: "thanks"
                            }[l.CMS_POSTIONS_CODE[d.position]] || "";
                            h.frxs.XSMonitor.sendEvent("add_product", {
                                slot: l.CMS_POSTIONS_NAME[d.position] || d.windowName,
                                sku: i.sku,
                                skuSn: i.skuSn,
                                sort: i.cmsProductIndex,
                                source: u,
                                ab: a.cmsAb || ""
                            }, "加车");
                        } else h.frxs.XSMonitor.sendEvent("add_product", {
                            slot: "加购",
                            sku_sn: i.skuSn,
                            source: "首页新人专区"
                        }, "");
                    } else {
                        var c = {};
                        switch (this.data.pageType) {
                          case "home":
                            c = {
                                window_id: i.window_id,
                                gsort: i.gsort,
                                rsort: i.rsort,
                                window_sort: i.window_sort,
                                source: "operation_home",
                                ab: i.ab || {},
                                ad_id: i.adId || "",
                                window_name: -2 === i.window_id ? "首页瀑布流" : i.window_name || "每日一品"
                            }, -2 === i.window_id && (c.source = "recommend_home"), "recommend_home_list" == i.slot && (c.list_id = i.listId, 
                            c.list_name = "list_".concat(i.listType), c.source = i.slot, c.slot = i.slot);
                            break;

                          case "brand":
                            c = {
                                sort: i.prIndex,
                                cat_id: this.data.selectCateDetails.windowId || null,
                                sec_cat_id: i.pointSecondWindowId,
                                source: "recommend_cate",
                                ab: i.ab || {},
                                ad_id: i.adId || "",
                                cat_name: "RECOMMEND" === i._type ? "推荐" : i.window_name
                            }, "RECOMMEND" === i._type && (c.source = i.slot || "recommend_sharelink", c.recommend_sid = this._guid);
                            break;

                          default:
                            i.hasOwnProperty("prIndex") && (c.sort = i.prIndex), c.card_type = [ "medium", "big" ][+("bigCard" === this.data.searchResultCardType)], 
                            c.source = "search";
                        }
                        var p = s(s({
                            ad_id: i.ad_id || "",
                            slot: i.slot,
                            sku_sn: i.skuSn,
                            queryId: i.queryId || -1,
                            extra_operate: i.tsBuyStart - new Date().getTime() > 0 ? "wantBuy" : ""
                        }, this.getPageEvtFiled && this.getPageEvtFiled() || {}), c);
                        i.martketActivity && i.martketActivity.productDetailImg && (p.slot = "营销大促", p.active_name = "marketing_promotion");
                        var m = s({}, p.ab || {});
                        wx.$.getTestMeta("productAdsText") && i.productTitle ? (m.productAdsText = wx.$.getTestMeta("productAdsText"), 
                        p = s(s({}, p), {}, {
                            ab: m
                        })) : (m.productAdsText = "D", p = s(s({}, p), {}, {
                            ab: m
                        })), h.frxs.XSMonitor.sendEvent("add_product", p, "加车"), wx.$.getTestMeta("fuzzy") && h.frxs.XSMonitor.sendTestEvent("add_product", s(s({}, p), {}, {
                            slot: "销量模糊-商品卡片加购"
                        }), "加车"), h.frxs.XSMonitor.sendTestEvent("add_product", s(s({}, p), {}, {
                            slot: "首页改版-商品卡片加购"
                        }), "加车");
                    }
                } catch (t) {}
            },
            tsSalesCutOff: [],
            setProductSaleCountDown: function(t) {
                var e = this;
                t.map(function(t) {
                    -1 == e.tsSalesCutOff.indexOf(t.tsBuyEnd) && e.tsSalesCutOff.push(t.tsBuyEnd);
                });
            },
            refreshSalesCutOff: function() {
                if (this.tsSalesCutOff.length > 0 && this.scrollTop < 15e3) {
                    var t = this.now(), e = this.$getData().salesCutOffMap;
                    this.tsSalesCutOff.map(function(a) {
                        if (t < a) {
                            var s = h.frxs.getCountDownTimeToObject(t, a);
                            e[a] = {
                                hour: s.totalHours,
                                minute: s.minutes,
                                second: s.seconds
                            };
                        } else e[a] = {
                            hour: "00",
                            minute: "00",
                            second: "00"
                        };
                    }), this.setData({
                        salesCutOffMap: e
                    });
                }
            },
            setSaleDuration: function(t) {
                if (0 != (t || []).length) {
                    var e = {};
                    t.map(function(t) {
                        var a = n.default.getCountDownTimeToObject(t.tsBuyStart, t.tsBuyEnd);
                        e["saleDurationMap.".concat(t.key)] = a;
                    }), this.setData(e);
                }
            },
            goPageHotList: function(t) {
                try {
                    var e = t.detail.listId || t.detail.marketingDataDto.listId, a = t.detail.marketingDataDto.listType, s = p.RANK_ROUTER_KEY[a] || "subPages/home/brand/hotlist/index", i = t.currentTarget.dataset.from, r = {
                        listId: e,
                        from: i,
                        listType: p.CONVERT_HOTLIST_CODE[a] || ""
                    };
                    h.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "list_link",
                        source: i,
                        list_id: e,
                        list_type: a
                    }), h.router.navigateTo({
                        path: s,
                        query: r
                    });
                } catch (t) {}
            },
            onSimilarProductsEvent: function(t) {
                try {
                    var e = t.target.dataset, a = e.from, i = e.product, r = {
                        slot: "看相似商品",
                        sku_sn: i.skuSn
                    };
                    "index" === a && (r = s(s({}, r), {}, {
                        window_id: i.windowId || -2,
                        window_name: i.windowName || "为你推荐"
                    })), "cate_product" === a && (r = s(s({}, r), {}, {
                        cat_id: this.data.selectCateDetails.windowId || null,
                        sec_cat_id: i.secondWindowId
                    })), console.log("相似商品按钮埋点params", r), h.frxs.XSMonitor.sendEvent("slot_click", r, "");
                } catch (t) {}
            }
        }
    };
};

var a = require("../@babel/runtime/helpers/defineProperty"), s = require("../@babel/runtime/helpers/objectSpread2"), i = require("../utils/index"), r = e(require("../utils/cartService.js")), o = t(require("../utils/events.js")), n = (e(require("../utils/userdata.js")), 
e(require("../utils/common.js"))), d = e(require("../router/index")), u = e(require("../utils/sample-store-dialog.js")), c = (e(require("../router/page-name.js")), 
require("../utils/subscribe-message")), l = require("../const/cms-positions.js"), p = require("../const/hot-constants.js"), h = getApp(), m = "WAITING", f = "ACTIVE", y = "SOLDOUT", g = "OVER", v = "LACK";