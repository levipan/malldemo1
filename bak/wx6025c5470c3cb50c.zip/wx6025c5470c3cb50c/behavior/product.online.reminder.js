var e = require("../@babel/runtime/helpers/interopRequireWildcard"), t = require("../@babel/runtime/helpers/interopRequireDefault"), s = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/defineProperty"), o = require("../api/index.js"), u = t(require("../utils/cartService.js")), n = require("../utils/index.js"), c = e(require("../utils/events.js")), i = (t(require("../router/index.js")), 
t(require("../@xsyx-components/hanzo-dialog/dialog.js"))), d = t(require("../@xsyx-components/hanzo-page-loading/loading.js")), a = (t(require("./video/product.js")), 
require("../const/storage.key.js")), l = getApp(), m = l.frxsConfig.ossDomain;

module.exports = function() {
    return {
        data: {
            canCartProducts: !1,
            alertInfo: {
                show: !1
            },
            recommendProducts: [],
            recommendInfo: {},
            showAddSubGuid: !1,
            productReminderSubscribeStatus: "",
            todayProductSubReminder: !1,
            subMainSwitch: !1,
            productReminderTmpId: "",
            curSubProductDetail: {},
            showTkRecommend: !1
        },
        methods: {
            popupFollowRecommendProducts: [],
            followSubStatus: "success",
            showSubscribeAlert: function() {
                switch (this.followSubStatus) {
                  case "success":
                    this.showSubscribeSuccessAlert();
                    break;

                  case "repeat":
                    this.showRepeatSubscribeAlert();
                    break;

                  case "overrun":
                    this.showOverrunSubscribeAlert();
                }
            },
            showRepeatSubscribeAlert: function(e) {
                (this.popupFollowRecommendProducts || []).length > 0 ? this.setData({
                    recommendProducts: this.popupFollowRecommendProducts,
                    recommendInfo: {
                        title: "您已订阅",
                        guide: "您已经订阅了该商品，后续上线之后会主动提醒您～",
                        icon: "info"
                    }
                }) : this.setData({
                    alertInfo: {
                        title: "您已订阅",
                        content: "您已经订阅了该商品，后续上线之后会主动提醒您～",
                        confirmText: "知道了",
                        show: !0,
                        confirmEvtName: "onProductReminderSubMsg"
                    }
                });
            },
            showOverrunSubscribeAlert: function(e) {
                (this.popupFollowRecommendProducts || []).length > 0 ? this.setData({
                    recommendProducts: this.popupFollowRecommendProducts,
                    recommendInfo: {
                        title: "商品订阅数量已超过上限",
                        guide: "您可以去个人中心 - 商品上线提醒，将您不需要的商品“取消订阅”",
                        icon: "info"
                    }
                }) : this.setData({
                    alertInfo: {
                        title: "商品订阅数量已超过上限",
                        content: "您可以去个人中心 - 商品上线提醒，将您不需要的商品“取消订阅”",
                        confirmText: "前往取消订阅",
                        closeIconEvtName: "onAlertInfoClose",
                        show: !0,
                        confirmEvtName: "onProductReminderSubMsg"
                    }
                });
            },
            showSubscribeSuccessAlert: function(e) {
                (this.popupFollowRecommendProducts || []).length > 0 ? this.setData({
                    recommendProducts: this.popupFollowRecommendProducts,
                    recommendInfo: {
                        title: "商品“上线提醒我”订阅成功",
                        icon: "success"
                    }
                }) : this.setData({
                    alertInfo: {
                        title: "商品“上线提醒我”订阅成功",
                        iconUrl: m + "/2020/08/05/438309748.png",
                        content: "您订阅的商品上线当天，系统会及时提醒，敬请关注！",
                        confirmText: "知道了",
                        show: !0,
                        confirmEvtName: "onProductReminderSubMsg"
                    }
                });
            },
            onAlertInfoClose: function() {
                var e;
                this.setData((r(e = {}, "alertInfo.show", !1), r(e, "recommendProducts", []), r(e, "showTkRecommend", !1), 
                e));
            },
            onAddProductSubReminder: function(e) {
                this.addProductSub(e.detail);
            },
            addProductSub: function(e) {
                var t = this, s = l.frxs.getMOrSData("userKey"), r = l.frxs.getMOrSData("isLogin");
                if (s && r) {
                    var u = {
                        sku: e.sku,
                        activityId: e.presaleActivityId || e.activityId || e.acId,
                        productId: e.productId || e.prId,
                        areaId: l.frxs.getMOrSData("areaId")
                    };
                    d.default.showLoading({
                        title: "添加中...",
                        icon: "loading",
                        zIndex: 2e4
                    }), this.curSubProductDetail = e, o.memberApi.addProductSub(u, {
                        silence: !0
                    }).then(function(s) {
                        t.getRecommendProduct({
                            params: u,
                            callback: function(s) {
                                t.popupFollowRecommendProducts = s, t.followSubStatus = "success", t.productReminderSubMsg({
                                    success: function() {
                                        t.showSubscribeAlert();
                                    }
                                }), d.default.close(), t.addSubProductEvent(e, s, {
                                    rspCode: "success"
                                });
                            }
                        });
                    }).catch(function(s) {
                        [ "FE10731003001", "FE10731003002" ].indexOf(s.rspCode) >= 0 ? t.getRecommendProduct({
                            params: u,
                            callback: function(e) {
                                t.popupFollowRecommendProducts = e, t.followSubStatus = "", "FE10731003001" == s.rspCode ? t.followSubStatus = "overrun" : "FE10731003002" == s.rspCode && (t.followSubStatus = "repeat"), 
                                t.productReminderSubMsg({
                                    success: function() {
                                        t.showSubscribeAlert();
                                    }
                                }), d.default.close();
                            }
                        }) : (i.default.alert({
                            content: s.rspDesc || "订阅失败，请稍后重试...",
                            zIndex: 2e4
                        }), d.default.close()), t.addSubProductEvent(e, [], s);
                    });
                } else l.userSvr.autoLogin({
                    success: function() {
                        t.addProductSub(e);
                    }
                });
            },
            addSubProductEvent: function(e, t, s) {
                var r;
                this.lastSubProduct = e, l.frxs.XSMonitor.sendEvent("sub_product", {
                    sku: e.sku || "",
                    sku_sn: e.skuSn || "",
                    list: (r = [], t.map(function(e) {
                        r.push(e.skuSn);
                    }), r),
                    code: "success" == (s || {}).rspCode ? "success" : "fail"
                }, "上线提醒我");
            },
            getRecommendProduct: function(e) {
                o.brandHousePromotionApi.queryRecommand(s(s({}, e.params), {}, {
                    storeId: l.frxs.getMOrSData("storeId")
                }), {
                    contentType: "application/json",
                    silence: !0
                }).then(function(t) {
                    t = t || [];
                    var s = u.default.getCartList();
                    t.map(function(e) {
                        e.isCanAddCart = u.default.getCanAddStatus(e, s);
                    });
                    var r = t.filter(function(e) {
                        return e.isCanAddCart;
                    }) || [];
                    e.callback(r);
                }).catch(function(t) {
                    e.callback([]);
                });
            },
            subRecommendBatchAddCart: function(e) {
                var t = this, r = e.detail.products, o = [], n = {};
                r.map(function(e) {
                    e.saleRemain = e.saleRemain || -1, e.usaleQty = e.usaleQty || 0, e.ulimitQty = e.ulimitQty || 0;
                    var r = u.default.addCart(e, 1, t);
                    o.push(s(s({}, r), {}, {
                        product: e
                    }));
                    var c = e.hasOwnProperty("index") ? e.index : t.data.recommendProducts.findIndex(function(t) {
                        return t.spuSn == e.spuSn;
                    });
                    n["recommendProducts[".concat(c, "].isCanAddCart")] = u.default.getCanAddStatus(e);
                }), this.setData(n);
                var a = o.filter(function(e) {
                    return "success" == e.rspCode;
                }), m = o.filter(function(e) {
                    return "success" != e.rspCode;
                });
                if (a.length > 0) "cart" == this.data.pageType && this.setData({
                    hasNewProduct: !0
                }), d.default.showToast({
                    title: "已加入购物车",
                    icon: "success1",
                    zIndex: 2e4
                }), this.behavior_convenient_getCart && this.behavior_convenient_getCart(); else {
                    var p = "";
                    m.map(function(e, t) {
                        p += (t > 0 ? "\r\n" : "") + e.info;
                    }), i.default.alert({
                        title: "温馨提示",
                        content: p,
                        zIndex: 2e4
                    });
                }
                if (this.onAlertInfoClose(), "tk" === this._get(e, "currentTarget.dataset.type", "")) {
                    var f = [];
                    return r.forEach(function(e) {
                        f.push(e.skuSn);
                    }), void l.frxs.XSMonitor.sendEvent("add_product", {
                        source: "推客推单品弹窗",
                        sku_sn: f
                    }, "");
                }
                c.default.emit(c.EVENTS.REFRESH_CART), this.addXsEventBatchSubAddCart(o, "onlineRemindRecommendAddCart");
            },
            onlineReminderPageAddCart: function(e) {
                var t = e.product;
                t.saleRemain = t.saleRemain || -1, t.usaleQty = t.usaleQty || 0, t.ulimitQty = t.ulimitQty || 0;
                var s = u.default.addCart(t, 1, this);
                "success" == s.rspCode ? e.success(s) : i.default.alert({
                    title: "温馨提示",
                    content: s.info,
                    zIndex: 2e4
                });
            },
            addCartSuccess: function(e) {
                return d.default.showToast({
                    title: "已加入购物车",
                    icon: "success1",
                    mask: !0,
                    zIndex: 2e4
                });
            },
            addXsEventBatchSubAddCart: function(e, t) {
                var r = this.curSubProductDetail, o = {
                    sub_sku_sn: r.skuSn,
                    sub_sku: r.sku
                };
                if ("onlineRemindRecommendAddCart" == t) {
                    var u = this.route.toLowerCase(), n = [ "home_sub", "category_sub", "searchproduct_sub", "productdetail_sub", "cart_sub", "orderman_sub", "ordersearch_sub", "orderdetail_sub" ], c = [ "home", "brand", "", "", "cart", "", "", "" ], i = [ "pages/home/index/index", "pages/home/cateproduct/index", "subpages/home/brand/search/search", "subproduct/detail/index", "pages/home/cart/cart", "subpages/users/orderlist/orderlist", "subpages/users/ordersearch/index", "subpages/users/orderdetail/orderdetail" ], d = this.data.pageType;
                    o.source = function() {
                        if (d) {
                            var e = n[c.indexOf(d)];
                            if (e) return e;
                        }
                        return n[i.indexOf(u)] || "";
                    }();
                }
                e.map(function(e) {
                    l.frxs.XSMonitor.sendEvent("add_product", s({
                        sku_sn: e.product.skuSn,
                        sku: e.product.sku || ""
                    }, o));
                });
            },
            onProductReminderSubMsg: function(e) {},
            setProductSubListGuide: function() {
                this.productReminderSubMsg({
                    isProductSubListPage: !0
                });
            },
            productReminderSubMsg: function(e) {
                var t = this;
                e = e || {};
                var s = l.frxsConfig.tmplIds.productReminder;
                if (s) {
                    var r = l.frxs.formaterDate(new Date(), "yyyy-MM-dd"), o = (l.frxs.getStorageSync(a.STORAGE_KEY.SUB_TMPLID_PRODUCTS) || {})[r] || [];
                    wx.getSetting({
                        withSubscriptions: !0,
                        complete: function(r) {
                            var u = (r.subscriptionsSetting || {}).mainSwitch || !1, n = ((r.subscriptionsSetting || {}).itemSettings || {})[s] || "";
                            if (u && "accept" == n) t.popupProductReminderSubMsg(e); else {
                                if (t.curSubProductDetail && o.indexOf(t.curSubProductDetail.spuSn) >= 0) return void (e && e.success && e.success());
                                t.popupProductReminderSubMsg(e);
                            }
                        }
                    });
                } else e && e.success && e.success();
            },
            popupProductReminderSubMsg: function() {
                var e = this;
                this.saveCurSubProductDetail();
                var t = l.frxsConfig.tmplIds;
                if (t.productReminder) {
                    var s = [ t.productReminder ];
                    t.productBuy && s.push(t.productBuy), t.commodityReduction && s.push(t.commodityReduction), 
                    wx.requestSubscribeMessage && wx.requestSubscribeMessage({
                        tmplIds: s,
                        complete: function(t) {
                            l.frxs.setStorageSync(a.STORAGE_KEY.LAST_PRODUCT_SUB_REMINDER_TS, l.frxs.formaterDate(new Date(), "yyyy-MM-dd")), 
                            e.setData({
                                showAddSubGuid: !1
                            }), (0, n.tmplIdsAddEvt)(s, t, "上线提醒我"), e.showSubscribeAlert();
                        }
                    });
                } else this.showSubscribeAlert();
            },
            saveCurSubProductDetail: function() {
                var e = l.frxs.formaterDate(new Date(), "yyyy-MM-dd");
                if (this.curSubProductDetail) {
                    var t = (l.frxs.getStorageSync(a.STORAGE_KEY.SUB_TMPLID_PRODUCTS) || {})[e] || [];
                    t.push(this.curSubProductDetail.spuSn), l.frxs.setStorageSync(a.STORAGE_KEY.SUB_TMPLID_PRODUCTS, r({}, "".concat(e), t));
                }
            }
        }
    };
};