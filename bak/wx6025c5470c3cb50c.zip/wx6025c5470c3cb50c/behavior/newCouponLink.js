var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.__toLink = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = getApp();
    try {
        var d = t.activityCode, a = t.linkUrl, n = void 0 === a ? "" : a, u = t.urlType, s = t.ticketToolId, l = t.ticketId, p = t.activityId, c = void 0 === p ? "" : p, v = t.toolActivityId, f = void 0 === v ? "" : v, h = t.tmExpire, m = void 0 === h ? "" : h, b = t.tmFinish, x = void 0 === b ? "" : b, y = t.toolType, g = void 0 === y ? "" : y, I = t.toolName, T = void 0 === I ? "" : I, q = t.orderAmountLimit, C = void 0 === q ? "" : q, w = t.amount, L = void 0 === w ? "" : w, O = t.orderStep, S = void 0 === O ? [] : O, A = {
            activityCode: d,
            activityId: c,
            toolActivityId: f,
            tmExpire: m,
            tmFinish: x,
            ticketId: l || s,
            toolType: g,
            toolName: T,
            orderAmountLimit: C,
            amount: L,
            orderStep: S
        };
        if ("SINGLE" !== t.rootType && !n && "CET_ODR" == u) return o.default.navigateTo({
            path: "subShopCart/productList/index",
            query: {
                coupon: encodeURIComponent(JSON.stringify(A))
            }
        });
        if (0 === n.indexOf("@")) {
            var E = {};
            n.substr(1).split("&").forEach(function(e) {
                var t = e.split("=");
                E[t[0]] = t[1];
            }), e.detail.store.params = E, o.default.navigateTo({
                path: "/subProduct/detail/index",
                query: i({}, E || {})
            });
        } else if (0 === n.indexOf("%windId=") && n.substr(8)) r.globalData["cateProduct-selectWindowId"] = {
            windId: n.substr(8)
        }, o.default.switchTab({
            path: r.frxsConfig.mall.page.cateProduct
        }); else if (0 === n.indexOf("%secondWindowId") && n.substr(16)) o.default.navigateTo({
            path: "/subProduct/boutique/boutique",
            query: {
                secondWindowId: n.substring(16, n.length)
            }
        }); else if (n) {
            if ("CET_ODR" === u) return o.default.navigateTo({
                path: "subShopCart/productList/index",
                query: {
                    coupon: encodeURIComponent(JSON.stringify(A))
                }
            });
            o.default.navigateTo({
                path: "/pages/home/h5Active/index",
                query: {
                    url: n
                }
            });
        } else wx.reLaunch({
            url: "/pages/home/index/index"
        });
    } catch (e) {
        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
        console.error(e), wx.reLaunch({
            url: "/pages/home/index/index"
        });
    }
};

var i = require("../@babel/runtime/helpers/objectSpread2"), o = t(require("../router/index"));