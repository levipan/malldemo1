var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/asyncToGenerator"), a = require("../api/index.js"), s = (e(require("../xapp/runtime")), 
e(require("../utils/moment.min"))), o = e(require("../router/index")), i = require("../utils/datetime"), c = require("../api/formatData/product"), u = e(require("../utils/cartService")), d = getApp(), l = {
    initNewUserActiveProduct: function(e) {
        return (e = (0, c.formatProductsData)(e, !0)).map(function(e) {}), this.refreshProductKeyPreIdMap && this.refreshProductKeyPreIdMap(e), 
        this.refreshOriginProductsMap && this.refreshOriginProductsMap(e), this.refreshCmsOriginProductsMap && this.refreshCmsOriginProductsMap(e), 
        this.refreshProductsStatus && this.refreshProductsStatus(e), this.setSaleData && this.setSaleData({
            data: e
        }), this.addPresaleTss && this.addPresaleTss(e), e;
    },
    newUserActiveAddCarToast: function(e) {
        var t = this, r = e.product, n = e.ticketsMap, a = e.position, s = void 0 === a ? "index" : a, o = e.cartList, i = "添加购物车成功！", c = this._get(r, "skuSn", "") || "";
        n = n || {}, o = o || [];
        var u = "PRICE" === this._get(n, "".concat(c, ".toolType"), ""), l = o.filter(function(e) {
            return "PRICE" === t._get(n, "".concat(e.skuSn, ".toolType"), "");
        }) || [];
        u && l.length > 0 && (i = l.find(function(e) {
            return e.skuSn === c;
        }) || null ? "新人专享价商品限购1份，超出部分恢复原价～" : "新人专享价商品限购1份，已为您选择最佳优惠", "product-detail" !== s && d.frxs.showToast({
            title: i
        }));
        "product-detail" === s && d.frxs.showToast({
            title: i
        });
    },
    authActiveNewUser: function() {
        return n(t.default.mark(function e() {
            var n, s, o, i;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = !1, e.prev = 1, s = d.frxs.isLogin()) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return", !0);

                  case 5:
                    return o = {}, (i = d.frxs.getMOrSData("areaId") || null) && (o.areaId = i), e.next = 10, 
                    a.tradeApi.isNewUser(r({
                        userKey: s,
                        blackBox: d.frxs.storage("safe_bb") || ""
                    }, o), {
                        silence: !0
                    });

                  case 10:
                    return n = e.sent, e.abrupt("return", n);

                  case 14:
                    return e.prev = 14, e.t0 = e.catch(1), console.error(e.t0), e.abrupt("return", !1);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 1, 14 ] ]);
        }))();
    },
    onCloseNewUserModal: function() {
        var e = new Date(this.now()), t = (0, s.default)(e).endOf("day").format("x"), r = this.$storage.get("new-user-active") || {};
        r[d.frxs.getMOrSData("areaId")] = !0, this.$storage.set("new-user-active", r, Math.ceil((t - e.getTime()) / 1e3)), 
        this.setData({
            showNewUserModal: !1
        }, function() {});
    },
    authIsNewUser: function() {
        var e = this;
        return n(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.authActiveNewUser();

                  case 2:
                    return n = t.sent, d.frxs.setMData("isNewUser", n), t.abrupt("return", n);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    now: function() {
        return +new Date() + (this.timeOffset || d.frxs.getMOrSData("timeDiffServerAndClient") || 0);
    },
    newUserLoginCallBack: function() {
        var e = this;
        return n(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (d.frxs.isLogin()) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return e.onCloseNewUserModal(), t.next = 5, e.authActiveNewUser();

                  case 5:
                    n = t.sent, d.frxs.setMData("isNewUser", n), n ? o.default.navigateTo({
                        path: "/subNewUser/active/index"
                    }) : wx.reLaunch({
                        url: "/pages/home/index/index"
                    });

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    onOpenNewUserActivePage: function(e) {
        try {
            var t = e.currentTarget.dataset, n = t.slot, a = t.skuSn, s = {};
            "新人弹窗商品卡片" === n && (s.sku_sn = a), d.frxs.XSMonitor.sendEvent("slot_click", r({
                slot: n
            }, s), "");
        } catch (e) {}
        if (d.frxs.isLogin()) return this.onCloseNewUserModal(), o.default.navigateTo({
            path: "/subNewUser/active/index"
        });
        wx.$.page().options.callback = !0, d.frxs.setMData("nextFName", {
            name: "newUserLoginCallBack"
        }), d.frxs.toLogin();
    },
    timeTo: function(e) {
        var t = new Date(e) - new Date(this.now());
        if (t <= 0) return {
            d: [ 0, 0 ],
            h: [ 0, 0 ],
            m: [ 0, 0 ],
            s: [ 0, 0 ],
            hm: 0,
            zero: !0
        };
        var r = parseInt(t / 1e3 / 60 / 60 / 24), n = parseInt(t / 1e3 / 60 / 60 - 24 * r), a = parseInt(t / 1e3 / 60 - 1440 * r - 60 * n), s = parseInt(t / 1e3 - 86400 * r - 3600 * n - 60 * a), o = Math.floor((t - 864e5 * r - 36e5 * n - 6e4 * a - 1e3 * s) / 100);
        return s < 10 && (s = "0" + s), a < 10 && (a = "0" + a), n < 10 && (n = "0" + n), 
        {
            d: r,
            h: ((n || "00") + "").split(""),
            m: ((a || "00") + "").split(""),
            s: ((s || "00") + "").split(""),
            hm: ((o || "00") + "").split("")[0]
        };
    },
    getNewUserActive: function(e, r) {
        var o = this, c = d.frxs.getMOrSData("storeInfo") || !1;
        if (!c) return r && r(!1);
        var l = d.frxs.isLogin() ? a.couponApi.loginUserGetActivity : a.couponApi.notLoginUserGetActivity, f = {
            provinceCode: c.provinceId,
            cityCode: c.cityId,
            areaCode: c.countyId,
            saleRegionCode: c.areaId,
            storeId: c.storeId,
            channelUse: "WXAPP",
            blackbox: d.frxs.storage("safe_bb") || ""
        };
        "index-modal" === e && (f.productCnt = 6);
        var p = {}, w = function() {
            var r = n(t.default.mark(function r(n) {
                var c, d, l, w, h, g, m, x, U, v, k, P;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (p.newUserTicket = o._get(n, "newUserTicket", !1) || !1, "23:00", p.newUserTicket && (c = [], 
                        p.newUserTicket.timeStepAmountList && p.newUserTicket.timeStepAmountList.length > 0 ? (d = p.newUserTicket.timeStepAmountList, 
                        p.newUserTicket.timeStepAmountList = [], d.forEach(function(e, t) {
                            var r = (0, i.strToTs)(e.endTime);
                            o.now() - r < 0 && (d[t + 1] ? c.push({
                                endTime: r,
                                rightAmount: d[t + 1].amount,
                                amount: e.amount
                            }) : c.push({
                                endTime: r,
                                rightAmount: 0,
                                amount: e.amount
                            }));
                        }), l = new Date(o.now()), w = +new Date("".concat(l.getFullYear(), "/").concat(l.getMonth() + 1, "/").concat(l.getDate(), " ").concat("23:00")), 
                        +l > w && (h = (0, s.default)(new Date(o.now())).add(1, "days").toDate(), w = +new Date("".concat(h.getFullYear(), "/").concat(h.getMonth() + 1, "/").concat(h.getDate(), " ").concat("23:00"))), 
                        g = c.length - 1 >= 0 ? c.length - 1 : 0, m = o._get(c, "".concat(g, ".amount"), 0) || 0, 
                        c[g] = {
                            rightAmount: 0,
                            amount: m || p.newUserTicket.amount,
                            endTime: w
                        }) : (x = new Date(o.now()), U = +new Date("".concat(x.getFullYear(), "/").concat(x.getMonth() + 1, "/").concat(x.getDate(), " ").concat("23:00")), 
                        +x > U && (v = (0, s.default)(new Date(o.now())).add(1, "days").toDate(), U = +new Date("".concat(v.getFullYear(), "/").concat(v.getMonth() + 1, "/").concat(v.getDate(), " ").concat("23:00"))), 
                        c[0] = {
                            endTime: U,
                            rightAmount: 0,
                            amount: p.newUserTicket.amount,
                            orderAmountLimit: p.newUserTicket.orderAmountLimit
                        }), p.newUserTicket.timeStepAmountList = c), p.newUserRebateTicketPackage = o._get(n, "ticketPackageInfo", !1) || !1, 
                        p.newUserProducts = o._get(n, "newUserProducts", !1) || !1, k = !1, "index-modal" === e) {
                            t.next = 25;
                            break;
                        }
                        return t.prev = 7, P = "index-page" === e ? 15 : 99, t.next = 11, a.homePromotionApi.queryNewUserProduct({
                            areaId: f.saleRegionCode,
                            storeId: f.storeId,
                            limit: P
                        }, {
                            silence: !0,
                            contentType: "application/json"
                        });

                      case 11:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 14;
                            break;
                        }
                        t.t0 = [];

                      case 14:
                        k = t.t0, (k = o._get(k, "products", []) || []) && 0 === k.length && (k = !1), 15 === P && k && k.length < 3 && (k = !1), 
                        99 === P && k && k.length < 3 && (k = !1), t.next = 25;
                        break;

                      case 21:
                        t.prev = 21, t.t1 = t.catch(7), console.error(t.t1), k = !1;

                      case 25:
                        "index-modal" !== e && (u.default.getCartList().forEach(function(e) {
                            var t = (k || []).find(function(t) {
                                return t.skuSn === e.skuSn;
                            }) || null;
                            t && (t.cartQuantity = e.cartQuantity);
                        }), p.newUserProducts = k), (p.newUserProducts && 0 === p.newUserProducts.length || "index-modal" === e && p.newUserProducts && p.newUserProducts.length < 6) && (p.newUserProducts = !1), 
                        p.newUserTicket ? (p.newUserTicket.index = 1, p.newUserRebateTicketPackage ? (p.newUserRebateTicketPackage.index = 2, 
                        p.newUserProducts && (p.newUserProductsIndex = 3)) : p.newUserProducts && (p.newUserProductsIndex = 2)) : p.newUserRebateTicketPackage ? (p.newUserRebateTicketPackage.index = 1, 
                        p.newUserProducts && (p.newUserProductsIndex = 2)) : p.newUserProducts && (p.newUserProductsIndex = 1), 
                        p.newUserProducts && (p.newUserProducts = o.initNewUserActiveProduct(p.newUserProducts));

                      case 29:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 7, 21 ] ]);
            }));
            return function(e) {
                return r.apply(this, arguments);
            };
        }();
        l(f, {
            silence: !0,
            contentType: "application/json"
        }).then(function() {
            var e = n(t.default.mark(function e(n) {
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, w(n);

                      case 2:
                        r && r(p);

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }()).catch(function() {
            var e = n(t.default.mark(function e(n) {
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return console.error(n), e.next = 3, w({
                            newUserTicket: !1,
                            newUserProducts: !1,
                            ticketPackageInfo: !1
                        });

                      case 3:
                        r && r(p);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }());
    }
};

exports.default = l;