var e = require("../@babel/runtime/helpers/interopRequireWildcard"), t = require("../@babel/runtime/helpers/interopRequireDefault"), r = t(require("../@babel/runtime/regenerator")), a = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/asyncToGenerator"), o = (t(require("../xapp/runtime")), 
require("../api/index")), i = require("../const/storage.key.js"), u = e(require("../utils/events.js")), s = t(require("../utils/picasso.js")), f = require("../utils/getConfig.js"), l = getApp();

module.exports = function() {
    return {
        data: {
            moduleConfig: {}
        },
        methods: {
            mallGetConfig: function(e, t) {
                var i = this;
                return n(r.default.mark(function n() {
                    var c, d, S, p;
                    return r.default.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            return d = (c = e = "string" == typeof e ? {
                                version: e
                            } : e || {}).version, S = c.areaId, p = t || i.storeInfo || l.frxs.getMOrSData("storeInfo"), 
                            r.prev = 3, r.next = 6, (0, s.default)({
                                storeInfo: p
                            });

                          case 6:
                            r.next = 10;
                            break;

                          case 8:
                            r.prev = 8, r.t0 = r.catch(3);

                          case 10:
                            return r.abrupt("return", new Promise(function(e) {
                                try {
                                    var t = p.storeId || l.frxs.getMOrSData("storeId"), r = l.frxs.getMData("moduleConfig");
                                    if (r && r.areaId == S) return i.setData({
                                        moduleConfig: r
                                    }, function() {
                                        return u.default.emit("MOUDULECONFIG", r), e(r);
                                    });
                                    var n = a({}, f.defModuleConfig);
                                    if (!t) return;
                                    var s = function() {
                                        l.frxs.setMAndSData("moduleConfig", a(a({}, i.data.moduleConfig), {}, {
                                            areaId: S || p.areaId
                                        })), l.frxs.setMData("version", d), u.default.emit("MOUDULECONFIG", i.data.moduleConfig), 
                                        e(n);
                                    };
                                    S > 0 || p.areaId > 0 || s(), o.brandHousePromotionApi.fetchGetConfig({
                                        areaId: S || p.areaId,
                                        storeId: "".concat(t),
                                        location: p.detailAddress
                                    }, {
                                        contentType: "application/json",
                                        silence: !0
                                    }).then(function(e) {
                                        (n = Object.assign({}, n, e)).activeCenter = !0, n.beginPreSale = !0, n.showSpecialGray && (n.homeGrayKey = !1, 
                                        n.showMyFavoriteProduct = !1), n.newFuzzy ? n.fuzzy = n.newFuzzy : n.fuzzy = "A" == wx.$.getTestMeta("fuzzy"), 
                                        n.fuzzySalesData = !1, i.setData({
                                            moduleConfig: n
                                        }, s);
                                    }).catch(function() {
                                        "V1" === d && (n.cityVersion = !1), i.setData({
                                            moduleConfig: n
                                        }, s);
                                    });
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    console.error(e);
                                }
                            }));

                          case 11:
                          case "end":
                            return r.stop();
                        }
                    }, n, null, [ [ 3, 8 ] ]);
                }))();
            },
            initFuzzySalesStatus: function() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                this.setData({
                    showFuzzySales: l.frxs.getMOrSData(i.STORAGE_KEY.SHOW_FUZZY_SALES) || !1
                }), e && this.eventOnFuzzySalesStatus();
            },
            eventOnFuzzySalesStatus: function() {
                var e = this;
                u.default.on(u.EVENTS.SHOW_FUZZY_SALES, function(t) {
                    e.setData({
                        showFuzzySales: t
                    });
                });
            },
            eventRemoveFuzzySalesStatus: function() {
                u.default.remove(u.EVENTS.SHOW_FUZZY_SALES);
            }
        }
    };
};