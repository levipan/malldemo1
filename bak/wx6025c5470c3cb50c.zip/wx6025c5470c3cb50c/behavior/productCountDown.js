var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            countDownMap: {},
            saleCountDownMap: {}
        },
        members: {
            tsBuyStartList: [],
            intervalCountDown: 0,
            waitCountDownProducts: [],
            countDownStart: function() {
                var t = this;
                this.countDownStop(), this.intervalCountDown = setInterval(function() {
                    t.refreshCountDownMap();
                }, 1e3);
            },
            countDownStop: function() {
                clearInterval(this.intervalCountDown), this.intervalCountDown = 0;
            },
            refreshCountDownMap: function() {
                var t = this, n = this.now();
                (this.tsBuyStartList || []).map(function(o) {
                    o > n && t.refreshProductCountDownMap(o, n);
                });
            },
            refreshProductCountDownMap: function(t, e) {
                e = e || this.now();
                var r = o.default.getCountDownTimeToObject(e, t);
                this.setData(n({}, "countDownMap.".concat(t), {
                    hours: r.totalHours >= 0 ? r.totalHours : "00",
                    minute: r.minutes >= 0 ? r.minutes : "00",
                    second: r.seconds >= 0 ? r.seconds : "00"
                }));
            },
            addTsBuyStart: function(t) {
                var n = this;
                (t || []).map(function(t) {
                    -1 == n.tsBuyStartList.indexOf(t.tsBuyStart) && (n.tsBuyStartList.push(t.tsBuyStart), 
                    n.refreshProductCountDownMap(t.tsBuyStart));
                });
            }
        }
    };
};

var n = require("../@babel/runtime/helpers/defineProperty"), o = t(require("../utils/common.js"));