var e = require("../@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            canPurchaseProducts: [],
            ifShowCartPopup: !1,
            cartCount: 0
        },
        members: {
            getCanPurchaseProduct: function(e) {
                var r = this, s = t(t({}, e), {}, {
                    success: function(t) {
                        var s = "function" == typeof r.now ? r.now() : i.frxs.getSysDateTime(), a = t.filter(function(e) {
                            return e.tsBuyStart <= s && e.tsBuyEnd > s && e.canSale;
                        }) || [];
                        e.success && e.success(a);
                    }
                });
                this.getCartProducts(s);
            },
            getCartProducts: function(e) {
                e = t(t({}, {
                    loginVerify: !0,
                    silence: !1
                }), e);
                var s = s || i.frxs.getMOrSData("userKey");
                if (i.frxs.isNullOrWhiteSpace(s)) e.success && e.success([]); else {
                    var u = this.getCacheCartProducts(), o = n.getCartList();
                    if (0 != u.length) {
                        var c = this.areaId || i.frxs.getMOrSData("areaId"), f = this.storeId || i.frxs.getMOrSData("storeId"), l = {
                            userId: i.frxs.getMOrSData("userId"),
                            storeId: f,
                            areaId: c,
                            eskuSns: u,
                            apiVersion: this.data.apiVersion,
                            version: "STORE_PRICE"
                        }, d = t({
                            userKey: s
                        }, l);
                        r.tradeCartApi.fetchShopCar(d, {
                            loginVerify: !1 !== e.loginVerify,
                            silence: e.silence,
                            sig: !0,
                            contentType: "application/json"
                        }).then(function(t) {
                            var r = t || [];
                            r.length > 0 && r[0].tmBuyStart && (r = (0, a.formatProductsData)(r, !0)), (r = r.filter(function(e) {
                                return e || {};
                            })).map(function(e) {
                                e.primaryUrl = e.imgUrl, e.cartQuantity = (o.find(function(t) {
                                    return t.eskuSn && t.eskuSn == e.eskuSn;
                                }) || {}).cartQuantity || 1;
                            });
                            var s = (r || []).filter(function(e) {
                                return e.saleAmt <= 0 || e.marketAmt <= 0;
                            }) || [];
                            n.getPriceList({
                                isGray: !0,
                                areaId: c,
                                storeId: f,
                                products: r,
                                failPriceProducts: s,
                                getNum: 0,
                                success: function(t) {
                                    e.success && e.success(t.filter(function(e) {
                                        return e.saleAmt > 0 && e.marketAmt > 0;
                                    }) || []);
                                },
                                fail: function() {
                                    e.fail && e.fail();
                                }
                            });
                        }).catch(function(t) {
                            e.fail && e.fail();
                        });
                    } else e.success && e.success([]);
                }
            },
            getCacheCartProducts: function(e) {
                e = t({
                    isSendEvt: !0
                }, e);
                var r = n.getCartList();
                if (!r || 0 == r.length) return e.isSendEvt && s.default.emit(s.EVENTS.REFRESH_CART, null), 
                [];
                for (var a = [], u = 0; u < r.length; u++) {
                    var o = r[u];
                    a.push(o.eskuSn);
                }
                return 0 == a.length ? (i.frxs.removeStorageSync("cart"), e.isSendEvt && (s.default.emit(s.EVENTS.ADD_CART, null), 
                s.default.emit(s.EVENTS.REFRESH_CART, null)), []) : e.isGetProducts ? r : a || [];
            },
            openCartPopup: function(e, t) {
                var r = this;
                this.getCanPurchaseProduct({
                    loginVerify: !1,
                    silence: !0,
                    success: function(s) {
                        var a = (s || []).length > 0;
                        r.setData({
                            canPurchaseProducts: (s || []).reverse(),
                            ifShowCartPopup: a
                        }), a && (e.indexAdInfo.cart = !0, r.setIndexAdInfo(e.areaId, e.indexAdInfo)), t && t({
                            isPopup: a
                        });
                    },
                    fail: function() {
                        t && t({
                            isPopup: !1
                        });
                    }
                });
            },
            indexClosePopup: function() {
                this.setData({
                    canPurchaseProducts: []
                });
            },
            indexGoShop: function() {
                this.indexClosePopup(), i.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "首页购物车提醒弹窗"
                }), this.toCart();
            },
            refreshCartNum: function() {
                this.setData({
                    cartCount: n.getCartNum()
                });
            },
            addEventRefreshCartNum: function() {
                s.default.on(s.EVENTS.ADD_CART, this.refreshCartNum, this), s.default.on(s.EVENTS.REFRESH_CART, this.execRefreshCart, this);
            },
            execRefreshCart: function() {
                this.refreshCartNum(), this.refreshCartQuantity && this.refreshCartQuantity();
            },
            removeEventRefreshCartNum: function() {
                s.default.remove(s.EVENTS.ADD_CART, this.refreshCartNum, this), s.default.remove(s.EVENTS.REFRESH_CART, this.execRefreshCart, this);
            },
            showIndexCartPopupCallBack: function() {
                i.frxs.XSMonitor.sendEvent("slot_show", {
                    slot: "首页购物车提醒弹窗"
                });
            }
        }
    };
};

var t = require("../@babel/runtime/helpers/objectSpread2"), r = require("../api/index.js"), s = e(require("../utils/events.js")), a = require("../api/formatData/product.js"), i = getApp() || {}, n = require("../utils/cartService.js");