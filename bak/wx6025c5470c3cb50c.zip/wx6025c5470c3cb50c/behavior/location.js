var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {},
        members: {
            getWechatLocation: function() {
                a.userSvr.getWechatLocation({
                    isShowLoading: !0,
                    success: function(e) {
                        t.default.navigateTo({
                            path: "/subPages/users/changdot/changdot",
                            isRedirect: !0,
                            query: {
                                latitude: e.latitude,
                                longitude: e.longitude
                            }
                        });
                    }
                });
            },
            getPathDelta: function(e) {
                var t = getCurrentPages(), a = t.findIndex(function(t) {
                    return ~e.indexOf(t.route);
                });
                if (~a) return t.length - a - 1;
                throw new Error("没有找到路径");
            },
            checkoutStoreRun: function(e) {
                var a = wx.$.sessionStorage.get("toPageConfig") || {
                    path: "/pages/home/index/index",
                    query: {},
                    type: "reLaunch"
                };
                if ("navigateBack" === a.type) try {
                    this.$sessionStorage.get("changeStoreBack") && this.$sessionStorage.set("isNewStore", !0);
                    var r = this.getPathDelta(a.path);
                    t.default.navigateBack({
                        delta: r
                    });
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    t.default.reLaunch({
                        path: "/pages/home/index/index"
                    });
                } else t.default[a.type || "reLaunch"]({
                    query: a.query || {},
                    path: a.path || "/pages/home/index/index"
                });
                wx.$.sessionStorage.remove("toPageConfig"), e && e(a);
            }
        }
    };
};

var t = e(require("../router/index")), a = getApp();