Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {},
        members: {
            onCloseReciveCouponModal: function() {
                this.setData({
                    reciveVisible: !1,
                    activityId: []
                });
            },
            getDaysDistanceNumber: function(i) {
                var o = +e.frxs.strToDate((0, t.formaterDate)(+new Date() + (e.frxs.getMOrSData("timeDiffServerAndClient") || 0), "yyyy-MM-dd 00:00:00"));
                return Math.floor((i - o) / 864e5);
            },
            formatCoupon: function(i, o) {
                var r = this;
                return (i || []).map(function(i) {
                    var a = o;
                    if (a || ("FPD" !== i.activityType && "FPD_AUTO" !== i.activityType || (a = "GLOBAL"), 
                    "MPD" !== i.activityType && "MPD_AUTO" !== i.activityType && "YPH" !== i.activityType || (a = "MULTIPLE")), 
                    i.rootType = a, i.orderAmountLimit = 1 * Number(i.orderAmountLimit / 100).toFixed(2), 
                    i.amount = 1 * Number(i.amount / 100).toFixed(2), i.maxDiscount = 1 * Number(i.maxDiscount / 10).toFixed(2), 
                    i && i.ticketStatusList && i.ticketStatusList.length > 0 && (i.tmActive = i.ticketStatusList[0].tmActive, 
                    i.tmFinish = i.ticketStatusList[0].tmFinish), i.tmActive) {
                        var n = +new Date() + (e.frxs.getMOrSData("timeDiffServerAndClient") || 0);
                        try {
                            var c = wx.$._get(i, "now", !1) || fasle;
                            c && (n = +e.frxs.strToDate(c));
                        } catch (t) {}
                        if (i.noStart = (0, t.strToTs)(i.tmActive) > n, i.noStart) {
                            var s = r.getDaysDistanceNumber(+e.frxs.strToDate((0, t.formaterDate)(i.tmActive, "yyyy-MM-dd 00:00:00"))), u = [ !1, "明日", "后日" ][s];
                            console.log(u, "qugao"), console.log(s, "qugao"), 0 == s ? ("MULTIPLE" === i.rootType ? i.timeText = "生效日期".concat((0, 
                            t.formaterDate)(i.tmActive, "yyyy.MM.dd")) : i.timeText = "".concat((0, t.formaterDate)(i.tmActive, "yyyy年MM月dd日"), "生效"), 
                            i.btnText = "".concat((0, t.formaterDate)(i.tmActive, "HH"), "点生效")) : 1 == s || 2 == s ? ("MULTIPLE" === i.rootType ? i.timeText = "生效日期".concat((0, 
                            t.formaterDate)(i.tmActive, "yyyy.MM.dd")) : i.timeText = "".concat((0, t.formaterDate)(i.tmActive, "yyyy年MM月dd日"), "(").concat(u, ")生效"), 
                            i.btnText = "".concat(u, "生效")) : ("MULTIPLE" === i.rootType ? i.timeText = "生效日期".concat((0, 
                            t.formaterDate)(i.tmActive, "yyyy.MM.dd")) : i.timeText = "".concat((0, t.formaterDate)(i.tmActive, "yyyy年MM月dd日"), "生效"), 
                            i.btnText = "".concat((0, t.formaterDate)(i.tmActive, "MM月dd日"), "生效"));
                        }
                    }
                    return i.orderStep && (i.orderStep = i.orderStep.map(function(t) {
                        return t.singleToolAmount = 1 * Number(t.singleToolAmount / 100).toFixed(2), t.useOrderAmountLimit = 1 * Number(t.useOrderAmountLimit / 100).toFixed(2), 
                        t;
                    })), i;
                });
            },
            handleCartRecive: function(t) {
                if (!e.frxs.isLogin()) return e.frxs.toLogin();
                e.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "商品卡片_领券"
                }, "");
                var i = t.currentTarget.dataset.product || t.detail.product, o = [];
                i && i.skuSnCouponList && i.skuSnCouponList.length > 0 && (o = i.skuSnCouponList.map(function(t) {
                    return t.activityId;
                })), i && i.oldSkuSnCouponList && i.oldSkuSnCouponList.length > 0 && (o = i.oldSkuSnCouponList.map(function(t) {
                    return t.activityId;
                })), this.setData({
                    reciveVisible: !0,
                    activityId: o
                });
            }
        }
    };
};

var t = require("../utils/datetime"), e = getApp();