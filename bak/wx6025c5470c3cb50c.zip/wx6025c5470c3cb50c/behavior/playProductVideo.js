var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            playerVideoMap: {},
            playTimeUpdate: {},
            videoFullScreen: !1,
            videoThumbsupMap: {},
            videoDataMap: {}
        },
        members: {
            isPlayVideo: !1,
            videoNewPageFullscreen: !1,
            scrollTopResetPoint: 0,
            productsIfVideoPlay: !1,
            handlePlayer: function(e) {
                var o = this;
                this.isPlayVideo = !0;
                var a = e.detail.product, d = e.detail.key || a.key;
                if (this.__liveProduct = this.originProductsMap[d], !this.isToLive(this.__liveProduct, e)) {
                    var n = this.getVideoProductKey(a.key, e.detail.product.prefix || e.detail.windId);
                    if (!a.videoUrl && !a.video) return;
                    this.stopPlayerVideo(function() {
                        o.setData(i({}, "playerVideoMap.".concat(n), 2));
                    }, 1, n), this.addVideoViewCount(a), this.productsIfVideoPlay = !0;
                }
                var r = this.originProductsMap[d], u = {};
                if ("直播商品卡片" === r.slot && this.livePalyerTimes.length > 0) {
                    var l = this.livePalyerTimes.find(function(e) {
                        return e.spuSn === r.spuSn;
                    });
                    l && (u.live_id = l.liveId);
                }
                s.frxs.XSMonitor.sendEvent("home_video_play", t(t({}, u), {}, {
                    sku_sn: r.skuSn,
                    window_id: r.window_id,
                    gsort: r.gsort,
                    rsort: r.rsort,
                    window_sort: r.window_sort
                }), "");
            },
            handleLivePlayer: function(e) {
                "living" != (this.data.liveDetails || {}).liveStatus ? this.handlePlayer(e) : this.toLive();
            },
            handlePlayEnded: function(e) {
                this.isPlayVideo = !1;
                var t = e.detail.product, o = this.getVideoProductKey(t.key, e.detail.product.prefix || e.detail.windId);
                this.setData(i({}, "playerVideoMap.".concat(o), 1)), this.productsIfVideoPlay = !1;
            },
            setPlayerVideoMap: function(e, t) {
                var i = this, o = this.data.playerVideoMap || {}, a = this.data.playTimeUpdate || {};
                e.map(function(e) {
                    var d = i.getVideoProductKey(e.key, t);
                    o[d] = 1, a[d] = 0;
                }), this.setData({
                    playerVideoMap: o,
                    playTimeUpdate: a
                });
            },
            stopPlayerVideo: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3, i = arguments.length > 2 ? arguments[2] : void 0;
                if (this.videoNewPageFullscreen || this.data.videoFullScreen) e && e(); else {
                    var o = {}, a = this.data.playerVideoMap || {};
                    Object.keys(a).map(function(e) {
                        (2 == a[e] || 3 == a[e] && e != i) && (o["playerVideoMap.".concat(e)] = t);
                    }), Object.keys(o).length > 0 ? this.setState(o, function() {
                        e && e();
                    }) : "function" == typeof e && e();
                }
            },
            handlePlayPause: function(e) {
                this.isPlayVideo = !0;
                var t = e.detail.product, o = this.getVideoProductKey(t.key, e.detail.product.prefix || e.detail.windId);
                this.setData(i({}, "playerVideoMap.".concat(o), 3)), this.productsIfVideoPlay = !1;
            },
            stopProductVideo: function(e, t) {
                var o = this;
                if (1 != this.data.videoFullScreen && this.productsIfVideoPlay) {
                    var a = this.data.playerVideoMap || {}, d = Object.keys(a).find(function(e) {
                        if (2 == a[e]) return e;
                    });
                    if (d) {
                        var s = (t || wx).createSelectorQuery();
                        s.select(".product_key_".concat(d)).boundingClientRect(), s.exec(function(t) {
                            if (!t || 0 == t.length || !t[0] || t[0].left > 150) e && e(); else {
                                var a = t[0].top + t[0].height + 300, s = t[0].top - 300;
                                a < 0 || s > ((wx.getSystemInfoSync() || {}).windowHeight || 3e3) ? o.setData(i({}, "playerVideoMap.".concat(d), 3), function() {
                                    e && e(), o.productsIfVideoPlay = !1;
                                }) : e && e();
                            }
                        });
                    } else e && e();
                } else e && e();
            },
            handlePlayFullScreenChange: function(e) {
                this.setData({
                    videoFullScreen: e.detail.fullScreen
                }), e.detail.fullScreen ? "function" == typeof this.taskerPause && (this.scrollTopResetPoint = this.scrollTop) : "function" == typeof this.taskerContinue && wx.pageScrollTo({
                    scrollTop: this.scrollTopResetPoint,
                    duration: 0
                });
                var t = e.detail, i = t.product, o = t.fullScreen, a = e.detail.key || i.key, d = this.originProductsMap[a];
                s.frxs.XSMonitor.sendEvent("video_fullscreen_change", {
                    sku_sn: d.skuSn,
                    window_id: d.window_id,
                    gsort: d.gsort,
                    rsort: d.rsort,
                    window_sort: d.window_sort,
                    fullScreen: o
                }, "");
            },
            videoBackToCur: function(e) {
                var t = this;
                this.videoNewPageFullscreen = !1, o.default.navigateBack(), setTimeout(function() {
                    t.setPlayTimeUpdate(e);
                }, 1e3);
            },
            setPlayTimeUpdate: function(e) {
                var t = this;
                if (1 == e.playStatus) return this.stopPlayerVideo(), void (this.isPlayVideo = !1);
                this.setData(i({}, "playerVideoMap.".concat(e.key), e.playStatus), function() {
                    t.setData(i({}, "playTimeUpdate.".concat(e.key), e.timeUpdate));
                }), this.isPlayVideo = !0;
            },
            getVideoProductKey: function(e, t) {
                return e + (t ? "_" + t : "");
            },
            addVideoViewCount: function(e) {
                var t = this.originProductsMap[e.key], i = t.prId, o = t.acId;
                i > 0 && o > 0 && a.homePromotionApi.fetchVideoViewCount({
                    productId: i,
                    acId: o
                }).then(function(e) {}).catch(function(e) {});
            },
            handlePlayLove: function(e) {
                var t = this, o = this.originProductsMap[e.detail], s = o.prId, n = o.acId;
                this.data.videoThumbsupMap[o.key] || a.homePromotionApi.fetchVideoThumbsup({
                    productId: s,
                    acId: n,
                    userId: d.default.getMOrSData("userId")
                }, {
                    silence: !1
                }).then(function(e) {
                    d.default.showToast({
                        title: "点赞成功"
                    });
                    var a = ((t.data.videoDataMap[o.key] || {}).likeNum || 0) + 1;
                    t.setData(i({}, "videoDataMap.".concat(o.key, ".likeNum"), a)), t.addMyVideoThumbsupInfo(o);
                }).catch(function(e) {
                    d.default.showToast({
                        title: "点赞失败"
                    });
                });
            },
            cacheVideoThumbsup: function(e) {
                this.addMyVideoThumbsupInfo(e);
            },
            getMyVideoAllThumbsupInfo: function() {
                return d.default.getStorageSync("myVideoThumbsupInfo") || {};
            },
            setMyVideoAllThumbsupInfo: function(e) {
                d.default.setStorageSync("myVideoThumbsupInfo", e);
            },
            addMyVideoThumbsupInfo: function(e) {
                var t = this.getMyVideoAllThumbsupInfo(), o = {
                    saveTime: +new Date(),
                    userId: d.default.getMOrSData("userId"),
                    prId: e.prId,
                    prType: e.prType
                };
                t["".concat(e.key)] = o, this.setMyVideoAllThumbsupInfo(t), this.setData(i({}, "videoThumbsupMap.".concat(e.key), o));
            },
            removeMyVideoThumbsupInfo: function() {
                var e = this.getMyVideoAllThumbsupInfo(), t = {};
                if (Object.keys(e).length > 0) {
                    var i = +new Date();
                    Object.keys(e).forEach(function(o) {
                        var a = e[o], d = i - a.saveTime;
                        "CHOICE" == a.prType ? d < 108e5 && (t[o] = e[o]) : d < 108e6 && (t[o] = e[o]);
                    });
                }
                Object.keys(t).length > 0 ? this.setMyVideoAllThumbsupInfo(t) : d.default.removeStorageSync("myVideoThumbsupInfo");
            },
            getMyVideoThumbsupInfo: function(e) {
                var t = this.getMyVideoAllThumbsupInfo();
                return t && Object.keys(t).length > 0 && t["".concat(e)] || null;
            },
            loadVideoThumbsup: function() {
                this.setData({
                    videoThumbsupMap: this.getMyVideoAllThumbsupInfo()
                });
            }
        }
    };
};

var t = require("../@babel/runtime/helpers/objectSpread2"), i = require("../@babel/runtime/helpers/defineProperty"), o = (e(require("../utils/userdata.js")), 
e(require("../router/index"))), a = require("../api/index.js"), d = e(require("../utils/common.js")), s = getApp();