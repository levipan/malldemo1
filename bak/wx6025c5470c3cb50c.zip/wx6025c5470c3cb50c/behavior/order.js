var e = require("../@babel/runtime/helpers/interopRequireWildcard"), t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        verificationCode: !1,
        isFirstPay: 1,
        mumbers: {
            safe: "",
            showPopDiv: function() {
                var e = this;
                try {
                    l.frxs.XSMonitor.sendEvent("slot_click", {
                        slot: "提交"
                    }, ""), l.frxs.XSMonitor.sendTestEvent("slot_click", {
                        slot: "提交订单",
                        amount: this.data.productCashAmt || this.__productCashAmt || ""
                    });
                } catch (e) {}
                if (this.checkTempStore()) f.default.showSampleDialog(); else if (l.frxs.isNullOrWhiteSpace(this.submitVerifyLogin())) try {
                    l.frxs.XSMonitor.sendEvent("monitorError_warn", {
                        content: {
                            userKey: l.frxs.isLogin()
                        }
                    });
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.log(e);
                } else {
                    var t = l.frxs.getStorageSync("db-user"), r = t.nickName, a = t.mobileNo, s = wx.$._get(this, "_user.nickName", !1) || l.frxs.trim(wx.$._get(this, "data.wechat.nickName", !1) || r || wx.$._get(this, "data.user.nickName", !1)), n = wx.$._get(this, "_user.mobileNo", !1) || l.frxs.trim(wx.$._get(this, "data.user.mobileNo", !1) || a);
                    if (l.frxs.isNullOrWhiteSpace(n) || l.frxs.isNullOrWhiteSpace(s)) return this.getUser({
                        silence: !1,
                        success: function(t) {
                            e.showPopDiv();
                        }
                    }), !1;
                    if (0 == this.data.products.length) return l.frxs.toptip("商品列表为空..."), !1;
                    if (!s || 0 == l.frxs.trim(s).length) return l.frxs.showToast({
                        title: "收货人不能为空"
                    }), !1;
                    if (l.frxs.isNullOrWhiteSpace(n)) return l.frxs.showToast({
                        title: "收货人手机不能为空"
                    }), !1;
                    if (!/^1\d{10}$/.test(n)) return l.frxs.showToast({
                        title: "收货人手机号码无效"
                    }), !1;
                    var o = this.data.products[0], i = parseInt(o.cartQuantity);
                    if ("" == o.cartQuantity) return l.frxs.showToast({
                        title: "请输入购物车数量!"
                    });
                    var u = 0, c = null;
                    if (i > o.saleRemain && o.saleRemain >= 0 && o.salePct >= 0) {
                        var d = o.saleRemain;
                        u = d, c = {
                            title: l.frxs.format(l.frxs.constDefinition.messageInfo.productInsufficientStock, o.prName, d)
                        };
                    }
                    o.ulimitQty && o.ulimitQty > 0 && o.ulimitQty < i && (0 == u || u > o.ulimitQty) && (u = o.ulimitQty, 
                    c = {
                        title: l.frxs.format(l.frxs.constDefinition.messageInfo.productUserLimitNumber, "该", o.ulimitQty)
                    });
                    var p = l.frxs.getMOrSData("moduleConfig") || {}, h = p.showSpecialGray ? 9999 : l.frxs.constDefinition.shoppingCartNumber;
                    if (h > 0 && i > h && (u = h, c = {
                        title: p.showSpecialGray ? "最多只能买9999份哦！" : l.frxs.constDefinition.messageInfo.productShoppingCartNumberOverflow
                    }), null != c) return l.frxs.toptip(c);
                    try {
                        this._user.nickName = s, this._user.mobileNo = n;
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        console.error(e);
                    }
                    this.setData({
                        "wechat.nickName": s,
                        "user.mobileNo": n
                    }, function() {
                        e.onSureOrder({
                            detail: {}
                        });
                    });
                }
            },
            hidePopDiv: function(e) {
                this.setData({
                    showpop: !1
                }), e && l.frxs.XSMonitor.sendEvent("slot_click", {
                    areaId: l.frxs.getMOrSData("areaId"),
                    storeId: l.frxs.getMOrSData("storeId"),
                    source: {
                        confirmOrder: "订单确认页",
                        uyingDirect: "立即购买页"
                    }[this.pageName]
                }, "取消付款按钮点击");
            },
            getProduct: (e = n(a.default.mark(function e() {
                var t, r, o, i, u, c, p, f, h, g, S, y, k, x, C, v, I, b, N, O, w, D = this;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (wx.showLoading(), t = this, r = JSON.parse(JSON.stringify(l.frxs.getMOrSData("sureCart"))), 
                        o = JSON.parse(JSON.stringify(l.frxs.getMOrSData("cart") || [])), r = r.map(function(e) {
                            var t = o.find(function(t) {
                                return t.skuSn === e.skuSn && t.spuSn === e.spuSn;
                            }) || null;
                            return t && (e.cartQuantity = t.cartQuantity), e;
                        }), !this.$sessionStorage.get("isNewStore")) {
                            e.next = 21;
                            break;
                        }
                        return i = [], r.forEach(function(e) {
                            i.push(e.eskuSn);
                        }), e.prev = 8, e.next = 11, d.tradeCartApi.orderCartSkuList({
                            eskuSns: i,
                            areaId: l.frxs.getMOrSData("areaId"),
                            storeId: l.frxs.getMOrSData("storeId")
                        }, {
                            contentType: "application/json",
                            loading: "加载中"
                        });

                      case 11:
                        u = e.sent, c = !1, r = r.map(function(e) {
                            var t = u.find(function(t) {
                                return t.eskuSn === e.eskuSn;
                            });
                            return e.primaryUrl = e.imgUrl, e.primaryUrls = e.primaryUrls || [], e.primaryUrls.push(e.imgUrl), 
                            e.changeCodeType = 1, t || (e.changeCodeType = 3, c = !0), t && t.saleAmt !== e.saleAmt && (e.changeCodeType = 2, 
                            c = !0), t && !1 === t.canSale && (e.changeCodeType = 3, c = !0), t && (t.cartQuantity = e.cartQuantity), 
                            s(s({}, e), t || {});
                        }), c && l.frxs.showToast({
                            title: "当前商品有变动~"
                        });
                        try {
                            p = (p = JSON.parse(JSON.stringify(r || []))).map(function(e) {
                                return delete e.changeCodeType, e;
                            }), l.frxs.setMAndSData("sureCart", p);
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            console.error(e);
                        }
                        e.next = 21;
                        break;

                      case 18:
                        e.prev = 18, e.t0 = e.catch(8), console.error(e.t0);

                      case 21:
                        if (f = [], r && r.length > 0) {
                            for (h = 0, g = 0, S = [], y = 0; y < r.length; y++) k = r[y].cartQuantity || 1, 
                            x = r[y].saleAmt, C = r[y].attr || (r[y].attrs && r[y].attrs.length > 0 ? r[y].attrs[0].attr : ""), 
                            v = r[y].productType || r[y].prType, I = r[y].proId || r[y].prId, r[y].productType = v, 
                            r[y].proId = I, r[y].cartQuantity = k, r[y].attr = C, r[y].index = y, r[y].changeCodeType && 3 === r[y].changeCodeType || (h += k * x, 
                            g += k), b = r[y].tmPickUp, r[y].tmPickUp = l.frxs.formaterDate(b, "MM月dd日 HH:mm"), 
                            S.push(b), f.push(r[y]), r[y].verificationCode && (this.verificationCode = !0);
                            for (S.sort(function(e, t) {
                                return e > t ? 1 : -1;
                            }), N = [], O = 0; O < S.length; O++) w = l.frxs.formaterDate(S[O], "MM月dd日 HH:mm"), 
                            -1 === N.indexOf(w) && N.push(w);
                            t.setData({
                                tihuotime: N,
                                products: f,
                                cart: {
                                    num: g,
                                    amount: h.toFixed(2)
                                }
                            }, n(a.default.mark(function e() {
                                var t, r, n;
                                return a.default.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        return e.prev = 0, e.next = 3, m.collectCoupons.call(D);

                                      case 3:
                                        e.next = 8;
                                        break;

                                      case 5:
                                        e.prev = 5, e.t0 = e.catch(0), console.error(e.t0);

                                      case 8:
                                        return e.prev = 8, t = [], f.forEach(function(e) {
                                            var r = {};
                                            r.skuSn = e.skuSn, r.vendor = e.vendorId, r.discount = e.discount || 100;
                                            var a = e.firstLevelCategoryId || null;
                                            if (a) {
                                                var n = e.secondLevelCategoryId || null;
                                                r.category = s({
                                                    cateId: a
                                                }, n ? {
                                                    children: {
                                                        cateId: n
                                                    }
                                                } : {}), t.push(r);
                                            }
                                        }), e.next = 13, D.getCouponList({
                                            skuInfoList: t
                                        });

                                      case 13:
                                        r = e.sent, n = D._get(r, "couponList", []) || [], D.couponList = n, D.initCoupon({
                                            couponList: JSON.parse(JSON.stringify(D.couponList)),
                                            productList: JSON.parse(JSON.stringify(f)),
                                            beforeSetData: function(e, t) {
                                                var r = [], a = {}, o = !1;
                                                if (e.products.forEach(function(e) {
                                                    "PRICE" === D._get(e, "coupon.toolType", "") && (o = !0, (a = JSON.parse(JSON.stringify(e))).cartQuantity = 1), 
                                                    r.push(JSON.parse(JSON.stringify(e)));
                                                }), o) {
                                                    D.setData({
                                                        newUserProduct: a
                                                    });
                                                    var i = {
                                                        amount: 0
                                                    };
                                                    r.forEach(function(e) {
                                                        "PRICE" === D._get(e, "coupon.toolType", "") && i.amount < e.coupon.amount && (i = e.coupon);
                                                    }), i.ticketId && (n = n.filter(function(e) {
                                                        return !("SINGLE" === e.rootType && e.supportSkuSet[0] === i.supportSkuSet[0] || "PRICE" === e.toolType && e.ticketId !== i.ticketId);
                                                    }), D.couponList = n), D.initCoupon({
                                                        couponList: JSON.parse(JSON.stringify(D.couponList)),
                                                        productList: JSON.parse(JSON.stringify(r)),
                                                        callback: function() {
                                                            D.initXing && D.initXing();
                                                        }
                                                    });
                                                } else D.setData({
                                                    newUserProduct: {}
                                                }), t(s(s({}, e), {}, {
                                                    products: r
                                                }));
                                            },
                                            callback: function() {
                                                D.initXing && D.initXing();
                                            }
                                        }), e.next = 22;
                                        break;

                                      case 19:
                                        e.prev = 19, e.t1 = e.catch(8), console.error(e.t1);

                                      case 22:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, null, [ [ 0, 5 ], [ 8, 19 ] ]);
                            })));
                        }
                        this.initSafe();

                      case 24:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 8, 18 ] ]);
            })), function() {
                return e.apply(this, arguments);
            }),
            initSafe: function() {
                var e = this;
                return n(a.default.mark(function t() {
                    var r, n, i, u, c, d, p;
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return r = function() {
                                try {
                                    var t = e.$storage.get("safe_bb_uying");
                                    if (t) return e.safe = t, void wx.hideLoading();
                                    var r = l.frxsConfig.safe, a = r.partnerCode, n = r.appName, i = r.env, u = {
                                        partnerCode: a,
                                        appName: n,
                                        fpUrl: r.fpUrl
                                    };
                                    i && (u.env = i), new o.default(s({}, u)).getInfo({
                                        page: e,
                                        openid: "",
                                        unionid: "",
                                        timeout: 2500,
                                        success: function(t) {
                                            t = t || "", e.$storage.set("safe_bb_uying", t, 86400), e.safe = t, wx.hideLoading();
                                        },
                                        fail: function(e) {
                                            l.frxs.XSMonitor.sendEvent("fm_error", {
                                                slot: "设备指纹失败",
                                                fail: e
                                            }, ""), console.error("同盾：fail", e);
                                        },
                                        complete: function() {
                                            wx.hideLoading();
                                        }
                                    });
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    console.error(e), wx.hideLoading();
                                }
                            }, t.abrupt("return", r());

                          case 8:
                            if (n = t.sent, u = (i = n || {}).areaList, c = i.storeList, d = parseInt(l.frxs.getMOrSData("areaId") || 0), 
                            p = parseInt(l.frxs.getMOrSData("storeId") || 0), 0 !== u.length) {
                                t.next = 14;
                                break;
                            }
                            return t.abrupt("return", (void 0)(p, c));

                          case 14:
                            if (1 !== u.length) {
                                t.next = 22;
                                break;
                            }
                            if (-1 !== parseInt(u[0])) {
                                t.next = 17;
                                break;
                            }
                            return t.abrupt("return", wx.hideLoading());

                          case 17:
                            if (1 !== parseInt(u[0])) {
                                t.next = 19;
                                break;
                            }
                            return t.abrupt("return", r());

                          case 19:
                            if (0 !== parseInt(u[0])) {
                                t.next = 21;
                                break;
                            }
                            return t.abrupt("return", (void 0)(p, c));

                          case 21:
                            return t.abrupt("return", (void 0)(d, p, u, c));

                          case 22:
                            u.length > 1 && (void 0)(d, p, u, c), t.next = 29;
                            break;

                          case 25:
                            t.prev = 25, t.t0 = t.catch(4), l.frxs.setMData("tongdun_bb", !1), r();

                          case 29:
                          case "end":
                            return t.stop();
                        }
                    }, t, null, [ [ 4, 25 ] ]);
                }))();
            },
            getStore: function() {
                var e = this;
                return new Promise(function(t) {
                    var r = e.data.storeId;
                    d.commonStoreApi.fetchStoreInfo({
                        storeId: r
                    }, {
                        loading: "加载中"
                    }).then(function(r) {
                        r && (l.frxs.setMAndSData("storeId", r.storeId), l.frxs.setMAndSData("areaId", r.areaId), 
                        l.frxs.setMAndSData("countyId", r.countyId), l.frxs.setMAndSData("storeInfo", r), 
                        r.storeName += r.storeName.lastIndexOf("店") == r.storeName.length - 1 ? "" : "店", 
                        e.setData({
                            store: r
                        })), t();
                    });
                });
            },
            setPageUser: function(e, t) {
                var r = "", a = "";
                t ? (r = e, a = wx.$.deepCopy(t)) : (r = l.frxs.isLogin(), a = wx.$.deepCopy(e));
                var s = wx.$.deepCopy(a) || {};
                l.frxs.XSMonitor.sendEvent("getUserInfoData", {
                    slot: "getUserInfo",
                    user: JSON.stringify(s)
                });
                var n = s.wechatNickName, o = s.nickName, i = l.frxs.getStorageSync("wechat-nickName") || !1;
                return s.nickName = i && 0 !== i.length ? i : n || o, s.mobileNo = l.frxs.getMOrSData("user-mobileNo") || s.mobileNo, 
                s.userId = s.userId || l.frxs.getMOrSData("userId"), s.userKey = r, s;
            },
            getUser: function(e) {
                var t = this, r = this;
                l.userSvr.getUserInfo(s(s({}, e || {}), {
                    success: function(a, n) {
                        var o = t.setPageUser(a, n);
                        t._user = wx.$.deepCopy(o);
                        var i = {};
                        r.data.wechat && r.data.wechat.nickName || (i = {
                            wechat: {
                                nickName: o.nickName
                            }
                        }), r.setData(s(s({}, i), {}, {
                            user: o
                        })), null != o.currentStoreId && o.currentStoreId != r.data.storeId && l.frxs.updateDbCurStoreId({
                            storeId: r.data.storeId,
                            success: function() {}
                        }), e && e.success && e.success(o);
                    }
                }));
            },
            closeVerify: function() {
                this.setData({
                    needVerify: !1
                });
            },
            onSureOrder: function(e) {
                var t = this;
                if (this.verificationCode && void 0 === e.detail.token) return this.hidePopDiv(), 
                void this.setData({
                    needVerify: !0
                });
                var r = e.detail.token;
                r && (this.setData({
                    needVerify: !1
                }), "fallback" !== r && (this.token = r));
                l.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "确认订单"
                }, "");
                1 != this.data.isSureOrder && (this.hidePopDiv(), !0 === this.data.products[0].isNewUserPromotion ? this.authNewUser({
                    success: function() {
                        t.lastSureOrder();
                    }
                }) : this.lastSureOrder());
            },
            onClickCouponErrorCancel: function() {
                this.noCouponPay = !1, this.setData({
                    showErrorCoupon: !1
                }), l.router.navigateTo({
                    path: "/subPages/pages/coupon/list/index"
                });
            },
            onClickCouponErrorMask: function() {
                this.noCouponPay = !1, this.setData({
                    showErrorCoupon: !1
                });
            },
            onClickCouponErrorOk: function() {
                this.onClickCouponErrorMask(), this.noCouponPay = !0, this.lastSureOrder();
            },
            lastSureOrder: function() {
                var e = this;
                return n(a.default.mark(function t() {
                    var s, n, o, i, f, m, g, S, y, k, x, C, v, I, b, N, O, w, D, _, M, P, E, T, A, L, U, R, q, J, j, Q, X, $, B, F, H, V, W, G;
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (s = e.submitVerifyLogin(), !l.frxs.isNullOrWhiteSpace(s)) {
                                t.next = 3;
                                break;
                            }
                            return t.abrupt("return");

                          case 3:
                            if (n = l.frxs.getMOrSData("_p") || {}, o = l.frxs.getMOrSData("user-location") || {}, 
                            (i = {}).tgs = [ (wx.$._get(l.frxs.getMData("_c"), "t", "consumer") || "consumer").toUpperCase(), "pushOrderCenter" == n.ac_type || "asst" == n.t ? "STORE" : "" ].filter(function(e) {
                                return e;
                            }), i.ai = e.data.store.areaId, i.ct = "MINI_PROGRAM", i.un = e._user.mobileNo, 
                            i.wn = e._user.nickName, i.iv = 0, i.ot = "CHOICE", i.p = l.frxs.trim(e._user.mobileNo), 
                            i.umx = o.latitude || "", i.umy = o.longitude || "", e.orderType && (i.tgs = [ "FREE_PURCHASE" ], 
                            "PHONE" == e.orderType && (i.ot = "PHONE")), e._user.nickName ? i.r = e._user.nickName : i.r = l.frxs.trim(e.data.wechat && e.data.wechat.nickName ? e.data.wechat.nickName : e.data.user.nickName), 
                            i.si = e.data.store.storeId, i.wi = e._user.headImgUrl, l.frxs.storage("safe_bb") && (i.bb = l.frxs.storage("safe_bb")), 
                            l.frxs.isNullOrWhiteSpace(i.wi) && (i.wi = "https://front-xps-cdn.xsyx.xyz/2021/06/01/958528978.jpg"), 
                            (e.data.xxCount || e.xxCount) && (i.tgs = [ "POINT_EXCHANGE_SHOPPING" ], i.ej = {
                                ac: l.frxsConfig.oneBuyCode || 1e6
                            }), i.wn = l.frxs.replaceSpecialAndIcon(i.wn, "?"), i.r = l.frxs.replaceSpecialAndIcon(i.r, "?"), 
                            f = {
                                confirmOrder: "订单确认页",
                                uyingDirect: "立即购买页"
                            }, i.r && 0 != l.frxs.trim(i.r).length) {
                                t.next = 29;
                                break;
                            }
                            return l.frxs.showToast({
                                title: "收货人不能为空，且不能包含特殊字符"
                            }), t.abrupt("return", !1);

                          case 29:
                            return i.wn && 0 != l.frxs.trim(i.wn).length || (i.wn = i.r), m = wx.$.sessionStorage.get("_videoNumberArray") || [], 
                            g = {}, t.prev = 32, t.next = 35, d.expressApi.queryBindRelation({}, {
                                contentType: "application/json",
                                silence: !0
                            });

                          case 35:
                            S = t.sent, g = S && S.bindInfo ? S.bindInfo : wx.$.storage.get("pdAndStoreMap") || {}, 
                            t.next = 42;
                            break;

                          case 39:
                            t.prev = 39, t.t0 = t.catch(32), g = wx.$.storage.get("pdAndStoreMap") || {};

                          case 42:
                            for (y = [], k = [], x = e.data.memberCardData || {}, e.data.canBuyMbCard && e.data.memberCardData && e.data.selectMbCard && k.push({
                                sku: x.sku,
                                skuSn: x.skuSn,
                                eskuSn: x.eskuSn,
                                cartQuantity: 1,
                                acId: x.activityId,
                                productType: "VIP_CARD"
                            }), C = e.data.products.concat(k), v = 0; v < C.length; v++) if (3 != C[v].changeCodeType) {
                                (I = {}).pai = C[v].acId || C[v].activityId, I.q = C[v].cartQuantity, I.sku = C[v].sku, 
                                I.pi = C[v].proId, I.pt = C[v].productType, I.ess = C[v].eskuSn || C[v].eSkuSn || "", 
                                C[v].coupon = {
                                    ticketId: (e.canBuyPdMap[(C[v] || {}).skuSn] || {}).singleTiks
                                };
                                try {
                                    I.tks = !e.noCouponPay && C[v].coupon.ticketId ? [ C[v].coupon.ticketId ] : [];
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    I.tks = [];
                                }
                                (b = g[C[v].skuSn] || n.s || n.S) && (I.ei = {
                                    shareStoreId: g[C[v].skuSn] || b
                                }), y.push(I), "VIDEO" !== i.ct && m.indexOf(C[v].skuSn) > -1 && (i.ct = "VIDEO");
                            }
                            i.itemList = y, e.token && (i.tk = e.token);
                            try {
                                e.data.checkedCoupon.isAvailable && !e.noCouponPay && (N = e.data.checkedCoupon.ticketId) && (i.tks = [ N ]);
                            } catch (e) {}
                            0 === (O = l.frxs.getMData("tkInfo") || {}).code && O.id && O.sign && (i.pi = O.id, 
                            i.sign = O.sign), i.so = 0 === O.code ? "YES_PROMOTE" : -1 === O.code ? "NO_PROMOTE" : "NONE";
                            try {
                                e.xingResult.length > 0 && !e.noCouponPay && e.xingResult.forEach(function(t) {
                                    var r = e.xingCouponList[t.index].ticketId;
                                    i.tks || (i.tks = []), r && i.tks.push(r);
                                });
                            } catch (e) {}
                            return i.v = "2", i.tmsm = {}, e.noCouponPay || (w = e.canBuyPdMap, e.data.mockData.forEach(function(e) {
                                if (e.items && e.items.length > 0 && 0 == e.unAvailableCode && e.selected && !e.isMemberCard) {
                                    var t = [];
                                    e.items.forEach(function(e) {
                                        w[e.skuSn] && t.push(e.skuSn);
                                    }), t.length && (i.tmsm[e.ticketId] = t);
                                }
                            }), i.tks = r(e.xingCounpLs), Object.keys(w || {}).forEach(function(t) {
                                var a = w[t];
                                if (a.mutiles) {
                                    var s = [];
                                    e.data.useMbCartAmt > 0 && e.data.canUseCouPLs && e.data.canUseCouPLs.length > 0 && (s = (e.data.canUseCouPLs || []).filter(function(e) {
                                        return e.selected && e.isMemberCard && (0 == e.unAvailableCode || 3 == e.unAvailableCode || 5 == e.unAvailableCode);
                                    }).map(function(e) {
                                        return e.ticketId;
                                    }));
                                    var n = [];
                                    Object.keys(a.mutiles).forEach(function(e) {
                                        s.includes(e) || n.push(e);
                                    }), i.tks = [].concat(r(i.tks), n);
                                }
                            }), i.tks = r(new Set(Array.from(i.tks))), e.data.canBuyMbCard && e.data.selectMbCard && e.data.useMbCartAmt > 0 && (D = (e.data.canUseCouPLs || []).filter(function(e) {
                                return e.selected && e.isMemberCard && (0 == e.unAvailableCode || 3 == e.unAvailableCode || 5 == e.unAvailableCode);
                            }), _ = {}, (D || []).forEach(function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                                _[e.toolActivityId] = (e.items || []).map(function(e) {
                                    return e.skuSn;
                                });
                            }), i.att = JSON.stringify({
                                vipCard: {
                                    cardCode: (e.data.memberCardData || {}).cardTemplateCode,
                                    ticketSkuSnsMap: _
                                }
                            }))), l.frxs.XSMonitor.sendEvent("slot_click", {
                                slot: "create_order",
                                params: {
                                    tks: i.tks,
                                    tmsm: i.tmsm,
                                    canBuyPdMap: encodeURIComponent(JSON.stringify(e.canBuyPdMap))
                                }
                            }), e.paramsData = i, console.error(i, "下单参数"), e.setData({
                                isSureOrder: !0
                            }), M = {
                                order: JSON.stringify(i)
                            }, P = (0, p.showLoading)({
                                title: "正在提交订单"
                            }), t.prev = 61, t.next = 64, d.tradeApi.saveOrder(M, {
                                silence: !0
                            });

                          case 64:
                            E = t.sent, T = e.data.products, c.default.emit(c.EVENTS.HAS_CREATE_ORDER, !0), 
                            A = [];
                            try {
                                for (L = 0; L < T.length; L++) U = T[L], R = U.areaId, q = U.eskuSn, J = U.skuSn, 
                                j = U.spuSn, Q = U.eSkuSn, X = {
                                    areaId: R,
                                    spuSn: j,
                                    eskuSn: q || Q,
                                    eSkuSn: q || Q,
                                    optype: "create",
                                    qty: 0,
                                    cartQuantity: 0,
                                    skuSn: J
                                }, h.addCartWaitProduct(X), A.push(X);
                                (e.data.xxCount || e.xxCount) && (($ = l.frxs.getMData("xxOrderSkuSnMap") || new Map()).set(i.itemList[0].ess, i.itemList), 
                                l.frxs.setMData("xxOrderSkuSnMap", $)), e.memberCartKey = h.memberCartKey, e.cartSyncClountToLocal(A).then(function(e) {
                                    console.log(e);
                                }).catch(function(e) {
                                    console.log(e);
                                });
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.log(e);
                            }
                            try {
                                for (B = [], F = [], H = [], V = 0; V < T.length; V++) if (3 != T[V].changeCodeType) {
                                    B.push(T[V].skuSn), F.push(T[V].cartQuantity), W = [];
                                    try {
                                        W = !e.noCouponPay && T[V].coupon.ticketId ? [ T[V].coupon.ticketId ] : [];
                                    } catch (e) {
                                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                        W = [];
                                    }
                                    W.length > 0 && H.push(W[0]);
                                }
                                G = e.data.totalPrice, i.tks && i.tks.length > 0 && H.push(i.tks[0]), l.frxs.XSMonitor.sendEvent("create_order", {
                                    order_id: E.orderId,
                                    order_total: G,
                                    sku_sn: B.join(","),
                                    number: F.join(","),
                                    mkt_acid: H.join(",")
                                }, "");
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.error(e);
                            }
                            P(), e.sureOrderSuccess(E), t.next = 90;
                            break;

                          case 74:
                            if (t.prev = 74, t.t1 = t.catch(61), console.error(t.t1), P(), e.setData({
                                isSureOrder: !1
                            }), "login_expire" != t.t1.rspCode) {
                                t.next = 81;
                                break;
                            }
                            return t.abrupt("return");

                          case 81:
                            if ("FE0310029022" != t.t1.rspCode) {
                                t.next = 85;
                                break;
                            }
                            l.frxs.alert({
                                content: t.t1.rspDesc,
                                success: function() {
                                    u.default.navigateBack();
                                }
                            }), t.next = 90;
                            break;

                          case 85:
                            if ("FE02231001009" != t.t1.rspCode && "FE02231001008" != t.t1.rspCode) {
                                t.next = 89;
                                break;
                            }
                            return t.abrupt("return", e.setData({
                                showErrorCoupon: !0,
                                isSureOrder: !1,
                                errorCouponText: t.t1.rspDesc || "优惠券使用失败，建议您进入优惠中心，查看优惠券使用状态哦～"
                            }));

                          case 89:
                            wx.showModal({
                                content: t.t1.rspDesc || l.frxs.constDefinition.messageInfo.orderSureFail,
                                showCancel: !1
                            });

                          case 90:
                            l.frxs.XSMonitor.sendEvent("slot_click", {
                                areaId: l.frxs.getMOrSData("areaId"),
                                storeId: l.frxs.getMOrSData("storeId"),
                                source: f[e.pageName]
                            }, "确认订单按钮点击");

                          case 91:
                          case "end":
                            return t.stop();
                        }
                    }, t, null, [ [ 32, 39 ], [ 61, 74 ] ]);
                }))();
            },
            sureOrderSuccess: function(e) {
                var t = this;
                var r = this.data;
                r.user, r.wechat;
                l.frxs.setStorageSync("user-mobileNo", this._user.mobileNo), l.frxs.setStorageSync("wechat-nickName", this._user.nickName);
                l.frxs.removeMAndS("sureCart"), c.default.emit(c.EVENTS.REFRESH_CART);
                var a = {};
                console.log(this.data.user);
                try {
                    l.frxs.XSMonitor.sendEvent("initPay", {
                        slot: "userInitPay",
                        orderId: e.orderId,
                        userId: this._user.userId || l.frxs.getMOrSData("userId"),
                        userInfo: JSON.stringify(this._user)
                    });
                } catch (e) {}
                console.log(this), e && e.orderId ? this.weiXinPay({
                    orderId: e.orderId,
                    userId: this._user.userId || l.frxs.getMOrSData("userId"),
                    success: function(r) {
                        try {
                            for (var a = [], n = [], o = [], i = [], u = t.data.products, d = 0; d < u.length; d++) if (3 != u[d].changeCodeType) {
                                a.push(u[d].skuSn), n.push(u[d].sku), o.push(u[d].cartQuantity);
                                var f = [];
                                try {
                                    f = !t.noCouponPay && u[d].coupon.ticketId ? [ u[d].coupon.ticketId ] : [];
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    f = [];
                                }
                                f.length > 0 && i.push(f[0]);
                            }
                            var h = t.data.totalPrice;
                            t.paramsData.tks && t.paramsData.tks.length > 0 && i.push(t.paramsData.tks[0]), 
                            l.frxs.XSMonitor.sendEvent("pay_success", {
                                order_id: e.orderId,
                                order_total: h,
                                sku_sn: a.join(","),
                                sku: n.join(","),
                                number: o.join(","),
                                mkt_acid: i.join(","),
                                is_first_order: 1 === t.isFirstPay ? 1 : 0,
                                __gray: "zpActive"
                            }, ""), t.orderType && c.default.emit(c.EVENTS.HAS_PAYSUCCESS, !0), l.frxs.XSMonitor.sendTestEvent("pay_success", {
                                slot: "支付成功",
                                amount: t.data.productCashAmt || t.__productCashAmt || ""
                            });
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            console.error(e);
                        }
                        t.setData({
                            btnText: "付款成功，正在跳转..."
                        });
                        var m = l.frxsConfig.tmplIds || {};
                        if (m.pick && "function" == typeof wx.requestSubscribeMessage) {
                            var g = [ m.pick ];
                            m.discountCouponReminder && g.push(m.discountCouponReminder), m.activityStart && g.push(m.activityStart), 
                            wx.requestSubscribeMessage({
                                tmplIds: g,
                                complete: function(a) {
                                    var n = {
                                        orderId: e.orderId,
                                        firstOrder: e.firstOrder,
                                        orderDate: e.orderDate,
                                        totalCashAmt: e.totalCashAmt,
                                        orderTotal: e.orderTotal
                                    };
                                    r.mkParam && (n = s(s({}, n), {}, {
                                        mkParam: encodeURIComponent(JSON.stringify(r.mkParam))
                                    })), r.querySome && (n = s(s({}, n), {}, {
                                        querySome: encodeURIComponent(JSON.stringify(r.querySome))
                                    })), t.toPaySuccess(n), (0, p.tmplIdsAddEvt)(g, a, "取货通知");
                                }
                            });
                        } else {
                            var S = {
                                orderId: e.orderId,
                                firstOrder: e.firstOrder,
                                orderDate: e.orderDate,
                                totalCashAmt: e.totalCashAmt,
                                orderTotal: e.orderTotal
                            };
                            r.mkParam && (S = s(s({}, S), {}, {
                                mkParam: encodeURIComponent(JSON.stringify(r.mkParam))
                            })), r.querySome && (S = s(s({}, S), {}, {
                                querySome: encodeURIComponent(JSON.stringify(r.querySome))
                            })), t.toPaySuccess(S);
                        }
                        t.isFirstPay++;
                    },
                    fail: function(r) {
                        try {
                            "FE07231002002" === r.rspCode && t.onAddOrderProduct2Cart(wx.$._get(t.data, "products", []));
                        } catch (r) {
                            r = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(r);
                            console.error(r);
                        }
                        t.isFirstPay++, console.error(r), t.setData({
                            isSureOrder: !1
                        });
                        try {
                            for (var a = [], s = [], n = [], o = [], i = t.data.products, c = 0; c < i.length; c++) if (3 != i[c].changeCodeType) {
                                a.push(i[c].skuSn), s.push(i[c].sku), n.push(i[c].cartQuantity);
                                var d = [];
                                try {
                                    d = !t.noCouponPay && i[c].coupon.ticketId ? [ i[c].coupon.ticketId ] : [];
                                } catch (r) {
                                    r = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(r);
                                    d = [];
                                }
                                d.length > 0 && o.push(d[0]);
                            }
                            var p = t.data.totalPrice;
                            t.paramsData.tks && t.paramsData.tks.length > 0 && o.push(t.paramsData.tks[0]), 
                            l.frxs.XSMonitor.sendEvent("pay_fail", {
                                error_message: r.rspDesc || "未获取到支付成功信息，请在10分钟内到订单中继续支付，逾时订单将自动关闭！",
                                order_id: e.orderId,
                                order_total: p,
                                sku_sn: a.join(","),
                                sku: s.join(","),
                                number: n.join(","),
                                mkt_acid: o.join(",")
                            }, "");
                        } catch (r) {
                            r = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(r);
                            console.error(r);
                        }
                        "pages/order/pay/pay" !== t.route && u.default.navigateTo({
                            path: "/pages/order/pay/pay",
                            isRedirect: !0,
                            query: {
                                orderId: e.orderId,
                                firstOrder: e.firstOrder
                            }
                        });
                    }
                }) : (a = {
                    path: "/subPages/users/orderList/orderList",
                    isRedirect: !0,
                    query: {
                        orderStatus: "NEED_PAY"
                    }
                }, u.default.navigateTo(a));
                try {
                    if (this.data.checkedCoupon.isAvailable && !this.noCouponPay) {
                        var n = this.data.checkedCoupon.ticketId;
                        n && n;
                    }
                } catch (e) {}
            },
            nickNameBlur: function(e) {
                this.setData({
                    "user.nickName": e.detail.value
                });
                try {
                    this._user.nickName = e.detail.value, this.hasChange = !0;
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            nickNameInput: function(e) {
                this.setData({
                    "wechat.nickName": e.detail.value
                });
                try {
                    this._user.nickName = e.detail.value, this.hasChange = !0;
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            mobileNoBlur: function(e) {
                this.setData({
                    "user.mobileNo": e.detail.value
                });
                try {
                    this._user.mobileNo = e.detail.value, this.hasChange = !0;
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            mobileNoInput: function(e) {
                this.setData({
                    "user.mobileNo": e.detail.value
                });
                try {
                    this._user.mobileNo = e.detail.value, this.hasChange = !0;
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
            },
            phoneCall: function(e) {
                var t = e.currentTarget.dataset.tel;
                e.currentTarget.dataset.type;
                wx.makePhoneCall({
                    phoneNumber: t
                });
            },
            goBack: function() {
                u.default.navigateBack();
            },
            onChangeCouponList: function(e) {
                var t = !this.data.showCouponList, r = e.currentTarget.dataset, a = r.couponList, s = r.currCoupon, n = r.type, o = r.key, i = r.index;
                this.updatedCoupon = {
                    type: n,
                    key: o,
                    index: i
                }, this.setData({
                    showCouponList: t,
                    couponList: a,
                    currCoupon: s
                }), t && l.frxs.XSMonitor.sendEvent("slot_show", {
                    slot: "券列表弹窗"
                }, "");
            },
            submitVerifyLogin: function() {
                var e = this, t = l.frxs.getMOrSData("userKey");
                return t && wx.$._get(this, "_user.userId", !1) || l.userSvr.getUserInfo({
                    success: function(t, r) {
                        var a = e.setPageUser(t, r);
                        e._user = wx.$.deepCopy(a), e.showPopDiv();
                    },
                    fail: function(e) {
                        l.frxs.showModal({
                            title: "验证登录信息失败，请稍候重试...",
                            showCancel: !1
                        });
                    }
                }), t;
            },
            checkTempStore: function() {
                return l.frxs.getMOrSData("storeId") == l.frxsConfig.tempStoreId;
            },
            authNewUser: function(e) {
                d.tradeApi.fetchNewUser({
                    userKey: wx.getStorageSync("userKey") || ""
                }).then(function(t) {
                    var r = (t || {}).newUser, a = (t || {}).needPay;
                    if (!0 !== r || a) return l.frxs.toptip(a ? "您在兴盛优选目前存在待支付的订单，暂时无法参与该活动，您可在待支付订单自动取消后再次参加" : "该商品仅供新客购买，您暂无购买资格");
                    e.success();
                }).catch(function(e) {
                    return l.frxs.toptip((e || {}).rspDesc || "提交订单繁忙，请稍候重试!");
                });
            },
            getOrderShareInfo: function() {
                try {
                    var e = this.data.products[0].imgUrl || this.data.products[0].primaryUrl;
                    e || (e = (this.data.products[0].primaryUrls || [])[0]);
                    var t = 0;
                    return this.data.products.map(function(e) {
                        t += (e.marketAmt - e.saleAmt) * e.cartQuantity;
                    }), {
                        prImg: e,
                        discountAmt: t = t.toFixed(2)
                    };
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    return {};
                }
            }
        }
    };
    var e;
}, require("../@babel/runtime/helpers/Arrayincludes");

var r = require("../@babel/runtime/helpers/toConsumableArray"), a = t(require("../@babel/runtime/regenerator")), s = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/asyncToGenerator"), o = t(require("../utils/fm-1.6.5-es.en.js")), i = (t(require("../xapp/runtime")), 
t(require("../behavior/newUserCoupon.js"))), u = t(require("../router/index")), c = e(require("../utils/events.js")), d = require("../api/index.js"), p = require("../utils/index.js"), f = t(require("..//utils/sample-store-dialog.js")), l = (require("../api/index"), 
getApp()), h = require("../utils/cartService.js"), m = (0, i.default)();