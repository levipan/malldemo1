var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../@babel/runtime/helpers/objectSpread2"), t = e(require("../utils/fm-1.6.5-es.en.js")), n = getApp();

exports.default = function() {
    return {
        members: {
            initSafe: function(e) {
                var o = this;
                try {
                    var i = n.frxsConfig.safe, a = i.partnerCode, s = i.appName, f = i.env, u = {
                        partnerCode: a,
                        appName: s,
                        fpUrl: i.fpUrl
                    };
                    f && (u.env = f);
                    var l = new t.default(r({}, u));
                    if (n.frxs.storage("safe_bb")) return e && e();
                    setTimeout(function() {
                        l.getInfo({
                            page: o,
                            openid: "",
                            unionid: "",
                            timeout: 2500,
                            success: function(e) {
                                e = e || "", n.frxs.storage("safe_bb", e, 86400);
                            },
                            fail: function(e) {
                                n.frxs.XSMonitor.sendEvent("fm_error", {
                                    slot: "设备指纹失败",
                                    fail: e
                                }, ""), console.error("同盾：fail", e);
                            },
                            complete: function() {
                                e && e();
                            }
                        });
                    }, 0);
                } catch (r) {
                    r = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(r);
                    console.log(r), e && e();
                }
            }
        }
    };
};