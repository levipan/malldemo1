Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(r) {
    return {
        data: {},
        members: {
            visibleProducts: [],
            productAnchorMap: {},
            fixProductsAnchor: function(r) {
                var t = this, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                return o.length ? Promise.all(Object.values(o).map(function(o) {
                    var c = o.key;
                    return new Promise(function(o) {
                        var i = t.createSelectorQuery();
                        i.select("#product_key_".concat(c, "_").concat(r)).boundingClientRect(), i.exec(function(r) {
                            var i = e(r, 1)[0] || {}, n = i.top, u = i.height;
                            t.productAnchorMap[c] = {
                                top: n + t.scrollTop,
                                height: u,
                                end: n + t.scrollTop + u,
                                key: c
                            }, o(t.productAnchorMap[c]);
                        });
                    });
                })) : Promise.resolve();
            },
            getVisibleProducts: function(e, t) {
                var o = t + r;
                return Object.values(e).filter(function(e) {
                    var r = e.top, c = e.end;
                    e.key;
                    return t <= r && o >= r || t <= c && o >= c;
                });
            },
            refreshVisibleProducts: function(e, r) {
                this.visibleProducts = this.getVisibleProducts(e, r);
            }
        }
    };
}, require("../@babel/runtime/helpers/Objectvalues");

var e = require("../@babel/runtime/helpers/slicedToArray");