var r = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.__toLink = function(r) {
    try {
        var u = r.linkUrl || "";
        if (0 === u.indexOf("@")) {
            var a = {};
            u.substr(1).split("&").forEach(function(e) {
                var r = e.split("=");
                a[r[0]] = r[1];
            }), e.detail.store.params = a, i.default.navigateTo({
                path: "/subProduct/detail/index",
                query: t({}, a || {})
            });
        } else 0 === u.indexOf("%windId=") && u.substr(8) ? this.goToWindow(u.substr(8)) : 0 === u.indexOf("%secondWindowId") && u.substr(16) ? i.default.navigateTo({
            path: "/subProduct/boutique/boutique",
            query: {
                secondWindowId: u.substring(16, u.length)
            }
        }) : u ? i.default.navigateTo({
            path: "/pages/home/h5Active/index",
            query: {
                url: u
            }
        }) : wx.reLaunch({
            url: "/pages/home/index/index"
        });
    } catch (e) {
        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
        wx.reLaunch({
            url: "/pages/home/index/index"
        });
    }
};

var t = require("../@babel/runtime/helpers/objectSpread2"), i = r(require("../router/index"));