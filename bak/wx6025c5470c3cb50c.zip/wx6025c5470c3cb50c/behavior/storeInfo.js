var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            storeStatus: ""
        },
        members: {
            setStoreStatus: function(e) {
                var t = (e || {}).storeStatus;
                if (t == a.default.NORMAL) return !0;
                if (t == a.default.OUT_BUSINESS) return !0;
                if (t == a.default.FROZEN) return !0;
                if (t == a.default.NOT_ONLINE) return !0;
                var s = "";
                switch (t) {
                  case "FROZEN":
                    s = "https://front-xps-cdn.xsyx.xyz/2020/03/24/500247771.png";
                    break;

                  case "OUT_BUSINESS":
                    s = "https://front-xps-cdn.xsyx.xyz/2020/03/24/495782505.png";
                    break;

                  case "NOT_ONLINE":
                  case "NOT_LOGISTICS":
                    s = "https://front-xps-cdn.xsyx.xyz/2020/03/24/495782505.png";
                }
                var o = r.SHOP_STATUS_TO_TEXT[t] || r.SHOP_STATUS_TO_TEXT.DELETE, u = "";
                return t == a.default.OUT_BUSINESS && (u = "上线时间见群通知"), n.globalData.storeState = "lock", 
                t == a.default.DELETE && n.frxs.removeMAndS("storeId"), this.setData({
                    storeIsLocked: !0,
                    hasFreshHouse: !1,
                    "pageErrorMsg.show": !0,
                    "pageErrorMsg.title": o,
                    "pageErrorMsg.desc": u,
                    "pageErrorMsg.imgPath": s,
                    "pageErrorMsg.displayTime": "",
                    storeStatus: t
                }), this.setPageErrorMsg({
                    title: o
                }), !1;
            },
            goToSwitchStore: function() {
                n.userSvr.getWechatLocation({
                    isShowLoading: !0,
                    hasStoreId: !0,
                    success: function(e) {
                        s.default.navigateTo({
                            path: "/subPages/users/changdot/changdot",
                            query: {
                                mapX: e.longitude,
                                mapY: e.latitude
                            }
                        });
                    }
                }), n.aldstat.sendEvent("点击了找找附近的门店");
            },
            goToHistoryStore: function() {
                s.default.navigateToAndBack({
                    path: "/subPages/users/selfdot/mydot/mydot"
                });
            },
            getCommonStoreInfo: function(e, s) {
                var r = this;
                if (e.storeId > 0) {
                    var u = n.frxs.getMOrSData("storeInfo") || {}, d = [ a.default.NORMAL, a.default.OUT_BUSINESS, a.default.FROZEN ];
                    u.storeId == e.storeId && d.indexOf(u.storeStatus) >= 0 && e.success && e.success(u), 
                    e.realTimeData || u.storeId != e.storeId ? o.commonStoreApi.fetchStoreInfo({
                        storeId: e.storeId
                    }, t({
                        silence: !0
                    }, s || {})).then(function(t) {
                        n.frxs.setMAndSData("areaId", t.areaId), n.frxs.setMAndSData("countyId", t.countyId), 
                        n.frxs.setMAndSData("storeInfo", t), r.setData({
                            areaId: t.areaId
                        }), u.storeId == e.storeId && -1 != d.indexOf(u.storeStatus) || e.success && e.success(t), 
                        e.complete && e.complete(t);
                    }).catch(function() {
                        e.fail && e.fail(), e.complete && e.complete({});
                    }) : e.complete && e.complete(u);
                } else e.fail && e.fail(), e.complete && e.complete({});
            }
        }
    };
};

var t = require("../@babel/runtime/helpers/objectSpread2"), s = e(require("../router/index")), r = require("../const/shop-status-to-text"), a = e(require("../const/shop-status.js")), o = require("../api/index.js"), n = getApp();