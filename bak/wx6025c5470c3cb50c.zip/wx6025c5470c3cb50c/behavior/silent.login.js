var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("../api/index.js"), n = require("../const/storage.key.js"), o = require("../utils/common.js"), r = require("../utils/userdata.js");

module.exports = function() {
    return {
        loginByVender: function(n) {
            var r = this, a = n.query, i = a.token, s = a.storeId;
            n.query = {}, wx.login({
                success: function(a) {
                    var c = a.code, l = a.errMsg;
                    if (o.setMData("wxLoginSuccessCode", c), -1 === l.indexOf("ok")) return r.silentLogin_relaunchApp(n);
                    var u = wx.getSystemInfoSync(), d = {
                        token: i,
                        storeId: s,
                        code: c,
                        item: "WECHAT_MINI_MEMBER",
                        "terminal.devId": "",
                        "terminal.brand": u.brand,
                        "terminal.os": u.system,
                        "terminal.type": u.model,
                        "request.providerName": "TONGDUN",
                        "request.blackBox": o.storage("safe_bb") || ""
                    };
                    t.newAuthApi.internalAuthorizeLogin(e({}, d), {
                        silence: !0
                    }).then(function(t) {
                        var a = t.userKey;
                        try {
                            var i = wx.getStorageSync("guestId");
                            (i || a) && (wx.$CG.$tran.emit("UPDATA_GUESTID", {
                                guestId: i,
                                userKey: a
                            }), wx.$CG.$tran.emit("GUEST_INTO", {
                                guestId: i,
                                userKey: a
                            })), o.XSMonitor.sendEvent("monitorError_warn", e(e({}, {
                                guestId: i,
                                userKey: a
                            }), {}, {
                                sort: "01",
                                slot: "updata_guestid_guest_into"
                            }), "");
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            console.log("UPDATA_GUESTID && GUEST_INTO", e);
                        }
                        if (!a) return r.silentLogin_relaunchApp(n);
                        o.setMAndSData("userKey", a), o.setMAndSData("isLogin", !0), r.silentLogin_getUserInfo({
                            userKey: a,
                            callback: function() {
                                o.setMAndSData("storeId", s), r.silentLogin_relaunchApp(n);
                            }
                        });
                    }).catch(function() {
                        r.silentLogin_relaunchApp(n);
                    });
                },
                fail: function() {}
            });
        },
        appLoginCheck: function(e) {
            var t = this;
            try {
                if ("wantStock" === e.query.source) return o.XSMonitor.sendEvent("monitorError_warn", {
                    type: "门店端进入",
                    slot: "静默登录"
                }, ""), this.loginByVender(e);
                if (1 * e.query.autoLogin == 1) return e.callback(), o.XSMonitor.sendEvent("monitorError_warn", {
                    type: "autoLogin",
                    slot: "静默登录"
                }, ""), this.globalData.isCheckLogin = !0;
                if (this.globalData.isCheckLogin) return e.callback(), void o.XSMonitor.sendEvent("monitorError_warn", {
                    type: "isCheckLogin",
                    slot: "静默登录"
                }, "");
                if (!this.isSilentLogin(e)) return this.globalData.isCheckLogin = !0, e.callback(), 
                void o.XSMonitor.sendEvent("monitorError_warn", {
                    type: "当前页面不需要静默登录",
                    slot: "静默登录"
                }, "");
                if ((o.getStorageSync(n.STORAGE_KEY.LOGINCHECKEXPIRETS) || 0) > +new Date()) return this.globalData.isCheckLogin = !0, 
                e.callback(), void o.XSMonitor.sendEvent("monitorError_warn", {
                    type: "静默登录验证时间未过期",
                    slot: "静默登录"
                }, "");
                wx.showLoading({
                    title: "加载中..."
                }), this.slientLogin_autoLogin({
                    forceCheck: !0,
                    callback: function() {
                        wx.hideLoading(), t.silentLogin_saveExpireTs(), t.silentLogin_relaunchApp(e), e.callback(), 
                        o.XSMonitor.sendEvent("monitorError_warn", {
                            type: "静默登录回调",
                            slot: "静默登录"
                        }, "");
                    }
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                this.silentLogin_relaunchApp(e), e.callback();
            }
        },
        slientLogin_autoLogin: function(a) {
            var i = this;
            if (!a.forceCheck && (o.getStorageSync(n.STORAGE_KEY.LOGINCHECKEXPIRETS) || 0) > +new Date()) return a.callback();
            var s = function() {
                var n = wx.getSystemInfoSync();
                wx.login({
                    success: function(s) {
                        var c = s.code, l = s.errMsg;
                        if (o.setMData("wxLoginSuccessCode", c), -1 !== l.indexOf("ok")) {
                            var u = {
                                code: c,
                                item: "WECHAT_MINI_MEMBER",
                                "terminal.devId": "",
                                "terminal.brand": n.brand,
                                "terminal.os": n.system,
                                "terminal.type": n.model,
                                "request.providerName": "TONGDUN",
                                "request.blackBox": o.storage("safe_bb") || ""
                            }, d = o.getMOrSData("storeId") || 0;
                            d > 0 && (u.storeId = d);
                            var g = o.getMOrSData("guestId");
                            g && "-1" !== g && (u.guestId = g), o.XSMonitor.sendEvent("monitorError_warn", e(e({}, u), {}, {
                                type: "开始请求",
                                slot: "静默登录"
                            }), ""), t.newAuthApi.silenceLogin(u, {
                                silence: !0
                            }).then(function(t) {
                                var n = t.guestId, s = t.silenceLoginResult, c = t.userKey, l = t.userInfoDto;
                                if (o.XSMonitor.sendEvent("monitorError_warn", {
                                    guestId: n,
                                    silenceLoginResult: s,
                                    userKey: c,
                                    userInfoDto: l,
                                    type: "返回请求",
                                    slot: "静默登录"
                                }, ""), g && "-1" !== g || o.setMAndSData("guestId", n || "-1"), n) try {
                                    wx.$CG.$tran.emit("GUEST_ID_UPDATE", {
                                        guestId: n
                                    });
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    console.log(e);
                                }
                                if (n || c) try {
                                    wx.$CG.$tran.emit("UPDATA_GUESTID", {
                                        guestId: n,
                                        userKey: c
                                    }), wx.$CG.$tran.emit("GUEST_INTO", {
                                        guestId: n,
                                        userKey: c
                                    }), o.XSMonitor.sendEvent("monitorError_warn", e(e({}, {
                                        guestId: n,
                                        userKey: c
                                    }), {}, {
                                        sort: "02",
                                        slot: "updata_guestid_guest_into"
                                    }), "");
                                } catch (e) {
                                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                    console.log("UPDATA_GUESTID && GUEST_INTO", e);
                                }
                                if (!s || !c) return a.callback(c);
                                if (o.setMAndSData("userKey", c), o.setMAndSData("isLogin", !0), l) {
                                    if (0 == d) {
                                        var u = l.currentStoreId || 0;
                                        u > 0 && o.setMAndSData("storeId", u);
                                    }
                                    return r.updateUserInfo(l), a.callback(c);
                                }
                                i.silentLogin_getUserInfo({
                                    userKey: c,
                                    callback: function(e) {
                                        if (0 == d) {
                                            var t = e.currentStoreId || 0;
                                            t > 0 && o.setMAndSData("storeId", t);
                                        }
                                        return a.callback(c);
                                    }
                                });
                            }).catch(function() {
                                a.callback();
                            });
                        } else a.callback();
                    },
                    fail: function() {
                        a.callback();
                    }
                });
            }, c = o.getMOrSData("userKey"), l = o.getMOrSData("isLogin");
            c && l ? t.newAuthApi.frontCheckAuthStatus({
                userKey: c
            }, {
                silence: !0
            }).then(function(e) {
                e ? (o.getMOrSData("storeId") || 0) > 0 ? a.callback(c) : i.silentLogin_getUserInfo({
                    userKey: c,
                    callback: function(e) {
                        var t = e.currentStoreId || 0;
                        return t > 0 && o.setMAndSData("storeId", t), a.callback(c);
                    }
                }) : (o.removeMAndS("db-user"), o.removeMAndS("getUserInfo_V1"), s());
            }).catch(function() {
                a.callback(c);
            }) : s();
        },
        silentLogin_getUserInfo: function(e) {
            try {
                r.getUserInfo({
                    getMode: "db",
                    loginVerify: !1,
                    success: function(t) {
                        var n = t.currentStoreId || 0;
                        return n > 0 && o.setMAndSData("storeId", n), e.callback(t);
                    },
                    fail: function() {
                        return e.callback({});
                    }
                });
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                return e.callback({});
            }
        },
        silentLogin_saveExpireTs: function() {
            var e = +o.strToDate(o.formaterDate(new Date(), "yyyy-MM-dd") + " 23:00:00");
            o.setStorageSync(n.STORAGE_KEY.LOGINCHECKEXPIRETS, e);
        },
        silentLogin_relaunchApp: function(t) {
            var n = this, r = t.path, a = t.query;
            this.globalData.isCheckLogin = !0;
            var i = o.parseParam(e(e({}, a), {}, {
                v: Math.random()
            }), null, !1), s = r ? "/" + r : "/pages/home/index/index?v=" + Math.random();
            i.length > 0 && (s = s + "?" + i), wx.reLaunch({
                url: s,
                complete: function() {
                    n.globalData.pageCartLoad = !0;
                }
            });
        },
        isSilentLogin: function(e) {
            var t = e.path, n = e.query;
            return !(("pages/home/index/index" == t || "" == t) && (o.getMOrSData("storeId") > 0 || (n || {}).storeId > 0));
        },
        silentLogin_getLocationShop: function(n) {
            var r = this;
            wx.$CG.getLocation({
                type: "gcj02",
                success: function(a) {
                    if ("getLocation:ok" == a.errMsg) {
                        var i = {
                            mapX: a.longitude,
                            mapY: a.latitude
                        };
                        (n.needGoToTm ? t.storeApi.getNearStoreListV2 : t.storeApi.getNearStoreList)(e(e({}, i), {}, {
                            page: 1,
                            size: 1
                        }), {
                            silence: !0
                        }).then(function(e) {
                            var t = e;
                            if (t.exitStore = !0, n.needGoToTm && !1 === t.exitStore) return wx.$route.reLaunch({
                                name: "home-subTMMain-index",
                                query: {
                                    jumpType: "storeIsNone"
                                }
                            }), void wx.hideLoading();
                            ((t = n.needGoToTm ? t.storeFrontNearInfoDtoList : t) || []).length > 0 && t[0].storeId > 0 ? (o.setMAndSData("storeId", t[0].storeId), 
                            o.setMAndSData("areaId", t[0].areaId), r.silentLogin_newUserAutoSelectStore({
                                lng: a.longitude,
                                lat: a.latitude,
                                code: "success"
                            }), n.callback(t[0])) : (r.silentLogin_newUserAutoSelectStore({
                                lng: a.longitude,
                                lat: a.latitude,
                                code: "fail"
                            }), n.callback());
                        }).catch(function(e) {
                            r.silentLogin_newUserAutoSelectStore({
                                lng: e.longitude,
                                lat: e.latitude,
                                code: "fail"
                            }), n.callback();
                        });
                    } else r.silentLogin_newUserAutoSelectStore({
                        code: "fail"
                    }), n.callback();
                },
                fail: function() {
                    r.silentLogin_newUserAutoSelectStore({
                        code: "fail"
                    }), n.callback();
                }
            });
        },
        silentLogin_newUserAutoSelectStore: function(t) {
            try {
                o.XSMonitor.sendEvent("slot_click", e(e({}, t), {}, {
                    slot: "允许位置授权"
                }), "");
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.log(e);
            }
        }
    };
};