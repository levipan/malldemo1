Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var o = wx.getSystemInfoSync().windowHeight, t = {
    data: {
        showToTop: !1
    },
    onClickToTop: function() {
        if (this.setData({
            showToTop: !1
        }), "pages/home/productDetail/productDetail" === this.route || "subProduct/detail/index" === this.route) return this.setData({
            tabScroll1Top: Math.random()
        });
        wx.pageScrollTo({
            scrollTop: 0
        });
    },
    onPageScroll: function(t) {
        t.scrollTop > 3 * o ? !this.data.showToTop && this.setData({
            showToTop: !0
        }) : this.data.showToTop && this.setData({
            showToTop: !1
        });
    },
    tabScroll: function(t) {
        t.detail.scrollTop > 3 * o ? !this.data.showToTop && this.setData({
            showToTop: !0
        }) : this.data.showToTop && this.setData({
            showToTop: !1
        });
    }
};

exports.default = t;