var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {},
        members: {
            upAvatorsDistinct: function(t) {
                var e = [], s = [];
                return (t || []).map(function(t) {
                    var a = t.wxName || t;
                    -1 == e.indexOf(a) && (e.push(a), s.push({
                        wxName: a
                    }));
                }), s;
            },
            getMyAllThumbsupInfo: function() {
                return s.default.getStorageSync("myThumbsupInfo") || {};
            },
            setMyAllThumbsupInfo: function(t) {
                s.default.setStorageSync("myThumbsupInfo", t);
            },
            addMyThumbsupInfo: function(t, e) {
                var a = this.getMyAllThumbsupInfo();
                t.saveTime = +new Date(), t.userId = s.default.getMOrSData("userId"), t.textId = e, 
                a["textId-".concat(e)] = t, this.setMyAllThumbsupInfo(a);
            },
            removeMyThumbsupInfo: function() {
                var t = this.getMyAllThumbsupInfo(), e = {};
                if (Object.keys(t).length > 0) {
                    var a = +new Date();
                    Object.keys(t).forEach(function(s) {
                        a - t[s].saveTime < 36e5 && (e[s] = t[s]);
                    });
                }
                Object.keys(e).length > 0 ? this.setMyAllThumbsupInfo(e) : s.default.removeStorageSync("myThumbsupInfo");
            },
            getMyThumbsupInfo: function(t) {
                var e = this.getMyAllThumbsupInfo();
                return e && Object.keys(e).length > 0 && e["textId-".concat(t)] || null;
            },
            concatThumbsupList: function(t, e) {
                t.upAvators = t.upAvators || [];
                var s = this.getMyThumbsupInfo(e);
                s && (t.isCur = "TRUE", t.upAvators.push(s));
            },
            textsVideoPlay: function(t) {
                var s = this;
                console.log("textsVideoPlay:", t), this.stopVideoPlay(function() {
                    var a = t.detail.data.textsIndex;
                    s.setData(e({}, "zhibo.imgtextList[".concat(a, "].playStatus"), 2));
                });
                try {
                    t.detail.isFirst && a.frxs.XSMonitor.sendEvent("bprd_video_play", {
                        sku: this.data.productInfo.product.sku,
                        sku_sn: this.data.productInfo.product.skuSn,
                        sort: t.detail.data.textsIndex,
                        page_type: "broadcast_prdpage"
                    }, "");
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.log(t);
                }
            },
            textsVideoPause: function(t) {
                try {
                    var e = t.detail, s = e.currentTime, o = e.duration, n = e.preCurrentTime;
                    a.frxs.XSMonitor.sendEvent("bprd_video_stop", {
                        sku: this.data.productInfo.product.sku,
                        sku_sn: this.data.productInfo.product.skuSn,
                        sort: t.detail.data.textsIndex,
                        total_progress: o,
                        watch_time: s - n,
                        curr_progress: s,
                        page_type: "broadcast_prdpage"
                    }, "");
                } catch (t) {
                    t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                    console.log(t);
                }
            },
            textsVideoEnded: function(t) {
                var s = t.detail.data.textsIndex;
                this.setData(e({}, "zhibo.imgtextList[".concat(s, "].playStatus"), 1));
            },
            stopVideoPlay: function(t) {
                var e = {};
                this.data.zhibo.imgtextList.map(function(t, s) {
                    "VIDEO" == t.imgs[0].type && (e["zhibo.imgtextList[".concat(s, "].playStatus")] = 1);
                }), Object.keys(e).length > 0 ? this.setData(e, function() {
                    t && t();
                }) : t && t();
            },
            videoFullscreenChange: function(t) {
                var s;
                0 == t.detail.fullScreen ? (this.setData({
                    zhoboScrollY: !0
                }), this.tab({
                    currentTarget: {
                        id: 0
                    }
                })) : this.setData((e(s = {}, "tabArr.curBdIndex", -1), e(s, "tabArr.curHdIndex", -1), 
                e(s, "zhoboScrollY", !1), s));
            }
        }
    };
};

var e = require("../@babel/runtime/helpers/defineProperty"), s = t(require("../utils/common.js")), a = getApp();