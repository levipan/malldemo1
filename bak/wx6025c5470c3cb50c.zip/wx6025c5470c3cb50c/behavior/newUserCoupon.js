var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../@babel/runtime/helpers/objectSpread2"), t = require("../@babel/runtime/helpers/defineProperty"), n = e(require("../@babel/runtime/regenerator")), a = require("../@babel/runtime/helpers/asyncToGenerator"), o = require("../api/index.js");

e(require("../xapp/runtime.js"));

exports.default = function() {
    return {
        data: {
            unLoginModal: !1,
            unLoginModalBg: "https://front-xps-cdn.xsyx.xyz/2020/12/10/1988405833.png",
            unLoginModalSrc: "https://front-xps-cdn.xsyx.xyz/2020/12/10/1224485557.png"
        },
        receiveNewUserActivityStat: function() {
            return a(n.default.mark(function e() {
                var r, t;
                return n.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.abrupt("return", !1);

                      case 4:
                        return r = e.sent, t = r.todayActivityCompleted, e.abrupt("return", t);

                      case 9:
                        return e.prev = 9, e.t0 = e.catch(1), console.error(e.t0), e.abrupt("return", !1);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 1, 9 ] ]);
            }))();
        },
        unLoginModalLoad: function(e) {
            this.setData(t({}, e.currentTarget.dataset.key, !0));
        },
        collectCoupons: function() {
            var e = arguments;
            return a(n.default.mark(function t() {
                var a, s, u, i;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a = e.length > 0 && void 0 !== e[0] ? e[0] : {}, t.abrupt("return");

                      case 7:
                        if (u = s.frxs.getSysDateTime(), s.frxs.getMOrSData("collectCoupons") !== s.frxs.formaterDate(u, "yyyy-MM-dd")) {
                            t.next = 10;
                            break;
                        }
                        return t.abrupt("return");

                      case 10:
                        return t.next = 12, o.couponApi.receiveNewUserTicket(r(r({}, a), {}, {
                            userKey: void 0
                        }), {
                            silence: !0,
                            contentType: "application/json",
                            loginVerify: !1
                        });

                      case 12:
                        if (i = t.sent, s.frxs.XSMonitor.sendEvent("get_1212newuser_ticket", {
                            code: i ? "success" : "fail"
                        }, ""), i) {
                            t.next = 16;
                            break;
                        }
                        return t.abrupt("return");

                      case 16:
                        s.frxs.setMAndSData("collectCoupons", s.frxs.formaterDate(u, "yyyy-MM-dd")), t.next = 23;
                        break;

                      case 19:
                        t.prev = 19, t.t0 = t.catch(3), console.error(t.t0), s.frxs.XSMonitor.sendEvent("get_1212newuser_ticket", {
                            code: "fail"
                        }, "");

                      case 23:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 19 ] ]);
            }))();
        },
        onCloseUnLoginModal: function(e) {
            var r = getApp();
            this.setData({
                unLoginModal: !1
            }, function() {
                r.frxs.setMData("unLoginModal", !0), r.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "新人券弹窗_去用券"
                }, ""), r.frxs.isLogin() ? "function" == typeof e && e() : r.frxs.toLogin();
            });
        },
        isShowNewUserMask: function() {
            var e = this;
            return a(n.default.mark(function r() {
                var t, a;
                return n.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.abrupt("return", !1);

                      case 5:
                        return t = [ "pages/home/index/index", "pages/home/productDetail/productDetail", "subPages/users/changdot/changdot", "subProduct/detail/index", "subPages/users/shareOrder/shareOrder" ], 
                        a = !0, r.next = 9, e.receiveNewUserActivityStat();

                      case 9:
                        if (a = r.sent, -1 !== t.indexOf(e.route) && !(void 0).frxs.isLogin() && a && !(void 0).frxs.getMData("unLoginModal")) {
                            r.next = 12;
                            break;
                        }
                        return r.abrupt("return", !1);

                      case 12:
                        return e.setData({
                            unLoginModal: !0
                        }, function() {
                            (void 0).frxs.XSMonitor.sendEvent("slot_show", {
                                slot: "新人券弹窗"
                            }, "");
                        }), r.abrupt("return", !0);

                      case 14:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        }
    };
};