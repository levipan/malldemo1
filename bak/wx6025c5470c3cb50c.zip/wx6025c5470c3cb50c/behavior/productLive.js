var t = require("../@babel/runtime/helpers/interopRequireWildcard"), e = require("../@babel/runtime/helpers/interopRequireDefault"), i = require("../@babel/runtime/helpers/objectSpread2"), a = (require("../api/index.js"), 
e(require("../utils/common.js")), e(require("../router/index"))), s = e(require("../const/live-play-status.js")), r = t(require("../const/live-play-statusName.js")), u = require("../utils/datetime.js"), n = getApp(), o = {
    NOT_STARTED: "UPCOMING",
    PLAYING: "LIVING",
    SUSPEND: "LIVING",
    OVER: "FINISH",
    PLAYBACK: "FINISH",
    PRODUCT_EXPLAIN: "EXPLAIN"
}, l = {
    index: "home_product",
    search: "search_product",
    cate_product: "classification_product",
    detail: "details",
    explosive: ""
};

module.exports = function() {
    return {
        data: {
            liveStatusMap: {},
            liveStatusName: r.default,
            newLiveStatusMap: {}
        },
        livePalyerTimes: [],
        toLive: function(t, e, i, s) {
            var r = (t = t || {}).source || t.sourceType, u = t.studioId || t.sourceValue;
            if (2 == r && u > 0) if (n.frxs.compareVersion("2.6.2") > 0) {
                var o = encodeURIComponent(JSON.stringify({
                    path: "pages/home/index/index"
                }));
                wx.navigateTo({
                    url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=".concat(u, "&custom_params=").concat(o)
                });
            } else n.frxs.showModal({
                title: "建议升级",
                content: "由于微信版本过低，暂不支持观看直播，请升级微信后观看",
                confirmText: "升级",
                cancelText: "以后再说",
                success: function(t) {
                    t.confirm && wx.navigateTo({
                        url: "/subPages/home/wxgoup/wxgoup"
                    });
                }
            }); else if (3 == r && u > 0) wx.$route.navigateTo({
                url: "/subLive/liveRoom/index",
                query: {
                    id: u,
                    from: s
                }
            }); else if ((t || {}).liveId > 0 || (t || {}).id > 0) {
                var l = {
                    source: 1,
                    startTime: t.dailyStartTime,
                    endTime: t.dailyEndTime,
                    liveUrl: t.url || t.sourceValue
                };
                a.default.navigateTo({
                    path: "/pages/home/live/index",
                    query: l
                });
            }
            e && n.frxs.XSMonitor.sendEvent("slot_click", {
                slot: e,
                videoId: i,
                live_id: t.id
            });
        },
        toLiveExplain: function(t) {
            a.default.navigateTo({
                path: "/subLive/menuVideo/index",
                query: {
                    utvId: t.explainUtvId,
                    spuSn: t.spuSn,
                    from: "replay",
                    current_page_parm: "split"
                }
            });
            try {
                n.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "商品讲解中",
                    sku: t.sku,
                    sku_sn: t.skuSn,
                    from: "split"
                });
            } catch (t) {}
        },
        getProductLive: function(t) {
            return this.setNewLiveStatus(t), new Promise(function(t) {
                t(null);
            });
        },
        loadProductLiveStatus: function(t) {
            var e = this;
            if ((t = t || []).length > 0) {
                var a = this.now(), s = n.frxs.formaterDate(a, "yyyy-MM-dd"), r = {};
                t.map(function(t) {
                    t = i(i({}, t), e.getLiveStatus(t, a, s));
                    var u = e.spuSnKeyMap[t.spuSn];
                    r["liveStatusMap.".concat(u)] = t.status;
                }), this.livePalyerTimes = this.livePalyerTimes.concat(t), this.setData(r);
            }
        },
        waitLiveStatusTimes: [],
        addWaitUpdateLiveStatusTimes: function(t) {
            -1 == this.waitLiveStatusTimes.indexOf(t) && this.waitLiveStatusTimes.push(t);
        },
        removeWaitUpdateLiveStatusTimes: function(t) {
            t = t || this.now(), this.waitLiveStatusTimes = this.waitLiveStatusTimes.filter(function(e) {
                return e > t;
            });
        },
        getLiveStatus: function(t, e, i) {
            e = e || this.now(), i = i || n.frxs.formaterDate(e, "yyyy-MM-dd");
            var a = {}, r = +n.frxs.strToDate(t.startTime), u = +n.frxs.strToDate(t.endTime);
            if (a.tsStartTime = r, a.tsEndTime = u, t.dailyStartTime.length > 12) {
                var o = +n.frxs.strToDate(t.dailyStartTime), l = +n.frxs.strToDate(t.dailyEndTime);
                a.tsDailyStartTime = o, a.tsDailyEndTime = l, a.status = e > l ? s.default.FINISH : o > e ? s.default.UPCOMING : s.default.LIVING, 
                a.status != s.default.FINISH && this.addWaitUpdateLiveStatusTimes(a.status == s.default.UPCOMING ? a.tsDailyStartTime : a.tsDailyEndTime);
            } else {
                var v = +n.frxs.strToDate(i + " " + t.dailyStartTime);
                v < r && (v += 864e5);
                var d = +n.frxs.strToDate(i + " " + t.dailyEndTime);
                d < v && (d += 864e5), a.tsDailyStartTime = v, a.tsDailyEndTime = d, a.status = e > d || d > u ? s.default.FINISH : v > e ? s.default.UPCOMING : s.default.LIVING, 
                a.status != s.default.FINISH ? this.addWaitUpdateLiveStatusTimes(a.status == s.default.UPCOMING ? a.tsDailyStartTime : a.tsDailyEndTime) : v + 864e5 <= u && d + 864e5 <= u && this.addWaitUpdateLiveStatusTimes(v + 864e5);
                var f = "".concat(n.frxs.formaterDate(v, "MM-dd HH:mm"));
                a.formaterStartDate = f;
            }
            var m = "".concat(n.frxs.formaterDate(a.tsDailyStartTime, "MM-dd HH:mm"));
            return a.formaterStartDate = m, a;
        },
        refreshLivesStatus: function() {
            var t = this, e = this.now();
            if ((this.waitLiveStatusTimes || []).findIndex(function(t) {}) >= 0) {
                var a = n.frxs.formaterDate(e, "yyyy-MM-dd"), s = {}, r = this.data.liveStatusMap;
                this.livePalyerTimes.map(function(u, n) {
                    var o = t.getLiveStatus(u, e, a), l = t.spuSnKeyMap[u.spuSn];
                    o.status != r[l] && (u = i(i({}, u), o), s["liveStatusMap.".concat(l)] = u.status);
                }), Object.keys(s).length > 0 && this.setData(s), this.removeWaitUpdateLiveStatusTimes(e);
            }
        },
        isToLive: function(t, e) {
            var i = (e && e.currentTarget || {}).dataset, a = t || {}, r = a.spuSn, u = a.key, n = a.hasExplainVideo, o = void 0 !== n && n;
            if (u = u || this.spuSnKeyMap[r], this.isToNewLive(t, l[i && i.from || ""])) return !0;
            if (o && -1 === [ s.default.LIVING, s.default.UPCOMING ].indexOf(this.data.liveStatusMap[u])) return this.toLiveExplain(t), 
            !0;
            if ([ s.default.LIVING, s.default.FINISH ].indexOf(this.data.liveStatusMap[u]) >= 0) {
                var v = this.livePalyerTimes.find(function(t) {
                    return t.spuSn == r;
                }) || {};
                if ((v || {}).liveId > 0 || (v || {}).id > 0) return this.toLive(v), this.goLivePoint(t), 
                !0;
            }
            return !1;
        },
        goLivePoint: function(t) {
            try {
                var e = t || this.__liveProduct, a = {
                    hasNewLive: e.hasNewLive
                };
                if ("subMain/main/index?tabCode=home" === this.route && (a = {
                    window_id: e.window_id,
                    gsort: e.gsort,
                    rsort: e.rsort,
                    window_sort: e.window_sort
                }), "直播商品卡片" === e.slot && this.livePalyerTimes.length > 0) {
                    var s = this.livePalyerTimes.find(function(t) {
                        return t.spuSn === e.spuSn;
                    });
                    s && (a.live_id = s.liveId);
                }
                e.hasNewLive && e.tvLiveDto && (a.live_id = e.tvLiveDto.tvId), n.frxs.XSMonitor.sendEvent("prd_go_live", i({
                    slot: e.slot,
                    sku_sn: e.skuSn
                }, a), "");
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("eeeeeee", t);
            }
        },
        getClientProductLive: function(t) {
            return this.livePalyerTimes.find(function(e) {
                return e.spuSn == t.spuSn;
            }) || {};
        },
        productHasLive: function(t, e) {
            return e = e || this.spuSnKeyMap[t], !!this.data.liveStatusMap[e];
        },
        isToNewLive: function(t, e) {
            if (!this.data.newLiveStatusMap[t.key]) return !1;
            var i = t.tvId || t.tvLiveDto.tvId;
            return !(!t.hasNewLive || !i) && ("PRODUCT_EXPLAIN" === t.tvLiveDto.tvStatus ? (t.tvLiveDto.tvUrl && a.default.navigateTo({
                path: "subLive/liveRoom/liveVideo/index",
                query: {
                    liveUrl: t.tvLiveDto.tvUrl
                }
            }), !0) : (wx.$route.navigateTo({
                url: "/subLive/liveRoom/index",
                query: {
                    id: i,
                    from: e
                }
            }), this.goLivePoint(t), !0));
        },
        setNewLiveStatus: function(t) {
            var e = this.data.newLiveStatusMap, a = {};
            (t || []).forEach(function(t) {
                if (t.tvLiveDto) {
                    var e = t.tvLiveDto, i = e.tvStatus, s = e.pullStreamUrl, r = e.preStartTime, n = e.tvUrl;
                    "NOT_STARTED" === i && r && (0, u.now)() > (0, u.strToTs)(r) && (i = "PLAYING"), 
                    o[i] && ("PRODUCT_EXPLAIN" === i && n || s) && (a[t.key] = o[i]);
                }
            }), this.setData({
                newLiveStatusMap: i(i({}, e), a)
            });
        }
    };
};