var o = require("./configs/index.js"), e = {};

switch (o.ENV) {
  case "DEV":
    e = require("./configs/config.dev.js"), console.log("当前处于【开发环境】");
    break;

  case "DEV2":
    e = require("./configs/config.dev2.js"), console.log("当前处于【开发环境2】");
    break;

  case "DAILY":
    e = require("./configs/config.daily.js"), console.log("当前处于【Daily环境】");
    break;

  case "PRO":
    e = require("./configs/config.pro.js"), console.log("当前处于【生产环境】");
    break;

  case "UAT":
    e = require("./configs/config.uat.js"), console.log("当前处于【测试环境】");
    break;

  case "UAT1":
    e = require("./configs/config.uat1.js"), console.log("当前处于【测试环境1】");
    break;

  case "UAT2":
    e = require("./configs/config.uat2.js"), console.log("当前处于【测试环境2】");
    break;

  case "UAT3":
    e = require("./configs/config.uat3.js"), console.log("当前处于【测试环境3】");
    break;

  case "UAT4":
    e = require("./configs/config.uat4.js"), console.log("当前处于【测试环境4】");
    break;

  case "PROGRAY":
    e = require("./configs/config.progray.js"), console.log("当前处于【生产环境】");
    break;

  default:
    e = require("./configs/config.pro.js"), console.log("当前处于【生产环境】");
}

e.ENV = o.ENV, e.isPrintLog = o.isPrintLog, e.version = o.version, function(e, c) {
    try {
        "devtools" === wx.getSystemInfoSync().platform ? console.log("%c".concat(e), "color: white; background-color: ".concat(c, ";padding:4px 6px;font-size:20px")) : console.warn("".concat(e)), 
        !o.isPrintLog && Object.keys(console).forEach(function(o) {
            "function" == typeof console[o] && (console[o] = function() {});
        });
    } catch (o) {}
}("版本号：".concat(o.version), "#95B46A"), module.exports = e;