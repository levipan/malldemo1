Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CMS_XXX_POSTIONS_NAME = exports.CMS_XXX_POSTIONS_FROM = exports.CMS_XXX_POSTIONS_CHANNEL = exports.CMS_POSTIONS_NAME = exports.CMS_POSTIONS_CODE = exports.CMS_POSTIONS = void 0;

exports.CMS_POSTIONS = [ "TOPTEN", "THANKSFEEDBACK", "ONTHEHOUR", "DAILYSELECTION", "XXXBANNER", "XXXSUSPENSION" ];

exports.CMS_POSTIONS_CODE = {
    1: "TOPTEN",
    2: "THANKSFEEDBACK",
    3: "ONTHEHOUR",
    4: "DAILYSELECTION",
    5: "XXXBANNER",
    6: "XXXSUSPENSION"
};

exports.CMS_POSTIONS_NAME = {
    1: "十点爆款",
    2: "感恩回馈",
    3: "整点抢",
    4: "每日精选",
    5: "小兴兴播报",
    6: "小兴兴播报浮标",
    7: "新闻播报"
};

exports.CMS_XXX_POSTIONS_NAME = {
    5: "小兴兴播报",
    7: "新闻播报"
};

exports.CMS_XXX_POSTIONS_CHANNEL = {
    1: 50,
    2: 51
};

exports.CMS_XXX_POSTIONS_FROM = {
    5: "xxx_speaker",
    7: "news_speaker"
};