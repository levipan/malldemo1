Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    NORMAL: "NORMAL",
    FROZEN: "FROZEN",
    DELETE: "DELETE",
    NOT_ONLINE: "NOT_ONLINE",
    NOT_LOGISTICS: "NOT_LOGISTICS",
    OUT_BUSINESS: "OUT_BUSINESS",
    OUT_SPRING_BUSINESS: "OUT_SPRING_BUSINESS"
};