Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.STORAGE_KEY = void 0;

exports.STORAGE_KEY = {
    CLOSE_GUIDE_MYAPPLET: "close_guide_myapplet",
    SYSPARAMS: "sysParams-{0}",
    LAST_GUIDE_MYAPPLET_TIME: "last_guide_myapplet_time",
    LAST_GET_TICKETSNUM: "last_get_tickets_num",
    VIDEO_NAV_CLICK_TIME: "videoNavClickTime",
    INDEXAD: "index-ad-{0}",
    NAV_LIVE_DATA: "nav_live_data",
    LAST_LOAD_NAV: "last_load_nav",
    LOGINCHECKEXPIRETS: "loginCheckExpireTs",
    LAST_PRODUCT_SUB_REMINDER_GUIDE: "last_pr_sub_reminder_guide",
    CENTER_PRODUCT_SUB_REMINDER_GUIDE: "center_pr_sub_reminder_guide",
    ORDERLIST_PRODUCT_SUB_REMINDER_GUIDE: "orderlist_pr_sub_reminder_guide",
    LAST_PRODUCT_SUB_REMINDER_TS: "last_pr_sub_reminder_ts",
    ORDER_PRODUCT_COMMENT_GUIDE: "orderPrCommentGuide",
    SEARCH_PLACE_HOLD: "search_place_hold_{0}",
    SEARCH_HISTORY_KEY: "brandSearchKeys",
    SEARCH_HISTORY_KEY_DESC: "search_history_key_desc",
    XXL_ACTIVITY_TIME: "XXL_ACTIVITY_TIME",
    CANCEL_SUB_GUIDE: "CANCEL_SUB_GUIDE",
    SUB_TMPLID_PRODUCTS: "SUB_TMPLID_PRODUCTS",
    INDEX_SKIN: "INDEX_SKIN",
    SHOW_CATE_GUIDE: "SHOW_CATE_GUIDE",
    SHOW_CART_GUIDE: "SHOW_CART_GUIDE",
    SHOW_FUZZY_SALES: "SHOW_FUZZY_SALES",
    IF_SHOW_FUZZY_SALES: "IF_SHOW_FUZZY_SALES",
    SKIN_CONFIG: "SKIN_CONFIG",
    CMS_NAV_BAR: "CMS_NAV_BAR1_",
    MODULE_CONFIG: "moduleConfig",
    UPDATA_VERSION: "updataVersion",
    ADS_POPUP: "adsPopup",
    ADS_FOOT_BANNER: "adsFootBanner",
    ADS_MOVABLE: "adsMovable"
};