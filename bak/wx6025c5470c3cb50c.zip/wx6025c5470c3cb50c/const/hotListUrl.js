Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.hotListUrl = exports.convertHotListCode = exports.RANK_TYPE_TITLE_ICON_MAPS = exports.RANK_TYPE_TITLE_COLOR_MAPS = exports.RANK_TYPE_BG_MAPS = void 0;

exports.hotListUrl = {
    hot_sales: "subPages/home/brand/hotlist/index",
    day: "subPages/home/brand/hotlist/index",
    hot_sales_7d: "subPages/home/brand/hotlist/index",
    week: "subPages/home/brand/hotlist/index",
    special_offer: "subPages/home/brand/offerList/index",
    offer: "subPages/home/brand/offerList/index",
    new_releases: "subPages/home/brand/newList/index",
    new: "subPages/home/brand/newList/index",
    share: "subPages/home/brand/shareList/index",
    repurchase: "subPages/home/brand/repurchaseList/index"
};

exports.convertHotListCode = {
    hot_sales: "day",
    day: "day",
    hot_sales_7d: "week",
    week: "week",
    special_offer: "",
    new_releases: "",
    share: "",
    repurchase: ""
};

exports.RANK_TYPE_BG_MAPS = {
    hot_sales: "https://front-xps-cdn.xsyx.xyz/2021/09/27/669283702.png?imageMogr2/thumbnail/355x",
    hot_sales_7d: "https://front-xps-cdn.xsyx.xyz/2021/09/27/669283702.png?imageMogr2/thumbnail/355x",
    hot_sales_nearby: "https://front-xps-cdn.xsyx.xyz/2021/09/27/669283702.png?imageMogr2/thumbnail/355x",
    community: "https://front-xps-cdn.xsyx.xyz/2021/09/27/669283702.png?imageMogr2/thumbnail/355x",
    new_releases: "https://front-xps-cdn.xsyx.xyz/2021/09/27/1663926385.png?imageMogr2/thumbnail/355x",
    share: "https://front-xps-cdn.xsyx.xyz/2021/09/27/493551419.png?imageMogr2/thumbnail/355x",
    repurchase: "https://front-xps-cdn.xsyx.xyz/2021/09/27/2018637617.png?imageMogr2/thumbnail/355x",
    special_offer: "https://front-xps-cdn.xsyx.xyz/2021/09/27/687093120.png?imageMogr2/thumbnail/355x",
    StoreMorningMarket: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/rank/zaoshibg.png?imageMogr2/thumbnail/355x",
    StoreEveningMarket: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/rank/wanshibg.png?imageMogr2/thumbnail/355x",
    StoreSceneRecommend: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/rank/StoreSceneRecommendbg.png?imageMogr2/thumbnail/355x"
};

exports.RANK_TYPE_TITLE_COLOR_MAPS = {
    hot_sales: "#FF0000",
    hot_sales_7d: "#FF0000",
    hot_sales_nearby: "#FF0000",
    community: "#FF0000",
    new_releases: "#F80342",
    share: "#7D34F0",
    repurchase: "#365BFF",
    special_offer: "#FF5905",
    StoreMorningMarket: "#BB016B",
    StoreEveningMarket: "#8C2624",
    StoreSceneRecommend: "#E26040"
};

exports.RANK_TYPE_TITLE_ICON_MAPS = {
    hot_sales: "https://front-xps-cdn.xsyx.xyz/2021/09/27/182699273.png",
    hot_sales_7d: "https://front-xps-cdn.xsyx.xyz/2021/09/27/182699273.png",
    hot_sales_nearby: "https://front-xps-cdn.xsyx.xyz/2021/09/27/182699273.png",
    community: "https://front-xps-cdn.xsyx.xyz/2021/09/27/182699273.png",
    new_releases: "https://front-xps-cdn.xsyx.xyz/2021/09/27/1719427036.png",
    share: "https://front-xps-cdn.xsyx.xyz/2021/09/27/1366768945.png",
    repurchase: "https://front-xps-cdn.xsyx.xyz/2021/09/27/948598968.png",
    special_offer: "https://front-xps-cdn.xsyx.xyz/2021/09/27/1525740055.png",
    StoreMorningMarket: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/rank/zaoshi.png",
    StoreEveningMarket: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/rank/wanshi.png",
    StoreSceneRecommend: ""
};