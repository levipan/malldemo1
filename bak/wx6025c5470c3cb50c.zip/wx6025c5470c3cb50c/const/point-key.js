Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _ = {
    HOME_CMS: {
        ACTIVE_ENTRY_SHOW: "home_cms_active_entry_show",
        ACTIVE_ENTRY_CLICK: "home_cms_active_entry_click",
        RECOMMEND_CARD_SHOW: "home_cms_recommend_card_show",
        RECOMMEND_CARD_CLICK: "home_cms_recommend_card_click",
        NEWS_SHOW: "home_cms_news_show",
        NEWS_CLICK: "home_cms_news_click",
        ACTIVE_SPECIAL_SHOW: "home_cms_active_special_show",
        ACTIVE_SPECIAL_CLICK: "home_cms_active_special_click",
        TD_DISCOUNT_SHOW: "home_cms_td_discount_show",
        TD_DISCOUNT_TAB_CLICK: "home_cms_td_discount_tab_click",
        TD_DISCOUNT_ITEM_CLICK: "home_cms_td_discount_item_click",
        BRAND_SPECIAL_TOP_SHOW: "home_cms_brand_special_top_show",
        BRAND_SPECIAL_TOP_CLICK: "home_cms_brand_special_top_click",
        BRAND_SPECIAL_DOWN_SHOW: "home_cms_brand_special_down_show",
        BRAND_SPECIAL_DOWN_ITEM_CLICK: "home_cms_brand_special_down_item_click",
        EXPLOSIVE_SHOW: "home_cms_explosive_show",
        EXPLOSIVE_CLICK: "home_cms_explosive_click",
        EXPLOSIVE_ADD_CART: "home_cms_explosive_add_cart",
        ON_TIME_SHOW: "home_cms_on_time_show",
        ON_TIME_CLICK: "home_cms_on_time_click",
        ON_TIME_TAB_CLICK: "home_cms_on_time_tab_click"
    },
    MAKE_MONEY: {
        SHARE_ACTIVITY: "store_share_home_popup_activity_share",
        SHARE_PRODUCT: "store_share_home_popup_product_share",
        TODAY_PUSH_CLICK: "store_share_home_today_must_push_click",
        HOT_SEARCH_KEYWORD_CLICK: "store_share_search_hot_keywords_click",
        HISTORY_SEARCH_KEYWORD_CLICK: "store_share_search_history_keywords_click",
        INTELLISENSE_PROMPT_SEARCH_CLICK: "store_share_search_intellisense_prompt_click",
        SEARCH_BTN_CLICK: "store_share_search_keywords_click",
        SHARE_HOME: "store_share_home_index_share",
        SHARE_LOVE_ACTIVITY: "store_share_recommend_window_share",
        SHARE_LOVE_PRODUCT: "store_share_recommend_window_product_share",
        SHARE_ACTIVITY_SC: "store_share_home_activity_share",
        SHARE_PRODUCT_RECOMMEND: "store_share_home_product_recommend_share",
        SHARE_SEARCH_PRODUCT_RECOMMEND: "store_share_product_search_share",
        TODAY_PUSH_CLICK_PRODUCT: "store_share_must_push_product_share",
        GO_HOME: "store_share_home_tobuy_click",
        SHARE_ACTIVITY_CARD_SC: "store_share_home_activity_card_share"
    },
    SIGNIN: {
        SUBSCRIBE_WORK_WECHAT_SHOW: "subscribe_work_wechat_show",
        SUBSCRIBE_WORK_WECHAT_CLICK: "subscribe_work_wechat_click",
        SUBSCRIBE_WORK_WECHAT_POPUP_SHOW: "subscribe_work_wechat_popup_show",
        SUBSCRIBE_WORK_WECHAT_POPUP_CLICK: "subscribe_work_wechat_popup_click",
        BANNER_EGGS_CLICK: "signin_banner_eggs_click",
        ACTIVITY_CLICK: "signin_activity_click"
    },
    ONEBUY: {
        DETAIL_ALL_CLICK: "one_buy_porduct_detail_all_click",
        DETAIL_BUY_CLICK: "one_buy_porduct_detail_buy_click",
        SHOW: "one_buy_show",
        SIGN_CLOSE_TIPS: "one_buy_sign_close_tips",
        SIGN_CLICK_TIPS: "one_buy_sign_click_tips",
        CLICK: "one_buy_click",
        PRODUCT_DETAIL_CLICK: "one_buy_product_detail_click",
        LIST_PRODUCT_DETAIL_CLICK: "one_buy_list_product_detail_click",
        LIST_PRODUCT_BUY: "one_buy_list_product_buy",
        LIST_SHARE_CLICK: "one_buy_list_share_click",
        LIST_RULES_CLICK: "one_buy_list_rules_click",
        LIST_PRODUCT_SHOW: "one_buy_list_product_show"
    },
    YHC: {
        COLLECT_CARD_SHOW: "yph_collectorfoot_card_show",
        COLLECT_CARD_SIMILARITY_CLICK: "yph_collectorfoot_card_similarity_click",
        COLLECT_CARD_REMOVE: "yph_collectorfoot_card_remove",
        COLLECT_PRODUCT_CLICK: "yph_collect_product_click",
        MATCH_ORDER_BTN_CLICK: "yhc_match_order_btn_click",
        MATCH_POPUP_SHOW: "yhc_match_popup_show",
        MATCH_CANCEL_CLICK: "yhc_match_cancel_click",
        MATCH_IMG_MAGNIFY_CLICK: "yhc_match_img_magnify_click"
    },
    NINESECKILL: {
        NINESECKILL_SHOW: "seckill_card_show",
        NINESECKILL_ADD_PRODUCT: "seckill_card_add_product",
        NINESECKILL_LOGIN: "seckill_login",
        NINESECKILL_ROTATE: "seckill_product_rotate",
        NINESECKILL_COMMON: "seckill_product_common"
    },
    ONTIME: {
        TAB_CHANGE: "ontime_tab_change",
        SECKILL_PRODUCT_SHOW: "ontime_seckill_product_show",
        SECKILL_PRODUCT_APPINTMENT: "ontime_seckill_product_appintment",
        SECKILL_PRODUCT_CLICK: "ontime_seckill_product_click",
        RUSH_PRODUCT_SHOW: "ontime_rush_product_show",
        RUSH_PRODUCT_CLICK: "ontime_rush_product_click",
        RUSH_PRODUCT_APPINTMENT: "ontime_rush_product_appintment",
        RUSH_PRODUCT_ADD: "ontime_rush_product_add",
        RECOMMEND_WINDOWS_SHOW: "ontime_recommend_windows_show",
        RECOMMEND_WINDOWS_CLICK: "ontime_recommend_windows_click",
        RECOMMEND_PRODUCT_SHOW: "ontime_recommend_product_show",
        RECOMMEND_PRODUCT_CLICK: "ontime_recommend_product_click",
        RECOMMEND_PRODUCT_ADD: "ontime_recommend_product_add",
        RECOMMEND_SCREEN: "ontime_recommend_screen"
    },
    SUPER: {
        LIVE_CLICK: "super_live_click",
        LIVE_SUBSCRIBE: "super_live_subscribe",
        PRODUCT_ADD: "super_product_add",
        INVITE_FRIEND: "super_invite_friend",
        PAST_GOODS_EXPOSURE: "past_goods_exposure",
        PAST_GOODS_CLICK: "past_goods_click",
        PAST_GOODS_ADD: "super_past_product_add",
        PAST_GOODS_LOOK_MORE: "past_goods_look_more",
        SUPER_TAB_CHANGE: "super_tab_change",
        LIVE_MOMENT_EXPOSURE: "live_moment_exposure",
        LIVE_MOMENT_CLICK: "live_moment_click",
        LIVE_MOMENT_LIKE_CLICK: "live_moment_like_click"
    },
    MEMBER: {
        MEMBER_CARD_SHOW: "member_card_show",
        MEMBER_CARD_CLICK: "member_card_click"
    },
    INVITE: {
        INVITE_GIFTS_MAKE_MONEY: "invite_gifts_make_money",
        INVITE_GIFTS_MAKE_MONEY_SHARE: "invite_gifts_make_money_share",
        INVITE_GIFTS_POPUP_SHARE: "invite_gifts_popup_share",
        INVITE_GIFTS_POPUP_SCAN: "invite_gifts_popup_scan",
        INVITE_GIFTS_PAGE_SCAN: "invite_gifts_page_scan",
        INVITE_GIFTS_POPUP_POSTER: "invite_gifts_popup_poster",
        INVITE_GIFTS_DOWNLOAD_POSTER: "invite_gifts_download_poster",
        INVITE_GIFTS_RULE: "invite_gifts_rule",
        INVITE_GIFTS_VIEW_DETAILS: "invite_gifts_view_details",
        INVITE_GIFTS_GO_FULL_MINUS_COUPON: "invite_gifts_go_full_minus_coupon"
    }
}, e = function(e, c) {
    var o = (_[e] || {})[c];
    return o || (console.warn("".concat(e, "没有在“EVENT_NAME”中定义")), ("".concat(e, "_").concat(c) || "").toLowerCase());
};

exports.default = e;