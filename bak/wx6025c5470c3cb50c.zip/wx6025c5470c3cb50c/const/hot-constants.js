Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.RANK_ROUTER_KEY = exports.CONVERT_HOTLIST_CODE = void 0;

exports.RANK_ROUTER_KEY = {
    hot_sales: "/subPages/home/brand/hotlist/index",
    hot_sales_7d: "subPages/home/brand/hotlist/index",
    community: "subPages/home/brand/hotlist/index",
    hot_sales_nearby: "subPages/home/brand/hotlist/index",
    new_releases: "/subPages/home/brand/newList/index",
    share: "/subPages/home/brand/shareList/index",
    offer: "/subPages/home/brand/offerList/index",
    special_offer: "/subPages/home/brand/offerList/index",
    repurchase: "/subPages/home/brand/repurchaseList/index",
    StoreMorningMarket: "/subPages/home/brand/dayNightList/index",
    StoreEveningMarket: "/subPages/home/brand/dayNightList/index"
};

exports.CONVERT_HOTLIST_CODE = {
    hot_sales: "hot_sales",
    hot_sales_7d: "hot_sales_7d",
    community: "community",
    hot_sales_nearby: "hot_sales_nearby",
    special_offer: "",
    new_releases: "",
    share: "",
    repurchase: ""
};