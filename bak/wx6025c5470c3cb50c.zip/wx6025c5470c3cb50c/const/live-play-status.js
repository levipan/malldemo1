Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    UPCOMING: "UPCOMING",
    FINISH: "FINISH",
    LIVING: "LIVING",
    EXPLAIN: "EXPLAIN"
};