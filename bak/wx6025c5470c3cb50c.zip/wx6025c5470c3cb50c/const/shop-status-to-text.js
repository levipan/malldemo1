Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SHOP_STATUS_TO_TEXT = void 0;

exports.SHOP_STATUS_TO_TEXT = {
    NORMAL: "正常",
    FROZEN: "当前门店已冻结，无法购买",
    DELETE: "当前门店不存在，无法购买",
    NOT_ONLINE: "当前门店待上线，无法购买",
    NOT_LOGISTICS: "当前门店待上线，无法购买",
    OUT_BUSINESS: "当前门店已歇业，无法购买，上线时间见群通",
    OUT_SPRING_BUSINESS: "当前门店春节休假中，无法购买"
};