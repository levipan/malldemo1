Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.navBarStatus = void 0;

exports.navBarStatus = {
    HOME: "home",
    BRAND: "brand",
    YOUSHI: "youshi",
    CART: "cart",
    CENTER: "center"
};