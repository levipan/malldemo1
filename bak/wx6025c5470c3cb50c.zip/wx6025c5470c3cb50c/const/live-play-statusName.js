Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.NEW_LIVE_STATUS = void 0;

exports.default = {
    UPCOMING: "即将直播",
    FINISH: "直播回放",
    LIVING: "正在直播",
    EXPLAIN: "商品讲解"
};

exports.NEW_LIVE_STATUS = {
    NOT_STARTED: "NOT_STARTED",
    PLAYING: "PLAYING",
    SUSPEND: "SUSPEND",
    OVER: "OVER",
    EXPIRED: "EXPIRED",
    PRODUCT_EXPLAIN: "PRODUCT_EXPLAIN"
};