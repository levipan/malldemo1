Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PLAYER_STATUS = void 0;

exports.PLAYER_STATUS = {
    PLAYING: "PLAYING",
    PAUSE: "PAUSE",
    END: "END"
};