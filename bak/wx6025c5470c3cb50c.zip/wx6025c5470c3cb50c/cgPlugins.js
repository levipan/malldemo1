var e = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e, d) {
    var g = new i.default().init(e), c = new t.default().init(e), x = new n.default();
    x.init(e);
    var s = new u.default();
    return s.init(e), r.default.init(e), a.default.init(e, {
        isPlugin: !0
    }), l.default.init(e, {
        isPlugin: !0
    }), d && d({
        $router: g,
        $http: c,
        $data: x,
        $tran: s,
        $watch: r.default,
        $component: a.default,
        $page: l.default
    }), {
        $router: g,
        $http: c,
        $data: x,
        $tran: s,
        $watch: r.default,
        $component: a.default,
        $page: l.default
    };
};

var t = e(require("./xsyx_cg_plugin/cg-http/index.js")), i = e(require("./xsyx_cg_plugin/cg-router/index.js")), n = e(require("./xsyx_cg_plugin/cg-data/index.js")), u = e(require("./xsyx_cg_plugin/cg-tran/index.js")), r = e(require("./xsyx_cg_plugin/cg-watch/index.js")), a = e(require("./xsyx_cg_plugin/cg-component/index.js")), l = e(require("./xsyx_cg_plugin/cg-page/index.js"));