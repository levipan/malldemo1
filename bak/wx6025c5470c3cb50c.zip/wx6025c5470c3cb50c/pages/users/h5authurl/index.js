getApp().Page({
    data: {
        viewUrl: ""
    },
    onLoad: function(o) {
        var e = decodeURIComponent(o.url);
        console.log("viewurl", e), this.setData({
            viewUrl: e
        });
    },
    onShow: function() {}
});