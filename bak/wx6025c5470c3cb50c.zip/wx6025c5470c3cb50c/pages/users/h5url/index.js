var a = getApp();

a.XPage({
    __page: !0,
    data: {
        viewUrl: ""
    },
    onLoad: function(e) {
        "productShare" === e.from && a.frxs.setMData("_c", {
            s: e.storeId || "",
            f: "store",
            c: e.channel || "",
            c_type: e.abFlag || "",
            s_random: e.s_random,
            ac_type: e.ac_type || ""
        });
        var r = wx.$.decode(e.url, 3);
        r.indexOf("?") > -1 ? r += "&userKey=".concat(a.frxs.getMOrSData("userKey"), "&storeId=").concat(a.frxs.getMOrSData("storeId"), "&qrAreaId=").concat(a.frxs.getMOrSData("areaId") || "") : r += "#?userKey=".concat(a.frxs.getMOrSData("userKey"), "&storeId=").concat(a.frxs.getMOrSData("storeId"), "&qrAreaId=").concat(a.frxs.getMOrSData("areaId") || ""), 
        console.log("   ", r), this.setData({
            viewUrl: r
        });
    },
    onShow: function() {}
});