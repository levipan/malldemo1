var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../../@babel/runtime/helpers/objectSpread2"), a = e(require("../../../router/index"));

getApp().XPage({
    __page: !0,
    data: {},
    onLoad: function(e) {
        a.default.navigateTo({
            path: "/subPages/users/shareOrder/shareOrder",
            isRedirect: !0,
            query: r({}, e)
        });
    }
});