var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../../@babel/runtime/helpers/objectSpread2"), i = e(require("../../../router/index"));

getApp().XPage({
    __page: !0,
    data: {},
    onLoad: function(e) {
        i.default.navigateTo({
            path: "/subOrder/uyingDirect/uyingDirect",
            isRedirect: !0,
            query: r({}, e)
        });
    }
});