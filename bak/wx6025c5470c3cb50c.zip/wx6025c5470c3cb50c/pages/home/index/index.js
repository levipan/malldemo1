var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/regenerator")), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../@babel/runtime/helpers/objectSpread2"), a = (e(require("../../../xapp/runtime")), 
e(require("../../../router/index"))), i = require("../../../api/index"), s = getApp();

s.XPage({
    __page: !0,
    onLoad: function(e) {
        this.routerOptions = e, a.default.subSwitchTab({
            path: "subMain/main/index",
            isRedirect: !0,
            query: n(n({}, e), {}, {
                tabCode: "home"
            })
        });
    },
    onShow: function() {},
    authScene: function(e) {
        var u = this;
        return r(t.default.mark(function c() {
            return t.default.wrap(function(c) {
                for (;;) switch (c.prev = c.next) {
                  case 0:
                    return c.abrupt("return", new Promise(function() {
                        var c = r(t.default.mark(function r(c) {
                            var o, p, d, h, f, l, x, g, b, v, m, y, q;
                            return t.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (o = u.$get(e, "scene", ""), o = decodeURIComponent(o), p = !1, o || (d = decodeURIComponent(e.q || "?p="), 
                                    h = s.frxs.getQuerys(d), (o = decodeURIComponent((h || {}).p || "")) && (p = !0)), 
                                    t.prev = 4, 0 !== o.indexOf("xsyx_") && !p) {
                                        t.next = 35;
                                        break;
                                    }
                                    return t.next = 8, i.shortApi[p ? "queryLinkByShortLink" : "queryLink"]({
                                        shortLink: o
                                    }, {
                                        silence: !0
                                    });

                                  case 8:
                                    if (f = t.sent, l = f.businessType, x = f.link, g = f.channel, b = function(e) {
                                        u.$sessionStorage.set("_sourcePoster", {
                                            channel: e.channel,
                                            type: l
                                        });
                                    }, v = function(e, t) {
                                        t = t || {};
                                        var r = "";
                                        try {
                                            r = JSON.parse(wx.$.decode(t.p, 5)).c;
                                        } catch (e) {}
                                        t.channel = t.channel || g || r, b(t), t.invitationCode && s.frxs.setMAndSData("storeBindInfo", t), 
                                        e = e.startsWith("/") ? "" : "/" + x, s.enterAppOptions = n(n({}, s.enterAppOptions), {}, {
                                            path: e,
                                            query: t
                                        }), s.frxs.setMData("_c", {
                                            f: "ad",
                                            c: t.channel || g,
                                            c_type: function() {
                                                switch (l) {
                                                  case "CMS-H5":
                                                  case "CMS-H5-STORE":
                                                    return "cms_h5";

                                                  case "MINI-PROGRAM":
                                                    return "applets";

                                                  case "H5":
                                                    return "h5";

                                                  default:
                                                    return "";
                                                }
                                            }()
                                        });
                                    }, m = {
                                        success: function() {
                                            c(!0);
                                        },
                                        fail: function(e) {
                                            u.$sessionStorage.delete("_sourcePoster"), c(!1);
                                        }
                                    }, "CMS-H5-STORE" !== l) {
                                        t.next = 20;
                                        break;
                                    }
                                    return y = {}, (x.split("&") || []).forEach(function(e) {
                                        var t = e.split("=");
                                        "url" === t[0] ? (t.shift(), y.url = t.join("=")) : y[t[0]] = t[1];
                                    }), v("/pages/home/h5Active/index", n({}, y)), t.abrupt("return", a.default.navigateTo(n({
                                        path: "/pages/home/h5Active/index",
                                        isRedirect: !0,
                                        query: n({}, y)
                                    }, m)));

                                  case 20:
                                    if ("CMS-H5" !== l) {
                                        t.next = 23;
                                        break;
                                    }
                                    return v("/pages/home/h5Active/index", {
                                        url: x
                                    }), t.abrupt("return", a.default.navigateTo(n({
                                        path: "/pages/home/h5Active/index",
                                        isRedirect: !0,
                                        query: {
                                            url: x
                                        }
                                    }, m)));

                                  case 23:
                                    if ("MINI-PROGRAM" !== l) {
                                        t.next = 32;
                                        break;
                                    }
                                    return x.startsWith("/") || (x = "/" + x), (q = s.frxs.getQuerys(x) || {}).twitterId && q.sign && (s.frxs.setMData("tkInfo", {
                                        id: q.twitterId,
                                        sign: q.sign,
                                        code: 0
                                    }), s.frxs.setMData("_c", {
                                        twitterid: q.twitterId,
                                        f: "ad",
                                        c: q.channel
                                    })), -1 !== [ "/pages/home/index/index", "/pages/home/cateProduct/index", "/pages/users/center/center", "/pages/home/cart/cart" ].findIndex(function(e) {
                                        return e === x.split("?")[0];
                                    }) && (m.isLaunch = !0), v(x.split("?")[0], n({}, q)), t.abrupt("return", a.default.navigateTo(n({
                                        path: x.split("?")[0],
                                        isRedirect: !0,
                                        query: n({}, q)
                                    }, m)));

                                  case 32:
                                    if ("H5" !== l) {
                                        t.next = 35;
                                        break;
                                    }
                                    return v("/pages/users/h5url/index", {
                                        url: x
                                    }), t.abrupt("return", a.default.navigateTo(n({
                                        path: "/pages/users/h5url/index",
                                        isRedirect: !0,
                                        query: {
                                            url: x
                                        }
                                    }, m)));

                                  case 35:
                                    c(!1), t.next = 42;
                                    break;

                                  case 38:
                                    t.prev = 38, t.t0 = t.catch(4), console.error(t.t0), c(!1);

                                  case 42:
                                  case "end":
                                    return t.stop();
                                }
                            }, r, null, [ [ 4, 38 ] ]);
                        }));
                        return function(e) {
                            return c.apply(this, arguments);
                        };
                    }()));

                  case 1:
                  case "end":
                    return c.stop();
                }
            }, c);
        }))();
    },
    onGoLive: function() {
        wx.navigateTo({
            url: "/subLive/liveRoom/index"
        });
    }
});