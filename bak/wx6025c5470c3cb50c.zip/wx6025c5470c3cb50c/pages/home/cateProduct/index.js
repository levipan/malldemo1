var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../../@babel/runtime/helpers/objectSpread2"), a = e(require("../../../router/index"));

getApp().XPage({
    __page: !0,
    data: {},
    onLoad: function(e) {
        a.default.subSwitchTab({
            path: "/subMain/main/index",
            isRedirect: !0,
            query: r(r({}, e), {}, {
                tabCode: "brand"
            })
        });
    }
});