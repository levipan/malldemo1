var e = require("../../../@babel/runtime/helpers/interopRequireWildcard"), t = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = t(require("../../../@babel/runtime/regenerator")), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../../@babel/runtime/helpers/objectSpread2"), n = require("../../../@babel/runtime/helpers/toConsumableArray"), s = (t(require("../../../xapp/runtime")), 
require("../../../api/index")), i = e(require("../../../utils/events.js")), c = t(require("../../../router/index.js")), d = require("../../../const/storage.key.js"), u = t(require("../../../@xsyx-components/hanzo-page-loading/loading.js")), f = require("../../../utils/cartService.js"), l = getApp();

l.XPage({
    __page: !0,
    mixins: [ require("../../../behavior/getConfig") ],
    data: {
        url: "",
        showActive: !1,
        showPopup: !1,
        popupContent: "",
        baseAjaxError: !1,
        newStoreId: 0
    },
    onGetMessage: function(e) {
        var t = e.detail;
        console.error(t.data, "detail.data"), this.initShopCard(this._get(n(t.data).reverse().find(function(e) {
            return "shopping" === e.type;
        }), "val", [])), console.log(t.data), this.initPoint(n(t.data).filter(function(e) {
            return "point" === e.type;
        }));
    },
    initPoint: function(e) {
        try {
            (e || []).forEach(function(e) {
                var t = e.val;
                l.frxs.XSMonitor.sendEvent(t.event, o({}, t.param), "");
            });
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    initShopCard: function(e) {
        var t = this;
        try {
            if (0 === e.length) return;
            e.forEach(function(e) {
                if (!(Object.keys(e).length <= 2)) for (var r = 0; r < e.cartQuantity; r++) t.addCart(e);
            });
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    checkTempStore: function() {
        return 1 * l.frxs.getMOrSData("storeId") == 1 * l.frxsConfig.tempStoreId;
    },
    addCart: function(e) {
        if (this.checkTempStore()) return !1;
        this.sendEvent(e, 1), f.addCart(e), i.default.emit(i.EVENTS.REFRESH_CART, null);
    },
    sendEvent: function(e, t) {
        for (var r = 0; r < t; r++) try {
            l.frxs.XSMonitor.sendEvent("add_product", {
                activity_id: this.pageCode,
                skuSn: e.skuSn,
                sku: e.sku,
                spu_sn: e.spuSn,
                extra_operate: e.tsBuyStart - new Date().getTime() > 0 ? "wantBuy" : "",
                slot: "加车"
            }, "加入购物车");
        } catch (e) {}
    },
    getActiveStatusAjax: function(e, t) {
        return new Promise(function(r) {
            s.homePromotionApi.fetchGetQueryLandingPageStatus({
                pageCode: e,
                areaId: t,
                t: new Date().getTime()
            }, {
                silence: !0
            }).then(function(e) {
                r({
                    code: 0,
                    data: e
                });
            }).catch(function(e) {
                r({
                    code: -1,
                    data: e
                });
            });
        });
    },
    goHome: function() {
        l.router.switchTab({
            path: "/pages/home/index/index"
        });
    },
    showPopup: function(e) {
        wx.hideToast(), this.setData({
            showPopup: !0,
            showActive: !1,
            popupContent: e
        });
    },
    onH5LoadError: function() {
        wx.hideToast(), this.setData({
            showActive: !1
        }), wx.showToast({
            icon: "none",
            title: "加载失败，请稍后重试",
            duration: 3e3
        });
    },
    onH5LoadSuccess: function() {
        wx.hideToast();
    },
    onClickRefresh: function() {
        var e = this;
        this.setData({
            url: "",
            showActive: !1,
            showPopup: !1,
            popupContent: "",
            baseAjaxError: !1,
            newStoreId: 0
        }, function() {
            e.onLoad(e.formatOptions);
        });
    },
    onUnload: function() {
        wx.hideToast(), this.$sessionStorage.delete("_sourcePoster"), this.$sessionStorage.delete("h5ActivePage"), 
        this.$sessionStorage.delete("h5ActivePage_reload"), f.getCloudCarts({
            success: function() {
                i.default.emit(i.EVENTS.REFRESH_CART, null);
            },
            fail: function(e) {}
        });
        try {
            l.frxs.setMData("inner", null);
        } catch (e) {}
    },
    initErrorPage: function() {
        wx.hideToast(), this.setData({
            baseAjaxError: !0,
            showActive: !1
        });
    },
    authFindStore: function(e) {
        return 1 * e ? e : (wx.$.sessionStorage.set("toPageConfig", {
            path: this.route,
            query: this.options,
            type: "navigateBack"
        }), c.default.navigateTo({
            path: "/subPages/users/changdot/changdot"
        }), !1);
    },
    initActivePage: function() {
        var e = this;
        return a(r.default.mark(function t() {
            var a, o;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (t.prev = 0, a = e.authFindStore(e.clientStoreId)) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return");

                  case 4:
                    return u.default.showLoading({
                        title: "加载中...",
                        delayed: !0
                    }), t.next = 7, s.commonStoreApi.fetchStoreInfo({
                        storeId: a
                    });

                  case 7:
                    o = t.sent, u.default.close(), l.frxs.setMAndSData("areaId", o.areaId), l.frxs.setMAndSData("countyId", o.countyId), 
                    l.frxs.setMAndSData("cityId", o.cityId), l.frxs.setMAndSData("storeInfo", o), l.frxs.setMAndSData("storeId", o.storeId), 
                    e.clientStoreId = o.storeId, e.clientAreaId = o.areaId, t.next = 22;
                    break;

                  case 18:
                    return t.prev = 18, t.t0 = t.catch(0), u.default.close(), t.abrupt("return", e.initErrorPage());

                  case 22:
                    return t.abrupt("return", e.initActive());

                  case 23:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 18 ] ]);
        }))();
    },
    onShow: function() {
        this.$sessionStorage.get("h5ActivePage_reload") && (this.$sessionStorage.delete("h5ActivePage_reload"), 
        wx.redirectTo({
            url: "/pages/home/h5Active/index?".concat(l.frxs.parseParam(this.formatOptions))
        }));
    },
    onLoad: function(e) {
        var t = this;
        return a(r.default.mark(function a() {
            var o, n, i, d, f, h;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    t.formatOptions = wx.$.deepCopy(e), t.showShare = e.showShare, console.log(t.formatOptions);
                    try {
                        "productShare" === e.from && l.frxs.setMData("_c", {
                            s: e.storeId || "",
                            f: "store",
                            c: e.channel || "",
                            c_type: e.abFlag || "",
                            s_random: e.s_random,
                            ac_type: e.ac_type || ""
                        });
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        console.error(e);
                    }
                    o = t.$sessionStorage.get("_sourcePoster"), wx.hideShareMenu(), t.$sessionStorage.set("h5ActivePage", !0);
                    try {
                        t.formatOptions.url = wx.$.decode(t.formatOptions.url, 5), t.pageCode = l.frxs.getQuerys(t.formatOptions.url).pageCode;
                    } catch (e) {}
                    if (void 0 !== t.pageCode) {
                        r.next = 11;
                        break;
                    }
                    return t.normalH5 = !0, r.abrupt("return", t.setData({
                        url: t.formatOptions.url,
                        showActive: !0
                    }));

                  case 11:
                    if (t.clientStoreId = l.frxs.getMOrSData("storeId"), t.clientAreaId = l.frxs.getMOrSData("areaId"), 
                    t.formatOptions.storeId = Number(t.formatOptions.storeId) > 0 ? t.formatOptions.storeId : null, 
                    t.formatOptions.areaId = Number(t.formatOptions.areaId) > 0 ? t.formatOptions.areaId : null, 
                    !t.isOpenSwitchStoreConfirmBox(t.clientStoreId, t.formatOptions.storeId)) {
                        r.next = 17;
                        break;
                    }
                    return r.abrupt("return");

                  case 17:
                    if (!([ "CMS-H5-STORE", "CMS-H5" ].indexOf(t._get(o, "type", "")) > -1)) {
                        r.next = 46;
                        break;
                    }
                    if (t.clientStoreId) {
                        r.next = 21;
                        break;
                    }
                    return wx.$.sessionStorage.set("toPageConfig", {
                        path: t.route,
                        query: t.options,
                        type: "navigateBack"
                    }), r.abrupt("return", c.default.navigateTo({
                        path: "/subPages/users/changdot/changdot"
                    }));

                  case 21:
                    if (!t.clientStoreId || t.clientAreaId) {
                        r.next = 44;
                        break;
                    }
                    if (r.prev = 22, n = t.authFindStore(t.clientStoreId)) {
                        r.next = 26;
                        break;
                    }
                    return r.abrupt("return");

                  case 26:
                    return u.default.showLoading({
                        title: "加载中...",
                        delayed: !0
                    }), r.next = 29, s.commonStoreApi.fetchStoreInfo({
                        storeId: n
                    });

                  case 29:
                    i = r.sent, u.default.close(), l.frxs.setMAndSData("areaId", i.areaId), l.frxs.setMAndSData("countyId", i.countyId), 
                    l.frxs.setMAndSData("cityId", i.cityId), l.frxs.setMAndSData("storeInfo", i), l.frxs.setMAndSData("storeId", i.storeId), 
                    t.clientStoreId = i.storeId, t.clientAreaId = i.areaId, r.next = 44;
                    break;

                  case 40:
                    return r.prev = 40, r.t0 = r.catch(22), u.default.close(), r.abrupt("return", t.initErrorPage());

                  case 44:
                    r.next = 47;
                    break;

                  case 46:
                    t.clientAreaId && t.clientStoreId || !t.formatOptions.storeId || (t.clientAreaId = t.formatOptions.areaId, 
                    t.clientStoreId = t.formatOptions.storeId, l.frxs.setMAndSData("areaId", t.formatOptions.areaId), 
                    l.frxs.setMAndSData("storeId", t.formatOptions.storeId));

                  case 47:
                    if (t.clientStoreId) {
                        r.next = 50;
                        break;
                    }
                    return wx.$.sessionStorage.set("toPageConfig", {
                        path: t.route,
                        query: t.options,
                        type: "navigateBack"
                    }), r.abrupt("return", c.default.navigateTo({
                        path: "/subPages/users/changdot/changdot"
                    }));

                  case 50:
                    if (t.clientAreaId) {
                        r.next = 73;
                        break;
                    }
                    if (r.prev = 51, d = t.authFindStore(t.clientStoreId)) {
                        r.next = 55;
                        break;
                    }
                    return r.abrupt("return");

                  case 55:
                    return u.default.showLoading({
                        title: "加载中...",
                        delayed: !0
                    }), r.next = 58, s.commonStoreApi.fetchStoreInfo({
                        storeId: d
                    });

                  case 58:
                    f = r.sent, u.default.close(), l.frxs.setMAndSData("areaId", f.areaId), l.frxs.setMAndSData("countyId", f.countyId), 
                    l.frxs.setMAndSData("cityId", f.cityId), l.frxs.setMAndSData("storeInfo", f), l.frxs.setMAndSData("storeId", f.storeId), 
                    t.clientStoreId = f.storeId, t.clientAreaId = f.areaId, r.next = 73;
                    break;

                  case 69:
                    return r.prev = 69, r.t1 = r.catch(51), u.default.close(), r.abrupt("return", t.initErrorPage());

                  case 73:
                    return u.default.showLoading({
                        title: "加载中...",
                        delayed: !0
                    }), wx.hideShareMenu(), t.getActiveStatusAjax(t.pageCode, t.clientAreaId).then(function(e) {
                        var r = e.code, a = e.data;
                        if (u.default.close(), 1 * r != 0 || !a) return t.initErrorPage();
                        try {
                            a.shareable && wx.showShareMenu();
                            var o = function(e) {
                                return e.split("").map(function(e) {
                                    return e.toLocaleLowerCase();
                                }).join("");
                            };
                            wx.setNavigationBarColor({
                                frontColor: o(a.titleColor),
                                backgroundColor: o(a.titleBgColor)
                            });
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            console.log(e);
                        }
                        t.activeInfo = a;
                        try {
                            (l.frxs.getMOrSData("__CMS_UPDATE_TIME") || 0) < (a.pageUpdateTimestamp || 0) && l.frxs.setMAndSData("__CMS_UPDATE_TIME", a.pageUpdateTimestamp);
                        } catch (e) {}
                    }).catch(function(e) {
                        wx.hideShareMenu(), console.error(e);
                    }), r.next = 78, t.mallGetConfig({
                        areaId: t.clientAreaId || "",
                        storeId: t.clientStoreId || ""
                    });

                  case 78:
                    h = r.sent, u.default.close(), t.beginPreSale = h.beginPreSale, t.initActivePage();

                  case 82:
                  case "end":
                    return r.stop();
                }
            }, a, null, [ [ 22, 40 ], [ 51, 69 ] ]);
        }))();
    },
    isOpenSwitchStoreConfirmBox: function(e, t) {
        return l.frxs.XSMonitor.sendEvent("area_prompt", {
            target_area_id: this.formatOptions.areaId,
            target_store_id: this.formatOptions.storeId
        }, ""), !(!t || !e || t == e) && (this.setData({
            newStoreId: t,
            oldStoreId: e,
            storeId: e
        }), !0);
    },
    onShareAppMessage: function() {
        var e = !1;
        try {
            e = !1 !== this._get(l, "globalData.moduleConfig.cmsUseShareImage", void 0);
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            e = !1;
        }
        var t = "", r = "", a = encodeURIComponent(JSON.stringify({
            s: this.clientStoreId,
            f: "mini_program",
            c: 2012
        }));
        return this.normalH5 ? (r = "兴盛优选", t = "pages/home/h5Active/index?p=".concat(a, "&url=").concat(encodeURIComponent(encodeURIComponent(this.formatOptions.url)))) : (r = e ? this.activeInfo.shareText : this.activeInfo.pageName, 
        t = "pages/home/h5Active/index?p=".concat(a, "&storeId=").concat(this.clientStoreId, "&areaId=").concat(this.clientAreaId, "&url=").concat(encodeURIComponent(encodeURIComponent(this.formatOptions.url)))), 
        console.error(t), {
            title: r,
            imageUrl: e ? this.activeInfo.shareImage : void 0,
            path: t
        };
    },
    onSwitchStoreConfirm: function(e) {
        var t = e.detail, r = t.areaId, a = t.storeId;
        r && (l.frxs.setMAndSData("areaId", r), l.frxs.setMAndSData("storeId", a));
        var o = wx.$.deepCopy(this.formatOptions);
        o.storeId = a, o.areaId = r, wx.redirectTo({
            url: "/".concat(this.route, "?").concat(l.frxs.parseParam(o))
        });
    },
    initActive: function() {
        var e = l.frxs.XSMonitor.getUserIdentity() || !1;
        console.log(e);
        var t = l.frxs.getMOrSData("storeInfo") || {}, r = 1 != this.data.moduleConfig.fuzzy || l.frxs.getMOrSData(d.STORAGE_KEY.SHOW_FUZZY_SALES) ? "false" : "true", a = e ? "&userIdentity=".concat(encodeURIComponent(JSON.stringify(e))) : "", o = wx.$._get(this, "data.moduleConfig.activeAll", !1) || !1, n = wx.$._get(this, "data.moduleConfig.showConvenientPay", !1) || !1, s = {
            fuzzy: r,
            showFuzzySales: l.frxs.getMOrSData(d.STORAGE_KEY.SHOW_FUZZY_SALES),
            activeAll: o,
            showConvenientPay: n,
            beginPreSale: this.beginPreSale || !1,
            userKey: l.frxs.getMOrSData("userKey"),
            rankVersion: "v2",
            isIphoneX: l.globalData.isIPhoneX,
            isReport: !0,
            v: "1.2",
            storeId: this.clientStoreId,
            cityCode: t.cityId,
            areaCode: t.countyId,
            provinceCode: t.provinceId,
            channelUse: "WXAPP",
            saleRegionCode: this.clientAreaId,
            trans: !0,
            qpVersion: !0,
            newBuryVersion: !0,
            isYPHVersion: !0,
            isThin: !0,
            useNewLiveKey: this.data.moduleConfig.useNewLiveKey,
            isShowNewCart: !0,
            sendHome: !0,
            guid: l.frxs.getMOrSData("_xsm_g") || "",
            storeStatus: t.storeStatus
        };
        this.formatOptions.room_id && (s.room_id = this.formatOptions.room_id);
        var i = l.frxs.getMOrSData("__CMS_UPDATE_TIME") || 0;
        u.default.close();
        var c = "#wechat_redirect";
        "B" !== wx.$.getTestMeta("cmsIosTest") && (c = "");
        var f = "".concat(this.formatOptions.url, "&storeName=").concat(encodeURIComponent(t.storeName || "")).concat(a, "&").concat(l.frxs.parseParam(s), "&updateTime=").concat(i).concat(c);
        this.setData({
            url: f,
            showActive: !0
        });
    }
});