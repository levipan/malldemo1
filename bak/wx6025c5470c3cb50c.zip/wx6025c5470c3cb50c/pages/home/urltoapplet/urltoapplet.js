var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index")), n = getApp();

n.Page({
    data: {},
    onLoad: function(o) {
        var t = decodeURIComponent(n.frxs.getQuerys(decodeURIComponent(o.q)).appletUrl);
        e.default.redirectTo({
            path: t.split("?")[0],
            query: n.frxs.getQuerys(t)
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});