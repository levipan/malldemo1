var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../../@babel/runtime/helpers/objectSpread2"), r = e(require("../../../router/index"));

getApp().XPage({
    __page: !0,
    data: {},
    onLoad: function(e) {
        try {
            if ("A" === wx.$.getTestMeta("detailRewrite")) return void r.default.redirectTo({
                path: "/subDetail/index",
                query: t({}, e)
            });
        } catch (e) {}
        (e.imgUrl || e.prName) && (delete e.imgUrl, delete e.prName, delete e.saleAmt), 
        r.default.navigateTo({
            path: "/subProduct/detail/index",
            isRedirect: !0,
            query: t({}, e)
        });
    }
});