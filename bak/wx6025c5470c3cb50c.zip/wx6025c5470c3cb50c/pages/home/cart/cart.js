var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), r = require("../../../@babel/runtime/helpers/objectSpread2"), i = e(require("../../../router/index"));

getApp().XPage({
    __page: !0,
    onShow: function(e) {
        i.default.subSwitchTab({
            path: "subMain/main/index",
            isRedirect: !0,
            query: r(r({}, e), {}, {
                tabCode: "cart"
            })
        });
    }
});