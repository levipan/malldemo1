var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index"));

getApp().Page({
    data: {
        videoUrl: ""
    },
    timeUpdate: 0,
    hasBeenPlayed: !1,
    playStatus: 2,
    onLoad: function(e) {
        var t = this, a = {
            videoUrl: decodeURIComponent(e.videoUrl)
        };
        this.timeUpdate = e.timeUpdate || 0, this.setData(a, function() {
            var e = wx.createVideoContext("videoProduct");
            e.seek(parseFloat(t.timeUpdate)), e.play();
        });
    },
    videoPlay: function() {
        if (!this.hasBeenPlayed) {
            this.hasBeenPlayed = !0;
            var e = wx.createVideoContext("videoProduct");
            setTimeout(function() {
                e.requestFullScreen();
            }, 300), e.seek(parseFloat(this.timeUpdate));
        }
    },
    toBack: function(t) {
        e.default.navigateBack();
        var a = getCurrentPages();
        a[a.length - 2].videoBackToCur({
            key: this.options.key,
            timeUpdate: 1 == this.playStatus ? 0 : this.timeUpdate,
            playStatus: this.playStatus
        });
    },
    fullscreenChange: function(e) {
        e.detail.fullScreen || this.toBack();
    },
    playEnded: function() {
        this.playStatus = 1, this.toBack(1);
    },
    playPause: function() {
        console.warn("playPause：", 3), this.playStatus = 3;
    },
    playTimeupdate: function(e) {
        this.timeUpdate = e.detail.currentTime;
    },
    onUnload: function() {}
});