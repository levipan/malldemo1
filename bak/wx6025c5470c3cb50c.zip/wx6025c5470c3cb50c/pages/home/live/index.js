var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../utils/task")), i = t(require("../../../router/index")), a = require("../../../api/index.js"), s = getApp(), n = new e.default();

s.Page({
    data: {
        liveUrl: "",
        startTime: "",
        endTime: "",
        liveStatus: "",
        showLive: !1
    },
    timeOffset: 0,
    onLoad: function(t) {
        var e = this;
        switch (parseInt(t.source || 0)) {
          case 2:
          case 3:
            this.toLive();
            break;

          default:
            this.getSysTime(function() {
                e.setData({
                    liveUrl: decodeURIComponent(t.liveUrl),
                    startTime: decodeURIComponent(t.startTime),
                    endTime: decodeURIComponent(t.endTime),
                    areaId: s.frxs.getMOrSData("areaId")
                }), e.updateLiveStatus(), e.refreshLiveStatus();
            });
        }
    },
    toLive: function() {
        if (s.frxs.compareVersion("2.6.2") > 0) {
            var t = this.options.studioId, e = encodeURIComponent(JSON.stringify({
                path: "pages/home/index/index"
            }));
            wx.redirectTo({
                url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=".concat(t, "&custom_params=").concat(e)
            }), s.frxs.XSMonitor.sendEvent("go_live", {
                live_id: t
            });
        } else s.frxs.showModal({
            title: "建议升级",
            content: "由于微信版本过低，暂不支持观看直播，请升级微信后观看",
            confirmText: "升级",
            cancelText: "以后再说",
            success: function(t) {
                if (t.confirm) return wx.navigateTo({
                    url: "/subPages/home/wxgoup/wxgoup"
                });
                wx.navigateBack();
            }
        });
    },
    onShow: function() {
        n.continue();
    },
    onHide: function() {
        n.pause();
    },
    onUnload: function() {
        n.destroy();
    },
    now: function() {
        return Date.now() + (this.timeOffset || 0);
    },
    refreshLiveStatus: function() {
        var t = this, e = this.getUpdateLiveNextStatusTime();
        e.startTime > 0 && n.add(function() {
            t.updateLiveStatus();
        }, e.startTime), e.endTime > 0 && n.add(function() {
            t.updateLiveStatus();
        }, e.endTime), (e.startTime > 0 || e.endTime > 0) && n.run(100);
    },
    getUpdateLiveNextStatusTime: function() {
        var t = s.frxs.formaterDate(this.now(), "yyyy-MM-dd"), e = s.frxs.strToDate(this.data.startTime.length > 12 ? this.data.startTime : t + " " + this.data.startTime), i = s.frxs.strToDate(this.data.endTime.length > 12 ? this.data.endTime : t + " " + this.data.endTime), a = +e - this.now(), n = +i - this.now();
        return {
            startTime: 1e3 * Math.ceil(a / 1e3),
            endTime: 1e3 * Math.ceil(n / 1e3)
        };
    },
    updateLiveStatus: function() {
        var t = s.frxs.formaterDate(this.now(), "yyyy-MM-dd"), e = s.frxs.strToDate(t + " " + this.data.startTime), i = s.frxs.strToDate(t + " " + this.data.endTime);
        +e > this.now() ? "upcoming" != this.data.liveStatus && this.setData({
            liveStatus: "upcoming"
        }) : this.now() >= +i ? "finish" != this.data.liveStatus && this.setData({
            liveStatus: "finish"
        }) : "living" != this.data.liveStatus && this.setData({
            liveStatus: "living",
            showLive: !0
        });
    },
    getSysTime: function(t) {
        var e = this, i = this.data.areaId || s.frxs.getMOrSData("areaId");
        if (i > 0) return a.commonStoreApi.fetchSysParam({
            areaId: i
        }).then(function(i) {
            var a = i.offset;
            e.timeOffset = a, t();
        }).catch(function(e) {
            t();
        });
    },
    toIndex: function() {
        i.default.subSwitchTab({
            path: "subMain/main/index",
            query: {
                tabCode: "home"
            }
        });
    }
});