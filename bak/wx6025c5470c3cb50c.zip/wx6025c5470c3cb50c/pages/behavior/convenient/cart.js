var e = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../../@babel/runtime/regenerator")), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../api/index.js"), r = require("../../../const/nav-bar-status.js"), o = e(require("../../../utils/cartService.js")), i = e(require("../../../router/index.js")), s = getApp(), c = [ "rank", "similar", "yph", "zp", "sign" ];

module.exports = function() {
    return {
        data: {
            behavior_convenient_discountsAmt: -1,
            behavior_convenient_selectedProductAmt: 0,
            behavior_convenient_allProductSize: 0,
            behavior_convenient_selectedProductSize: 0,
            behavior_convenient_couponCloseV: 0,
            behavior_convenient_selectedProductQtyMap: {},
            behavior_convenient_couponList: [],
            behavior_convenient_redBag: {},
            behavior_convenient_redBagIsShow: !1,
            behavior_convenient_footerOperateInstance: null
        },
        methods: {
            behavior_convenient_redBagIsShow: function(e) {
                this.setData({
                    behavior_convenient_redBagIsShow: !!e.detail
                });
            },
            behavior_convenient_redBagCountdownOver: function(e) {
                e.detail && e.detail.length > 1 && this.behavior_convenient_getRedBagList();
            },
            behavior_convenient_redBagClearTimer: function() {
                this.data.pageType === r.navBarStatus.HOME && (this.data.behavior_convenient_footerOperateInstance || (this.data.behavior_convenient_footerOperateInstance = this.selectComponent("#behavior_convenient_footerOperateInstanceHome")), 
                this.data.behavior_convenient_footerOperateInstance && this.data.behavior_convenient_footerOperateInstance._clearInterval && this.data.behavior_convenient_footerOperateInstance._clearInterval()), 
                this.data.pageType === r.navBarStatus.BRAND && (this.data.behavior_convenient_footerOperateInstance || (this.data.behavior_convenient_footerOperateInstance = this.selectComponent("#behavior_convenient_footerOperateInstanceBrand")), 
                this.data.behavior_convenient_footerOperateInstance && this.data.behavior_convenient_footerOperateInstance._clearInterval && this.data.behavior_convenient_footerOperateInstance._clearInterval());
            },
            behavior_convenient_redBagOnRefresh: function(e) {
                e && s.frxs.setMData("behavior_convenient_redBagIsShow", !0), this.data.pageType === r.navBarStatus.HOME && (this.data.behavior_convenient_footerOperateInstance || (this.data.behavior_convenient_footerOperateInstance = this.selectComponent("#behavior_convenient_footerOperateInstanceHome")), 
                this.data.behavior_convenient_footerOperateInstance && this.data.behavior_convenient_footerOperateInstance.redBagOnRefresh && this.data.behavior_convenient_footerOperateInstance.redBagOnRefresh()), 
                this.data.pageType === r.navBarStatus.BRAND && (this.data.behavior_convenient_footerOperateInstance || (this.data.behavior_convenient_footerOperateInstance = this.selectComponent("#behavior_convenient_footerOperateInstanceBrand")), 
                this.data.behavior_convenient_footerOperateInstance && this.data.behavior_convenient_footerOperateInstance.redBagOnRefresh && this.data.behavior_convenient_footerOperateInstance.redBagOnRefresh());
            },
            behavior_convenient_getRedBagList: function() {
                var e = this, t = s.frxs.getMOrSData("storeInfo") || !1;
                if (t) {
                    var n = s.frxs.getMOrSData("userKey") || "";
                    if ((s.frxs.getMOrSData("isLogin") || !1) && n) {
                        var r = {
                            areaId: (t || {}).areaId,
                            storeId: this.storeId || (t || {}).storeId,
                            provinceCode: (t || {}).provinceId,
                            cityCode: (t || {}).cityId,
                            areaCode: (t || {}).countyId
                        };
                        a.portalCmsApi.queryUserTickets(r, {
                            contentType: "application/json",
                            silence: !0,
                            loginVerify: !1
                        }).then(function(t) {
                            t ? e.setData({
                                behavior_convenient_redBag: t
                            }) : e.setData({
                                behavior_convenient_redBag: {},
                                behavior_convenient_redBagIsShow: !1
                            }), e.setData({
                                isFootOperateFinish: !0
                            });
                        }).catch(function(t) {
                            e.setData({
                                isFootOperateFinish: !0
                            }), console.log(t);
                        });
                    } else this.setData({
                        isFootOperateFinish: !0
                    });
                } else this.setData({
                    isFootOperateFinish: !0
                });
            },
            behavior_convenient_couponShow: function(e) {
                "brand" === this.data.pageType && this.triggerEvent("tabbarPageCateProductCouponShow", e.detail), 
                "prSearch" === this.data.pageType && this.setData({
                    brandSearchInputZIndex: e.detail ? "99" : "1001",
                    pageIsScroll: !e.detail
                }), ~[ "ofenBuyList", "hotList", "newList", "offerList", "repurchaseList", "shareList" ].indexOf(this.data.pageType) && this.setData({
                    pageIsScroll: !e.detail
                }), ~[ "signIn" ].indexOf(this.data.pageType) && this.setData({
                    signInScroll: !e.detail
                });
            },
            behavior_convenient_closeCoupon: function() {
                this.setData({
                    behavior_convenient_couponCloseV: Date.now()
                });
            },
            behavior_convenient_goToHome: function() {
                i.default.switchTab({
                    path: "/pages/home/index/index"
                }), s.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "快捷支付首页"
                }, "");
            },
            behavior_convenient_refreshPageCartData: function(e, a) {
                var r = this;
                return n(t.default.mark(function n() {
                    var o;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return o = a || e, t.next = 3, r.behavior_convenient_getCart({
                                force: !!e.force,
                                type: e.type
                            });

                          case 3:
                            o && o();

                          case 4:
                          case "end":
                            return t.stop();
                        }
                    }, n);
                }))();
            },
            behavior_convenient_goToCart: function() {
                i.default.navigateTo({
                    path: "/subOrder/cart/cart"
                }), s.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "快捷支付购物车"
                }, "");
            },
            behavior_convenient_goToPay: function() {
                var e = this;
                if (this.behavior_convenient_going) return !1;
                var t = s.frxs.getMOrSData("storeInfo"), n = s.frxs.getMOrSData("userKey"), r = {
                    areaId: this.areaId || (t || {}).areaId,
                    storeId: this.storeId || (t || {}).storeId,
                    userKey: n,
                    cartSkus: [],
                    version: "STORE_PRICE",
                    needXCoin: !1
                };
                this.behavior_convenient_going = !0, a.tradeCartApi.canSaleProduct(r, {
                    contentType: "application/json",
                    silence: !0
                }).then(function(t) {
                    e.behavior_convenient_going = !1;
                    var n = "/subOrder/uyingDirect/uyingDirect";
                    ~[ "subMain/main/index", "pages/home/index/index", "pages/home/cateProduct/index", "subPages/home/brand/search/search", "subProduct/similarProduct/index", "subPages/home/brand/hotlist/index" ].indexOf((e.route || "").split("?")[0] || e.data.propsRoute) && (n += "?from=fast_payment", 
                    n += "&payAmount=".concat(t.selectedProductAmt)), t.productList && t.productList.length && (s.frxs.setMAndSData("sureCart", t.productList), 
                    i.default.navigateTo({
                        path: n,
                        query: {
                            pageFrom: "fast_payment"
                        }
                    }));
                }).catch(function() {
                    e.behavior_convenient_going = !1;
                }), s.frxs.XSMonitor.sendEvent("slot_click", {
                    slot: "快捷支付去结算"
                }, "");
            },
            behavior_convenient_getCart: function(e) {
                var r = this;
                return n(t.default.mark(function n() {
                    var i, d, u, v, h, _, p, f, l, b, g, I, y, O, S;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (t.prev = 0, d = (i = e || {}).force || !1, u = i.cartSkus, v = i.type, h = i.issue || !1, 
                            s.frxs.isLogin()) {
                                t.next = 9;
                                break;
                            }
                            return ~c.indexOf(v) && o.default.getCartList().map(function(e) {
                                r.behavior_convenient_cartNumberMap[e.skuSn] = e.cartQuantity;
                            }), t.abrupt("return");

                          case 9:
                            if (wx.$._get(s.frxs.getMData("moduleConfig") || {}, "showConvenientPay", !1)) {
                                t.next = 13;
                                break;
                            }
                            return r.setData({
                                isFootOperateFinish: !0
                            }), t.abrupt("return");

                          case 13:
                            if (_ = u, u || (p = o.default.getWaitSyncProducts() || [], f = s.frxs.getMOrSData("storeInfo"), 
                            _ = p.map(function(e) {
                                return {
                                    skuSn: e.skuSn,
                                    eskuSn: e.eskuSn,
                                    areaId: r.areaId || (f || {}).areaId,
                                    qty: e.cartQuantity,
                                    optype: e.optype || "manual"
                                };
                            })), l = s.frxs.getMOrSData("userKey"), b = s.frxs.getMOrSData("storeInfo") || !1) {
                                t.next = 20;
                                break;
                            }
                            return r.setData({
                                isFootOperateFinish: !0
                            }), t.abrupt("return");

                          case 20:
                            g = {
                                areaId: r.areaId || (b || {}).areaId,
                                storeId: r.storeId || (b || {}).storeId,
                                cartType: "CHOICE",
                                needSyncProduct: _.map(function(e) {
                                    return e.eSkuSn = e.eskuSn, e;
                                }),
                                unSelectedESkuSn: [],
                                clientType: "MINI_PROGRAM",
                                userKey: l,
                                version: "STORE_PRICE",
                                marketingJsonParam: {
                                    openId: "",
                                    client: "MEMBER",
                                    channelUse: "WXAPP",
                                    userScopeTypes: [ s.frxs.getMData("isNewUser") ? "NEW_USER" : "", "NORMAL" ].filter(function(e) {
                                        return e;
                                    }),
                                    issue: h,
                                    version: 2,
                                    provinceCode: b.provinceId,
                                    cityCode: b.cityId,
                                    areaCode: b.countyId,
                                    saleRegionCode: (b || {}).areaId,
                                    recommendType: 0,
                                    needXCoin: !1,
                                    showClientType: "MEMBER",
                                    primaryChannel: "XSYX",
                                    currentSecondaryChannel: "MEMBER",
                                    storeId: r.storeId || (b || {}).storeId
                                }
                            }, s.frxs.getMData("isNewUser") && (g.marketingJsonParam.jsonParam = {
                                blackBox: s.frxs.storage("safe_bb") || ""
                            });
                            try {
                                s.frxs.XSMonitor.sendEvent("monitorError_warn", {
                                    content: {
                                        cartParams: JSON.stringify(g)
                                    }
                                });
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.log(e);
                            }
                            return t.next = 25, a.tradeCartApi.cartPaymentV3(g, {
                                contentType: "application/json",
                                silence: !0,
                                loginVerify: !1
                            });

                          case 25:
                            I = t.sent;
                            try {
                                s.frxs.XSMonitor.sendEvent("monitorError_warn", {
                                    content: {
                                        cartContent: JSON.stringify(I)
                                    }
                                });
                            } catch (e) {
                                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                                console.log(e);
                            }
                            if (o.default.setPdAndStoreMap(_), I.unSelectedProductSet && s.frxs.setMAndSData("unSelectPdArr", I.unSelectedProductSet || []), 
                            u && !d || ~c.indexOf(v) && (r.behavior_convenient_cartNumberMap = I.allProductQtyMap), 
                            y = I.allProductQtyMap ? Object.keys(I.allProductQtyMap).reduce(function(e, t) {
                                return e + I.allProductQtyMap[t];
                            }, 0) : 0, O = I.selectedProductQtyMap ? Object.keys(I.selectedProductQtyMap).reduce(function(e, t) {
                                return e + I.selectedProductQtyMap[t];
                            }, 0) : 0, S = (I.discountInfo || {}).tickets || [], r.setData({
                                behavior_convenient_selectedProductQtyMap: I.selectedProductQtyMap || {},
                                behavior_convenient_allProductSize: y,
                                behavior_convenient_selectedProductSize: O,
                                behavior_convenient_couponList: S,
                                behavior_convenient_discountsAmt: (I.discountInfo || {}).totalReduce || 0,
                                behavior_convenient_selectedProductAmt: I.selectedProductAmt || 0
                            }), y > 0) {
                                t.next = 37;
                                break;
                            }
                            return r.behavior_convenient_getRedBagList(), t.abrupt("return");

                          case 37:
                            r.setData({
                                isFootOperateFinish: !0
                            }), t.next = 44;
                            break;

                          case 40:
                            t.prev = 40, t.t0 = t.catch(0), r.setData({
                                isFootOperateFinish: !0
                            }), console.log(t.t0);

                          case 44:
                          case "end":
                            return t.stop();
                        }
                    }, n, null, [ [ 0, 40 ] ]);
                }))();
            },
            behavior_convenient_makeOrderAdd: function() {
                this.behavior_convenient_refreshPageCartData({
                    force: !0
                });
            }
        }
    };
};