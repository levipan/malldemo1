var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index"));

getApp();

Page({
    data: {},
    onLoad: function(r) {
        e.default.navigateTo({
            path: "/subPages/game/index/index",
            isRedirect: !0,
            query: r
        });
    }
});