var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../router/index.js"));

getApp().XPage({
    __page: !0,
    onLoad: function(i) {
        e.default.navigateTo({
            path: "/subLive/index/index",
            isRedirect: !0,
            query: i
        });
    }
});