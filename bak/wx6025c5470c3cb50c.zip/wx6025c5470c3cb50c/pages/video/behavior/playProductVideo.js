Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        data: {
            playerVideoMap: {},
            playTimeUpdate: {}
        },
        members: {
            isPlayVideo: !1,
            currentVideoPlayMap: {},
            handlePlayer: function(e) {
                var i = this, n = ((e.currentTarget || {}).dataset || {}).page, s = void 0 === n ? "" : n, r = o.frxs.getMOrSData("areaId") || null, l = e.detail, d = l.key, u = l.auto, c = void 0 !== u && u;
                if (4 !== this.data.playerVideoMap[d]) {
                    this.isPlayVideo = !0, this.playVideoKey = d;
                    var p = this.data.videoDataMap[d].playNum + 1;
                    this.stopPlayerVideo(function() {
                        var e;
                        if (i.setData((t(e = {}, "playerVideoMap.".concat(d), 2), t(e, "videoDataMap.".concat(d, ".playNum"), p), 
                        e)), "author" == s) {
                            var a = i.data.authorInfo.playNum + 1;
                            i.setData(t({}, "authorInfo.playNum", a));
                        }
                    }, 1, d), a.videoApi.fetchPlayCount({
                        utvId: d,
                        areaId: r
                    }, {
                        contentType: "application/json",
                        silence: !0
                    }).then(function(e) {}).catch(function(e) {
                        console.log("fetchPlayCount请求数据问题~");
                    });
                } else c || o.frxs.toptip("视频加载失败，请稍后重试～");
            },
            handlePlayPause: function(e) {
                if (console.log(e), 1 !== this.data.playerVideoMap[e.detail.key]) {
                    this.isPlayVideo = !0;
                    var a = e.detail.key;
                    this.setData(t({}, "playerVideoMap.".concat(a), 3));
                }
            },
            handlePlayEnded: function(e) {
                this.isPlayVideo = !1;
                var a = e.detail.key;
                this.setData(t({}, "playerVideoMap.".concat(a), 1));
            },
            handlePlayError: function(e) {
                console.log(e), o.frxs.toptip("视频加载失败，请稍后重试～");
                var a = e.detail.key;
                this.setData(t({}, "playerVideoMap.".concat(a), 4));
            },
            setPlayerVideoMap: function(e) {
                var t = this.data.playerVideoMap || {}, a = this.data.playTimeUpdate || {};
                e.map(function(e) {
                    var i = e.key;
                    t[i] = 1, a[i] = 0;
                }), this.setData({
                    playerVideoMap: t,
                    playTimeUpdate: a
                });
            },
            stopPlayerVideo: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3, a = arguments.length > 2 ? arguments[2] : void 0, i = {}, o = this.data.playerVideoMap || {};
                Object.keys(o).map(function(e) {
                    (2 == o[e] || 3 == o[e] && e != a) && (i["playerVideoMap.".concat(e)] = t);
                }), Object.keys(i).length > 0 ? this.setData(i, function() {
                    e && e();
                }) : "function" == typeof e && e();
            },
            stopProductVideo: function(e) {
                var a = this, i = this.data.playerVideoMap || {}, o = Object.keys(i).find(function(e) {
                    if (2 == i[e]) return e;
                });
                if (o) {
                    var n = wx.createSelectorQuery();
                    n.select(".video_key_".concat(o)).boundingClientRect(), n.exec(function(i) {
                        if (!i || 0 == i.length || !i[0] || i[0].left > 150) e && e(); else {
                            var n = i[0].top + i[0].height + 300, s = i[0].top - 300;
                            n < 0 || s > ((wx.getSystemInfoSync() || {}).windowHeight || 3e3) ? a.setData(t({}, "playerVideoMap.".concat(o), 3), function() {
                                e && e();
                            }) : e && e();
                        }
                    });
                } else e && e();
            },
            handleLike: function(e) {
                var i = this, n = ((e.currentTarget || {}).dataset || {}).page, s = void 0 === n ? "" : n, r = e.detail, l = r.key, d = r.likeStatus, u = r.callback, c = r.error, p = o.frxs.getMOrSData("userKey"), h = o.frxs.getMOrSData("areaId") || null;
                if (!(o.frxs.getMOrSData("isLogin") && !o.frxs.isNullOrWhiteSpace(p))) return c && c(), 
                void this.autoLogin({
                    success: function() {
                        i.handleLike(e);
                    }
                });
                var y = {
                    type: d,
                    utvId: l,
                    areaId: h
                };
                a.videoApi.fetchVideoThumbsup(y, {
                    contentType: "application/json",
                    silence: !0
                }).then(function(e) {
                    var a = 0 === d ? -1 : 1, o = i.data.videoDataMap[l].likeNum + a;
                    if (o = o < 0 ? 0 : o, i.setData(t({}, "videoDataMap.".concat(l, ".likeNum"), o)), 
                    "author" == s) {
                        var n = i.data.authorInfo.likeNum + a;
                        i.setData(t({}, "authorInfo.likeNum", n));
                    }
                    u && u();
                    var r = getCurrentPages();
                    r.length > 0 && r[r.length - 2].updateLikeStatus(l, d);
                }).catch(function(e) {
                    c && c(), console.log("fetchVideoThumbsup请求数据问题~");
                }), this.xsSendEvent_videoStatus({
                    event: "video_like",
                    status: 0 === d ? "unlike" : "like",
                    key: l
                });
            },
            autoLogin: function(e) {
                o.userSvr.autoLogin({
                    success: function(t) {
                        e.success && e.success();
                    },
                    fail: function(e) {
                        o.frxs.showModal({
                            title: "验证登录信息失败，请稍候重试...",
                            showCancel: !1
                        });
                    }
                });
            },
            handlePlayerStatus: function(t) {
                var a = t.detail.key, o = this.currentVideoPlayMap["".concat(a)];
                (o = e(e({}, o || {}), {}, {
                    status: t.detail.status
                })).status == i.PLAYER_STATUS.PLAYING ? (o.startTime = +new Date(), this.xsSendEvent_videoStatus({
                    event: "video_play",
                    key: a
                })) : o.status == i.PLAYER_STATUS.PAUSE && o.duration > 0 && this.xsSendEvent_videoStatus({
                    event: "video_stop",
                    key: a,
                    extend_params: {
                        curr_progress: o.currentTime,
                        total_progress: o.duration,
                        watch_time: (+new Date() - o.startTime) / 1e3
                    }
                }), this.currentVideoPlayMap["".concat(a)] = o;
            },
            handlePlayTimeupdate: function(e) {
                var t = e.detail.key, a = this.currentVideoPlayMap["".concat(t)] || {};
                a.currentTime = e.detail.progress.currentTime, a.duration = e.detail.progress.duration, 
                this.currentVideoPlayMap["".concat(t)] = a;
            },
            handleFollowAuthor: function(e) {
                var i = this, n = o.frxs.getMOrSData("userKey");
                if (o.frxs.getMOrSData("isLogin") && !o.frxs.isNullOrWhiteSpace(n)) {
                    var s = e.detail, r = s.authorId, l = s.followStatus, d = s.canCancel, u = void 0 !== d && d, c = 1 == l ? 0 : 1;
                    a.videoApi.focusAuthor({
                        authorId: r,
                        type: c
                    }, {
                        silence: !0,
                        loading: " ",
                        contentType: "application/json"
                    }).then(function(e) {
                        u && i.setData(t({}, "authorInfo.followStatus", c)), i.setData(t({}, "authorMap.author_".concat(r), c));
                        var a = getCurrentPages();
                        a.length > 1 && (console.log(a[a.length - 2].updateFollowStatus), a[a.length - 2].updateFollowStatus(r, c));
                    }).catch(function(e) {});
                } else this.autoLogin({
                    success: function() {
                        i.handleFollowAuthor(e);
                    }
                });
            },
            xsSendEvent_videoStatus: function(t) {
                var a = t.event, i = t.key, n = t.status, s = void 0 === n ? "" : n, r = t.extend_params, l = void 0 === r ? {} : r, d = this.data.navIndex, u = "".concat(this.xsvideo_sid, "video_like" === a || "video_share" === a ? "_2" : "_1"), c = {
                    videoId: i,
                    xsvideo_sid: 0 === d ? u : "",
                    tab_sort: d
                };
                c = e(e({}, c), l), "video_like" === a && (c.status = s), o.frxs.XSMonitor.sendEvent(a, c);
            }
        }
    };
};

var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../@babel/runtime/helpers/defineProperty"), a = require("../../../api/index.js"), i = require("../../../const/player-status.js"), o = getApp();