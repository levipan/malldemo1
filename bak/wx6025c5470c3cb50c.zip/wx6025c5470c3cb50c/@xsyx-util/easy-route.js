var t, r, e = require("../@babel/runtime/helpers/typeof");

function n(t) {
    var r, n, a = getApp(), o = (r = a.globalData.router, n = [], function t(r) {
        if ("object" !== e(r) || !r) return r;
        for (var a = 0; a < n.length; a++) if (n[a].target === r) return n[a].copyTarget;
        var o = {};
        return Array.isArray(r) && (o = []), n.push({
            target: r,
            copyTarget: o
        }), Object.keys(r).forEach(function(e) {
            o[e] || (o[e] = t(r[e]));
        }), o;
    }(r));
    "/" !== t.substr(0, 1) && 0 != t.indexOf("plugin-private") && (t = "/" + t);
    var u = o.find(function(r) {
        return r.path === t;
    }) || {
        path: t,
        meta: {}
    }, i = getCurrentPages(), c = i[i.length - 1].route;
    "/" !== c.substr(0, 1) && (c = "/" + c);
    var f = o.filter(function(t) {
        return t.path === c;
    });
    return {
        from: f = f[0] || {},
        to: u
    };
}

function a(t) {
    t = t || {};
    var r = [];
    for (var e in t) t.hasOwnProperty(e) && r.push("".concat(e, "=").concat(t[e]));
    return "?" + (r = r.join("&"));
}

function o(t, r) {
    return {
        success: function() {
            t.success && t.success();
        },
        fail: function(r) {
            console.log(r), t.fail && t.fail();
        },
        complete: function(e) {
            t.complete && t.complete(), r && r();
        }
    };
}

module.exports = {
    init: function(e) {
        t = e.beforeRoute || function(t, r, e) {
            e();
        }, r = e.afterRoute || function(t, r) {};
    },
    navigateTo: function(e) {
        var u = n((e = e || {}).path), i = u.from, c = u.to;
        e.query && (c.query = e.query), e.meta && Object.assign(c.meta, e.meta);
        var f = c.path + a(c.query);
        t(c, i, function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (t) {
                var n = function() {
                    r(c, i);
                }, a = o(e, n);
                a.url = f, wx.navigateTo(a);
            }
        });
    },
    navigateBack: function(e) {
        var a = (e = e || {}).delta || 1, u = getCurrentPages(), i = u.length, c = n(a > i || a === i ? u[0].route : u[i - a - 1].route), f = c.from, v = c.to;
        t(v, f, function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (t) {
                var n = function() {
                    r(v, f);
                }, u = o(e, n);
                u.delta = a, wx.navigateBack(u);
            }
        });
    },
    redirectTo: function(e) {
        var u = n((e = e || {}).path), i = u.from, c = u.to;
        e.query && (c.query = e.query), e.meta && Object.assign(c.meta, e.meta);
        var f = c.path + a(c.query);
        t(c, i, function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (t) {
                var n = function() {
                    r(c, i);
                }, a = o(e, n);
                a.url = f, wx.redirectTo(a);
            }
        });
    },
    reLaunch: function(e) {
        var u = n((e = e || {}).path), i = u.from, c = u.to;
        e.query && (c.query = e.query), e.meta && Object.assign(c.meta, e.meta);
        var f = c.path + a(c.query);
        t(c, i, function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (t) {
                var n = function() {
                    r(c, i);
                }, a = o(e, n);
                a.url = f, wx.reLaunch(a);
            }
        });
    },
    switchTab: function(e) {
        var a = n((e = e || {}).path), u = a.from, i = a.to;
        e.meta && Object.assign(i.meta, e.meta);
        var c = i.path;
        t(i, u, function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (t) {
                var n = function() {
                    r(i, u);
                }, a = o(e, n);
                a.url = c, wx.switchTab(a);
            }
        });
    }
};