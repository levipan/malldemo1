Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getRefundList: {
        url: "/user/refund/page",
        method: "get"
    },
    submitRefund: {
        url: "/user/refund/create",
        method: "POST"
    },
    cancelRefund: {
        url: "/user/refund/cancel",
        method: "POST"
    },
    getRefundDetail: {
        url: "/user/refund/detail",
        method: "GET"
    },
    getRefundTickets: {
        url: "/user/refund/queryRefundTicketInfoByRefundId",
        method: "GET"
    },
    getRefundLastDetail: {
        url: "/user/refund/latest/detail",
        method: "GET"
    },
    getRefundLastTickets: {
        url: "/user/refund/queryRefundTicketInfoBySubOrderId",
        method: "GET"
    },
    getRefundHistory: {
        url: "/user/refund/negotiation/history",
        method: "GET"
    },
    getRefundReasonTypes: {
        url: "/user/refund/reasonTypes",
        method: "POST"
    },
    refundUpload: {
        url: "/file/upload",
        method: "POST"
    },
    getRefundLatest: {
        url: "/user/refund/latest/detail",
        method: "GET"
    }
};