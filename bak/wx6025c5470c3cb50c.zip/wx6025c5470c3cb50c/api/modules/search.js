Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = require("../../@babel/runtime/helpers/defineProperty"), o = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../formatData/product"), c = (t(e = {
    fetchSearchProduct: {
        url: "/user/product/searchProduct/V4",
        cloud: !0,
        repeat: 3,
        defParams: {
            apiVersion: "V4",
            rankVersion: "v2"
        },
        fit: function(e) {
            return (e = e || {}).records = (0, r.formatProductsData)(e.records || []), e.records = e.records.filter(function(e) {
                return e;
            }).map(function(e) {
                var t = e.marketingDataDto || {}, r = "商品卡片";
                return "HOME" === e.sourceType && (r = "源本商品卡片"), e.videoUrl && (r = "视频商品卡片"), 
                (e.hasLive || e.hasNewLive || e.hasExplainVideo) && (r = "直播商品卡片"), o(o({
                    slot: r
                }, e), t);
            }), e;
        }
    },
    tkFetchSearchProduct: {
        url: "/tk/user/product/searchProduct/V3",
        cloud: !0,
        repeat: 3,
        fit: function(e) {
            return (e = e || {}).records = (0, r.formatProductsData)(e.records || []), e;
        }
    },
    fetchSearchSuggestion: {
        url: "/user/product/searchSuggestion",
        repeat: 3,
        method: "get"
    },
    tkFetchSearchSuggestion: {
        url: "/tk/user/product/searchSuggestion",
        repeat: 3,
        method: "get"
    },
    fetchPlaceHold: {
        url: "/user/product/getPlaceHold",
        repeat: 3,
        method: "get"
    },
    fetchPlaceHoldNoCached: {
        url: "/user/product/getPlaceHold",
        method: "get"
    },
    fetchHotSellingList: {
        url: "/user/product/getHotSellingList",
        cloud: !0,
        repeat: 3,
        method: "get",
        fit: function(e) {
            return (e = e || {}).rows = (0, r.formatProductsData)(e.rows || []), e;
        }
    },
    getHotSellingListTabsAndDetails: {
        url: "/user/product/getHotSellingListTabsAndDetails",
        cloud: !0,
        repeat: 3,
        method: "get"
    },
    fetchHotWord: {
        url: "/user/product/getBoostHotWord",
        repeat: 3,
        method: "get"
    },
    getFilterDashboard: {
        url: "/user/product/getFilterDashboard",
        method: "post"
    },
    tkFetchPlaceHold: {
        url: "/tk/user/product/getPlaceHold",
        repeat: 3,
        method: "get"
    }
}, "fetchPlaceHold", {
    url: "/user/product/getPlaceHold",
    repeat: 3,
    method: "get",
    cached: 6e5
}), t(e, "fetchPlaceHoldNoCached", {
    url: "/user/product/getPlaceHold",
    method: "get"
}), t(e, "getRegularlyPurchaseList", {
    url: "/user/product/getRegularlyPurchaseList",
    cloud: !0,
    repeat: 3,
    method: "get",
    fit: function(e) {
        return (e = e || {}).rows = (0, r.formatProductsData)(e.rows || []), e;
    }
}), t(e, "fetchHotWord", {
    url: "/user/product/getBoostHotWord",
    repeat: 3,
    method: "get"
}), t(e, "getFilterDashboard", {
    url: "/user/product/getFilterDashboard",
    method: "post"
}), t(e, "searchQueryRecommendSpuSns", {
    url: "/user/product/getSearchRecommenderSpusnList",
    method: "post"
}), t(e, "searchQueryRecommendProducts", {
    url: "/user/product/getSearchRecommendProducts",
    cloud: !0,
    method: "post",
    defParams: {
        rankVersion: "v2"
    },
    fit: function(e) {
        return (e = e || {}).productList = (0, r.formatProductsData)(e.productList || []), 
        e;
    }
}), t(e, "getKeywordGuess", {
    url: "/user/product/getKeywordGuess",
    method: "post"
}), t(e, "getHomeHotword", {
    url: "/home/hotWord/v1",
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/home/hotWord/v1",
    mock: !1
}), t(e, "getHomeTogetherSearch", {
    url: "/home/togetherSearch/v1",
    cloud: !0,
    method: "post"
}), t(e, "getHomeRecommenderWords", {
    url: "/home/recommenderWords/v1",
    cloud: !0,
    method: "post"
}), t(e, "getHomePlaceHolder", {
    url: "/home/placeHolder/v1",
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/home/placeHolder/v1",
    mock: !1
}), t(e, "getHomeSearch", {
    url: "/home/search/v1",
    cloud: !0,
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/home/search/v1",
    mock: !1
}), t(e, "getHomeSearchPage", {
    url: "/home/search/page/v1",
    cloud: !0,
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/search/page/v1",
    mock: !1
}), t(e, "getHomeSearchRecommender", {
    url: "/home/searchRecommender/v1",
    cloud: !0,
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/home/searchRecommender/v1",
    mock: !1
}), t(e, "getHomeSearchRecommenderPage", {
    url: "/home/searchRecommender/page/v1",
    cloud: !0,
    method: "post",
    mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/home/searchRecommender/page/v1",
    mock: !1
}), t(e, "getTogetherBuyProductDescs", {
    url: "/user/product/getTogetherBuyProductDescs",
    cloud: !0,
    method: "post"
}), t(e, "getSearchAB", {
    url: "/abtest/ab",
    repeat: 3,
    method: "post",
    defParams: {
        businessIds: [ "default" ]
    }
}), t(e, "getSamplingAbVersion", {
    url: "/get_experiment_variables",
    repeat: 3,
    method: "post"
}), t(e, "tmSearchRankList", {
    url: "/home/rank/v1",
    cloud: !0,
    method: "post"
}), e);

exports.default = c;