Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    closeGroupOrder: {
        url: "/order/closeGroupOrder",
        method: "post"
    },
    createGroupOrder: {
        url: "/order/createGroupOrder",
        method: "post"
    },
    getOrderLogistics: {
        url: "/order/v1/getOrderLogistics",
        method: "post"
    },
    getOrderAddress: {
        url: "/order/v1/getOrderAddress",
        method: "post"
    },
    updateReceiptAddress: {
        url: "/order/updateReceiptAddress",
        method: "post"
    },
    signOrder: {
        url: "/order/sign",
        method: "post",
        repeat: 3
    },
    closeOrder: {
        url: "/order/closeOrder",
        method: "post"
    },
    saveOrder: {
        url: "/order/create",
        cloud: !0
    },
    getOrderUserList: {
        url: "/order/v1/getOrderUserList"
    },
    getOrderDetails: {
        url: "/order/v1/getOrderDetails"
    },
    fetchNewUser: {
        mockUrl: "http://webuser.dev2.xsyxsc.cn/tradeorder/user/new",
        url: "/user/new"
    },
    isNewUser: {
        url: "/user/newUser",
        cached: 3e4
    },
    getOrderDetails4Share: {
        url: "/order/getOrderDetails4Share"
    },
    getPaymentOrderDetails: {
        url: "/order/getPaymentOrderDetails"
    },
    billoflading: {
        url: "/payment/billoflading"
    },
    orderTips: {
        url: "/brandhouse/orderTips",
        cached: 3e4
    },
    getNewOrderAreaCnt: {
        url: "/order/v1/getOrderAreaCnt"
    },
    getOrderAreaCnt: {
        url: "/order/getOrderAreaCnt"
    },
    delOrder: {
        url: "/order/delOrder"
    },
    fetchStoreIndexMetric: {
        url: "/user/store/queryStoreIndexMetric",
        cached: 6e4,
        method: "post"
    },
    getHistoryList: {
        url: "/order/v1/getUserOrderHistoryList",
        cached: 6e4,
        method: "post"
    },
    queryOrderUserList: {
        url: "/order/v1/queryOrderUserList",
        method: "post"
    },
    getGrayRisk: {
        url: "/gray/risk",
        method: "get"
    },
    getOrderDynamic: {
        url: "/order/v1/orderDynamic",
        method: "post"
    },
    getLogsticDetail: {
        url: "/order/getLogsticDetail",
        method: "post"
    },
    getLogsticLocation: {
        url: "/order/getLogsticLocation",
        method: "post"
    }
};