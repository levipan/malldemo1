Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../formatData/product"), o = require("../formatData/windows"), u = {
    getBaseCommonProduct: {
        url: "/user/product/getBaseCommonProduct",
        method: "post",
        cloud: !0
    },
    getBiRankPd: {
        url: "bi/rankProduct/page",
        method: "post"
    },
    getAreaDetailList: {
        url: "/tk/getAreaDetailList",
        method: "get"
    },
    fetchGetShowBrandhouseInfo: {
        url: "/user/store/getShowBrandhouseInfo",
        cached: 6e4
    },
    fetchIndexProduct: {
        url: "/user/product/indexProduct"
    },
    fetchIndexBanner: {
        url: "/user/banner/indexBanner"
    },
    fetchIndexBannerList: {
        url: "/ads",
        mock: !1,
        defParams: {
            encodeCmsUrl: !0
        }
    },
    thumbsup: {
        url: "/user/product/thumbsup"
    },
    checkProduct: {
        url: "/user/product/checkProduct"
    },
    fetchGetSaleQtyAndPreference: {
        url: "/user/product/getSaleQtyAndPreference"
    },
    fetchIndexAd: {
        url: "/user/advertisement/queryIndexAd/v4",
        mockUrl: "http://172.16.10.43:8262/user/advertisement/queryIndexAd/v3",
        mock: !1
    },
    fetchIndexMarketingData: {
        url: "/user/product/indexProductMarketingData",
        mockUrl: "http://172.16.10.43:8262/user/product/indexProductMarketingData",
        mock: !1,
        repeat: 3,
        cached: 5e3
    },
    fetchProductInfo: {
        url: "/user/product/productInfo/v3",
        cloud: !0,
        mockUrl: "http://localhost:8000/home/productInfo.json",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        },
        fit: function(t) {
            try {
                return (0, r.formatProductInfoData)(t);
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                return t;
            }
        }
    },
    fetchImgtextList: {
        url: "/user/onlineImgtext/imgtextList/v2",
        mockUrl: "http://localhost:8000/home/imgtextList.json",
        mock: !1
    },
    fetchGetUserPurchaseRecord: {
        url: "/user/product/getUserPurchaseRecord",
        mockUrl: "http://localhost:8000/home/getUserPurchaseRecord.json",
        mock: !1
    },
    fetchSearchGetAbFlag: {
        url: "/user/product/getAbFlag",
        repeat: 3,
        method: "get"
    },
    fetchSearchSuggestion: {
        url: "/user/product/searchSuggestion",
        repeat: 3,
        method: "get"
    },
    fetchCateMenuItems: {
        url: "/user/product/indexWindows/v4",
        mockUrl: "http://mock.xsyxapp.com/user/product/indexWindows",
        cached: 6e4,
        mock: !1,
        repeat: 3,
        fit: function(t) {
            return (0, o.formatWindowsData)(t);
        }
    },
    fetchCateMenu: {
        url: "/user/window/classifyWindows",
        cached: 6e4,
        mock: !1,
        repeat: 3,
        fit: function(t) {
            return (0, o.formatClassifyWindowsData)(t);
        }
    },
    fetchIndexSortWindows: {
        url: "/user/product/indexSortWindows",
        mockUrl: "http://mock.xsyxapp.com/user/product/indexWindows",
        mock: !1,
        repeat: 3,
        fit: function(t) {
            return (0, o.formatSortWindowsData)(t);
        }
    },
    fetchIndexTopWindows: {
        url: "/user/window/getWindows",
        repeat: 3,
        fit: function(t) {
            return (0, o.formatSortWindowsData)(t);
        }
    },
    fetchCommonWindows: {
        url: "/user/window/getCommonWindows",
        repeat: 3,
        fit: function(t) {
            return {
                windowsLists: (0, o.formatCommonWindowsData)(t),
                risk: t.risk
            };
        }
    },
    fetchCommonProducts: {
        url: "/user/product/getCommonProducts",
        cloud: !0,
        repeat: 3,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales", "bb" ],
        fit: function(t) {
            return ((t = t || {}).products || []).length > 0 && (t.products = (0, r.formatProductsData)(t.products || [])), 
            t.rankData && (t.rankData.rankProducts = (0, r.formatProductsData)(t.rankData.rankProducts || [])), 
            t.recommendData && (t.recommendData.recommendProducts = (0, r.formatProductsData)(t.recommendData.recommendProducts || [])), 
            t;
        }
    },
    fetchVideoViewCount: {
        url: "/user/product/videoViewCount",
        mockUrl: "http://mock.xsyxapp.com/user/product/videoViewCount",
        mock: !1
    },
    fetchVideoThumbsup: {
        url: "/user/product/videoThumbsup",
        mockUrl: "http://mock.xsyxapp.com/user/product/videoThumbsup",
        mock: !1
    },
    fetchGetLive: {
        url: "/user/product/live/currentV2",
        mockUrl: "http://172.16.14.83:8262/user/product/live/current",
        mock: !1,
        fit: function(t) {
            if (((t || {}).productLiveDto || {}).prId > 0) {
                (t || {}).productLiveDto;
                t.productLiveDto = (0, r.formatProductData)(t.productLiveDto);
            }
            return t;
        }
    },
    queryNewUserProduct: {
        url: "/product/queryNewUserProduct",
        cloud: !0,
        repeat: 3
    },
    fetchGetProducts: {
        url: "/user/window/getProducts/v4",
        cloud: !0,
        mockUrl: "http://127.0.0.1:8000/test-data.json",
        repeat: 3,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            return (((t = t || {}).businessData || {}).records || []).length > 0 && (t.businessData.records = (0, 
            r.formatProductsData)(t.businessData.records || [])), t;
        }
    },
    fetchTopWindowProducts: {
        url: "/user/window/getProducts/v5",
        cloud: !0,
        repeat: 3,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales", "blackBox" ],
        fit: function(t) {
            return (((t = t || {}).businessData || {}).products || []).length > 0 && (t.businessData.products = (0, 
            r.formatProductsData)(t.businessData.products || [])), t;
        }
    },
    fetchGetRecommendProducts: {
        url: "/bi/classifyWindow/recommend",
        cloud: !0,
        repeat: 3,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            return (((t = t || {}).businessData || {}).records || []).length > 0 && (t.businessData.records = (0, 
            r.formatProductsData)(t.businessData.records || []).map(function(t) {
                return t._type = "RECOMMEND", t;
            })), t;
        }
    },
    fetchGetProductsMarketingData: {
        url: "/user/product/getProductsMarketingData/v3",
        cloud: !0,
        mockUrl: "http://172.16.10.43:8262/user/product/indexProductMarketingData",
        defParams: {
            rankVersion: "v2"
        },
        mock: !1,
        repeat: 3,
        cached: 5e3
    },
    fetchGetIndexWindowById: {
        url: "/user/window/getIndexWindowById",
        mock: !1,
        repeat: 3
    },
    fetchGetQueryIndexOperationPositions: {
        url: "/cms/queryIndexOperationPositions",
        mock: !1,
        method: "get",
        repeat: 3
    },
    fetchGetQueryLandingPageStatus: {
        method: "get",
        url: "/cms/queryLandingPageStatus",
        mock: !1,
        repeat: 3
    },
    fetchStoreLicences: {
        method: "post",
        url: "/user/product/productInfo/license",
        cloud: !0,
        mock: !1
    },
    fetchIndexIcons: {
        method: "post",
        url: "/mall/indexIcons",
        mock: !1,
        defParams: {
            encodeCmsUrl: !0
        }
    },
    getStraGrayConfig: {
        url: "/mall/experiment/getStrategy",
        method: "get"
    },
    getMixRecommendProducts: {
        url: "/user/product/getMixRecommendProducts/v4",
        cloud: !0,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            return (t = t || {
                businessData: {}
            }).businessData = t.businessData || {
                records: [],
                code: "no_data"
            }, t.businessData.records = (0, r.formatProductsData)(t.businessData.records || []), 
            t.businessData.rankData && (t.businessData.rankData.rankProducts = (0, r.formatProductsData)(t.businessData.rankData.rankProducts || [])), 
            t;
        },
        feed: function(t) {
            return t = t.code ? t : {
                records: [],
                code: "no_data"
            };
        }
    },
    fetchProductList: {
        url: "/tk/queryTkProductByType",
        cloud: !0,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tk/queryTkProductByType",
        method: "post"
    },
    fetchTKPoster: {
        url: "/tk/queryPosterByType",
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tk/queryPosterByType"
    },
    getBIRecommendRanking: {
        url: "/bi/getBIRecommendRanking",
        cloud: !0,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/100040/mall-promotion/DEV/bi/getBIRecommendRanking",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        },
        fit: function(t) {
            return t.neighbourProduct = (0, r.formatProductsData)(t.neighbourProduct || []), 
            t.recommendProduct = (0, r.formatProductsData)(t.recommendProduct || []), t;
        }
    },
    getBIRecommendProducts: {
        url: "/bi/getBIRecommendProducts",
        cloud: !0,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/100040/mall-promotion/DEV/bi/getBIRecommendProducts",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            return t.businessData = (0, r.formatProductsData)(t.businessData || []), t;
        }
    },
    getBIRecommendProductsV2: {
        url: "/bi/getBIRecommendProducts/v2",
        cloud: !0,
        method: "post",
        defParams: {
            rankVersion: "v2"
        },
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            try {
                var o = (t || {}).businessData, u = [];
                o && o.length && (o.forEach(function(t) {
                    "STORE" === t.type && t.storeProduct ? u.push(e({
                        type: t.type,
                        adId: t.adId
                    }, t.storeProduct)) : "HOME" === t.type && t.homeProduct && u.push(e({
                        type: t.type,
                        adId: t.adId
                    }, t.homeProduct));
                }), t.businessData = (0, r.formatProductsData)(u || []));
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("getBIRecommendProductsV2,error", t);
            }
            return t;
        }
    },
    getDetailRecommend: {
        url: "/bi/getDetailRecommend",
        method: "POST",
        cloud: !0,
        dynamicParams: [ "ndTrueSales" ],
        fit: function(t) {
            try {
                var o = t || {}, u = o.neighbourProducts, c = void 0 === u ? [] : u, a = o.similarProducts, d = void 0 === a ? [] : a, s = o.ab, n = void 0 === s ? {} : s;
                if (c && c.length) {
                    var i = c.reduce(function(t, r) {
                        var o = "STORE" === r.type ? r.storeProduct : r.homeProduct;
                        return o && t.push(e({
                            ab: n,
                            type: r.type,
                            adId: r.adId
                        }, o)), t;
                    }, []);
                    t.neighbourProducts = (0, r.formatProductsData)(i || []);
                }
                if (d && d.length) {
                    var m = d.reduce(function(t, r) {
                        var o = "STORE" === r.type ? r.storeProduct : r.homeProduct;
                        return o && t.push(e({
                            ab: n,
                            type: r.type,
                            adId: r.adId
                        }, o)), t;
                    }, []);
                    t.similarProducts = (0, r.formatProductsData)(m || []);
                }
            } catch (t) {
                t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
                console.log("getBIRecommendProductsV2,error", t);
            }
            return t;
        }
    },
    queryShoppingPositionAndProduct: {
        url: "/cms/queryShoppingPositionAndProduct/v2",
        cloud: !0,
        method: "POST"
    },
    getTmIndexCard: {
        url: "/cms/card/getIndexCard/v2",
        method: "POST"
    },
    getSeckillProduct: {
        url: "/favorite/product",
        cloud: !0,
        method: "post",
        defParams: {
            rankVersion: "v2"
        },
        fit: function(e) {
            var o = [];
            return e && e.length && e.forEach(function(t) {
                "STORE" === t.type && o.push(t.storeProduct);
            }), (0, r.formatProductsData)(o).map(function(e) {
                if (e.now = Date.now(), wx.$.isArray(e.skuSnCouponList)) {
                    var r = e.skuSnCouponList.map(function(t) {
                        var e = t.toolName;
                        if ("DISCOUNT" === t.toolType) e += "满".concat(t.orderAmountLimit, "元 | ").concat(1 * (t.discount / 10).toFixed(2), "折 | 最高优惠").concat(t.amount, "元"); else if (t.orderStep) {
                            e = e + " | " + t.orderStep.map(function(t) {
                                return "满".concat(t.useOrderAmountLimit, "减").concat(t.singleToolAmount, "元");
                            }).join(" | ");
                        } else e += "满".concat(t.orderAmountLimit, "减").concat(t.amount);
                        return e;
                    });
                    e.oldSkuSnCouponList = t(e.skuSnCouponList), e.skuSnCouponList = r;
                }
                return e;
            });
        }
    },
    queryWindowsSale: {
        url: "activity/query416TopicWindows",
        method: "post"
    },
    queryProductSale: {
        url: "activity/query416WindowProductDetails",
        method: "post"
    },
    getRecommendProduct: {
        url: "ad/getRecommendProduct",
        method: "post",
        defParams: {
            rankVersion: "v2",
            requireCoupon: "true",
            channelUse: "WXAPP"
        }
    },
    getRecommendProductV2: {
        url: "ad/getRecommendProductV2",
        method: "post",
        defParams: {
            rankVersion: "v2",
            requireCoupon: "true",
            channelUse: "WXAPP"
        }
    },
    getStoreNotice: {
        url: "/notice/getNotice",
        method: "post",
        cached: 6e3
    },
    getOtCategory: {
        method: "POST",
        url: "/cms/hourly/rush/category/info"
    },
    getOtCategoryProduct: {
        url: "/cms/hourly/rush/category/product/pageInfo",
        method: "POST",
        cloud: !0
    },
    getAllOtCategoryProduct: {
        url: "/cms/hourly/rush/all/category/product/pageInfo",
        method: "POST",
        cloud: !0
    },
    getHomeClassifyList: {
        url: "/user/index/tab",
        method: "POST"
    },
    getHomeProductList: {
        url: "/user/index/product/tab",
        method: "POST",
        cloud: !0
    },
    getClassifyList: {
        url: "/user/classify/list",
        method: "POST"
    },
    getClassifyProductList: {
        url: "/user/classify/product/list",
        method: "POST",
        cloud: !0
    }
};

exports.default = u;