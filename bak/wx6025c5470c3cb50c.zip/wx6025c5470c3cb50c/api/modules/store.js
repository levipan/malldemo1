var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

e(require("../../utils/common"));

exports.default = {
    getWeatherInfo: {
        url: "/weather/getWeatherInfo"
    },
    checkShowTel: {
        url: "/store/checkCallGrayOrgArea"
    },
    signUpAdd: {
        url: "/store/signUp/add",
        method: "post"
    },
    signUpSendMsg: {
        url: "/store/signUp/sendMsg",
        method: "post"
    },
    getOpenStoreCitys: {
        url: "/getOpenStoreCitys",
        method: "get",
        mock: !1,
        fit: function(e, r) {
            var t = [];
            return function e(r, o) {
                r.forEach(function(r) {
                    if (t.push({
                        id: r.orgAreaId,
                        parentId: r.parentId,
                        text: r.orgAreaName,
                        deep: o
                    }), r.orgAreaVos) return e(r.orgAreaVos, o + 1);
                });
            }(e, 0), t;
        }
    },
    signUpOrgArea: {
        url: "/orgArea",
        method: "post",
        mock: !1,
        fit: function(e, r) {
            return function e(r, t) {
                return r.forEach(function(r) {
                    var o = 0;
                    if (r.orgAreaVos) return o++, t.push({
                        id: r.orgAreaId,
                        parentId: r.parentId,
                        text: r.orgAreaName,
                        deep: o
                    }), e(r.orgAreaVos, t);
                }), t;
            }(e, []);
        }
    },
    signActivityUpOrgArea: {
        url: "/orgArea",
        method: "post",
        mock: !1,
        fit: function(e, r) {
            return function e(r, t) {
                return r.forEach(function(r) {
                    var o = 0;
                    if (r.orgAreaVos) return o++, t.push({
                        id: r.orgAreaId,
                        parentId: r.parentId,
                        text: r.orgAreaName,
                        deep: o
                    }), e(r.orgAreaVos, t);
                    t.push({
                        id: r.orgAreaId,
                        parentId: r.parentId,
                        text: r.orgAreaName
                    });
                }), t;
            }(e, []);
        }
    },
    getNearStoreList: {
        url: "store/getNearStoreList",
        cloud: !0,
        dynamicParams: [ "blackBox" ],
        method: "post"
    },
    getNearStoreListV2: {
        url: "store/getNearStoreListV2",
        cloud: !0,
        dynamicParams: [ "blackBox" ],
        method: "post"
    },
    getIpNearStore: {
        url: "store/getIpNearStore",
        method: "get",
        cloud: !0
    },
    getRecommendStore: {
        url: "store/recommend/getRecommendStore",
        method: "post",
        cloud: !0
    }
};