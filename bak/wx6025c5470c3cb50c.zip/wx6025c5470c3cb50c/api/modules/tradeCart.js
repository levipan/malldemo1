Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getImmediatelyBuyV3: {
        url: "/xsyx/cart/immediatelyBuy",
        method: "post",
        cloud: !0
    },
    getCanSaleProductListV3: {
        url: "/xsyx/cart/listCanSale",
        method: "post",
        cloud: !0
    },
    getUserCartV3: {
        url: "/xsyx/cart/list",
        method: "post",
        cloud: !0
    },
    cartPaymentV3: {
        url: "xsyx/cart/quick/payment",
        method: "post",
        cloud: !0
    },
    homeCartCount: {
        url: "/cart/home/cartCount",
        method: "post"
    },
    homeSync: {
        url: "/cart/home/sync",
        method: "post"
    },
    homeList: {
        url: "/cart/home/list",
        repeat: 3,
        method: "post",
        cloud: !0
    },
    homeImmediatelyBuy: {
        url: "/cart/home/immediatelyBuy",
        repeat: 3,
        method: "post",
        cloud: !0
    },
    canSaleProductList: {
        url: "/cart/v2/user/canSaleProductList",
        cloud: !0,
        method: "post"
    },
    immediatelyBuy: {
        url: "/cart/v2/user/immediatelyBuy",
        cloud: !0,
        repeat: 3,
        method: "post"
    },
    getUserCartV2: {
        url: "/cart/v2/user/list",
        cloud: !0,
        repeat: 3,
        method: "post"
    },
    cartIsGray: {
        url: "/cart/store/isGray",
        cached: 12e4,
        method: "post"
    },
    cartSync: {
        url: "/cart/user/sync",
        method: "post"
    },
    getCanSaleList: {
        url: "/cart/user/canSale/product/list",
        cloud: !0,
        repeat: 3,
        method: "post"
    },
    orderCancel: {
        url: "/cart/user/orderCancel",
        method: "post"
    },
    orderCartSkuList: {
        url: "/cart/areaSku/orderCartSkuList",
        cloud: !0,
        method: "post"
    },
    togetherOrder: {
        url: "/cart/v2/user/cart/together",
        cloud: !0,
        method: "post"
    },
    cartList: {
        url: "/cart/user/list",
        cloud: !0,
        method: "post"
    },
    canSaleAmount: {
        url: "/cart/v2/user/canSale/product/amount",
        method: "post",
        defParams: {
            recommendType: "0"
        }
    },
    canSaleProduct: {
        url: "/cart/user/canSale/product/list",
        cloud: !0,
        method: "post"
    },
    simpleList: {
        url: "/cart/user/simple/list",
        method: "post",
        cloud: !0
    },
    fetchShopCar: {
        url: "/cart/areaSku/popupList",
        cloud: !0
    },
    fetchPriceList: {
        contentType: "application/json",
        url: "/cart/areaSku/priceList",
        cloud: !0
    },
    queryAvatarUsers: {
        url: "/cart/coupon/avatarUsedCount",
        method: "post"
    },
    queryProductPhoto: {
        url: "/cart/product/photo",
        method: "get"
    },
    queryUsingUsers: {
        url: "/cart/coupon/usingCount",
        method: "get"
    },
    togetherOrderV3: {
        url: "/xsyx/cart/together/order",
        cloud: !0,
        method: "post"
    }
};