Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../formatData/product"), r = {
    fetchHotSellingList: {
        url: "/user/product/getHotSellingList",
        cloud: !0,
        repeat: 3,
        method: "get",
        fit: function(r) {
            return (r = r || {}).rows = (0, e.formatProductsData)(r.rows || []), r;
        }
    },
    getHotSellingListTabsAndDetails: {
        url: "/user/product/getHotSellingListTabsAndDetails",
        cloud: !0,
        defParams: {
            rankVersion: "v2"
        },
        repeat: 3,
        method: "get"
    },
    rankMore: {
        url: "/user/product/rank/more",
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/rank/more",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        }
    },
    getRefreshListRanks: {
        url: "/user/product/rank/hotList",
        cloud: !0,
        repeat: 3,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/getRefreshListRanks",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        }
    },
    newProductsRanks: {
        url: "/user/product/rank/new",
        cloud: !0,
        repeat: 3,
        method: "post",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/rank/newProducts",
        defParams: {
            rankVersion: "v2"
        }
    },
    specialOfferRanks: {
        url: "/user/product/rank/offer",
        cloud: !0,
        repeat: 3,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/rank/specialOffer",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        }
    },
    repurchaseRanks: {
        url: "/user/product/rank/repurchase",
        cloud: !0,
        repeat: 3,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/rank/repurchase",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        }
    },
    shareRanks: {
        url: "/user/product/rank/share",
        cloud: !0,
        repeat: 3,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/uatmallapplet/RankingApi/user/product/rank/share",
        mock: !1,
        defParams: {
            rankVersion: "v2"
        }
    },
    abtest: {
        url: "/abtest/ab",
        repeat: 3,
        method: "post"
    }
};

exports.default = r;