Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getSecKillState: {
        url: "/auth/secKill/getSecKillState",
        method: "POST"
    },
    getSubscribeState: {
        url: "/auth/secKill/getSubscribeState",
        method: "POST"
    },
    getSubscribeList: {
        url: "/secKill/getSubscribeList",
        method: "POST"
    },
    getWinnerList: {
        url: "/secKill/getWinnerList",
        method: "POST"
    },
    doSecKill: {
        url: "/auth/secKill/doSecKill",
        method: "POST"
    },
    doReserve: {
        url: "/auth/reserve/doReserve",
        method: "POST"
    },
    queryMySecKillPage: {
        url: "/auth/secKill/queryMySecKillPage",
        method: "POST"
    },
    getWinningVideo: {
        url: "/auth/secKill/getWinningVideo",
        method: "POST"
    },
    queryActivityList: {
        url: "/secKill/queryActivityList",
        method: "POST",
        mock: !1,
        mockData: {
            code: "1001",
            data: {
                areaId: 120,
                storeId: 66880000324090,
                goodsList: [ {
                    activityId: 104475,
                    eskuSn: "00202102171010200050074599",
                    goodsImgUrl: "http://frxsuatoss.xsyxsc.cn/item/dailyPush/20210217/R2poaw==.jpg",
                    goodsName: "新鲜食用百合1袋",
                    goodsState: 0,
                    limitQty: 505,
                    saleAmt: 13.23,
                    sku: "500020919",
                    skuSn: "000087407"
                }, {
                    activityId: 104475,
                    eskuSn: "00202102171010200050074599",
                    goodsImgUrl: "http://frxsuatoss.xsyxsc.cn/item/dailyPush/20210217/R2poaw==.jpg",
                    goodsName: "新鲜食用百合1袋",
                    goodsState: 1,
                    limitQty: 505,
                    saleAmt: 13.23,
                    sku: "500020919",
                    skuSn: "000087401"
                }, {
                    activityId: 102988,
                    eskuSn: "00202101231011425920062942",
                    goodsImgUrl: "http://frxsuatoss.xsyxsc.cn/item/20210123/R2ZKag==.jpg",
                    goodsName: "牛油烧烤猪",
                    goodsState: 2,
                    limitQty: 55,
                    saleAmt: 8.66,
                    sku: "500018472",
                    skuSn: "000064353"
                }, {
                    activityId: 104475,
                    eskuSn: "00202102171010200050074599",
                    goodsImgUrl: "http://frxsuatoss.xsyxsc.cn/item/dailyPush/20210217/R2poaw==.jpg",
                    goodsName: "新鲜食用百合1袋",
                    goodsState: 3,
                    limitQty: 505,
                    saleAmt: 13.23,
                    sku: "500020919",
                    skuSn: "000077804"
                }, {
                    activityId: 102988,
                    eskuSn: "00202101231011425920062942",
                    goodsImgUrl: "http://frxsuatoss.xsyxsc.cn/item/20210123/R2ZKag==.jpg",
                    goodsName: "牛油烧烤猪",
                    goodsState: 1,
                    limitQty: 55,
                    saleAmt: 8.66,
                    sku: "500018472",
                    skuSn: "000064355"
                } ],
                ruleImgUrl: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/seckill/1_2/seckill-rule.png",
                turnOver: !1,
                activityList: [ {
                    skuSn: "",
                    drawId: "",
                    taskId: "1",
                    activityId: "1",
                    goodsName: "苹果8",
                    serverTime: "2022-04-26 21:00:00",
                    shouldShow: !0,
                    goodsImgUrl: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/seckill/seckill_bg_top.png",
                    activityCode: "",
                    activityName: "",
                    periodNumber: "第一期",
                    secKillPrice: "9.9",
                    activityState: 1,
                    secKillEndTime: "2022-06-17 20:00:00",
                    activityEndTime: "2022-06-16 21:00:00",
                    secKillStartTime: "2022-06-16 17:59:00",
                    subscribeEndTime: "2022-06-16 17:56:00",
                    activityStartTime: "2022-06-16 21:00:00",
                    subscribeStartTime: "2022-06-24 15:53:00"
                } ]
            },
            rspCode: "success",
            success: !0
        }
    },
    getSpecialSecKillStateBatch: {
        url: "/auth/secKill/getSpecialSecKillStateBatch",
        method: "POST"
    },
    getSpecialSecKillState: {
        url: "/auth/secKill/getSpecialSecKillState",
        method: "POST"
    },
    ontimeJoinSeckill: {
        url: "/auth/secKill/secKillOnTime",
        method: "POST"
    },
    saveTurnState: {
        url: "/auth/secKill/saveTurnState",
        method: "POST"
    }
};