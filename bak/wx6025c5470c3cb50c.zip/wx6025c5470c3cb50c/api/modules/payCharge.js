Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getPhoneProduct: {
        method: "GET",
        url: "/pay-charge/payment/v2/phoneinfo"
    },
    getIspPhoneProduct: {
        method: "GET",
        url: "/pay-charge/payment/v2/phoneinfo/ispchange"
    }
};