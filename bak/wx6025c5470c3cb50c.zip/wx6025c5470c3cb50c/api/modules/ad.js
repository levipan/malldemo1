Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getADS: {
        url: "/ads/v1",
        method: "get"
    }
};