Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchLiveInfo: {
        url: "/tv/room/query",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/room/query",
        mock: !1
    },
    fetchLiveProducts: {
        url: "/tv/products/query"
    },
    createliveFocus: {
        url: "/tv/room/subscribe",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/room/focus",
        mock: !1
    },
    fetchReportType: {
        url: "/tv/report/types",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/report/types",
        mock: !1
    },
    createLiveReport: {
        url: "/tv/report/submit",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/report/submit",
        mock: !1
    },
    fetchReportList: {
        url: "/tv/report/list",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/report/list",
        mock: !1
    },
    createLivePoster: {
        url: "/tv/jigsaws/create",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/jigsaws/create",
        mock: !1
    },
    createLiveLike: {
        url: "/thumbsup/common/submit",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/room/thumb",
        mock: !1
    },
    getCartPocketData: {
        url: "/tv/products/list"
    },
    fetchLotteryInfo: {
        url: "/tv/activity/luckDraw/info",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/activity/luckDraw/info"
    },
    fetchRedPacketInfo: {
        url: "/tv/activity/redPacket/info",
        method: "get",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/activity/redPacket/info"
    },
    addAddress: {
        url: "/tv/activity/luckDraw/addAddress"
    },
    signUpLottery: {
        url: "/tv/activity/luckDraw/signUp"
    },
    getRedPacket: {
        url: "/tv/activity/redPacket/receive"
    },
    reportLotteryMission: {
        url: "/tv/activity/luckDraw/report"
    },
    getLiveAwardsRecordList: {
        url: "/tv/activity/myAwards"
    },
    getLiveAwardsPeopleList: {
        url: "/tv/activity/luckDraw/awardlist"
    },
    editAddressOrPhone: {
        url: "/tv/activity/luckDraw/addAddress"
    },
    addAwardAddress: {
        url: "/tv/activity/luckDraw/addAwardAddress"
    },
    fetchWelfareActivity: {
        url: "/tv/activity/welfare/list",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/welfareActivity/list"
    },
    getWelfareActivityCoupon: {
        url: "/tv/activity/welfare/receive",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/welfare/activity/receive"
    },
    getLiveList: {
        url: "/tv/room/square",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/room/square"
    },
    reportProClick: {
        url: "/tv/products/click",
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/tv/room/square"
    }
};