Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getSignActivityInfo: {
        url: "/venue/activity/sign/customer/activityInfoV2",
        cloud: !0,
        method: "post"
    },
    signIn: {
        url: "/venue/activity/sign/customer/signIn",
        cloud: !0,
        method: "post"
    },
    shareActivity: {
        url: "/venue/activity/sign/customer/shareActivity",
        cloud: !0,
        method: "post"
    },
    lotteryAwardPackage: {
        url: "/venue/activity/sign/customer/lotteryAwardPackage",
        cloud: !0,
        method: "post"
    },
    getcreateExchangeList: {
        url: "/exchange/queryExchangePointsVenue",
        cloud: !0,
        method: "post"
    },
    getcreateExchangeList_new: {
        url: "/exchange/queryExchangePointsVenues",
        cloud: !0,
        method: "post"
    },
    exchangePoints: {
        url: "/exchange/create",
        cloud: !0,
        method: "post"
    },
    getSignPointList: {
        url: "/trans/queryUserPointsListV2",
        cloud: !0,
        method: "get"
    },
    getSignTaskList: {
        url: "/venue/activity/sign/customer/signTaskList",
        cloud: !0,
        method: "post"
    },
    getSignTaskCode: {
        url: "/venue/activity/sign/customer/signTaskCode",
        cloud: !0,
        method: "post"
    },
    completeBrowseTask: {
        url: "/venue/activity/sign/customer/completeBrowseTask",
        cloud: !0,
        method: "post"
    },
    getEggInfo: {
        url: "/venue/activity/lucky/egg/info",
        cloud: !0,
        method: "POST"
    },
    getPointOneProductList: {
        url: "/venue/activity/sign/customer/pointOneProductList",
        cloud: !0,
        method: "POST"
    },
    getProductBaseInfo: {
        url: "/venue/activity/sign/customer/productBaseInfo",
        cloud: !0,
        method: "POST"
    },
    getAppPolite: {
        url: "/venue/app/firstOrder/canJoinActivity",
        cloud: !0,
        method: "POST"
    },
    getMemberCardInfo: {
        url: "/venue/card/v1/customer/index",
        cloud: !0,
        method: "POST"
    },
    getMemberReceiveAward: {
        url: "/venue/card/v1/customer/receiveUserRights",
        cloud: !0,
        method: "POST"
    },
    getIsCanOpenCard: {
        url: "/venue/card/v1/customer/isCanOpenCard",
        cloud: !0,
        method: "POST"
    },
    userCardRecord: {
        url: "/venue/card/v1/customer/userCardRecord",
        cloud: !0,
        method: "POST"
    },
    customerUserCenter: {
        url: "/venue/card/v1/customer/userCenter",
        cloud: !0,
        method: "post",
        dynamicParams: [ "blackBox" ]
    }
};