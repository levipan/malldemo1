Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchCancelReasonList: {
        url: "/order/cancel/forward",
        method: "get"
    },
    fetchCancelConfiorm: {
        url: "/order/cancel/confirm",
        method: "post"
    },
    getUserRefundApplyDetail: {
        url: "/user/aftersales/refundApplyDetail",
        method: "get"
    },
    fetchAfterSalesApply: {
        url: "/user/aftersales/apply",
        method: "post",
        header: {
            "content-type": "application/json"
        }
    },
    fetchAfterSalesCancel: {
        url: "/user/aftersales/cancel",
        method: "post"
    },
    fetchAfterSalesDetail: {
        url: "/user/aftersales/details",
        method: "get"
    },
    awaitReturnGoodsQty: {
        url: "/user/aftersales/awaitReturnGoodsQty",
        method: "get"
    },
    getRefundType: {
        url: "/user/aftersales/getRefundType",
        method: "get"
    },
    uploadVoucherAudit: {
        url: "/user/aftersales/uploadVoucherAudit",
        method: "post"
    }
};