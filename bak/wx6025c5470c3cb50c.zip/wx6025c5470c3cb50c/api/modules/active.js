Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getActivityInfo: {
        url: "/ugc/competition/query"
    },
    fetchWorkList: {
        url: "/ugc/work/list"
    },
    fetchThumbUp: {
        url: "/ugc/work/thumbUp"
    },
    fetchWorkCity: {
        url: "/ugc/area/list",
        method: "get"
    },
    fetchTagList: {
        url: "/ugc/tag/list"
    },
    searchWorkData: {
        url: "/ugc/work/search"
    },
    createOrEditWorks: {
        url: "/ugc/work/createOrEdit"
    },
    queryWorksDetail: {
        url: "/ugc/work/query"
    },
    getRecommentGoods: {
        url: "/product/suggestion/comment/list",
        method: "get"
    },
    getBoutiqueList: {
        url: "/ugc/competition/order/list",
        method: "get"
    },
    getMyCookingList: {
        url: "/ugc/work/my",
        method: "get"
    },
    queryByIds: {
        url: "/ugc/work/queryByIds"
    },
    submitRecomment: {
        url: "/home/product/comment/submit"
    },
    getRecommentReward: {
        url: "/home/product/comment/reward",
        method: "get"
    },
    getRecommentDetail: {
        url: "/home/product/comment/detail",
        method: "get"
    },
    getRecommentList: {
        url: "/home/product/comment/list"
    }
};