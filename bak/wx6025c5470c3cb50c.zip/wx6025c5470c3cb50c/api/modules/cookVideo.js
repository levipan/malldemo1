Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../formatData/product"), o = {
    getCookInfo: {
        method: "get",
        url: "/works/competition"
    },
    queryIsBlack: {
        method: "get",
        url: "/works/black"
    },
    getRecord: {
        url: "/works/record"
    },
    addCooksInfo: {
        url: "/works/add"
    },
    getCookDetail: {
        method: "get",
        url: "/works/detail"
    },
    getSuperLiveInfo: {
        url: "/tv/room/simpleInfo",
        method: "POST"
    },
    getSuperLiveMsg: {
        url: "/tv/im/historyMessage",
        method: "GET"
    },
    getPastProducts: {
        url: "/super/hot/pastGoods",
        method: "POST",
        fit: function(o) {
            var e = o || {};
            return e.records = (0, t.formatProductsData)(e.records || []), e;
        }
    },
    getSuperProductInfo: {
        url: "/super/hot/info",
        method: "POST",
        fit: function(o) {
            var e = o || {};
            return e.product = (0, t.formatProductData)(e.product), e;
        }
    },
    thumbUpLiveMsg: {
        url: "/super/hot/moment/like/v1",
        method: "GET"
    }
};

exports.default = o;