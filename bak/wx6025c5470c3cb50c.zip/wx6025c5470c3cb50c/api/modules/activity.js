Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getSuperActivity: {
        url: "/venue/shg/custom/getCardInfo",
        cloud: !0
    },
    showHelpUserReceive: {
        url: "/venue/shg/custom/v3/analyzeInviteCodeStatus",
        cloud: !0
    },
    helpUserReceive: {
        url: "/venue/shg/custom/v2/acceptShare",
        cloud: !0
    },
    showStoreCoupon: {
        url: "/venue/shg/custom/v3/acceptStoreShare",
        cloud: !0
    },
    receieveStoreCoupon: {
        url: "/venue/shg/custom/v3/drawAward",
        cloud: !0
    },
    getInviteCode: {
        url: "/venue/shg/custom/applyShareCodeShortLink",
        cloud: !0
    },
    getPhonePopup: {
        url: "/venue/hfcz/draw",
        dynamicParams: [ "blackBox" ]
    }
};