Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchGetUserConfig: {
        url: "/user.config.json",
        method: "get"
    },
    fetchCenterStoreData: {
        url: "/erea-data.json",
        method: "get"
    },
    fetchCenterStoreDataWhiteList: {
        url: "/erea-data-whitelist.json",
        method: "get"
    }
};