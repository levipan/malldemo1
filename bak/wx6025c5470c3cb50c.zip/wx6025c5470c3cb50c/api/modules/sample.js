Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchSomeData: {
        url: "/sample/data/normal",
        mockUrl: "/mock/data/normal",
        mockData: {
            rspCode: "success",
            data: []
        },
        cached: "5000",
        sensitive: "11",
        method: "POST",
        concurrency: !1,
        mock: !1,
        fit: function(e, t) {
            return e;
        },
        repeat: 3,
        feed: function(e, t) {}
    }
};