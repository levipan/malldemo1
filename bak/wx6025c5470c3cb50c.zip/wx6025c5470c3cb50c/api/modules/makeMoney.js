Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getCmsCardProductList: {
        url: "/storefront-store/operation/product/cmsCardProductList"
    },
    cmsLayoutCardProduct: {
        url: "/storefront-store/operation/product/cmsLayoutCardProduct"
    },
    checkShareProduct: {
        url: "/storefront-store/operation/product/checkShareProduct"
    },
    storeRecommend: {
        url: "/storefront-store/operation/product/storeRecommend"
    },
    queryWindowName: {
        url: "/storefront-store/operation/product/queryWindowName"
    },
    queryProductByWindowName: {
        url: "/storefront-store/operation/product/queryProductByWindowCode"
    },
    getStoreHotWord: {
        url: "/storefront-store/operation/product/getStoreHotWord"
    },
    searchProduct: {
        url: "/storefront-store/operation/product/searchProduct"
    },
    queryWindowNameNew: {
        url: "/storefront-store/operation/product/queryWindowNameNew"
    }
};