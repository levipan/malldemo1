Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    updateCurrStoreId: {
        url: "/member/user/updateCurrStoreId"
    },
    listUserHistoryStorePickUpByPage: {
        url: "/member/user/listUserHistoryStorePickUpByPage"
    },
    getStoreUserPickUpList: {
        url: "/member/user/getStoreUserPickUpList"
    },
    deleteHistoryStore: {
        url: "/member/user/deleteUserHistoryStorePickUpByStoreId"
    },
    getHistoryStore: {
        url: "/member/user/getStoreUserPickUpList"
    },
    getUserInfo: {
        url: "/member/user/getUserInfo"
    },
    updateUserImageNickName: {
        url: "/member/user/updateUserImageNickName"
    },
    updateUserImageNickNameV2: {
        url: "/member/user/updateUserImageNickNameV2"
    },
    getUserInfoUpdateCoolDown: {
        method: "GET",
        url: "/member/user/getUserInfoUpdateCoolDown"
    },
    addProductSub: {
        url: "/member/productSub/addProductSub"
    },
    listProductSub: {
        url: "/member/productSub/listProductSub"
    },
    cancelProductSub: {
        url: "/member/productSub/cancelProductSub"
    },
    listIndexProductSub: {
        url: "/member/productSub/listIndexProductSub"
    },
    getSmallXinXinTotal: {
        url: "/member/points/getUserTotalPoints",
        method: "get"
    },
    getPointsNumOfDay: {
        url: "/member/points/getPointsNumOfDay"
    },
    getListResources: {
        url: "/member/optionConf/getUserOptionConf",
        method: "POST",
        cached: 6e5
    },
    saveOrUpdateUserOptionConf: {
        url: "/member/optionConf/saveOrUpdateUserOptionConf",
        method: "POST"
    },
    getPlaceSuggestion: {
        url: "/member/map/placeSuggestion",
        method: "post",
        cloud: !0
    },
    getWxGeocoder: {
        url: "/member/map/geocoder",
        method: "post",
        cloud: !0
    },
    getFileSummary: {
        url: "/member/qualification/getQualificationCategory",
        method: "post"
    },
    getDefaultAddress: {
        url: "/member/address/getDefaultAddress",
        method: "post",
        mockData: {
            data: {
                city: "市级行政区名称",
                cityId: "市级行政区编号",
                county: "区级行政区名称",
                address: "详细地址",
                countyId: "区级行政区编号",
                district: "县级/街道行政区名称",
                province: "省级行政区名称",
                addressId: "收货地址id",
                districtId: "县级/街道行政区编号",
                provinceId: "省级行政区编号",
                addressIsDefalut: "是否是默认地址 1：是 0：否",
                consigneeMobileNo: "收货人手机号",
                consigneeNickName: "收货人名称"
            },
            rspCode: "success",
            rspDesc: "操作成功!"
        }
    },
    getAddressList: {
        url: "/member/address/listAddress",
        method: "post"
    },
    deleteAddress: {
        url: "/member/address/deleteAddress",
        method: "post"
    },
    getAddressDetail: {
        url: "/member/address/getAddressDetail",
        method: "post"
    },
    addAddress: {
        url: "/member/address/addAddress",
        method: "post"
    },
    updateAddress: {
        url: "/member/address/updateAddress",
        method: "post"
    },
    openStoreSub: {
        url: "/member/user/addStoreSub",
        method: "post"
    },
    newListProductSub: {
        url: "/member/productSub/batchAddProductSub"
    }
};