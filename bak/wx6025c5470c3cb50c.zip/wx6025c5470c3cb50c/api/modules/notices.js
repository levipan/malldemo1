Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getNoticesAuth: {
        url: "/user-wechat/whitelist/permissions",
        method: "get"
    },
    getNoticesList: {
        url: "/user-wechat/msgbox/msgs/page",
        cached: "60000",
        method: "get"
    },
    getNewNotices: {
        url: "/user-wechat/msgbox/msgs/newMsgs",
        method: "get"
    },
    getNewNoticesCached: {
        url: "/user-wechat/msgbox/msgs/newMsgs",
        cached: "60000",
        method: "get"
    },
    getLastNotices: {
        url: "/user-wechat/msgbox/msgs/lastMsgs",
        cached: "60000",
        method: "get"
    },
    getMsgRead: {
        url: "/msg/read",
        method: "post"
    },
    wxsubscribe: {
        url: "/msg/wxsubscribe",
        method: "post"
    }
};