Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    shareRandomCode: {
        url: "/store_promotion_reward_point/share_details/addDetail",
        method: "post"
    },
    storeShareSignIn: {
        url: "/store_promotion_reward_point/point_increase/shareSignIn",
        method: "post"
    }
};