Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    payMethodsList: {
        method: "GET",
        cloud: !0,
        url: "/pay-cashier/payment/cashier/c/cashiers"
    }
};