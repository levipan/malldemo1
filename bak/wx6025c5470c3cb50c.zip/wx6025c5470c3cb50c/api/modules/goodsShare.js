Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchClientLike: {
        url: "product/storeRecommend",
        method: "post"
    },
    fetchFriendPoster: {
        url: "product/storeSharePoster"
    },
    fetchweChatPoster: {
        url: "/product/storeShareWechat"
    },
    fetchTodayList: {
        url: "/store/promotion/dayhot/list",
        method: "get"
    },
    fetchTodaySecondList: {
        url: "/user/video/list"
    }
};