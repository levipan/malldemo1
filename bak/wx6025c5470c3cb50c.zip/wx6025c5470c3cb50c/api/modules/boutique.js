Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../formatData/product"), e = {
    getYPHSecondWindows: {
        url: "/user/window/getYPHSecondWindows",
        cloud: !0
    },
    getProductList: {
        url: "/user/product/getProductList",
        cloud: !0,
        fit: function(e) {
            var t = e || {};
            return (t.records || []).length > 0 && (t.records = (0, r.formatProductsData)(t.records || [])), 
            t;
        }
    }
};

exports.default = e;