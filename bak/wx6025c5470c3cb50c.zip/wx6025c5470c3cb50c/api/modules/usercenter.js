Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchLogout: {
        url: "/user/user/loginOut"
    },
    fetchGetStoreUserPickUpList: {
        url: "/user/user/getStoreUserPickUpList"
    },
    fetchLoginOut: {
        url: "/user/user/loginOut"
    }
};