var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../@babel/runtime/helpers/toConsumableArray"), o = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../formatData/common"), i = e(require("../../const/shop-status.js")), u = e(require("../../utils/common")), a = require("../../config.js"), s = {
    queryDeviceLeoShareList: {
        url: "/wechat/task/item/_search",
        method: "get"
    },
    queryOrderPageRights: {
        url: "/venue/card/v1/customer/queryOrderPageRights",
        method: "post"
    },
    parseStoreSharerInfo: {
        url: "/blindbox/share/parseStoreSharerInfo",
        method: "post"
    },
    queryAwardList: {
        url: "/blindbox/mine/queryAwardList",
        method: "post"
    },
    getCardInfo: {
        url: "/ticket/wish/cardInfo",
        cloud: !0,
        method: "post"
    },
    doCardExchange: {
        url: "/ticket/wish/exchange",
        cloud: !0,
        method: "post"
    },
    getExpectPrice: {
        url: "/ticket/wish/expectPrice",
        cloud: !0,
        method: "post"
    },
    queryWithdrawal: {
        url: "/blindbox/withdrawal/pageData",
        method: "post"
    },
    queryExchangeList: {
        url: "/blindbox/withdrawal/queryExchangeList",
        method: "post"
    },
    submitWithdrawal: {
        url: "/blindbox/withdrawal/submit",
        method: "post"
    },
    getEliteDrawSubmit: {
        url: "/blindbox/eliteDraw/submit",
        method: "post",
        mockData: {
            rspCode: "success",
            rspDesc: "请求成功!",
            data: {
                code: "000000",
                data: {
                    amount: 18,
                    awardName: "分享者抽奖金币3",
                    code: "000000",
                    denomination: "",
                    desc: "请求处理成功",
                    icon: "",
                    index: null,
                    rewardType: "activity_points",
                    success: !0,
                    userTime: "2022-06-30 23:59:59"
                }
            }
        },
        fit: function(e, t) {
            var r = o({}, wx.$._get(e, "data", {}));
            r.pitIndex = r.index;
            return "activity_points" === r.rewardType && (r.awardPrice = r.amount), r.couponType = {
                activity_points: "activity_points",
                entity: "ENTITY",
                none: "none"
            }[r.rewardType], r;
        }
    },
    getEliteDrawInfo: {
        url: "/blindbox/eliteDraw/getDrawInfo",
        method: "post",
        mockData: {
            rspCode: "success",
            rspDesc: "请求成功!",
            data: {
                code: "000000",
                data: {
                    availableDrawCount: 20,
                    code: "000000",
                    copies: 6,
                    desc: "活动已结束或不存在",
                    imgUrl: "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.jj20.com%2Fup%2Fallimg%2F4k%2Fs%2F02%2F2109242306111155-0-lp.jpg&refer=http%3A%2F%2Fimg.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1655797416&t=e95837ae2dd9976e4250125572b556cd",
                    ruleDescription: null,
                    success: !1
                }
            }
        },
        fit: function(e, t) {
            var o = {};
            o.activityCode = t.activityCode;
            var r = wx.$._get(e, "data.copies", null);
            o.code = wx.$._get(e, "data.code", null), o.totalNum = wx.$._get(e, "data.availableDrawCount", null), 
            o.currentNum = 0, o.turntableImgUrl = wx.$._get(e, "data.imgUrl", null), o.awardsArray = [];
            for (var i = 0; i < r; i++) o.awardsArray.push(i);
            return o;
        }
    },
    queryOrderRebate: {
        url: "/mall-activity-front/v1/activity/query",
        method: "post",
        fit: function(e, t) {
            return "XDFQ" !== wx.$._get(e, "activityCode", null) ? e : [ 36010, 36011, 36012, 36013, 36020, 36021, 36040 ].indexOf(1 * wx.$._get(e, "businessCode", 0)) > -1 ? (e.businessCode = 1 * e.businessCode, 
            e) : null;
        }
    },
    homeDrawTurntable: {
        url: "/venue/tjsq/v3/customer/drawTurnTable",
        cloud: !0,
        method: "post",
        mockData: {
            rspCode: "success",
            data: {
                show: !0,
                orderId: 2,
                stepValue: [ {
                    yvalue: 600,
                    xvalue: "100"
                }, {
                    yvalue: 600,
                    xvalue: "100"
                } ],
                yvalue: 600,
                xvalue: "100",
                effText: "23点至24点",
                toUseUrl: {},
                awardType: "TICKET",
                awardPrice: "100"
            }
        }
    },
    queryBackHome: {
        url: "/mall-activity-backhome/query",
        method: "post"
    },
    backhomeParticipate: {
        url: "/mall-activity-backhome/participate",
        method: "post"
    },
    savePositionFeedback: {
        url: "/store/savePositionFeedback",
        method: "post"
    },
    openBlindBoxConditionCheck: {
        url: "/blindbox/open/openBlindBoxConditionCheck",
        method: "post"
    },
    zeroBuyBlindBox: {
        url: "/blindbox/buy/zeroBuyBlindBox",
        method: "post"
    },
    queryObtainBoxCount: {
        url: "/blindbox/buy/queryObtainBoxCount",
        method: "post"
    },
    todoOpenBlindBox: {
        url: "/blindbox/open/openBlindBox",
        method: "post"
    },
    getGenerateSharePicture: {
        url: "/blindbox/share/generateSharePicture",
        method: "post"
    },
    getShareBoxPage: {
        url: "/blindbox/share/shareBoxPage",
        method: "post"
    },
    leoXingReceivSsuccess: {
        url: "/activity/coin/success",
        method: "POST"
    },
    getBlindBoxRewardList: {
        url: "/blindbox/mine/queryRewardList",
        method: "post"
    },
    getBlindBoxBuyRecord: {
        url: "/blindbox/mine/queryPurchasedRecords",
        method: "post"
    },
    getBlindBoxActive: {
        url: "/blindbox/mine/homePage",
        method: "post"
    },
    getTouristImageUrl: {
        url: "/agg/marketing/imageUrl",
        method: "post"
    },
    leoEntry: {
        url: "/activity/entry",
        method: "post",
        mockData: {
            data: {
                entryImg: "https://front-xps-cdn.xsyx.xyz/custom/shopping-vip/qugaoFiles/backHome/back_module.png",
                coin: 11,
                taskId: null
            },
            rspDesc: "success",
            rspCode: "success"
        }
    },
    leoAmt: {
        url: "/activity/amt",
        method: "post"
    },
    leoMessage: {
        url: "/activity/message",
        method: "get"
    },
    leoXingInfo: {
        url: "/leo/activity/info",
        cloud: !0,
        method: "POST"
    },
    leoCouponRecord: {
        url: "/activity/coupon/record",
        method: "POST"
    },
    leoCouponInfo: {
        url: "/activity/coupon/info",
        method: "GET"
    },
    leoXingReceive: {
        url: "/leo/activity/receive",
        cloud: !0,
        method: "POST"
    },
    fetchInviteTip: {
        url: "/twitter/marketingRankData/presenterCarouselData",
        method: "get",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/100105/frxs-auth-service/DEV/promotion/presenterCarouselData"
    },
    areaLocation: {
        url: "/twitter/area/areaLocation",
        method: "post"
    },
    updateCurrentAreaId: {
        url: "/twitter/twitter/updateCurrentAreaId",
        method: "post"
    },
    queryUserPoints: {
        url: "trans/queryUserPoints",
        cloud: !0,
        method: "get"
    },
    queryUserPointsList: {
        url: "trans/queryUserPointsList",
        method: "get"
    },
    queryRebateTicketPackage: {
        url: "/activityArea/newUser/queryRebateTicketPackage",
        method: "post"
    },
    fetchClientLike: {
        url: "product/storeRecommend",
        method: "post"
    },
    fetchAdsList: {
        url: "/ads",
        method: "POST",
        defParams: {
            encodeCmsUrl: !0
        }
    },
    fetchAdsActivity: {
        url: "/store/ads_activity",
        method: "POST"
    },
    fetchAdsActivityDetail: {
        url: "/store/ads_activity/detail",
        method: "POST"
    },
    fetchInviteNewActivity: {
        url: "/inviteNew/invitationCode",
        method: "GET"
    },
    saveRelationship: {
        url: "/inviteNew/saveRelationship",
        method: "POST"
    },
    fetchShareInfo: {
        url: "/inviteNew/shareInfo",
        method: "POST"
    },
    fetchFriendPoster: {
        url: "product/storeSharePoster"
    },
    fetchweChatPoster: {
        url: "/product/storeShareWechat"
    },
    fetchTodayList: {
        url: "/store/promotion/dayhot/list",
        method: "get"
    },
    getActivityInfo: {
        url: "/marketingActivity/getActivityInfo",
        method: "post"
    },
    forward: {
        url: "/marketingActivity/forward"
    },
    rewardCoupon: {
        url: "/receiveJournal/queryUserReceiveAward"
    },
    applyTicket: {
        url: "/receive/applyTicket",
        method: "post"
    },
    applyRedPacket: {
        url: "/receive/applyRedPacket",
        method: "post"
    },
    queryNewUserActivityForwardLink: {
        url: "/activityArea/newUser/queryNewUserActivityForwardLink",
        cloud: !0,
        method: "post"
    },
    applyStoreBudgetSharedLink: {
        url: "/activity/zxsy/shareInfo",
        method: "post",
        fit: function(e, t) {
            return e;
        }
    },
    pointsLimit: {
        url: "/marketingActivity/forward/pointsLimit",
        method: "post"
    },
    queryStoreBudgetByToken: {
        url: "/marketingActivity/queryStoreBudgetByToken",
        method: "get",
        fit: function(e, t) {
            return (e || {}).ticketSill = e.ticketSill ? e.ticketSill : 9.9, e;
        }
    },
    getStoreInfoForCurrentPickStore: {
        url: "/store/getStoreInfoForCurrentPickStoreNew",
        cloud: !0,
        dynamicParams: [ "blackBox" ],
        cached: 6e4,
        method: "post"
    },
    queryStoreListForEs: {
        url: "/store/queryStoreListForEs",
        cloud: !0,
        dynamicParams: [ "blackBox" ],
        method: "post"
    },
    fetchStoreInfo: {
        url: "/store/getStoreInfo",
        cloud: !0,
        dynamicParams: [ "blackBox" ],
        cached: 6e4,
        method: "post",
        fit: function(e, t, o) {
            return e.storeId == 1 * a.tempStoreId && (e.storeStatus = i.default.NORMAL), e;
        },
        fail: function(e, t, o) {
            var r = wx.$._get(e, "rspCode", null);
            try {
                var i = u.default.getStorageSync("storeHistoryList") || [];
                if (i && i.length) {
                    var a = -1;
                    i.forEach(function(e, o) {
                        e.storeId == t.storeId && (a = o);
                    }), -1 !== a && (i.splice(a, 1), u.default.setStorageSync("storeHistoryList", i));
                }
            } catch (e) {}
            if ([ "FE04451007002", "failure" ].indexOf(r) > -1 && !o.notRedirect) {
                var s = u.default.isLogin() ? "list" : "map";
                try {
                    wx.$CG.$tran.open({
                        pageName: s,
                        isRedirect: !0,
                        moduleName: "store"
                    });
                } catch (e) {}
            }
            return e;
        }
    },
    getStoreContactsTelProtected: {
        url: "/store/getStoreContactsTelProtected",
        method: "post"
    },
    fetchSelectByTime: {
        url: "/common/selectByTime"
    },
    fetchStoreList: {
        url: "/store/queryStoreList",
        method: "post"
    },
    fetchIndexStore: {
        url: "/user/store/getIndexStore",
        sensitive: 23,
        cached: 12e4,
        method: "post"
    },
    fetchSysParam: {
        url: "/common/getSysParam",
        method: "post",
        fit: function(e) {
            return (0, r.formatSysParamsData)(e);
        },
        repeat: 2,
        feed: function(e) {
            return (0, r.formatSysParamsFeed)();
        }
    },
    fetchUserInfo: {
        url: "/user/user/getUserInfo",
        method: "post"
    },
    getApppayToken: {
        url: "/auth/auth/authForPay"
    },
    queryMyTicketsNun: {
        url: "/ticket/v2/queryMyTicketsNum",
        cloud: !0,
        cached: 6e5,
        method: "post"
    },
    queryMyTickets: {
        url: "/ticket/v2/queryMyTickets",
        method: "post"
    },
    couponSkuSn: {
        url: "/couponSkuSn/list",
        method: "post"
    },
    couponProductList: {
        url: "/coupon/product/list",
        cloud: !0,
        method: "post"
    },
    queryRecommendTickets: {
        url: "/ticket/front/RecommendTickets",
        method: "post"
    },
    queryNoLoginRecommendTickets: {
        url: "/activityArea/noLogin/productTicket",
        method: "post"
    },
    loginUserGetActivity: {
        url: "/activityArea/newUser/activity",
        method: "post"
    },
    notLoginUserGetActivity: {
        url: "/activityArea/noLogin/activity",
        method: "post"
    },
    receiveTicketAll: {
        url: "/activity/receiveTicketAll",
        cloud: !0,
        method: "post",
        cached: 18e5
    },
    getNotPartakeActivityCount: {
        url: "/activity/discount/getNotPartakeActivityCount",
        method: "post"
    },
    getPromotionCenterV2: {
        url: "/activity/discount/v2/promotionCenter",
        cloud: !0,
        method: "post"
    },
    getPromotionCenter: {
        url: "/activity/discount/promotionCenter",
        cloud: !0,
        method: "post"
    },
    getGoodsCardActivityV2: {
        url: "/activity/discount/v2/goodsCardActivity",
        cloud: !0,
        method: "post"
    },
    getGoodsCardActivity: {
        url: "/activity/discount/goodsCardActivity",
        cloud: !0,
        method: "post"
    },
    receiveTicket: {
        url: "/activity/receiveTicket",
        cloud: !0,
        method: "post"
    },
    receiveTicketNew: {
        url: "/activityArea/cms/receiveTicket",
        cloud: !0,
        method: "post"
    },
    receiveNewUserTicket: {
        url: "/activities/receiveNewUserTicket",
        cloud: !0,
        method: "post"
    },
    receiveNewUserActivityStat: {
        url: "/activities/receiveNewUserActivityStat",
        cloud: !0,
        method: "post"
    },
    getActivityScope: {
        url: "/ticket/getActivityScope",
        cloud: !0,
        method: "get"
    },
    queryTicketProduct: {
        url: "activity/discount/homePagePopup",
        method: "post",
        mockUrl: "http://127.0.0.1:901/mock.json",
        fit: function(e) {
            (e = e || {}).allGoodsTickets = [].concat(t(wx.$._get(e, "allCategoryActivity", []) || []), t(wx.$._get(e, "singleCategoryActivity.allGoodsTickets", []) || [])), 
            e.multipleTickets = [].concat(t(wx.$._get(e, "multipleCategoryActivity", []) || []), t(wx.$._get(e, "singleCategoryActivity.multipleTickets", []) || [])), 
            e.ticketList = wx.$._get(e, "singleCategoryActivity.ticketList", []) || [], e.productMap = wx.$._get(e, "singleCategoryActivity.productMap", {}) || {}, 
            e.hotActivity = wx.$._get(e, "hotActivity", []) || [], e.ticketList.map(function(e) {
                e.coupopEndAmt = 1 * e.saleAmt - 1 * e.ticketAmt;
            });
            var r = [], i = e.productMap;
            return e.ticketList.map(function(e) {
                i[e.skuSn] && r.push(o(o({}, e), i[e.skuSn]));
            }), r.map(function(e) {
                e.coupopEndAmt = parseFloat((1 * e.saleAmt - 1 * e.ticketAmt).toFixed(2)), e.coupopEndAmt = e.coupopEndAmt > 0 ? e.coupopEndAmt : 0, 
                e.saleAmt < e.orderAmountLimit && (e.coupopEndAmt = 0);
            }), o(o({}, e), {}, {
                couponProducts: r
            });
        }
    },
    isPromotionStore: {
        url: "/store/isPromotionStore"
    },
    getPromotionStoreList: {
        url: "/store/getPromotionStoreList"
    },
    getStoreToken: {
        url: "/marketingActivity/applyStoreBudgetSharedLink",
        method: "post"
    },
    getTreasureInfo: {
        url: "/cbx/listBranchVenue",
        method: "get",
        feed: function(e) {
            return [];
        }
    },
    getTreasureInfoItem: {
        url: "/cbx/branchVenue",
        method: "get",
        feed: function(e) {
            return {};
        }
    },
    postOpenTreasure: {
        url: "/lottery/draw",
        cloud: !0,
        method: "post"
    },
    getSharedLink: {
        url: "/mkt/qc/getSharedLink",
        method: "get"
    },
    draw: {
        url: "/lottery/draw",
        method: "post"
    },
    issuedList: {
        url: "/mkt/qc/issuedList",
        method: "get"
    },
    issuedStatus: {
        url: "/mkt/qc/issuedStatus",
        method: "get"
    },
    storePosterImage: {
        url: "/jigsaws/homePagePoster",
        method: "post"
    },
    productShareImage: {
        url: "/jigsaws/productDetailShare",
        method: "post"
    },
    productPosterImage: {
        url: "/jigsaws/productDetailPoster",
        method: "post"
    },
    oldOrderDetailShareImage: {
        url: "/jigsaws/orderDetailShare",
        method: "post"
    },
    newOrderDetailShareImage: {
        url: "/jigsaws/orderDetailShareV2",
        method: "post"
    },
    newBottomCarouselList: {
        url: "/activity/discount/v2/bottomCarouselList",
        cloud: !0,
        cached: 3e5,
        method: "post",
        fit: function(e) {
            return (e = e || {}).hotActivity = wx.$._get(e, "hotActivity", []) || [], e.hotActivity = e.hotActivity.filter(function(e) {
                return !e.use || "YPH" !== e.activityType;
            }) || [], o({}, e);
        }
    },
    bottomCarouselList: {
        url: "/activity/discount/bottomCarouselList",
        cached: 3e5,
        method: "post"
    },
    hotActivity: {
        url: "/activity/discount/hotActivity",
        cloud: !0
    },
    getQueryAllTicket: {
        url: "/ticket/front/queryAllTicket",
        cloud: !0,
        method: "post",
        cached: 6e4
    },
    tjsqQueryWindow: {
        url: "/venue/window/v1/customer/queryWindow",
        cloud: !0,
        method: "post"
    },
    tjsqlotteryV2: {
        url: "/venue/tjsq/v3/customer/lottery",
        cloud: !0,
        method: "post"
    },
    tjsqLottery: {
        url: "/venue/tjsq/v1/customer/lottery",
        cloud: !0,
        method: "post"
    },
    getIndexPopup: {
        url: "/venue/global/v1/customer/indexPopup",
        cloud: !0,
        method: "post"
    },
    getNoAuthFixedPage: {
        url: "/venue/newUser/v1/customer/noAuthFixedPage",
        cloud: !0,
        method: "post"
    },
    getHomeFixedPage: {
        url: "/venue/newUser/v1/customer/fixedPage",
        cloud: !0,
        method: "post"
    },
    getTurntableCustomer: {
        url: "/venue/turntable/v1/customer/index",
        cloud: !0,
        method: "post"
    },
    shareTurntableInfo: {
        url: "/venue/turntable/v1/customer/shareTurntableInfo",
        cloud: !0,
        method: "post"
    },
    queryActivityInfo: {
        url: "/venue/turntable/v1/customer/queryActivityInfo",
        cloud: !0,
        method: "post"
    },
    drawTurntable: {
        url: "/venue/turntable/v1/customer/drawTurntable",
        cloud: !0,
        method: "post"
    },
    drawHotTurntable: {
        url: "/venue/hotTurntable/v1/customer/lottery",
        cloud: !0,
        method: "post"
    },
    getDefaultNationwideRankList: {
        url: "/venue/customer/getDefaultNationwideRankList",
        cloud: !0,
        method: "post"
    },
    queryLotteryRecordList: {
        url: "/venue/turntable/v1/customer/queryLotteryRecordList",
        cloud: !0,
        method: "post"
    },
    getPuzzleH5url: {
        url: "/venue/jigsaw/v1/customer/getH5Path",
        cloud: !0,
        method: "get"
    },
    completeFirstOrder: {
        url: "/venue/global/v1/customer/completeFirstOrder",
        cloud: !0,
        method: "post"
    },
    queryRedActivityInfo: {
        url: "/venue/redPackage/v2/customer/queryActivityInfo",
        cloud: !0,
        method: "post"
    },
    drawRedPackage: {
        url: "/venue/redPackage/v2/customer/drawRedPackage",
        cloud: !0,
        method: "post"
    },
    exchangeAward: {
        url: "/venue/redPackage/v2/customer/exchangeAward",
        cloud: !0,
        method: "post"
    },
    queryActiveTickets: {
        url: "/activityArea/promotion/query",
        cloud: !0,
        method: "post"
    },
    loginBackground: {
        url: "/agg/loginBackground",
        method: "post"
    },
    query: {
        url: "/venue/hotTurntable/v1/customer/query",
        cloud: !0,
        method: "post"
    },
    drawTurntableSale: {
        url: "/venue/hotTurntable/v1/customer/lottery",
        cloud: !0,
        method: "post"
    },
    queryLotteryRecordListSale: {
        url: "/venue/hotTurntable/v1/customer/lotteryRecords",
        cloud: !0,
        method: "post"
    },
    getWelfareCode: {
        url: "/activity/welfare/code",
        method: "get"
    },
    queryZxsyDrawAward: {
        url: "/venue/zxsy/v2/custom/drawAward",
        cloud: !0,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/venue/zxsy/v2/custom/drawAward",
        mock: !1
    },
    acceptShare: {
        url: "/venue/zxsy/v2/custom/acceptShare",
        cloud: !0,
        method: "post",
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/DEV/venue/zxsy/v2/custom/acceptShare",
        mock: !1
    },
    phoneMsgCheck: {
        url: "/blindbox/share/sharePhonePageMessage"
    },
    phoneMemberInfo: {
        url: "/venue/card/v1/customer/queryCallChargesRights"
    },
    storePoster: {
        url: "/store/posters",
        method: "POST"
    },
    getPartyList: {
        mock: !1,
        mockUrl: "http://ifd.pocket.xsyxsc.com/ifd/emock/UAT/user/group/recommend",
        url: "/user/group/recommend"
    },
    payOrderScoreSearch: {
        url: "/payorder/score/permissions/search",
        method: "post"
    },
    payOrderScorePermissions: {
        url: "/payorder/score/permissions ",
        method: "post"
    },
    getPingPartyConfig: {
        url: "/mall/getDefaultByCode",
        method: "get"
    }
};

exports.default = s;