Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    fetchShopCar: {
        url: "/user/product/queryShopCar/v3",
        cloud: !0
    },
    queryOtherAreaShopCar: {
        url: "/user/product/queryOtherAreaShopCar"
    },
    queryProductByToken: {
        url: "/user/product/promotion2/product/query/bytoken",
        mockUrl: "http://10.255.141.120:8262/user/product/promotion2/product/query/bytoken",
        method: "post"
    }
};