var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../@babel/runtime/helpers/objectSpread2"), t = (require("../../utils/index"), 
e(require("../../utils/common")), require("../formatData/product")), o = {
    fetchProductList: {
        url: "/user/product/index",
        method: "post"
    },
    fetchBrandMenuItems: {
        url: "/user/brandhouse/windows",
        mockUrl: "http://localhost:8000/brandhouse/brandwindow.json",
        cached: 6e4,
        fit: function(e) {
            return e.map(function(e) {
                return {
                    brandWindowId: e.brandWindowId || e.windId,
                    windowName: e.windowName || e.windName,
                    icon: e.icon
                };
            });
        }
    },
    fetchBrandList: {
        url: "/user/brandhouse/brand/list"
    },
    getSaleQtyAndPreference: {
        url: "/user/product/getSaleQtyAndPreference"
    },
    getProductsMarketingData: {
        url: "/user/brandhouse/window/getProductsMarketingData",
        cached: 5e3,
        repeat: 3
    },
    getSearchMarketingData: {
        url: "/user/product/searchMarketingData",
        repeat: 3
    },
    fetchBrandHouseProducts: {
        url: "/user/brandhouse/window/getProducts",
        mockUrl: "http://127.0.0.1:8000/test-data.json",
        repeat: 3,
        fit: function(e) {
            return (e = e || {}).records = (0, t.formatProductsData)(e.records || []), e;
        }
    },
    fetchBrandInfo: {
        url: "/user/brandhouse/brand/info"
    },
    fetchFollowPreProduct: {
        url: "/user/product/followPreproduct/v2"
    },
    queryProductBySkuSnOrSku: {
        url: "/user/product/queryProductBySkuSnOrSku",
        cloud: !0
    },
    fetchGetConfig: {
        url: "/mall/getConfig",
        method: "post",
        cached: 36e5
    },
    getProductLive: {
        url: "/user/product/getLiveBySpuSns"
    },
    batchQueryCanBuy: {
        url: "/user/product/batchQueryCanBuy"
    },
    queryRecommand: {
        url: "/user/product/queryRecommend",
        cloud: !0
    },
    getOrderShareTitle: {
        url: "/share/order/title",
        method: "get",
        mock: !1,
        mockUrl: "http://172.21.145.42:8262/share/order/title"
    },
    fetchQueryFootNav: {
        url: "/user/navigation/queryFootNav"
    },
    queryRecommendSpuSns: {
        url: "/user/product/getRecommendSpuSnList",
        method: "post"
    },
    queryRecommendProducts: {
        url: "/user/product/getRecommendProducts",
        method: "post"
    },
    searchQueryRecommendProducts: {
        url: "/user/product/getSearchRecommendProducts",
        defParams: {
            rankVersion: "v2"
        },
        method: "post",
        fit: function(e) {
            return (e = e || {}).productList = (0, t.formatProductsData)(e.productList || []), 
            e;
        }
    },
    getIndexRecommenderProducts: {
        url: "/user/product/getIndexRecommenderProducts",
        method: "post"
    },
    queryCmsPositionAndProduct: {
        url: "/cms/queryCmsPositionAndProduct/v2",
        cloud: !0,
        method: "post"
    },
    fetchIndexQuery: {
        url: "/cms/index/query"
    },
    getIndexWindowProducts: {
        url: "/user/product/getIndexWindowProducts/v4",
        cloud: !0
    },
    getIndexCard: {
        url: "/cms/card/getIndexCard"
    },
    getTmIndexCard: {
        url: "/cms/card/getIndexCard/v2"
    },
    getNewPhoneProduct: {
        method: "POST",
        url: "/phone/phoneinfo"
    },
    getPhoneProductCoupon: {
        method: "POST",
        url: "/phone/phoneCouponInfo"
    },
    getPtProductInfo: {
        url: "/user/group/productInfo",
        method: "post",
        fit: function(e) {
            return e = (0, t.formatProductData)(e || {});
        }
    },
    getPtOrderTips: {
        url: "/user/group/orderTips"
    },
    getPtShareImg: {
        url: "/jigsaws/group/productInfo/share",
        fit: function(e) {
            return r(r({}, e), {}, {
                title: e.content,
                imageUrl: e.img
            });
        }
    }
};

exports.default = o;