Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    expressDetail: {
        url: "/oms-api/queryRoute",
        method: "post"
    },
    getTmArriveTime: {
        url: "/oms-api/query/deliveryTime",
        method: "post"
    },
    getZeroOrderShare: {
        url: "/mall-activity-zerobuy/order/success/share/getContent",
        method: "post"
    },
    addBindRelation: {
        url: "/activity_web/storeActivity/addBindRelation",
        method: "post"
    },
    queryBindRelation: {
        url: "/activity_web/storeActivity/queryBindRelation",
        method: "post"
    },
    delBindRelation: {
        url: "/activity_web/storeActivity/delBindRelation",
        method: "post"
    }
};