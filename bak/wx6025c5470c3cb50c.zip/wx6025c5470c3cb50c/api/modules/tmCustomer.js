Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    unread: {
        url: "/v1/messages/unread",
        method: "GET",
        feed: function(e) {
            return (e || {}).data;
        }
    },
    getConversationInfo: {
        url: "/v1/conversations/getConversationInfo",
        method: "GET",
        feed: function(e) {
            return (e || {}).data;
        }
    }
};