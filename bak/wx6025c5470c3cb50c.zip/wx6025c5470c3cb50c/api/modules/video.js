Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../formatData/product"), o = {
    fetchVideoList: {
        url: "/user/video/list"
    },
    fetchProductList: {
        dynamicParams: [ "blackBox" ],
        url: "/user/video/product/list"
    },
    fetchVideoThumbsup: {
        url: "/user/video/thumbsup"
    },
    fetchPlayCount: {
        url: "/user/video/playCount"
    },
    fetchVideoThumbsupNum: {
        url: "/user/video/thumbsup/list"
    },
    fetchLiveList: {
        url: "/utv/live/list"
    },
    fetchLiveProductList: {
        url: "/utv/live/product/list"
    },
    fetchFocusVideoList: {
        url: "/user/video/focus/list",
        method: "get"
    },
    fetchLikedVideoList: {
        url: "/user/video/liked/list",
        method: "get"
    },
    fetchAuthorVideoList: {
        url: "/user/video/author/video/list",
        method: "get"
    },
    fetchAuthorInfo: {
        url: "/utv/user/author/info",
        method: "get"
    },
    focusAuthor: {
        url: "/utv/user/focus"
    },
    fetchRecommendVideoList: {
        url: "/user/video/recommend/list/V2",
        method: "get"
    },
    fetchIconCount: {
        url: "/utv/user/icon/count",
        method: "GET"
    },
    fetchVdeioNavClick: {
        url: "/utv/user/click"
    },
    fetchAuthorList: {
        url: "/user/video/author/video/list",
        method: "get"
    },
    fetchLiveInfo: {
        url: "/utv/live/diversion",
        method: "get"
    },
    fetchUserInfoNum: {
        url: "/utv/user/info",
        method: "get"
    },
    fetchFoucsAuthorList: {
        url: "/utv/user/focus/author/list",
        method: "get"
    },
    uploadVideoInfo: {
        url: "/user/video/save",
        method: "post"
    },
    upload: {
        url: "/upload",
        method: "post"
    },
    fetchCookbookVideoList: {
        url: "/user/video/cookbook/list"
    },
    fetchVideoShareImg: {
        url: "/user/video/share/image"
    },
    fetchVideoPlayList: {
        url: "/user/video/playList"
    },
    fetchGetCookbooks: {
        url: "/category/cookbook/list",
        method: "post",
        mock: !1,
        dynamicParams: [ "blackBox" ],
        mockUrl: "http://172.21.91.182:6201/getCookbooks?v=" + Math.random(),
        fit: function(t) {
            return ((t = t || {}).videoDetailROS || []).map(function(t) {
                t.products = (0, e.formatProductsData)(t.products);
            }), t;
        }
    },
    fetchGetCookbooksSearch: {
        dynamicParams: [ "blackBox" ],
        url: "/user/video/cookbook/search",
        method: "get",
        mock: !1,
        mockUrl: "http://10.255.58.220:8436/user/video/cookbook/search",
        fit: function(t) {
            return ((t = t || {}).videoDetailROS || []).map(function(t) {
                t.products = (0, e.formatProductsData)(t.products);
            }), t;
        }
    },
    fetchGetCookbooksCate: {
        url: "/category/list",
        method: "post",
        mock: !1,
        mockUrl: "http://172.21.91.182:6201/cookbookCate/list.json",
        fit: function(e) {
            return (e || []).map(function(e) {
                return t(t({}, e), {}, {
                    label: e.categoryName
                });
            });
        }
    },
    fetchGetCookbooksChildCate: {
        url: "/user/product/productInfo/getCookbooks",
        method: "get",
        mock: !0,
        mockUrl: "http://172.21.91.182:6201/getCookbooksChildCate?v=" + Math.random()
    },
    fetchGetDanmuList: {
        url: "/comments/danmu",
        method: "post"
    },
    fetchGetCommentList: {
        url: "/comments/page",
        method: "post"
    },
    fetchGetViceComment: {
        url: "/comments/sub/page",
        method: "post",
        mock: !1,
        mockData: {}
    },
    fetchAddComment: {
        url: "/comments/submit",
        method: "post"
    },
    fetchCommentLikes: {
        url: "/comments/submitLikes",
        method: "post"
    },
    fetchMsgCount: {
        url: "/comments/msg/count",
        method: "post"
    },
    fetchUserCommentsMsg: {
        url: "/comments/msg/page",
        method: "post"
    },
    fetchUpdateStatus: {
        url: "/product/suggestion/status/update",
        method: "post"
    },
    fetchStatusQuery: {
        url: "/product/suggestion/status/query",
        method: "post"
    },
    fetchSaveComment: {
        url: "/product/suggestion/comment/save",
        method: "post"
    },
    commentListQuery: {
        url: "/product/suggestion/comment/msg/query",
        method: "get"
    },
    CommentNumberQuery: {
        url: "/product/suggestion/comment/msg/count",
        method: "get"
    },
    tagNamesQuery: {
        url: "/product/suggestion/comment/tag/query",
        method: "get"
    },
    fetchQueryComment: {
        url: "/product/suggestion/comment/query",
        method: "get"
    },
    getProductDetailCookbooks: {
        url: "/user/video/productInfo/cookbook/list"
    },
    deleteComment: {
        url: "/comments/delete",
        method: "post"
    },
    fetchCommentsUserImgs: {
        url: "/comments/discuss/data",
        method: "get"
    },
    getNavigationIcon: {
        mockUrl: "http://172.21.91.182:901/mock/liveIcon.json",
        mock: !1,
        url: "/user/navigation/icon"
    },
    getSuperProductLiveMsg: {
        url: "/super/hot/index",
        method: "POST"
    }
};

exports.default = o;