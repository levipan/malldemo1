Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    clearConsignee: {
        url: "/member/storeConsignee/clear",
        method: "post",
        mock: !1,
        mockData: {
            rspCode: "success",
            rspDesc: "操作成功",
            data: null
        }
    },
    getListConsignee: {
        url: "/member/storeConsignee/list",
        method: "post",
        mock: !1,
        mockData: {
            rspCode: "success",
            data: [ {
                username: "张三",
                mobileNo: "13788888888"
            }, {
                username: "李四",
                mobileNo: "13766666666"
            } ]
        }
    },
    addOrUpdateConsignee: {
        url: "/member/storeConsignee/addOrUpdate",
        method: "post"
    },
    codeExchangeSessionKey: {
        url: "/auth/auth/codeExchangeSessionKey"
    },
    manualLogin: {
        url: "/auth/auth/manualLogin"
    },
    sendSMS: {
        url: "/auth/auth/sendVerificationCode"
    },
    loginOut: {
        url: "/auth/auth/logOut"
    },
    internalAuthorizeLogin: {
        url: "/auth/auth/internalAuthorizeLogin",
        mockUrl: "http://mock.xsyxapp.com/mock/95/auth/auth/silenceLogin"
    },
    silenceLogin: {
        url: "/auth/auth/silenceLoginAndGetUser",
        mockUrl: "http://mock.xsyxapp.com/mock/95/auth/auth/silenceLogin"
    },
    frontCheckAuthStatus: {
        url: "/auth/auth/frontCheckAuthStatus",
        mockUrl: "http://mock.xsyxapp.com/mock/95/auth/auth/frontCheckAuthStatus"
    },
    cancelAccount: {
        url: "/auth/auth/cancelAccount"
    },
    readMsg: {
        url: "/member/msg/readMsg",
        method: "post",
        defParams: {
            msgCode: "A10000"
        }
    },
    queryPrivacyPopup: {
        url: "/member/msg/queryUnReadMsg",
        defParams: {
            msgCode: "A10000"
        }
    }
};