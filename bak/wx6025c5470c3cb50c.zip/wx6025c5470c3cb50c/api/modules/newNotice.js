Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getNewNoticesList: {
        url: "/msgBox/msg/unreadNum",
        method: "post"
    },
    getSalesRefundList: {
        url: "/after/sales/refund/page",
        method: "post"
    },
    getOrderSearchPlaceholder: {
        url: "/common/config/orderSearchPlaceholder",
        method: "get"
    },
    getActivityDetail: {
        url: "/page/activity/detail",
        method: "post"
    }
};