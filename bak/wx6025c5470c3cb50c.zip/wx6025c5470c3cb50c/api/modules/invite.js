Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getInviteGiftsActivityInfo: {
        contentType: "application/json",
        url: "/venue/invitation/v1/custom/getActivityInfo",
        cloud: !0,
        method: "post"
    },
    getInviteGiftsShareCard: {
        url: "/venue/invitation/v1/custom/shareCard",
        cloud: !0,
        method: "post"
    },
    getInviteGiftsShareScan: {
        url: "/venue/invitation/v1/custom/shareFace",
        cloud: !0,
        method: "post"
    },
    getInviteGiftsSharePoster: {
        url: "/venue/invitation/v1/custom/sharePoster",
        cloud: !0,
        method: "post"
    },
    getInviteGiftsDetaiList: {
        url: "/venue/invitation/v1/custom/detailList",
        cloud: !0,
        method: "post"
    }
};