Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    pay: {
        url: "/payment/pay"
    },
    payNew: {
        url: "/payment/pay",
        cloud: !0
    },
    redPacketPay: {
        url: "/store-expansion/redPacket/pay"
    },
    payCallback: {
        url: "/payment/callback"
    }
};