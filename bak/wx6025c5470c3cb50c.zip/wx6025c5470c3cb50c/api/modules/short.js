Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    queryLink: {
        method: "get",
        url: "/short/link/queryLink",
        mock: !1
    },
    queryLinkByShortLink: {
        method: "get",
        url: "/short/link/queryLinkByShortLink",
        mock: !1
    },
    queryContent: {
        method: "POST",
        url: "/short/key/queryContent",
        mock: !1
    },
    uploadInfo: {
        method: "POST",
        url: "/upload/info",
        dynamicParams: [ "blackBox" ]
    }
};