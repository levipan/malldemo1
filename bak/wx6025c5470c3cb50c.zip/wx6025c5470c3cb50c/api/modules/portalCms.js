Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    getSkinConfig: {
        method: "POST",
        url: "/cms/skin/query"
    },
    fetchQueryFootNav: {
        url: "/cms/navigation/queryFootNav"
    },
    getHomeIndexIcon: {
        url: "/cms/indexIcons"
    },
    getAdsInfo: {
        url: "cms/ads/v1",
        dynamicParams: [ "blackBox" ],
        fit: function(e) {
            e = e || {};
            var t = {};
            return Object.keys(e).forEach(function(a) {
                t[a] = [], e[a].forEach(function(e) {
                    switch (e.selectType) {
                      case "PURCHASE_RECORD":
                        e.adZonePurchaseRecord = JSON.parse(e.selectTypeValue);
                        break;

                      case "COUPON":
                        e.adZoneCoupon = JSON.parse(e.selectTypeValue);
                        break;

                      case "PICTURE":
                        e.adZoneCoupon = !1;
                        break;

                      case "CLASSIFY":
                      case "CLASSIFY_FRONT":
                        0 === e.selectTypeValue.length ? e.adZoneClassifyWindows = null : e.adZoneClassifyWindows = e.selectTypeValue.split(",");
                        break;

                      case "ACTIVITY":
                        e.adZoneActivity = !0, e.selectTypeValue = JSON.parse(e.selectTypeValue), e.selectTypeValue.linePrice = 1 * (e.selectTypeValue.linePrice / 100).toFixed(2), 
                        e.selectTypeValue.producePrice = 1 * (e.selectTypeValue.producePrice / 100).toFixed(2);
                    }
                    t[a].push(e);
                });
            }), t;
        }
    },
    getMagicPopupInfo: {
        url: "popupWindow/config",
        method: "POST",
        mockData: {
            success: !0,
            data: {
                totalTimesOneDay: 5,
                taskList: [ {
                    id: 76,
                    crowdsPackDto: {
                        id: 67,
                        name: "fake_data"
                    },
                    taskCategoryDTO: {
                        id: 4,
                        priorityLevel: 2,
                        categoryName: "fake_data"
                    },
                    materialBaseDTO: {
                        id: 4,
                        popUpWindowName: "fake_data",
                        imgUrl: "fake_data",
                        materialType: "USER_DEFINED",
                        isHasShade: !1,
                        finishWay: JSON.stringify({
                            modules: [ {
                                id: "MCPM-p9P2wPoA",
                                name: "弹窗一",
                                describe: "弹窗一",
                                components: [ {
                                    x: 87,
                                    y: 54,
                                    zIndex: 1,
                                    width: "80",
                                    height: "80",
                                    name: "View",
                                    props: {
                                        text: "$111",
                                        init: {
                                            params: {
                                                a: 1
                                            }
                                        }
                                    },
                                    styles: {
                                        padding: {
                                            top: 0,
                                            left: 0,
                                            right: 0,
                                            bottom: 0
                                        },
                                        margin: {
                                            top: 0,
                                            left: 0,
                                            right: 0,
                                            bottom: 0
                                        },
                                        border: {
                                            color: {
                                                rgba: {
                                                    a: 1,
                                                    b: 93,
                                                    g: 94,
                                                    r: 90
                                                }
                                            },
                                            border: {
                                                width: 1,
                                                style: "solid",
                                                top: !1,
                                                bottom: !1,
                                                left: !1,
                                                right: !1
                                            }
                                        },
                                        boxShadow: {
                                            color: {
                                                rgba: {
                                                    a: 1,
                                                    b: 93,
                                                    g: 94,
                                                    r: 90
                                                }
                                            },
                                            x: 0,
                                            y: 4,
                                            blurry: 4,
                                            expand: 0
                                        },
                                        borderRadius: {
                                            top: 0,
                                            left: 0,
                                            bottom: 0,
                                            right: 0
                                        },
                                        background: {
                                            color: {
                                                rgba: {
                                                    a: 1,
                                                    b: 93,
                                                    g: 94,
                                                    r: 90
                                                }
                                            },
                                            img: {
                                                link: "https://front-xps-cdn.xsyx.xyz/custom/marvelcode/pro/v1/Group (27).png?imageMogr2/format/webp",
                                                backgroundRepeat: "repeat",
                                                backgroundSize: "cover",
                                                backgroundSizeX: 100,
                                                backgroundSizeY: 100
                                            }
                                        },
                                        font: {
                                            fontSize: "",
                                            fontWeight: "",
                                            fontType: "",
                                            lineHeight: "",
                                            letterSpacing: "",
                                            alignMode: "",
                                            color: {
                                                rgba: {
                                                    a: 1,
                                                    b: 93,
                                                    g: 94,
                                                    r: 90
                                                }
                                            }
                                        }
                                    },
                                    children: [ {
                                        name: "Text",
                                        props: {
                                            init: {
                                                params: {
                                                    a: 4
                                                }
                                            },
                                            text: "909$",
                                            textOverflow: "",
                                            lineClamp: 2
                                        },
                                        children: [ {
                                            name: "766",
                                            props: {
                                                init: {
                                                    params: {
                                                        a: 5
                                                    }
                                                },
                                                text: "555$",
                                                textOverflow: "",
                                                lineClamp: 2
                                            }
                                        } ]
                                    } ],
                                    events: [ {
                                        type: "click"
                                    }, {
                                        type: "jump",
                                        params: {
                                            path: "",
                                            appId: ""
                                        }
                                    }, {
                                        type: "close"
                                    }, {
                                        type: "request",
                                        params: {
                                            url: ""
                                        }
                                    } ]
                                }, {
                                    name: "ScorllView",
                                    props: {
                                        scorllX: !0,
                                        scorllY: !0
                                    }
                                }, {
                                    name: "Button",
                                    props: {
                                        text: "111"
                                    }
                                }, {
                                    name: "Text",
                                    props: {
                                        text: "111",
                                        textOverflow: "",
                                        lineClamp: 2
                                    }
                                }, {
                                    name: "Image",
                                    props: {
                                        src: "",
                                        init: {
                                            params: {
                                                a: 8
                                            }
                                        },
                                        text: "234$",
                                        objectFit: "fill"
                                    }
                                } ]
                            } ]
                        }),
                        linkType: "fake_data",
                        linkUrl: "fake_data",
                        mpTypeId: 83,
                        ticketList: [ "fake_data" ],
                        skuSnList: [ "fake_data" ]
                    },
                    h5Url: "fake_data",
                    mpTypeId: "fake_data",
                    appUrl: "fake_data",
                    exposureFrequencyType: "MULTI",
                    exposureTimes: "2",
                    taskCycleType: "fake_data",
                    exposureSumTimes: "fake_data",
                    exposureSumPeople: "fake_data",
                    exposureStartDateInOneDay: "2022-03-17 15:12:22",
                    exposureEndDateInOneDay: "2013-07-28 20:25:38",
                    exposureType: "FOLLOW_LAST",
                    areaId: 98,
                    areaName: "fake_data",
                    name: "fake_data",
                    dataStatus: "fake_data",
                    statusName: "fake_data"
                } ]
            },
            rspCode: "success",
            rspDesc: "操作成功"
        }
    },
    getTmHomeIcons: {
        url: "/cms/homeIcons",
        method: "POST"
    },
    getHomeCmsCardConfig: {
        url: "/cms/cardPosition/v2/list",
        method: "POST"
    },
    getHomeCardConfig: {
        url: "/cms/cardPosition/v2/listV2",
        method: "POST"
    },
    getActiveEntryInfo: {
        url: "/cms/cardPosition/v2/details/bottomCard",
        method: "POST"
    },
    getActiveRecommendCard: {
        url: "/cms/cardPosition/v2/details/oneCard",
        method: "POST"
    },
    getSpecialCard: {
        url: "/cms/cardPosition/v2/details/marketCard",
        method: "POST"
    },
    getTdDiscountCard: {
        method: "POST",
        url: "/cms/cardPosition/v2/details/fourCard"
    },
    getExplosiveCard: {
        method: "POST",
        url: "/cms/cardPosition/v2/details/superProductCard"
    },
    getSuperExplosiveActive: {
        method: "POST",
        url: "/cms/cardPosition/details/superProductCardV1"
    },
    getSuperProductShare: {
        method: "POST",
        url: "/share/poster/queryPoster"
    },
    getBothSuperExplosive: {
        method: "POST",
        url: "/cms/cardPosition/v2/details/superProductCardV3"
    },
    getActiveSpecial: {
        url: "/cms/cardPosition/v2/details/twoCard",
        method: "POST"
    },
    getNewsCard: {
        method: "POST",
        url: "/cms/cardPosition/v2/details/messageCard"
    },
    getOntimeCard: {
        method: "POST",
        url: "/cms/cardPosition/v2/details/hourlCard"
    },
    getOntimeTabList: {
        method: "POST",
        url: "/cms/activity/column/info"
    },
    getOtProducts: {
        method: "POST",
        url: "/cms/activity/product/pageInfo",
        cloud: !0
    },
    getApptAndjoinCount: {
        method: "POST",
        url: "/cms/hourly/rush/subscribe/info"
    },
    ontimeSubscribe: {
        url: "cms/sub/subscribe",
        method: "POST"
    },
    onTimeSubscribeStatus: {
        url: "cms/sub/subscribeStatus",
        method: "POST"
    },
    getOntimeSubscribeNum: {
        url: "cms/sub/subNumQuery",
        method: "POST"
    },
    onTimePageShare: {
        url: "/share/poster/cms/activity/page/share",
        method: "GET"
    },
    onTimeDetailShare: {
        url: "/share/poster/cms/activity/product/share",
        method: "POST"
    },
    queryUserTickets: {
        url: "/cms/quick/payment",
        method: "post",
        defParams: {
            channelUse: "WXAPP",
            configType: "MARKET_ACTIVITY"
        }
    },
    getHomeIconList: {
        url: "/cms/commonIndexIcons",
        method: "POST"
    },
    getOntimeAndActiveCard: {
        url: "/cms/cardPosition/v2/details/multiV2",
        method: "POST"
    },
    getHomeNotice: {
        url: "/cms/notice/query",
        method: "POST"
    }
};

exports.default = e;