Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    getTmProductDetail: {
        url: "/item/home/product/getProductInfo",
        cloud: !0,
        method: "POST"
    },
    getTmSkusnInfo: {
        url: "/item/home/product/getProductBaseInfo",
        cloud: !0,
        method: "POST"
    },
    getRecommendProduct: {
        url: "/item/home/recommend/getRecommendProduct",
        cloud: !0,
        method: "POST",
        mock: !1
    },
    getFeedback: {
        url: "/item/home/recommend/getFeedback",
        method: "POST"
    },
    getPurchaseServiceDesc: {
        url: "/item/home/product/getPurchaseServiceDesc",
        method: "POST"
    },
    cmsShoppingShare: {
        url: "/item/home/jigsaw/cmsShoppingShare",
        method: "POST"
    },
    getProductDetailShare: {
        url: "/item/home/jigsaw/productDetailShare",
        method: "POST"
    },
    getSupplierLicense: {
        url: "/item/home/product/license",
        cloud: !0,
        method: "POST"
    },
    getTMCate: {
        url: "/item/home/recommend/category",
        repeat: 3,
        mock: !1,
        mockData: {
            rspCode: "success",
            data: [ {
                categoryId: "111",
                categoryName: "潮流归案"
            }, {
                categoryId: "333",
                categoryName: "潮流"
            }, {
                categoryId: "444",
                categoryName: "潮流你呀"
            }, {
                categoryId: "5555",
                categoryName: "美丽好的"
            }, {
                categoryId: "3345",
                categoryName: "潮流的"
            }, {
                categoryId: "5645645",
                categoryName: "潮流"
            }, {
                categoryId: "45645",
                categoryName: "潮流"
            }, {
                categoryId: "34534",
                categoryName: "潮流"
            }, {
                categoryId: "5645",
                categoryName: "潮流"
            }, {
                categoryId: "53453",
                categoryName: "潮流"
            }, {
                categoryId: "656",
                categoryName: "潮流"
            }, {
                categoryId: "54667",
                categoryName: "潮流"
            }, {
                categoryId: "2234",
                categoryName: "潮流"
            } ]
        }
    },
    getThemeList: {
        url: "/user/theme/list",
        method: "POST"
    },
    getKeyWords: {
        url: "/item/home/recommend/keyWords",
        method: "POST"
    },
    saveKeyWords: {
        url: "/item/home/recommend/saveKeyWords",
        method: "POST"
    },
    onOperateProduct: {
        url: "/item/home/recommend/collect/operate",
        method: "POST"
    },
    onOperateFootprint: {
        url: "/item/home/recommend/track/operate",
        method: "POST"
    },
    collectProduct: {
        url: "/item/home/recommend/collect/operate",
        method: "POST"
    },
    getThemeDetail: {
        url: "/user/theme/detail",
        method: "POST",
        cloud: !0
    },
    newUserDraw: {
        url: "/agg/new/activity/draw",
        method: "post"
    }
};