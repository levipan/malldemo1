var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.xpsApi = exports.videoApi = exports.usercenterApi = exports.uploadApi = exports.txActive = exports.turingApi = exports.tradeCartApi = exports.tradeApi = exports.tmSearchApi = exports.tmRefundApi = exports.tmProductApi = exports.tmCustomerApi = exports.tkUserApi = exports.tkPromotionApi = exports.storeApi = exports.signApi = exports.shortApi = exports.seckillApi = exports.searchApi = exports.searchABVApi = exports.searchABApi = exports.riversServiceApi = exports.riversCart = exports.rankingApi = exports.puzzleCouponApi = exports.portalCmsApi = exports.pointApi = exports.payMethodsApi = exports.payChargeApi = exports.payApi = exports.panShiApi = exports.orderCommentApi = exports.noticesApi = exports.newTradeCartApi = exports.newSearchApi = exports.newPayApi = exports.newNoticeApi = exports.newAuthApi = exports.memberApi = exports.marketActivityApi = exports.makeMoneyApi = exports.liveRoomApi = exports.leoServiceApi = exports.inviteGiftsApi = exports.homeUserApi = exports.homePromotionApi = exports.homePayApi = exports.homeApi = exports.groupScoreApi = exports.featuretagApi = exports.expressZeroApi = exports.expressApi = exports.couponApi = exports.cookVideoApi = exports.configApi = exports.commonStoreApi = exports.commonPromotionApi = exports.commonApi = exports.commentApi = exports.centerAcApi = exports.cartApi = exports.cancelOrderApi = exports.brandHousePromotionApi = exports.boutiqueApi = exports.authApi = exports.adApi = void 0;

var r = require("./core.js"), t = require("./hooks.js"), o = e(require("./modules/common")), i = e(require("./modules/home.js")), p = e(require("./modules/express.js")), s = e(require("./modules/brandhouse")), a = e(require("./modules/trade")), u = e(require("./modules/cancelOrder")), d = e(require("./modules/point")), l = e(require("./modules/tradeCart")), A = e(require("./modules/pay")), x = e(require("./modules/payMethods")), m = e(require("./modules/payCharge")), n = e(require("./modules/usercenter")), g = e(require("./modules/comment")), c = e(require("./modules/config")), v = e(require("./modules/short")), f = e(require("./modules/cart")), M = e(require("./modules/turing")), H = e(require("./modules/auth")), h = e(require("./modules/member")), q = e(require("./modules/notices")), y = e(require("./modules/newNotice")), k = e(require("./modules/store")), C = e(require("./modules/video")), S = e(require("./modules/search")), P = e(require("./modules/rank")), w = e(require("./modules/ad")), b = e(require("./modules/orderComment")), R = e(require("./modules/featuretag")), O = (e(require("./modules/goodsShare")), 
e(require("./modules/active"))), V = e(require("./modules/xps")), j = e(require("./modules/boutique")), B = e(require("./modules/liveRoom")), z = e(require("./modules/tmProduct")), N = e(require("./modules/tmCustomer")), U = e(require("./modules/tmRefund")), T = e(require("./modules/sign")), D = e(require("./modules/portalCms")), G = e(require("./modules/cookVideo")), K = e(require("./modules/seckill")), Z = e(require("./modules/centerAc")), F = e(require("./modules/makeMoney")), _ = e(require("./modules/activity")), E = e(require("./modules/invite.js")), Y = require("../config.js"), I = Y.apiHost.api, J = Y.apiHost.tradeApi, L = Y.apiHost.cancelOrder, Q = Y.apiHost.payApi, W = Y.apiHost.newPayApi, X = Y.apiHost.panShiApi, $ = Y.apiHost.payMethods, ee = Y.apiHost.payCharge, re = Y.apiHost.promotionApi, te = Y.apiHost.shortApi, oe = Y.apiHost.couponApi, ie = Y.apiHost.comment, pe = Y.apiHost.expressApi, se = Y.apiHost.expressZeroApi, ae = Y.apiHost.tkUserApi, ue = Y.apiHost.tkPromotionApi, de = Y.apiHost.storeApi, le = Y.turingTestDomain, Ae = Y.apiHost.auth, xe = (Y.apiHost.member, 
Y.apiHost.pointApi), me = Y.apiHost.groupScoreApi, ne = Y.apiHost.configApi, ge = Y.apiHost.noticesApi, ce = Y.apiHost.newNoticeApi, ve = Y.apiHost.videoApi, fe = Y.apiHost.tradeCartApi, Me = Y.apiHost.newTradeCartApi, He = Y.apiHost.searchApi, he = Y.apiHost.searchABApi, qe = Y.apiHost.searchABVApi, ye = (Y.apiHost.newSearchApi, 
Y.apiHost.rankingApi), ke = Y.apiHost.adApi, Ce = Y.apiHost.xpsApi, Se = Y.apiHost.uploadApi, Pe = Y.apiHost.promotionApi, we = Y.apiHost.tmSearchApi, be = Y.apiHost.tmPromotionApi, Re = Y.apiHost.tmCustomerApi, Oe = Y.apiHost.tmRefundApi, Ve = Y.apiHost.signApi, je = Y.apiHost.cookVideoApi, Be = Y.apiHost.portalCmsApi, ze = Y.apiHost.puzzleCouponApi, Ne = Y.apiHost.marketActivityApi, Ue = Y.apiHost.leoServiceApi, Te = Y.apiHost.makeMoneyApi, De = Y.apiHost.seckillApi, Ge = Y.apiHost.tradeCartApi, Ke = Y.apiHost.featuretagApi || "https://pay-daily.xsyxsc.cn/featuretag/select", Ze = Y.apiHost.centerActApi, Fe = Y.apiHost.blindBoxRiversApi, _e = Y.apiHost.inviteCouponApi, Ee = (0, 
r.registerModule)(Ge, l.default);

exports.riversCart = Ee;

var Ye = (0, r.registerModule)(pe + "", p.default);

exports.expressApi = Ye;

var Ie = (0, r.registerModule)(se + "", p.default);

exports.expressZeroApi = Ie;

var Je = (0, r.registerModule)(Ue, o.default);

exports.leoServiceApi = Je;

var Le = (0, r.registerModule)(Fe, o.default);

exports.riversServiceApi = Le;

var Qe = (0, r.registerModule)(De, K.default);

exports.seckillApi = Qe;

var We = (0, r.registerModule)(xe + "", d.default);

exports.pointApi = We;

var Xe = (0, r.registerModule)(I + "/api", H.default);

exports.authApi = Xe;

var $e = (0, r.registerModule)(Ae, H.default);

exports.newAuthApi = $e;

var er = (0, r.registerModule)(I + "/api", h.default);

exports.memberApi = er;

var rr = (0, r.registerModule)(le, M.default);

exports.turingApi = rr;

var tr = (0, r.registerModule)(te, v.default);

exports.shortApi = tr;

var or = (0, r.registerModule)(I + "/api", o.default);

exports.commonApi = or;

var ir = (0, r.registerModule)(I + "/api", i.default);

exports.homeApi = ir;

var pr = (0, r.registerModule)(J + "/tradeorder", a.default);

exports.tradeApi = pr;

var sr = (0, r.registerModule)(fe, l.default);

exports.tradeCartApi = sr;

var ar = (0, r.registerModule)(Me, l.default);

exports.newTradeCartApi = ar;

var ur = (0, r.registerModule)(L, u.default);

exports.cancelOrderApi = ur;

var dr = (0, r.registerModule)(Q + "/tradeorder", A.default);

exports.payApi = dr;

var lr = (0, r.registerModule)(W + ([ "PRO", "PROGRAY" ].indexOf(Y.ENV) > -1 ? "/payorder" : "/tradeorder"), A.default);

exports.newPayApi = lr;

var Ar = (0, r.registerModule)(X, A.default);

exports.panShiApi = Ar;

var xr = (0, r.registerModule)(Q + "/tradeorder", A.default);

exports.homePayApi = xr;

var mr = (0, r.registerModule)(I + "/api", n.default);

exports.usercenterApi = mr;

var nr = (0, r.registerModule)(ie, g.default);

exports.commentApi = nr;

var gr = (0, r.registerModule)(ve, C.default);

exports.videoApi = gr;

var cr = (0, r.registerModule)($, x.default);

exports.payMethodsApi = cr;

var vr = (0, r.registerModule)(ee, m.default);

exports.payChargeApi = vr;

var fr = (0, r.registerModule)(ve, B.default);

exports.liveRoomApi = fr;

var Mr = (0, r.registerModule)(Ve, T.default);

exports.signApi = Mr;

var Hr = (0, r.registerModule)(re, f.default);

exports.cartApi = Hr;

var hr = (0, r.registerModule)(re, o.default);

exports.commonPromotionApi = hr;

var qr = (0, r.registerModule)(oe, o.default);

exports.couponApi = qr;

var yr = (0, r.registerModule)(ze, o.default);

exports.puzzleCouponApi = yr;

var kr = (0, r.registerModule)(re, i.default);

exports.homePromotionApi = kr;

var Cr = (0, r.registerModule)(He, S.default);

exports.searchApi = Cr;

var Sr = (0, r.registerModule)(he, S.default);

exports.searchABApi = Sr;

var Pr = (0, r.registerModule)(qe, S.default);

exports.searchABVApi = Pr;

var wr = (0, r.registerModule)(we, S.default);

exports.tmSearchApi = wr;

var br = (0, r.registerModule)(He, S.default);

exports.newSearchApi = br;

var Rr = (0, r.registerModule)(ye, P.default);

exports.rankingApi = Rr;

var Or = (0, r.registerModule)(ke, w.default);

exports.adApi = Or;

var Vr = (0, r.registerModule)(me, o.default);

exports.groupScoreApi = Vr;

var jr = (0, r.registerModule)(Ne, _.default);

exports.marketActivityApi = jr;

var Br = (0, r.registerModule)(re, s.default);

exports.brandHousePromotionApi = Br;

var zr = (0, r.registerModule)(de, o.default);

exports.commonStoreApi = zr;

var Nr = (0, r.registerModule)(ae, o.default);

exports.tkUserApi = Nr;

var Ur = (0, r.registerModule)(ue, i.default);

exports.tkPromotionApi = Ur;

var Tr = (0, r.registerModule)(de, i.default);

exports.homeUserApi = Tr;

var Dr = (0, r.registerModule)(de, k.default);

exports.storeApi = Dr;

var Gr = (0, r.registerModule)(Se, C.default);

exports.uploadApi = Gr;

var Kr = (0, r.registerModule)(ge, q.default);

exports.noticesApi = Kr;

var Zr = (0, r.registerModule)(ce, y.default);

exports.newNoticeApi = Zr;

var Fr = (0, r.registerModule)(ne, c.default);

exports.configApi = Fr;

var _r = (0, r.registerModule)(Pe, b.default);

exports.orderCommentApi = _r;

var Er = (0, r.registerModule)(Ke, R.default);

exports.featuretagApi = Er;

var Yr = (0, r.registerModule)(ve, O.default);

exports.txActive = Yr;

var Ir = (0, r.registerModule)(Ce, V.default);

exports.xpsApi = Ir;

var Jr = (0, r.registerModule)(re, j.default);

exports.boutiqueApi = Jr;

var Lr = (0, r.registerModule)(be, z.default);

exports.tmProductApi = Lr;

var Qr = (0, r.registerModule)(Re, N.default);

exports.tmCustomerApi = Qr;

var Wr = (0, r.registerModule)(Oe, U.default);

exports.tmRefundApi = Wr;

var Xr = (0, r.registerModule)(je, G.default);

exports.cookVideoApi = Xr;

var $r = (0, r.registerModule)(Be, D.default);

exports.portalCmsApi = $r;

var et = (0, r.registerModule)(Te, F.default);

exports.makeMoneyApi = et;

var rt = (0, r.registerModule)(Ze, Z.default);

exports.centerAcApi = rt;

var tt = (0, r.registerModule)(_e, E.default);

exports.inviteGiftsApi = tt, (0, r.registerHook)("afterFetch", t.loginHook), (0, 
r.registerHook)("afterFetch", t.alertHook), (0, r.registerComputedOptions)({
    userKey: function() {
        return ((getApp() || {}).globalData || {}).userKey || wx.getStorageSync("userKey");
    }
});