var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fetch = void 0, exports.registerComputedOptions = function(e) {
    _ = o(o({}, _), e);
}, exports.registerHook = function(e, t) {
    v[e] || (v[e] = []);
    v[e].push(t);
}, exports.registerModule = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], a = {};
    return Object.keys(r).map(function(i) {
        var s = r[i] || {}, u = s.url, l = s.method, d = void 0 === l ? "POST" : l, f = s.cached, p = s.mock, m = s.mockUrl, g = s.mockData, y = s.fit, h = s.sensitive, v = s.repeat, w = s.feed, _ = s.fail, T = s.defParams, x = void 0 === T ? {} : T, C = s.dynamicParams, P = void 0 === C ? [] : C, q = s.cloud, D = s.timeout, E = void 0 === D ? 6e4 : D;
        a.time = +new Date(), a[i] = function(r) {
            var s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            P.map(function(e) {
                r[e] = S[e]();
            }), r = o(o({}, x || {}), r), a.time = s.hasOwnProperty("_time") ? s._time : +new Date();
            var l = a[i], T = (s || {}).hasOwnProperty("loading") ? s.loading : b.loading, C = function() {};
            "object" === t(T) ? C = (0, n.showLoading)(o(o({}, T), {}, {
                duration: 1e4
            })) : T && (C = (0, n.showLoading)({
                title: "string" == typeof T ? T : "加载中"
            }));
            var D = h && h == new Date().getHours();
            if (!D && f && l.__lastRequestTime && !s.noCached) {
                var j = Date.now() - l.__lastRequestTime > f;
                if (!j && (0, n.shallowEqual)(r, l.__lastCachedParams)) {
                    var A = "function" == typeof y ? y(l.__lastCachedResponse, r, s) : l.__lastCachedResponse, R = Promise.resolve(A);
                    return R.then(function() {
                        "function" == typeof C && setTimeout(C, 500);
                    }), R;
                }
            }
            var F = (e || "").replace(/\/$/, "") + "/" + (u || "").replace(/^\//, ""), K = p ? m : F, I = function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                return O(K, r, o(o({
                    timeout: E
                }, s), {}, {
                    method: p ? "GET" : d,
                    enableCloud: q
                }), p ? g : void 0).then(function(e) {
                    C(), l.cache = l.__lastCachedResponse = wx.$.deepCopy(e);
                    var t = "function" == typeof y ? y(e, r, s) : e;
                    return l.__lastRequestTime = Date.now(), l.__lastCachedParams = r, t;
                }, function(o) {
                    return --t > 0 && -1 == c.default.indexOf((o || {}).rspCode) ? e(t) : (C(), (0, 
                    n.isFunction)(w) ? Promise.resolve(w(o, r, s)) : (0, n.isFunction)(_) ? Promise.reject(_(o, r, s)) : Promise.reject(o));
                });
            };
            return I(v);
        };
    }), a;
};

var t = require("../@babel/runtime/helpers/typeof"), r = require("../@babel/runtime/helpers/defineProperty"), o = require("../@babel/runtime/helpers/objectSpread2"), n = require("../utils/index.js"), a = require("../utils/storage.js"), i = require("../utils/common"), s = e(require("../config")), u = e(require("../utils/md5.min.js")), c = e(require("../const/login-expire.js")), l = require("../const/storage.key"), d = (0, 
require("./hooks.js").gatewayErrorFactory)(), f = d.setGatewayTotal, p = d.setGatewayFailAmount, m = d.getIsDC, g = require("../utils/common.js"), y = wx.getSystemInfoSync() || {}, h = g.compareVersion("2.16.0", y.SDKVersion || "2.16.1") <= 0, v = {
    afterFetch: []
}, w = !1, _ = {
    userKey: function() {
        return (0, a.getStorageSync)("userKey") || "";
    }
}, S = {
    ndTrueSales: function() {
        return (0, a.getStorageSync)(l.STORAGE_KEY.IF_SHOW_FUZZY_SALES) || !1;
    },
    blackBox: function() {
        return (0, a.storage)("safe_bb") || "";
    },
    bb: function() {
        return (0, a.storage)("safe_bb") || "";
    }
}, b = {
    method: "POST",
    dataType: "json",
    loadMsg: "加载中",
    silence: !1,
    loading: !1,
    data: {}
}, T = s.default.wxCloudInfo || null;

b.header = {
    "Content-type": "post" === b.method.toLowerCase() || "get" === b.method.toLowerCase() ? "application/x-www-form-urlencoded" : "application/json",
    Accept: "application/json, text/plain, */*",
    source: "applet",
    version: s.default.version,
    "X-Feature-Tag": "item_product_home"
};

var O = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, c = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, d = arguments.length > 3 ? arguments[3] : void 0, y = c || {}, S = y.silence, O = y.timeout, x = void 0 === O ? 6e4 : O;
    return new Promise(function(y, O) {
        var C = null, P = {
            success: function(e) {
                var t = (e || {}).data || {}, r = t.data, o = t.rspCode, a = t.rspDesc;
                "success" === o ? y(r) : (S || (0, n.showToast)(a || "发生了一些小问题~"), O((e || {}).data || {}));
            },
            fail: function(e) {
                S || (0, n.showToast)("网络连接失败~"), O(e);
            },
            complete: function(r) {
                v.afterFetch.length && v.afterFetch.map(function(n) {
                    n(e, r, t, o(o({}, b), c));
                });
            }
        }, q = Object.keys(_).map(function(e) {
            return !("userKey" == e && !_[e]()) && r({}, e, _[e]());
        }).reduce(function(e, t) {
            return o(o({}, e), t);
        }, {}), D = JSON.parse(JSON.stringify(b.header));
        if (c.header && (D = o(o({}, D), c.header)), (c || {}).contentType && (D["Content-type"] = c.contentType), 
        t.storeUserKey && (D.storeUserKey = t.storeUserKey), D.userKey = t.userKey || q.userKey || "", 
        D.version = s.default.version, D.source = "applet", D.preBuy = "true", D.fuzzy = !0 === ((0, 
        a.getStorageSync)("moduleConfig") || {}).fuzzy ? "true" : "false", D.userRecommend = !1 === (0, 
        a.getStorageSync)("isOpenProductRecommend") ? "false" : "true", !0 === (0, a.getStorageSync)(l.STORAGE_KEY.SHOW_FUZZY_SALES) && (D.xsyxAb = "true"), 
        D.clientType = "MINI_PROGRAM", "PRO" != s.default.ENV) {
            var E = (0, a.getStorageSync)("apiFeatureTag");
            E && (D["X-Feature-Tag"] = E);
        }
        if (d) P.success({
            data: d
        }), P.complete({
            data: d
        }), C = wx.request(o(o(o(o({
            url: e
        }, b), {}, {
            data: data
        }, c), {}, {
            header: D
        }, P), {}, {
            timeout: x
        })); else {
            var j = o(o(o(o({}, {
                clientType: "MINI_PROGRAM"
            }), b.data), q), t);
            c.hasOwnProperty("sig") && c.sig && (j = "application/x-www-form-urlencoded" === D["Content-type"] ? (0, 
            i.parseParam)(j) : JSON.stringify(j), D["Api-Timestamp"] = 1 * new Date().getTime() + ((0, 
            i.getMOrSData)("timeDiffServerAndClient") || 0) + -1 * (new Date().getTimezoneOffset() + 480) * 1e3 * 60, 
            D["Api-Version"] = "V3", D["Api-Sign"] = (0, u.default)(j + D["Api-Timestamp"] + s.default.httpSlot));
            var A = !0;
            try {
                A = "gateway" === g.getMData("picasso").gateway.meta;
            } catch (e) {}
            try {
                (s.default.cloudDomain || []).some(function(t) {
                    return e.indexOf(t) > -1;
                }) && (c.enableCloud = !0);
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                console.error(e);
            }
            if (A && (c.enableCloud || c.wxGateway) && T && !m()) {
                if (!w) try {
                    (h ? wx.__cloud__ : wx.cloud).init({
                        traceUser: !0,
                        env: T.env
                    }), w = !0;
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    p(), g.XSMonitor.sendEvent("monitorError_error", {
                        content: e
                    }, "");
                }
                var R = e.split("/"), F = "/".concat(R.slice(3, 10).join("/")), K = R[2];
                K = (T.newDomain || {})[K] || K;
                var I = {};
                T.configEnv && (I = {
                    config: {
                        env: T.configEnv
                    }
                });
                var k = o(o({
                    path: F,
                    data: j,
                    method: c.method || "POST"
                }, I), {}, {
                    timeout: x,
                    header: o(o({}, D), {}, {
                        "X-WX-EXCLUDE-CREDENTIALS": "unionid, cloudbase-access-token, openid",
                        "X-WX-GATEWAY-ID": T.gatewayId,
                        HOST: K
                    })
                });
                f(), C = (h ? wx.__cloud__ : wx.cloud).callContainer(o(o({}, k), {}, {
                    success: function(e) {
                        P.success(e);
                    },
                    fail: function(e) {
                        P.fail(e), p();
                    },
                    complete: function(e) {
                        P.complete(e);
                    }
                }));
            } else C = wx.request(o(o(o(o({
                url: e
            }, b), {}, {
                data: j
            }, P), c), {}, {
                header: D,
                timeout: x
            }));
        }
        c.hasOwnProperty("abort") && (c.abort.abort = function() {
            return C && C.abort();
        });
    });
};

exports.fetch = O;