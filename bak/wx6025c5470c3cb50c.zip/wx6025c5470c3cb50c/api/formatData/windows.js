var i = require("../../@babel/runtime/helpers/interopRequireWildcard");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.formatClassifyWindowsData = function(i) {
    var o = function(i, n) {
        var o = [];
        return i.forEach(function(i, a) {
            var r = i.brandWindowId || i.windowId;
            o.push(e(e({}, i), {
                type: n,
                page: 0,
                isLoadComplete: !1,
                brandWindowId: r,
                windowId: r,
                label: i.windowName,
                icon: i.iconUrl || i.icon
            }));
        }), o;
    };
    return i.brandHouseWindows = o(i.brandHouseWindows || [], "brandHouseWindows"), 
    i.activityWindows = o(i.activityWindows || [], "activityWindows"), i.classifyWindows = o(i.classifyWindows || [], "classifyWindows"), 
    i.recommendWindows = o(i.recommendWindows || [], "recommendWindows"), i.pageLoadingScheme = "V2" == i.apiVersion || (((getApp() || {}).globalData || {}).moduleConfig || {}).cityVersion ? 2 : 1, 
    ((getApp() || {}).globalData || {}).apiVersion = i.apiVersion, n.default.emit(n.EVENTS.UPDATE_CATE_SHOW_STATUS, "V2" == i.apiVersion), 
    i;
}, exports.formatCommonWindowsData = function(i) {
    var e = {}, n = function(i, n) {
        switch (i.type = n, i.isLoadComplete = !1, i.brandWindowId = i.windowId, i.label = i.windowName, 
        i.isFirst = !1, i.secondWindows = i.secondWindows || [], n) {
          case "classify":
            i.idPrefix = "cate_";
            break;

          case "activity":
            i.idPrefix = "cate_ms_";
            break;

          case "brand_house":
            i.idPrefix = "cate_brand_", i.type = "brandhouse";
            break;

          case "recommend_window":
            i.type = "recommendWindows", i.windowId = -2;
            break;

          case "home_shopping":
            i.windowId = -3;
        }
        return e[n] || (i.isFirst = !0, e[n] = !0), i;
    }, o = (i.recommendWindows || []).map(function(i) {
        return n(i, "recommendWindows");
    }) || [], a = (i.commonWindowDTOS || []).map(function(i) {
        return n(i, i.windowType.toLowerCase());
    }) || [];
    return o.concat(a);
}, exports.formatSortWindowsData = function(i) {
    var e = i.windows || [], n = {};
    return e.map(function(i) {
        var e = i.windowType.toLowerCase();
        switch (i.type = e, e) {
          case "classify":
            i.idPrefix = "cate_";
            break;

          case "activity":
            i.idPrefix = "cate_ms_";
            break;

          case "brand_house":
            i.idPrefix = "cate_brand_", i.type = "brandhouse";
        }
        return i.isFirst = !1, n[e] || (i.isFirst = !0, n[e] = !0), i;
    }), e;
}, exports.formatWindowsData = function(i) {
    var o = i.businessData || {}, a = function(i) {
        var n = [];
        return i.forEach(function(i, o) {
            var a = i.brandWindowId || i.windowId;
            n.push(e(e({}, i), {
                page: 0,
                isLoadComplete: !1,
                brandWindowId: a,
                windowId: a,
                label: i.windowName,
                icon: i.iconUrl || i.icon
            }));
        }), n;
    };
    return o.brandHouseWindows = a(o.brandHouseWindows || []), o.activityWindows = a(o.activityWindows || []), 
    o.classifyWindows = a(o.classifyWindows || []), o.pageLoadingScheme = "V2" == o.apiVersion || (((getApp() || {}).globalData || {}).moduleConfig || {}).cityVersion ? 2 : 1, 
    ((getApp() || {}).globalData || {}).apiVersion = o.apiVersion, n.default.emit(n.EVENTS.UPDATE_CATE_SHOW_STATUS, "V2" == o.apiVersion), 
    e(e({}, i), {}, {
        businessData: o
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), n = (require("../../utils/index"), 
i(require("../../utils/events.js")));