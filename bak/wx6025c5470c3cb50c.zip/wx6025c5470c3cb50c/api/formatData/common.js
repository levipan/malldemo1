Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.formatSysParamsData = function(r) {
    if (r && r.time) {
        var s = "";
        for (var i in r) if ("time" != i) {
            s = i;
            break;
        }
        var o = r.time ? a.strToDate(r.time) : new Date();
        a.setMAndSData("timeDiffServerAndClient", +o - +new Date()), s && a.setMAndSData("sysParams-" + s, r[s]);
    }
    var f = (0, t.strToTs)(r.time) - Date.now();
    ((getApp() || {}).globalData || {}).timeOffset = f, (0, t.setTimeOffset)(f);
    var n = e(e({}, r), {}, {
        offset: f
    }), m = r["7Z_LIMIT_TIME"];
    m && (n.bizRange = m, ((getApp() || {}).globalData || {}).bizRange = m);
    return a.setStorageSync("request_fetchSysParam", n), n;
}, exports.formatSysParamsFeed = function() {
    var e = wx.getStorageSync("request_fetchSysParam");
    "number" == typeof (e || {}).offset && (e.time = (0, t.formaterDate)(+new Date() + e.offset, "yyyy-MM-dd HH:mm:ss"));
    return e;
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../utils/index.js"), a = require("../../utils/common.js");