Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.convertSaleDate = n, exports.convertSaleTime = m, exports.formatProductData = a, 
exports.formatProductInfoData = function(t, e, r) {
    return a(t, e, null, r);
}, exports.formatProductsData = r, exports.notWindowsFormatProductsData = function(t) {
    var e = r(t), a = e.filter(function(t) {
        return "BRAND_HOUSE" == t.prType;
    }), n = e.filter(function(t) {
        return "CHOICE" == t.prType;
    });
    return {
        brandhouseProducts: a,
        choiceProducts: n,
        products: e
    };
};

var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../utils/index");

function r(t, r) {
    t = t || [];
    var n = [], m = (0, e.getEffectiveBizRangeInfo)(), s = (0, e.now)(), o = (0, e.formaterDate)((0, 
    e.now)(), "yyyy-M-d"), i = (0, e.formaterDate)(s + (1 == m.isNextDay ? 864e5 : 0), "yyyy-M-d");
    return m.startTimeStr = (0, e.formaterDate)(m.startTime, "yyyy-MM-dd HH:mm:ss"), 
    m.endTimeStr = (0, e.formaterDate)(m.endTime, "yyyy-MM-dd HH:mm:ss"), t.map(function(t, e) {
        n.push(a(t, s, o, i, m, r));
    }), n;
}

function a(r, a, s, o, i, y) {
    if (i = i || (0, e.getEffectiveBizRangeInfo)(), a = a || (0, e.now)(), s = s || (0, 
    e.formaterDate)(a, "yyyy-M-d"), o = o || (0, e.formaterDate)(a + (1 == i.isNextDay ? 864e5 : 0), "yyyy-M-d"), 
    !r) return r;
    var u = r.tmBuyStart, d = r.tmBuyEnd, T = r.tmShowStart, f = r.tmShowEnd;
    T = T || u, f = f || d, u = (0, e.strToTs)(u), d = (0, e.strToTs)(d);
    var S = (0, e.strToTs)(T), D = (0, e.strToTs)(f), c = "";
    if (r.isNextDayPickUp) {
        var p = Math.min(Math.max(a + (1 == i.isNextDay ? 864e5 : 0), u), d);
        if (c = (0, e.formaterDate)(p, "MM月dd日"), (y || i.isNextDay) && 1 == r.assignType) {
            var x = m(a, s, T, f, u, d, i);
            S = x.tmShowStartTs, D = x.tmShowEndTs, u = x.tmBuyStart, d = x.tmBuyEnd;
        }
        if (0 == r.assignType) {
            var B = n(u, d, i);
            u = B.tmBuyStart, d = B.tmBuyEnd;
        }
        c = (0, e.formaterDate)((0, e.strToDate)(r.tmPickUp || u) - 864e5, "MM月dd日");
    } else if (0 == r.assignType) {
        c = (0, e.timeRange)(u, d);
        var M = n(u, d, i);
        u = M.tmBuyStart, d = M.tmBuyEnd;
    } else {
        var h = m(a, s, T, f, u, d, i);
        S = h.tmShowStartTs, D = h.tmShowEndTs, u = h.tmBuyStart, d = h.tmBuyEnd, c = h.tmBuyStartDate;
    }
    return t(t({}, r), {}, {
        key: (0, e.pk)(r.spuSn, r.skuSn),
        tsBuyEnd: d,
        tsBuyStart: u,
        tsShowStart: S,
        tsShowEnd: D,
        tmPickUpDate: r.tmPickUp ? (0, e.tmToDate)(r.tmPickUp) : null,
        tmBuyStartDate: c,
        isContinuousSale: -1 != c.indexOf("-")
    });
}

function n(t, e, r) {
    var a = t, n = e;
    return r.isNextDay ? a > r.nextDayEndTime || n < r.startTime ? (t = a, e = n) : n < r.nextDayStartTime ? (t = a, 
    e = Math.min(n, r.endTime)) : (t = Math.max(a, r.nextDayStartTime), e = Math.min(n, r.nextDayEndTime)) : a > r.endTime || n < r.startTime ? (t = a, 
    e = n) : (t = Math.max(a, r.startTime), e = Math.min(n, r.endTime)), {
        tmBuyStart: t,
        tmBuyEnd: e
    };
}

function m(t, r, a, n, m, s, o) {
    var i = (0, e.formaterDate)(t, "yy年M月d日"), y = (0, e.strToTs)(a), u = (0, e.strToTs)(n), d = (0, 
    e.formaterDate)(n, "yy年M月d日");
    return +t > s && +t < u && d != i && (m = (0, e.strToTs)(r + (0, e.formaterDate)(m, " HH:mm:ss")) + 864e5, 
    s = (0, e.strToTs)(r + (0, e.formaterDate)(s, " HH:mm:ss")) + 864e5), {
        tmShowStartTs: y,
        tmShowEndTs: u,
        tmBuyStart: m,
        tmBuyEnd: s,
        tmBuyStartDate: (0, e.timeRange)(y, u)
    };
}