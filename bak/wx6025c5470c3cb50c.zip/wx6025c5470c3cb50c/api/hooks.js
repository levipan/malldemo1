var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.alertHook = function(e, o, t, r) {
    var n = (o || {}).data || {};
    !0 === r.alertHook && "success" != n.rspCode && wx.showModal({
        title: "温馨提示",
        content: n.rspDesc || "发生了点小问题!",
        showCancel: !1,
        success: function() {
            !function(e, o, t, r) {
                if ([ "system_version_too_low", "unsupported_system_version" ].indexOf(o.rspCode || "") >= 0) {
                    if ("function" != typeof wx.getUpdateManager) return;
                    var n = wx.getUpdateManager();
                    n.onCheckForUpdate(function(e) {
                        e.hasUpdate || "unsupported_system_version" !== o.rspCode || wx.showToast({
                            title: "暂无更新",
                            icon: "none",
                            duration: 2e3
                        });
                    }), "unsupported_system_version" === o.rspCode && (n.onUpdateReady(function() {
                        wx.showModal({
                            title: "更新提示",
                            content: "新版本已经准备好，是否重启应用？",
                            success: function(e) {
                                e.confirm && n.applyUpdate();
                            }
                        });
                    }), n.onUpdateFailed(function() {
                        wx.showModal({
                            title: "更新提示",
                            content: "新版本下载失败",
                            showCancel: !1
                        });
                    }));
                }
            }(0, n);
        }
    });
}, exports.gatewayErrorFactory = function() {
    var e = 0, o = 0, t = !1;
    return {
        setIsDC: function(e) {
            t = e;
        },
        getIsDC: function() {
            return t;
        },
        setGatewayTotal: function() {
            ++e;
        },
        setGatewayFailAmount: function() {
            (++o >= 5 || o / e >= .5) && !t && wx.request({
                url: "https://rivers-third.xsyxsc.com/rivers/degrade/status",
                success: function(e) {
                    try {
                        t = e.data.data;
                    } catch (e) {}
                }
            });
        }
    };
}, exports.loginHook = function(e, n, s, a) {
    var i = (n || {}).data || {}, u = "boolean" != typeof a.loginVerify || !0 === a.loginVerify, d = [ "login_expire", "loginExpire", "loginError", "10009", 10009 ].indexOf(i.rspCode || "") >= 0;
    if (d) {
        r.removeMAndS("userId"), r.removeMAndS("userKey"), r.removeMAndS("red-bag"), r.removeMAndS("collectCoupons"), 
        r.removeMAndS("unLoginModal"), r.removeMAndS("isLogin"), r.removeMAndS("userInfo"), 
        r.removeMAndS("wechat-nickName"), r.removeMAndS("user-mobileNo"), r.removeMData("wxGetUserProfileInfo"), 
        r.removeMData("wxLoginSuccessCode");
        var c = wx.$initStore((0, o.default)());
        c.setCurrAddress(null), c.setDefaultAddress(null), wx.$data.remove("cart"), wx.$data.remove("skuSnNumber", {
            module: "store"
        }), wx.$data.remove("spuSnNumber"), wx.$data.remove("cartNumber"), wx.$data.remove("wait-sync-cart"), 
        wx.$data.remove("cart", {
            module: "store"
        }), wx.$initStore((0, t.default)()).setBagNumber(0);
    }
    u && d && r.goToLoginShowModal(i.rspDesc);
};

var o = e(require("../plugins/store/address.js")), t = e(require("../plugins/store/bagNumber.js")), r = require("../utils/common.js");