var e = require("@babel/runtime/helpers/interopRequireWildcard"), t = require("@babel/runtime/helpers/interopRequireDefault"), r = require("@babel/runtime/helpers/typeof");

require("@babel/runtime/helpers/Objectvalues");

var n = t(require("@babel/runtime/regenerator")), a = require("@babel/runtime/helpers/toConsumableArray"), i = require("@babel/runtime/helpers/asyncToGenerator"), s = require("@babel/runtime/helpers/defineProperty"), o = require("@babel/runtime/helpers/objectSpread2"), u = t(require("./xsyx_cg_module_main/store/main.js")), c = t(require("./xsyx_cg_module_main/search/main.js")), p = t(require("./xsyx_cg_module_main/old/main.js")), d = t(require("./xsyx_cg_module_main/member/main.js")), l = t(require("./xsyx_cg_module_main/login/main.js")), g = t(require("./xapp/index")), h = t(require("./xapp/utils")), f = require("./plugins/store/index"), x = t(require("./utils/point")), m = t(require("./cgPlugins.js"));

require("./utils/polyfill"), require("./utils/injectionis"), require("./monitor.js");

t(require("./xapp/runtime"));

var b = require("./utils/sysInfo"), S = require("./api/index"), _ = require("./utils/source-point");

require("./utils/wx-api.js");

var w = e(require("./utils/events.js")), y = require("./configs/config.scene.js"), v = t(require("./utils/scene")), $ = require("./router/index"), I = require("./configs/config.point.js"), D = t(require("./behavior/silent.login.js")), P = require("./utils/index"), M = require("./plugins/router/router.js"), O = require("./plugins/storage/storage"), k = t(require("./plugins/store/bagNumber")), A = t(require("./utils/picasso")), q = require("./const/storage.key"), E = require("./utils/globalPointEvent.js");

g.default.use("store", f.store), g.default.use("afterFunction", x.default);

var T = require("./config"), C = require("./utils/common"), L = require("./utils/userdata"), N = require("./utils/cartService.js"), R = require("./utils/homeBagService.js"), j = require("./plugins/router/index"), V = (0, 
D.default)();

var U, B, H, G = (U = wx.getSystemInfoSync() || {}, B = wx.$._get(U, "safeArea.top", b.isIPhoneX ? 47 : 0), 
H = b.isIPhoneX ? 34 : 0, U.screenHeight > wx.$._get(U, "safeArea.bottom", 0) && (H = U.screenHeight - wx.$._get(U, "safeArea.bottom", 0)), 
o(o({}, U), {}, {
    isIPhoneX: b.isIPhoneX,
    safeBottomHeight: H,
    safeTopHeight: B,
    safeHeight: wx.$._get(U, "safeArea.height", !1) || U.screenHeight - B - H
}));

console.log(G, "extendSysInfo"), g.default.use("extend", {
    data: {
        sysInfo: G,
        ossSuffix: {
            q: "?x-oss-process=image/quality,q_70",
            indexShopCart: "?x-oss-process=image/resize,w_345,h_194,m_mfit/crop,g_center,w_345,h_194,q_70",
            detailTopImg: ""
        }
    },
    __defaultShareInfo: {
        title: "【兴盛优选】下单链接",
        imageUrl: "https://front-xps-cdn.xsyx.xyz/2021/11/27/1579119918.png",
        path: "/pages/home/index/index"
    },
    initLocalStore: function(e) {
        var t = this, r = {};
        return Object.keys(e).forEach(function(t) {
            "name" !== t && (wx.$.isFunction(e[t]) || (r[t] = wx.$.deepCopy(e[t])));
        }), t.setData(s({}, e.name, r)), e.commit = function(r, n) {
            t.data[this.name][r] = n, t.setData(s({}, this.name, t.data[this.name]), {
                update: !0
            }), e[r] = n;
        }, e.getStore = function(e, t) {
            return t ? $store.store[t][e] : this[e];
        }, e;
    },
    getEventParams: function(e) {
        return o(o({}, wx.$._get(e, "currentTarget.dataset", {}) || {}), {}, {
            detail: wx.$._get(e, "detail", {}) || {}
        });
    },
    _onNavigateTo: function(e) {
        var t = e.currentTarget.dataset || {}, r = t.path, n = t.query, a = t.type;
        a = a || "navigateTo", n = n || {}, getApp().router[a]({
            path: r
        });
    },
    bindNewStoreLink: function() {
        try {
            var e = getApp();
            if (!e.frxs.isLogin()) return;
            var t = e.frxs.getMOrSData("storeBindInfo"), r = wx.$._get(t, "invitationCode", "") || "";
            if (!r) return;
            var n = wx.$._get(t, "channel", "") || "", a = e.frxs.getMOrSData("db-user") || {}, i = a.nickName, s = void 0 === i ? "" : i, o = a.headImgUrl, u = void 0 === o ? "" : o;
            if (!s || !u) return;
            var c = {
                invitationCode: r,
                nickname: s,
                headImg: u,
                blackBox: e.frxs.storage("safe_bb") || "",
                clientType: "MINI_PROGRAM"
            };
            S.couponApi.saveRelationship(c, {
                silence: !0,
                contentType: "application/json"
            }), e.frxs.setMData("_c", {
                s: e.frxs.getMOrSData("storeId"),
                f: "ad",
                c: n
            }), e.frxs.removeMAndS("storeBindInfo");
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    initTkSubscribeMessage: function() {
        try {
            var e = getApp(), t = e.frxs.getMData("tkInfo") || {}, r = wx.$.storage.get("tk_subscribe_message");
            0 === t.code && t.id && t.sign && !r && (wx.requestSubscribeMessage && wx.getSetting({
                withSubscriptions: !0,
                success: function(t) {
                    var r = e.frxsConfig.tmplIds.tkMessage, n = [ r ];
                    t && t.subscriptionsSetting && t.subscriptionsSetting.mainSwitch && !t.subscriptionsSetting[r] && wx.requestSubscribeMessage({
                        tmplIds: n,
                        complete: function(e) {
                            (0, P.tmplIdsAddEvt)(n, e, "tk购买优惠通知");
                        }
                    });
                }
            }), this.$storage.set("tk_subscribe_message", 1, 172800));
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    bindTk: function() {
        try {
            var e = getApp();
            if (this.__wxExparserNodeId__ == e.preShowPageId || !this.__wxExparserNodeId__) return e.isRunBindTk = null;
            var t = JSON.parse(JSON.stringify(e.enterAppOptions || {})), r = wx.$._get(t, "query", {}) || {}, n = (wx.$._get(t, "scene", !1), 
            wx.$._get(t, "path", "") || "");
            r.twitterId && r.sign && "subTK/pages/home/index" !== n && (e.globalData.tkInfo = {
                id: r.twitterId,
                sign: r.sign,
                code: 0
            }), e.isRunBindTk = null;
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e, "绑定tk关系失败"), K.isRunBindTk = null;
        }
    }
});

var K = null;

g.default.use("onLoad", function() {
    var e = i(n.default.mark(function e(t) {
        var r, i, s, u, c, p, d, l, g, h, f, x, m;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                r = t.next, t.params, i = t.options, K || (K = getApp()), this._storeId = K.frxs.getMOrSData("storeId"), 
                this._isLogin = K.frxs.isLogin();
                try {
                    (s = wx.$._get(i, "iType", !1)) && (u = JSON.parse(wx.$.decode(s, 5)), wx.$.isObject(u) && Object.keys(u).length > 0 && K.frxs.setMData("inner", u));
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
                try {
                    i.bsd && (c = JSON.parse(wx.$.decode(i.bsd, 5)), K.frxs.getMData("picasso").sendEventManually("sharePageShow", {
                        slot: "分享链接落地页打开"
                    }, "", c));
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
                try {
                    wx.$._get(i, "channel", !1) && (p = {}, Object.keys(i).forEach(function(e) {
                        -1 === i[e].indexOf("http") && (p[e] = i[e]);
                    }), K.frxs.setMData("_p", o({}, p)), K.frxs.setMData("_c", o({}, p)));
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
                try {
                    if ((d = wx.$._get(i, "p", !1)) && (l = JSON.parse(wx.$.decode(d, 5)), wx.$.isObject(l) && Object.keys(l).length > 0)) {
                        try {
                            (g = wx.$._get(this, "options.channel", !1)) && g.match(/^[0-9]*$/g) && (g = +g), 
                            g && (l.c = g);
                        } catch (e) {
                            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                            console.log(e);
                        }
                        console.log("这里是::::::", l), K.frxs.setMData("_p", l), K.frxs.setMData("_c", o({}, l)), 
                        59 === Number(l.c) && (h = wx.$.sessionStorage.get("_videoNumberArray") || [], wx.$.sessionStorage.set("_videoNumberArray", a(new Set([].concat(a(h), [ l.sku_sn ]))))), 
                        l && "read" === l.type && (0, _.onSourceUploadInfo)(l);
                    }
                } catch (e) {
                    e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                    console.error(e);
                }
                if (!([ "pages/home/index/index" ].indexOf(this.route) > -1 && this.authScene)) {
                    e.next = 14;
                    break;
                }
                return e.next = 11, this.authScene(i);

              case 11:
                if (!e.sent) {
                    e.next = 14;
                    break;
                }
                return e.abrupt("return", r(!1));

              case 14:
                if (e.prev = 14, -1 === [ "subMain/main/index", "pages/home/index/index" ].indexOf(this.route)) {
                    e.next = 30;
                    break;
                }
                if (!K.frxs.getStorageSync("isCareVersion")) {
                    e.next = 22;
                    break;
                }
                return wx.$CG.$tran.open({
                    moduleName: "old",
                    routerQuery: o(o({}, i), {}, {
                        tabCode: i.tabCode || "home"
                    })
                }), K.frxs.setMData("inner", {
                    i: "11"
                }), e.abrupt("return");

              case 22:
                if ("" !== K.frxs.getStorageSync("isCareVersion")) {
                    e.next = 30;
                    break;
                }
                if (f = K.frxs.getMOrSData("userKey"), x = K.frxs.getMOrSData("isLogin"), !f || !x) {
                    e.next = 30;
                    break;
                }
                return e.next = 28, S.memberApi.getListResources({}, {
                    contentType: "application/json",
                    silence: !0
                });

              case 28:
                (m = e.sent) && m.length && m.forEach(function(e) {
                    if ("CARE_VERSION" === e.optionCode && (K.frxs.setMAndSData("isCareVersion", "1" == e.optionValue), 
                    "1" == e.optionValue)) return wx.$CG.$tran.open({
                        moduleName: "old",
                        routerQuery: o(o({}, i), {}, {
                            tabCode: i.tabCode || "home"
                        })
                    }), void K.frxs.setMData("inner", {
                        i: "11"
                    });
                    "PRODUCT_RECOMMEND" === e.optionCode && K.frxs.setMAndSData("isOpenProductRecommend", "1" == e.optionValue);
                });

              case 30:
                e.next = 35;
                break;

              case 32:
                e.prev = 32, e.t0 = e.catch(14), console.log("isCareVersion--\x3eerror", e.t0);

              case 35:
                if (e.prev = 35, -1 === [ "pages/home/productDetail/productDetail", "subProduct/detail/index", "subDetail/index" ].indexOf(this.route) || "DETAIL_PAGE_SHARE" !== i.position && "SIMPLE_HOME_SHARE" !== i.position) {
                    e.next = 39;
                    break;
                }
                return K.frxs.getMOrSData("isCareVersion") && "SIMPLE_HOME_SHARE" !== i.position ? (wx.$CG.$tran.open({
                    moduleName: "old",
                    routerQuery: o(o({}, i), {}, {
                        tabCode: "brand"
                    })
                }), K.frxs.setMData("inner", {
                    i: "11"
                })) : "SIMPLE_HOME_SHARE" === i.position ? (i.tabCode = "home", wx.reLaunch({
                    url: "/subMain/main/index?".concat(K.frxs.parseParam(i))
                })) : wx.reLaunch({
                    url: "/pages/home/cateProduct/index?".concat(K.frxs.parseParam(i))
                }), e.abrupt("return", r(!1));

              case 39:
                e.next = 44;
                break;

              case 41:
                e.prev = 41, e.t1 = e.catch(35), console.error(e.t1);

              case 44:
                r((K || {
                    globalData: {
                        isCheckLogin: !0
                    }
                }).globalData.isCheckLogin);

              case 45:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 14, 32 ], [ 35, 41 ] ]);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}()), g.default.use("onShow", function() {
    var e = i(n.default.mark(function e(t) {
        var r, a, i, s;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = t.next, K || (K = getApp()), this._g_recommend_sid = K.frxs.newGuid(), this.bindNewStoreLink && this.bindNewStoreLink(), 
                K.isRunBindTk && this.bindTk(), !!!~[ "subLogin/pages/login/index", "subLogin/pages/telLogin/index" ].indexOf(this.route)) {
                    e.next = 8;
                    break;
                }
                return e.abrupt("return", r(!0));

              case 8:
                if (!K.frxs.getMOrSData("storeId") || 1 * this._storeId == 1 * K.frxs.getMOrSData("storeId")) {
                    e.next = 14;
                    break;
                }
                if (!([ "subPages/home/brand/hotlist/index", "subPages/home/brand/newList/index", "subPages/home/brand/shareList/index", "subPages/home/brand/offerList/index", "subPages/home/brand/repurchaseList/index" ].indexOf(this.route) > -1)) {
                    e.next = 14;
                    break;
                }
                if (K.frxs.getMOrSData("inCircleFriend")) {
                    e.next = 14;
                    break;
                }
                return wx.reLaunch({
                    url: "/pages/home/index/index"
                }), e.abrupt("return");

              case 14:
                if (K.frxs.getMOrSData("storeId") && 1 * this._storeId != 1 * K.frxs.getMOrSData("storeId")) {
                    e.next = 21;
                    break;
                }
                if (!([ "subOrder/pay/pay", "subOrder/uyingDirect/uyingDirect", "subPages/pages/payPhone/home/index", "subPages/users/orderList/orderList", "subPages/users/orderDetail/orderDetail", "subPages/subOrder/uyingDirect/uyingDirect", "subPages/users/orderSearch/index" ].indexOf(this.route) > -1)) {
                    e.next = 19;
                    break;
                }
                return e.abrupt("return", r(!0));

              case 19:
                if (this._isLogin !== K.frxs.isLogin()) {
                    e.next = 21;
                    break;
                }
                return e.abrupt("return", r(!0));

              case 21:
                if (a = this.route, i = [ "pages/home/index/index", "pages/users/center/center", "pages/home/cart/cart", "pages/home/cateProduct/index", "pages/home/live/index", "subMain/main/index" ], 
                s = C.parseParam(o(o({}, this.options), {}, {
                    v: Math.random()
                }), null, !1), -1 !== i.indexOf(a)) {
                    e.next = 28;
                    break;
                }
                return a = "/" + a + "?" + s, wx.redirectTo({
                    url: a,
                    success: function() {}
                }), e.abrupt("return", r(!1));

              case 28:
                return a = "/" + a + "?" + s, wx.reLaunch({
                    url: a,
                    complete: function() {}
                }), e.abrupt("return", r(!1));

              case 31:
              case "end":
                return e.stop();
            }
        }, e, this);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}()), g.default.use("onHide", function() {
    var e = i(n.default.mark(function e(t) {
        var r;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.next, (getApp() || {}).preShowPageId = this.__wxExparserNodeId__, e.abrupt("return", r(!0));

              case 3:
              case "end":
                return e.stop();
            }
        }, e, this);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}()), wx.$.Page = g.default.getPage(Page), wx.$.Component = g.default.getComponent(Component), 
(0, M.routeInit)(wx, j), (0, O.storageInit)(wx, {}), App(o(o({
    aldstat: {
        sendEvent: function() {}
    },
    Page: Page,
    XPage: wx.$.Page,
    XComponent: wx.$.Component,
    frxsConfig: T,
    frxs: C,
    userSvr: L,
    pointConfig: C.formatPointConfig(I.pointConfig),
    methods: require("./utils/methods"),
    globalData: {
        scene: "",
        sceneNameItem: "",
        liveId: "无",
        menuList: void 0,
        userInfo: null,
        brandHouseVisited: !1,
        cartData: {},
        countCart: function() {
            return Object.values(this.cartData).map(function(e) {
                return e.count;
            }).reduce(function(e, t) {
                return e + t;
            }, 0);
        },
        showBrand: wx.getStorageSync("showBrand"),
        event: w.default,
        isCheckLogin: !1
    }
}, V), {}, {
    authVersion: function() {
        return -1 !== this.frxs.compareVersion("2.2.2") || (wx.reLaunch({
            url: "/subPages/home/wxgoup/wxgoup"
        }), !1);
    },
    onLaunch: function(e) {
        var t = this, r = (0, m.default)(this), n = r.$router, a = r.$http, i = r.$data, s = r.$tran, g = r.$watch, h = r.$component, f = r.$page;
        w.default.emit(w.EVENTS.APP_ENTER_OPTIONS, e), A.default.apply(this), s.on("UPDATE_USER_ID", function(e) {
            e.userId;
            A.default.apply(t);
        }), (0, E.getSearchAb)(this), (0, E.getSearchAbV)(this), this.isRunBindTk = !0, 
        this.enterAppOptions = e, this.router = (0, $.routerInit)(this);
        try {
            this.hideAppTabbar();
            var x = Date.now(), b = "".concat(C.newGuid(), "-").concat(x);
            (0, E.guestInto)({
                app: this,
                into_key: b
            }), C.XSMonitor.sendEvent("monitorError_warn", {
                into_key: b,
                t: x,
                type: "onLaunch",
                slot: "静默登录"
            }), this.appLoginCheck(o(o({}, e), {}, {
                callback: function() {}
            }));
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            C.XSMonitor.sendEvent("monitorError_error", {
                content: e,
                type: "app_onlaunch_error"
            }, "");
        }
        this.appInitData(e), N.clearCartQuantityZero(), this.checkUpdata(), (0, v.default)(o(o({}, e), {}, {
            xsApp: this
        })), N.removeWaitSyncExpireProduct(), this.updatePointList(), N.removeStorageExpireCartProduct(), 
        N.ifTaskGray(), R.cartTask(), wx.$initStore.call(this, (0, k.default)()).getBagNumber(), 
        wx.$webpS = this.isSupportWebp(), l.default.call(this, {
            $router: n,
            $http: a,
            $data: i,
            $tran: s,
            $watch: g,
            $component: h,
            $page: f
        }), d.default.call(this, {
            $router: n,
            $http: a,
            $data: i,
            $tran: s,
            $watch: g,
            $component: h,
            $page: f
        }), p.default.call(this, {
            $router: n,
            $http: a,
            $data: i,
            $tran: s,
            $watch: g,
            $component: h,
            $page: f
        }), c.default.call(this, {
            $router: n,
            $http: a,
            $data: i,
            $tran: s,
            $watch: g,
            $component: h,
            $page: f
        }), u.default.call(this, {
            $router: n,
            $http: a,
            $data: i,
            $tran: s,
            $watch: g,
            $component: h,
            $page: f
        });
    },
    postMsgRead: function(e) {
        var t = e.tmplType || e.query.tmplType || "";
        if (t && this.frxs.setMData("_c", {
            c_type: t,
            f: "ad",
            c: 24
        }), this.frxs.getMOrSData("userKey")) {
            var r = e.msgId || e.query.msgId || "";
            r && S.noticesApi.getMsgRead({
                msgId: r,
                msgType: "wechatSubscribe"
            }, {
                contentType: "application/json",
                silence: !0,
                header: {
                    bizType: "MEMBER"
                }
            });
        }
    },
    updatePointList: function() {
        var e = this;
        try {
            S.pointApi.getPointConfig({
                appid: T.appId
            }, {
                contentType: "application/json",
                silence: !0
            }).then(function(t) {
                var r = t.config, n = t.version;
                C.isArray(r) && h.default.compareVersion(n, I.pointVersion) && (e.pointConfig = C.formatPointConfig(r));
            }).catch(function(e) {});
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.log(e);
        }
    },
    initTk: function(e) {
        var t = (e || {}).scene, r = (e || {}).path;
        if (1037 !== t && [ "subTK/pages/home/index", "subTK/pages/areaList/index", "subTK/pages/search/index" ].indexOf(r) > -1) return wx.reLaunch({
            url: "/pages/home/index/index"
        });
    },
    onShow: function(e) {
        var t = this;
        try {
            w.default.emit(w.EVENTS.APP_ENTER_OPTIONS, e), A.default.apply(this), (0, _.sourcePoint)(e, this), 
            this.isRunBindTk = !0, this.enterAppOptions = e;
            var r = (e || {}).scene;
            this.globalData.scene = r;
            var n = (e || {}).query || {};
            this.globalData.sceneNameItem = y.sceneName[r], this.initTk(e), n.invitationCode && this.frxs.setMAndSData("storeBindInfo", n), 
            wx.setStorageSync("scene", r), 1014 === e.scene && setTimeout(function() {
                t.postMsgRead(e);
            }, 1e3);
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e), this.globalData.sceneNameItem = y.sceneName.null;
        }
    },
    hideAppTabbar: function() {
        C.compareVersion("2.5.0") < 0 && wx.hideTabBar();
    },
    checkUpdata: function() {
        var e = this;
        this.frxs.getMOrSData(q.STORAGE_KEY.UPDATA_VERSION) != T.version && wx.request({
            method: "POST",
            url: T.checkVersion,
            data: {
                appId: T.appId
            },
            success: function(t) {
                var r = t && t.data && t.data.data || {};
                e.appUpdateManager(r, function(e) {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，是否重启应用？",
                        success: function(t) {
                            t.confirm && e.applyUpdate();
                        }
                    });
                });
            },
            fail: function() {
                e.appUpdateManager();
            }
        });
    },
    appUpdateManager: function(e, t) {
        var r = this;
        try {
            if ("function" != typeof wx.getUpdateManager) return;
            var n = e || {}, a = n.rollback, i = void 0 === a ? 0 : a, s = n.version, o = void 0 === s ? T.version : s, u = n.forceUpgrade, c = void 0 === u ? 0 : u, p = wx.getUpdateManager();
            p.onCheckForUpdate(function(e) {}), p.onUpdateReady(function() {
                if (C.getMOrSData(q.STORAGE_KEY.UPDATA_VERSION) != o) return i && C.compareVersion(o, T.version) >= 0 ? (t && t(p), 
                void r.frxs.setMAndSData(q.STORAGE_KEY.UPDATA_VERSION, o)) : void (c && C.compareVersion(o, T.version) < 1 && (t && t(p), 
                r.frxs.setMAndSData(q.STORAGE_KEY.UPDATA_VERSION, o)));
            }), p.onUpdateFailed(function() {
                r.frxs.setMAndSData(q.STORAGE_KEY.UPDATA_VERSION, o), wx.showModal({
                    title: "更新提示",
                    content: "新版本下载失败",
                    showCancel: !1
                });
            });
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    appInitData: function(e) {
        var t = C.getWxSysInfo();
        this.globalData.sysInfo = t, this.globalData.launchAppInfo = {
            startTime: +new Date(),
            options: e
        }, this.globalData.isIPhone = -1 != wx.getSystemInfoSync().model.indexOf("iPhone"), 
        this.globalData.isIPhoneX = this.frxs.checkIsIphoneX(), this.globalData.isFullScreen = t.screenHeight / t.screenWidth >= 2.1, 
        this.globalData.bottomBlankHeignt = this.globalData.isIPhoneX ? 68 : this.globalData.isFullScreen ? 10 : 0, 
        this.setGlobalDataValue([ "userKey", "storeId", "areaId" ]);
    },
    setGlobalDataValue: function(e) {
        var t = this;
        (e = "object" == r(e) ? e : [ e ]).map(function(e) {
            var r = wx.getStorageSync(e);
            ("string" != typeof r || r) && (t.globalData[e] = r);
        });
    },
    onHide: function(e) {
        var t = getCurrentPages(), r = t[t.length - 1];
        r && r.hideAppPoint && r.hideAppPoint("screen_hide");
    },
    onError: function(e) {
        try {
            wx.$.log.error(e);
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    },
    isSupportWebp: function() {
        var e = {
            support: !1,
            supportBcg: !1
        };
        try {
            var t = this.frxs.getMOrSData("support-webp");
            if (null != t && "" !== t) return t;
            var r = wx.getSystemInfoSync(), n = r.platform, a = r.system, i = this.frxs.compareVersion("2.9.0") >= 0;
            e.support = "devtools" === n || i;
            var s = /[0-9.]*$/.exec(a), o = s ? s[0] : "", u = "ios" === n && !!o && this.frxs.compareVersion("14.0.0", o) >= 0;
            e.supportBcg = -1 !== [ "android", "windows", "mac", "devtools" ].indexOf(n) || u;
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            e = {
                support: !1,
                supportBcg: !1
            };
        }
        return this.frxs.setMAndSData("support-webp", e), e;
    }
}));