Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.version = exports.isPrintLog = exports.ENV = void 0;

exports.ENV = "PRO";

exports.version = "2.5.7";

exports.isPrintLog = !1;