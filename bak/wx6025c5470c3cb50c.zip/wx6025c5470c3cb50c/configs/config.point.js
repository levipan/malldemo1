Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pointVersion = exports.pointConfig = void 0;

exports.pointVersion = "1.0.0";

exports.pointConfig = [ {
    page: "subTMAddress/pages/editAddress/index",
    points: [ {
        method: "onClickSuggestion",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "选择推荐地址"
            }
        }, {
            type: "expression",
            key: "sort",
            expr: "argus[0].currentTarget.dataset.index",
            ast: {
                type: "variable",
                value: "_argus.0.currentTarget.dataset.index",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onSwitch",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "ternary",
                condition: {
                    type: "variable",
                    value: "_page.data.isDefaultAddress"
                },
                true: {
                    type: "static",
                    value: "设置默认地址"
                },
                false: {
                    type: "static",
                    value: "取消设置默认地址"
                }
            }
        } ]
    }, {
        method: "onConfirmAddressEqModal",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "更新所在地区"
            }
        } ]
    }, {
        method: "onDelete",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "删除地址"
            }
        } ]
    }, {
        method: "onClickGoBack",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "编辑中返回"
            }
        } ]
    } ]
}, {
    page: "subTMAddress/pages/addAddress/index",
    points: [ {
        method: "onClickSuggestion",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "选择推荐地址"
            }
        }, {
            type: "expression",
            key: "sort",
            ast: {
                type: "variable",
                value: "_argus.0.currentTarget.dataset.index",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onSwitch",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "ternary",
                condition: {
                    type: "variable",
                    value: "_page.data.isDefaultAddress"
                },
                true: {
                    type: "static",
                    value: "设置默认地址"
                },
                false: {
                    type: "static",
                    value: "取消设置默认地址"
                }
            }
        } ]
    }, {
        method: "onConfirmAddressEqModal",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "更新所在地区"
            }
        } ]
    } ]
}, {
    page: "subTMOrder/pages/order-detail/index",
    points: [ {
        method: "onOpenChangeAddress",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "修改地址"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.pageOptions.orderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onGoToRecommend",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "好物推荐"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_argus.0.currentTarget.dataset.product.subOrderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onBuyAgain",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "再次购买"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_argus.0.currentTarget.dataset.product.subOrderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onLinkCustom",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系客服"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.detail.orderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onOpenExpressDetail",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "查看物流"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.detail.orderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onDelete",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "删除"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.detail.orderId",
                defaultValue: ""
            }
        } ]
    } ]
}, {
    page: "subTMAddress/pages/changeAddress/index",
    points: [ {
        method: "onOpenAddAddress",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "添加新地址"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.pageOptions.orderId",
                defaultValue: ""
            }
        } ]
    } ]
}, {
    page: "subTMAddress/pages/address/index",
    points: [ {
        method: "onOpenEditAddress",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "切换地址"
            }
        } ]
    }, {
        method: "onOpenAddAddress",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "添加收货地址"
            }
        } ]
    } ]
}, {
    page: "subPages/users/orderList/orderList",
    points: [ {
        method: "onCallPhone",
        event: "make_phone_call",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_argus.0.currentTarget.dataset.index",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        } ]
    }, {
        method: "virtualPhoneShow",
        event: "slot_show",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "门店电话弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            expr: "page.data.orderList[page.clickOrderIndex].orderId",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneOk",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "呼叫门店老板"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneClose",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneCancel",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        } ]
    } ]
}, {
    page: "subPages/users/orderSearch/index",
    points: [ {
        method: "onCallPhone",
        event: "make_phone_call",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_argus.0.currentTarget.dataset.index",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        } ]
    }, {
        method: "virtualPhoneShow",
        event: "slot_show",
        slot: "门店电话弹窗",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "门店电话弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            expr: "page.data.orderList[page.clickOrderIndex].orderId",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneOk",
        slot: "呼叫门店老板",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "呼叫门店老板"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneClose",
        slot: "关闭呼叫门店老板弹窗",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneCancel",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        } ]
    } ]
}, {
    page: "subPages/users/orderDetail/orderDetail",
    points: [ {
        method: "onCallHotService",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "没有需要联系帮帮忙热线"
            }
        } ]
    }, {
        method: "onCloseSolvePop",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "已解决"
            }
        } ]
    }, {
        method: "onCloseOrderCancelPop",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "取消订单"
            }
        } ]
    }, {
        method: "onCallStoreBossPhone",
        slot: "呼叫门店老板",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "取消订单"
            }
        } ]
    }, {
        method: "getStoreVirtualPhone",
        event: "slot_show",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "门店电话弹窗"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "取消订单"
            }
        } ]
    }, {
        method: "onCancelOrderByPayed",
        slot: "取消订单",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "onCallPhone",
        event: "make_phone_call",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        }, {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        } ]
    }, {
        method: "virtualPhoneShow",
        event: "slot_show",
        slot: "门店电话弹窗",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneOk",
        slot: "呼叫门店老板",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneClose",
        slot: "关闭呼叫门店老板弹窗",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderDetails.orderId",
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneCancel",
        slot: "关闭呼叫门店老板弹窗",
        exposer: [ {
            type: "expression",
            key: "order_id",
            ast: {
                type: "variable",
                value: "_page.data.orderList",
                children: {
                    type: "variable",
                    value: "_page.clickOrderIndex",
                    children: {
                        type: "variableKey",
                        value: "orderId"
                    }
                },
                defaultValue: ""
            }
        }, {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    } ]
}, {
    page: "subMain/main/index?tabCode=center",
    points: [ {
        method: "phoneCall",
        event: "make_phone_call"
    }, {
        method: "virtualPhoneShow",
        event: "slot_show",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "门店电话弹窗"
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneOk",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "呼叫门店老板"
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneClose",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        }, {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        } ]
    }, {
        method: "virtualPhoneCancel",
        exposer: [ {
            type: "expression",
            key: "source",
            ast: {
                type: "static",
                value: "联系门店"
            }
        }, {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "关闭呼叫门店老板弹窗"
            }
        } ]
    }, {
        method: "toAddressList",
        exposer: [ {
            type: "expression",
            key: "slot",
            ast: {
                type: "static",
                value: "收货地址"
            }
        } ]
    } ]
} ];

JSON.stringify([ "你的顾客最爱", "今日必推", "横扫全场" ]);