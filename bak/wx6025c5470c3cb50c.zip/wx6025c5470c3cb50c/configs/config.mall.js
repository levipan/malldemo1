Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    mall: {
        showLive: !0,
        showBanner: !0,
        showProductVideo: !0,
        isValetorder: !1,
        cartKey: "cart",
        page: {
            prIndex: "/pages/home/index/index",
            prDetails: "/subProduct/detail/index",
            prQualifications: "/subPages/home/qualifications/index",
            cateProduct: "/pages/home/cateProduct/index",
            search: "/subPages/home/brand/search/search",
            cart: "/pages/home/cart/cart",
            center: "/pages/users/center/center",
            uyingDirect: "/pages/order/uyingDirect/uyingDirect",
            confirmOrder: "/pages/order/confirmOrder/confirmOrder",
            youshi: "/pages/video/index/index",
            live: "/subLive/live/index",
            payPhone: "/subPages/pages/payPhone/home/index"
        }
    }
};