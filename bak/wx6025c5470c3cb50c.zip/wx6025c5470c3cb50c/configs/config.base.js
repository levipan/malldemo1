Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    serviceTel: "4008889997",
    hotTel: "4008889997",
    helpTel: "4009933166",
    downloadFile: [ {
        old: "apimagev.frxs.cn",
        new: "profrxssso.oss-cn-shenzhen.aliyuncs.com"
    } ],
    ossDomain: "https://front-xps-cdn.xsyx.xyz",
    yearBillRange: "2000/1/24||2000/3/1",
    smaShowInfo: {
        areaIds: [ 104, 105 ],
        start: +new Date("2020/03/24 00:00:00"),
        end: +new Date("2020/03/24 23:59:59")
    },
    isDebug: !1,
    youshiEnableStatus: !0,
    oneBuyCode: 1e6
};

exports.default = e;