var e = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("./utils/xs-monitor.min.js")), t = e(require("./xapp/utils.js")), n = require("./config"), a = (require("./utils/common"), 
wx.getStorageSync("userId")), o = [ "FE04831008001", "FE04851008900", "FE04851008999", "FE04831009001", "FE04851009002", "FE04851009999", "FE04851010002", "FE04851010999" ], i = [ "aldwx.com/d.html", "aldwx.com/config/app.json", "monitor.dev2.xsyxsc.cn/r" ], s = require("./config.js");

if (Math.random() < 1 && (console.log("进入采样"), new r.default({
    testingUrl: s.picasso.sendUrl,
    ignorelist: [ "pages/home/index/index", "pages/users/center/center", "pages/home/cart/cart", "pages/home/cateProduct/index", "subMain/main/index", "home", "brand", "cart", "center", "subOld/index/index" ],
    hooks: {
        np: function() {
            try {
                var e = getCurrentPages(), r = e[e.length - 1];
                return r.route && (~r.route.indexOf("subMain/main/index") || ~r.route.indexOf("subOld/index/index")) ? {
                    route: wx.getStorageSync("__subMainType") || r.options.tabCode || "home"
                } : "";
            } catch (e) {
                e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                return "";
            }
        }
    },
    version: n.version,
    extra: {},
    userId: a,
    setSystemInfo: !0,
    setLocation: !0,
    key: n.appId,
    delay: 1e3,
    url: n.monitor.report,
    performanceUrl: n.monitor.performance,
    behaviorUrl: n.monitor.behavior,
    except: [ /^Script error\.?/, /^Javascript error: Script error\.? on line 0/ ],
    random: 1,
    repeat: 5,
    printConsole: "devtools" !== wx.getSystemInfoSync().platform && n.isPrintLog,
    notPrintConsole: i,
    canUse: t.default.compareVersion(wx.getSystemInfoSync().SDKVersion, "2.6.2") > 0,
    sentry: function(e) {
        if (!e) return "请求没有响应";
        if (200 !== e.statusCode) {
            var r = (e || {}).data || {}, t = r.error, n = r.message, a = r.status;
            return JSON.stringify({
                error: t,
                message: n,
                status: a
            });
        }
        var i = (e || {}).data || {}, s = i.rspCode, u = i.rspDesc;
        return "failure" === s ? JSON.stringify((e || {}).data || e) : "fail" === s || "failed" === s || "illegal_time_request" === s || "illegalArgumentError" === s || o.indexOf(s) >= 0 ? JSON.stringify(u) : void 0;
    },
    getPublicAttr: function(e, r) {
        var t, n, a = function(e) {
            var r = getApp();
            return void 0 === ((r || {}).globalData || {})[e] ? wx.getStorageSync(e) : r.globalData[e];
        };
        return {
            ab_version: a("_searchTestABV"),
            aid: a("areaId"),
            sid: a("storeId"),
            c: (t = "_c", n = getApp(), (n ? n.globalData[t] : void 0) || null),
            u: a("userId") || null,
            inner_live: a("inner_live") || null,
            inner: function() {
                var t = a("inner") || null;
                if (!e || "add_product" === e || "slot_click" === e && "立即购买" == r.slot) {
                    var n = a("fixed_inner");
                    return Object.assign(t || {}, n || {});
                }
                return t;
            }() || null
        };
    }
})), r.default.sendEvent) {
    var u = r.default.sendEvent;
    r.default.sendEvent = function() {
        for (var e = arguments.length, r = new Array(e), t = 0; t < e; t++) r[t] = arguments[t];
        try {
            var n = getApp(), a = wx.$._get(r, "0", ""), o = wx.$._get(r, "1", {}) || {}, i = wx.$._get(r, "2", "") || "", s = wx.$._get(o, "__gray", !1);
            if (s) {
                delete o.__gray;
                var l = n.frxs.getMData("picasso") || {};
                l && l[s] && l[s].sendEvent && l[s].sendEvent(a, o, i);
            }
            u(a, o, i);
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            u.apply(void 0, r);
        }
    }, r.default.sendTestEvent = function(e, r) {
        var t = function(e) {
            var r = getApp().frxs.getMData("picasso") || {};
            return e && r && r[e] && r[e].sendEvent || r && r.sendEvent ? r : null;
        };
        try {
            var n = wx.$._get(r, "__gray", !1);
            if (!n) return function(e, r) {
                var n = t();
                n && n.sendEvent(e, r);
            }(e, r);
            !function(e, r, n) {
                delete n.__gray;
                var a = t(e);
                a && a[e].sendEvent(r, n);
            }(n, e, r);
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            console.error(e);
        }
    };
}

r.default.sendEvent || (r.default.sendEvent = function(e, r) {
    console.warn('[xs-monitor] 监控未开启, 忽略埋点"'.concat(e, '"'));
}, r.default.sendTestEvent = function(e, r) {
    console.warn('[xs-monitor] 监控未开启, 忽略埋点"'.concat(e, '"'));
});

var l = r.default;

exports.default = l;