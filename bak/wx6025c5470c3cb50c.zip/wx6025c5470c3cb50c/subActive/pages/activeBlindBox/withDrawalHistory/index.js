// subActive/pages/activeBlindBox/withDrawalHistory/index.js
Page({data: {}})