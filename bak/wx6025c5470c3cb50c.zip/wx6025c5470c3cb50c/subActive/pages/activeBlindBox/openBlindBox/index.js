// subActive/pages/activeBlindBox/openBlindBox/index.js
Page({data: {}})