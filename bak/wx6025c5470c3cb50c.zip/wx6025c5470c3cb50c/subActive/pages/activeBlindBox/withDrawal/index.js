// subActive/pages/activeBlindBox/withDrawal/index.js
Page({data: {}})