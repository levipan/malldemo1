// subActive/pages/activeBlindBox/wishCard/index.js
Page({data: {}})