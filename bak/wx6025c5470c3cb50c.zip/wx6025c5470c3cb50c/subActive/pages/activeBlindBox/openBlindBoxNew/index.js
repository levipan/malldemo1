// subActive/pages/activeBlindBox/openBlindBoxNew/index.js
Page({data: {}})