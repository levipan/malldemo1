// subActive/pages/activeBlindBox/history-detailed/index.js
Page({data: {}})