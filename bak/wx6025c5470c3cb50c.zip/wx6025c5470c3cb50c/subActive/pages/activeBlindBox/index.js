// subActive/pages/activeBlindBox/index.js
Page({data: {}})