// subActive/pages/activeShare/shareFloor7/index.js
Page({data: {}})