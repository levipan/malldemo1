// subActive/pages/activeShare/shareFloor10/index.js
Page({data: {}})