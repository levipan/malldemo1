// subActive/pages/activeShare/shareFloor4/index.js
Page({data: {}})