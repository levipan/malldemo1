// subActive/pages/activeShare/shareFloor1/index.js
Page({data: {}})