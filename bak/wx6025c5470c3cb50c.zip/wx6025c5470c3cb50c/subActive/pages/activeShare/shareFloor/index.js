// subActive/pages/activeShare/shareFloor/index.js
Page({data: {}})