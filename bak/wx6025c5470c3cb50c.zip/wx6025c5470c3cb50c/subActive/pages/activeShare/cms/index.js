// subActive/pages/activeShare/cms/index.js
Page({data: {}})