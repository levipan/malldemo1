// subActive/pages/activeShare/shareFloor2/index.js
Page({data: {}})