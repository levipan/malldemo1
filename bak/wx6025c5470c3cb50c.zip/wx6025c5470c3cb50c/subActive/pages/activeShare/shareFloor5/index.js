// subActive/pages/activeShare/shareFloor5/index.js
Page({data: {}})