// subActive/pages/activeShare/shareFloor6/index.js
Page({data: {}})