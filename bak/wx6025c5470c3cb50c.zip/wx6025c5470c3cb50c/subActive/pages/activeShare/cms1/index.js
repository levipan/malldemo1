// subActive/pages/activeShare/cms1/index.js
Page({data: {}})