// subActive/pages/activeShare/shareFloor3/index.js
Page({data: {}})