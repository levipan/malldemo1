// subActive/pages/activeShare/cms2/index.js
Page({data: {}})