var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.store = void 0;

e(require("./demo1.js"));

var r = e(require("./address.js")), u = e(require("./singleCoupon.js")), t = e(require("./orderNumber")), o = e(require("./bagNumber")), s = {
    hideActiveMovable: wx.$.storage.get("hideActiveMovable"),
    address: (0, r.default)(),
    orderNumber: (0, t.default)(),
    bagNumber: (0, o.default)(),
    singleCoupon: (0, u.default)()
};

exports.store = s;