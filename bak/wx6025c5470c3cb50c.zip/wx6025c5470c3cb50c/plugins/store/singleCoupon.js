var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        __name: "singleCoupon",
        skusnCouponMap: {},
        getSingleCouponList: function() {
            var e = this;
            return t(r.default.mark(function t() {
                var u, s, a, i, p, c;
                return r.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (r.prev = 0, (u = getApp()).frxs.getMOrSData("userKey") && u.frxs.getMOrSData("isLogin")) {
                            r.next = 4;
                            break;
                        }
                        return r.abrupt("return");

                      case 4:
                        return s = {
                            requestType: "CUSTOMER",
                            userScopeTypes: [ "NORMAL" ],
                            channelUse: "WXAPP",
                            primaryChannel: "XSYX",
                            secondaryChannels: [ "MEMBER", "HOME" ],
                            saleRegionCode: "0",
                            storeId: "0",
                            provinceCode: "0",
                            cityCode: "0",
                            areaCode: "0"
                        }, (a = u.frxs.getMOrSData("storeInfo")) && (s = n(n({}, s), {}, {
                            saleRegionCode: a.areaId,
                            storeId: a.storeId,
                            provinceCode: a.provinceId,
                            cityCode: a.cityId,
                            areaCode: a.countyId
                        })), r.next = 9, o.couponApi.getQueryAllTicket(s, {
                            contentType: "application/json"
                        });

                      case 9:
                        if (!(i = r.sent)) {
                            r.next = 17;
                            break;
                        }
                        return p = {}, c = {}, i.filter(function(e) {
                            return "SINGLE" === e.rootType;
                        }).forEach(function(e) {
                            e.showTicketPrice && (e.eskuSn && (p[e.eskuSn] ? p[e.eskuSn].orderAmountLimit > e.orderAmountLimit && (p[e.eskuSn] = e) : p[e.eskuSn] = e), 
                            e.skus && e.skus.length && (c[e.skus[0]] = e));
                        }), e.commit({
                            skusnCouponMap: p,
                            skusnStoreCouponMap: c
                        }), r.abrupt("return", {
                            skusnCouponMap: p,
                            skusnStoreCouponMap: c
                        });

                      case 17:
                        r.next = 22;
                        break;

                      case 19:
                        return r.prev = 19, r.t0 = r.catch(0), r.abrupt("return", {
                            skusnCouponMap: {},
                            skusnStoreCouponMap: {}
                        });

                      case 22:
                      case "end":
                        return r.stop();
                    }
                }, t, null, [ [ 0, 19 ] ]);
            }))();
        }
    };
};

var r = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../api/index");