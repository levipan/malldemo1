var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        __name: "address",
        defaultAddress: null,
        currAddress: null,
        getCurrAddress: function() {
            var e = this, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return new Promise(function() {
                var n = u(t.default.mark(function u(n) {
                    var a, s, d;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (a = e.getStore(), !(s = a.currAddress)) {
                                t.next = 3;
                                break;
                            }
                            return t.abrupt("return", n({
                                code: 0,
                                data: s
                            }));

                          case 3:
                            return t.next = 5, e.getDefaultAddress(r);

                          case 5:
                            if (0 === (d = t.sent).code) {
                                t.next = 8;
                                break;
                            }
                            return t.abrupt("return", n({
                                code: -3,
                                data: d.data
                            }));

                          case 8:
                            return e.setCurrAddress(d.data), t.abrupt("return", n({
                                code: 0,
                                data: d.data
                            }));

                          case 10:
                          case "end":
                            return t.stop();
                        }
                    }, u);
                }));
                return function(e) {
                    return n.apply(this, arguments);
                };
            }());
        },
        updateDefaultAndCurrAddress: function(e) {
            this.setCurrAddress(e), this.setDefaultAddress(e);
        },
        setCurrAddress: function(e) {
            this.commit("currAddress", e);
        },
        getDefaultAddress: function() {
            var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return new Promise(function() {
                var s = u(t.default.mark(function u(s) {
                    var d, i, c, o;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (d = getApp().frxs.isLogin()) {
                                t.next = 3;
                                break;
                            }
                            return t.abrupt("return", s({
                                code: -2,
                                data: {
                                    rspDesc: "用户未登录"
                                }
                            }));

                          case 3:
                            if (a = r({
                                userKey: d
                            }, a), i = e.getStore(), !(c = i.defaultAddress)) {
                                t.next = 7;
                                break;
                            }
                            return t.abrupt("return", s({
                                code: 0,
                                data: c
                            }));

                          case 7:
                            return t.prev = 7, t.next = 10, n.memberApi.getDefaultAddress(a, {
                                silence: !0
                            });

                          case 10:
                            return o = t.sent, e.setDefaultAddress(o), t.abrupt("return", s({
                                code: 0,
                                data: o
                            }));

                          case 15:
                            return t.prev = 15, t.t0 = t.catch(7), console.error(t.t0), t.abrupt("return", s({
                                code: -1,
                                data: t.t0
                            }));

                          case 19:
                          case "end":
                            return t.stop();
                        }
                    }, u, null, [ [ 7, 15 ] ]);
                }));
                return function(e) {
                    return s.apply(this, arguments);
                };
            }());
        },
        setDefaultAddress: function(e) {
            this.commit("defaultAddress", e);
        }
    };
};

var r = require("../../@babel/runtime/helpers/objectSpread2"), t = e(require("../../@babel/runtime/regenerator")), u = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/index.js");