var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        name: "test",
        text: "test----",
        detail: {
            a: 123,
            b: +new Date()
        },
        setDetail: function(e) {
            var r = this;
            this.commit("detail", e), wx.$useStore((0, t.default)()).setText("ddddddddd"), setTimeout(function() {
                console.error(r.getStore("text", "address"));
            }, 3e3);
        },
        setText: function(e) {
            this.commit("text", e);
        }
    };
};

var t = e(require("./address"));

(0, t.default)();