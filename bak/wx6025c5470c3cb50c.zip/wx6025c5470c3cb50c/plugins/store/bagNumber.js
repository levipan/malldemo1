var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        __name: "bagNumber",
        number: 0,
        getBagNumber: function() {
            var e = this;
            return t(r.default.mark(function t() {
                var n, u, i;
                return r.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (n = wx.$data.getSync("cart"), u = 0, !n) {
                            r.next = 7;
                            break;
                        }
                        n && n.map(function(e) {
                            var r = Number(e.cartQuantity);
                            u += r;
                        }), e.updateBagNumber(u), r.next = 21;
                        break;

                      case 7:
                        if (getApp() && getApp().frxs.isLogin()) {
                            r.next = 10;
                            break;
                        }
                        return r.abrupt("return");

                      case 10:
                        return r.prev = 10, r.next = 13, a.riversCart.homeCartCount();

                      case 13:
                        (i = r.sent) && (u = i.skuSnCount), e.updateBagNumber(u), r.next = 21;
                        break;

                      case 18:
                        r.prev = 18, r.t0 = r.catch(10), console.error(r.t0);

                      case 21:
                      case "end":
                        return r.stop();
                    }
                }, t, null, [ [ 10, 18 ] ]);
            }))();
        },
        updateBagNumber: function(e) {
            this.setBagNumber(e);
        },
        setBagNumber: function(e) {
            this.commit("number", e || 0);
        }
    };
};

var r = e(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/index.js");