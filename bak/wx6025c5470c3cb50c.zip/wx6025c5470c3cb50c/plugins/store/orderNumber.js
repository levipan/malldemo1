var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        __name: "orderNumber",
        number: 0,
        getOrderCount: function() {
            var e = this;
            return new Promise(function() {
                var u = t(r.default.mark(function t(u) {
                    var a, i;
                    return r.default.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            if (getApp().frxs.isLogin()) {
                                r.next = 3;
                                break;
                            }
                            return r.abrupt("return", u({
                                code: -2,
                                data: {
                                    rspDesc: "用户未登录"
                                }
                            }));

                          case 3:
                            return r.prev = 3, r.next = 6, n.tradeApi.getNewOrderAreaCnt({
                                orderType: "HOME"
                            }, {
                                loginVerify: !1,
                                silence: !0
                            });

                          case 6:
                            return a = r.sent, i = 0, a.forEach(function(e) {
                                i += e.cnt || 0;
                            }), e.setOrderNumber(i), r.abrupt("return", u({
                                code: 0,
                                data: i
                            }));

                          case 13:
                            return r.prev = 13, r.t0 = r.catch(3), console.error(r.t0), r.abrupt("return", u({
                                code: -1,
                                data: r.t0
                            }));

                          case 17:
                          case "end":
                            return r.stop();
                        }
                    }, t, null, [ [ 3, 13 ] ]);
                }));
                return function(e) {
                    return u.apply(this, arguments);
                };
            }());
        },
        setOrderNumber: function(e) {
            this.commit("number", e);
        }
    };
};

var r = e(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/index.js");