var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CreateRouter = o, exports.routeInit = exports.RouteType = void 0;

var r = e(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), u = require("../../@babel/runtime/helpers/objectSpread2"), c = (e(require("../../xapp/runtime")), 
{
    NAVIGATE_TO: "navigateTo",
    SWITCH_TAB: "switchTab",
    REDIRECT_TO: "redirectTo",
    RELAUNCH: "reLaunch"
});

exports.RouteType = c;

function o(e) {
    var o = null, i = null, s = null, l = e.routes;
    l.beforeEach && (o = l.beforeEach), l.routeError && (i = l.routeError);
    var f = function(e) {
        var r = new Map(), t = function(e, t) {
            if (r.get(e)) throw new Error("🚀 ~ route: the route has been renamed ~ ".concat(e, " "));
            r.set(e, t);
        };
        return e.pages && e.pages.map(function(e) {
            e.name && t(e.name, e), e.redirect && "string" != typeof e.redirect && e.redirect.name && t(e.redirect.name, e.redirect);
        }), e.subPackages && e.subPackages.map(function(e) {
            e.pages.map(function(r) {
                r.url = r.url && "/" !== r.url.substr(0, 1) ? "".concat(e.root, "/").concat(r.url) : "".concat(e.root).concat(r.url), 
                r.name && t(r.name, r), r.redirect && "string" != typeof r.redirect && r.redirect.name && (r.redirect.url = r.redirect.url && "/" !== r.redirect.url.substr(0, 1) ? "".concat(e.root, "/").concat(r.redirect.url) : "".concat(e.root).concat(r.redirect.url), 
                t(r.redirect.name, r.redirect));
            });
        }), r;
    }(l), p = function(e) {
        return "/" !== e.substr(0, 1) ? "/" + e : e;
    }, b = function e(r, t) {
        if (r.name || r.url) {
            var n = f.get(r.name) || function(e) {
                return {
                    url: e
                };
            }(r.url), a = n.url, u = n.redirect;
            if (u) return "string" == typeof u ? p(u) : e(u);
            if (a) return p(a);
            throw new Error("🚀 ~ route: page route is not found ~ ".concat(r.name));
        }
        if (!r.url) throw new Error("🚀 ~ route: route url is not found");
    }, d = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return Object.keys(e).map(function(r) {
            var t = e[r];
            return t instanceof Object && (t = JSON.stringify(t)), "".concat(r, "=").concat(t);
        }).join("&");
    }, g = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = !1;
        return e.name && (r = !!f.get(e.name).isTabBar), e.url ? (f.forEach(function(t) {
            var n = e.url.split("?")[0];
            t.url === p(n) && (r = !!t.isTabBar);
        }), r) : r;
    }, v = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 ? arguments[1] : void 0, t = -1;
        return r.map(function(r, n) {
            p(r.route) === p(e) && (t = n);
        }), t;
    }, h = function() {
        var e = a(r.default.mark(function e(a) {
            var l, h, x, T, m, y, k, O, E, q, R, j, C, A, I, _, L;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, l = 10, h = getCurrentPages(), x = a.type || "navigateTo", T = h[h.length - 1], 
                    m = p(T.route), y = b(a), k = d(a.query || {}), !s || (r = s.query, N = a.query || {}, 
                    JSON.stringify(r) !== JSON.stringify(u(u({}, r), N))) || s.name !== a.name && s.nextUrl !== a.url) {
                        e.next = 10;
                        break;
                    }
                    return e.abrupt("return");

                  case 10:
                    if (a.nextUrl = y, a.url = k ? y.indexOf("?") >= 0 ? "".concat(y).concat(k) : "".concat(y, "?").concat(k) : y, 
                    s = a, setTimeout(function() {
                        s = null;
                    }, 1500), !g(a) && x !== c.SWITCH_TAB) {
                        e.next = 30;
                        break;
                    }
                    if (O = Object.assign(a, {
                        url: a.url.split("?")[0]
                    }), !a.isOldPath) {
                        e.next = 20;
                        break;
                    }
                    return e.next = 19, wx.switchTab(O);

                  case 19:
                    return e.abrupt("return", e.sent);

                  case 20:
                    if (x !== c.RELAUNCH) {
                        e.next = 24;
                        break;
                    }
                    return e.next = 23, wx.reLaunch(a);

                  case 23:
                    return e.abrupt("return", e.sent);

                  case 24:
                    if (!((E = v(a.url, h)) > -1)) {
                        e.next = 27;
                        break;
                    }
                    return e.abrupt("return", w({
                        delta: h.length - 1 - E,
                        query: a.query
                    }));

                  case 27:
                    return e.next = 29, wx.redirectTo(a);

                  case 29:
                    return e.abrupt("return", e.sent);

                  case 30:
                    if (!o) {
                        e.next = 38;
                        break;
                    }
                    q = null, R = null, j = n(f);
                    try {
                        for (j.s(); !(C = j.n()).done; ) A = t(C.value, 2), A[0], I = A[1], p(I.url) === m && (R = I), 
                        p(I.url) === y && (q = I);
                    } catch (e) {
                        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
                        j.e(e);
                    } finally {
                        j.f();
                    }
                    if (_ = Object.assign({}, q, a), o(_, R)) {
                        e.next = 38;
                        break;
                    }
                    return e.abrupt("return");

                  case 38:
                    if (!(h.length >= l)) {
                        e.next = 43;
                        break;
                    }
                    if (!((L = v(a.url, h)) > -1)) {
                        e.next = 42;
                        break;
                    }
                    return e.abrupt("return", w({
                        delta: h.length - 1 - L,
                        query: a.query
                    }));

                  case 42:
                    return e.abrupt("return", wx.redirectTo(a));

                  case 43:
                    if (x !== c.REDIRECT_TO) {
                        e.next = 47;
                        break;
                    }
                    return e.next = 46, wx.redirectTo(a);

                  case 46:
                    return e.abrupt("return", e.sent);

                  case 47:
                    if (x !== c.RELAUNCH) {
                        e.next = 51;
                        break;
                    }
                    return e.next = 50, wx.reLaunch(a);

                  case 50:
                    return e.abrupt("return", e.sent);

                  case 51:
                    return e.next = 53, wx.navigateTo(a);

                  case 53:
                    return e.abrupt("return", e.sent);

                  case 56:
                    e.prev = 56, e.t0 = e.catch(0), console.error("error", e.t0), a.name && Object.assign(a, f.get(a.name)), 
                    i && i(a);

                  case 61:
                  case "end":
                    return e.stop();
                }
                var r, N;
            }, e, null, [ [ 0, 56 ] ]);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }(), x = function() {
        var e = a(r.default.mark(function e(t) {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("navigateTo--------navigate", t), e.next = 3, h(Object.assign(t, {
                        type: c.NAVIGATE_TO
                    }));

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }(), T = function() {
        var e = a(r.default.mark(function e(t) {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("switchTab----------navigate", t), e.next = 3, h(Object.assign(t, {
                        type: c.SWITCH_TAB
                    }));

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }(), m = function() {
        var e = a(r.default.mark(function e(t) {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("redirectTo-------navigate", t), e.next = 3, h(Object.assign(t, {
                        type: c.REDIRECT_TO
                    }));

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }(), y = function() {
        var e = a(r.default.mark(function e(t) {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("reLaunch-----------navigate", t), e.next = 3, h(Object.assign(t, {
                        type: c.RELAUNCH
                    }));

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }(), w = function() {
        var e = a(r.default.mark(function e() {
            var t, n, a, u, c, o, i, s = arguments;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = s.length > 0 && void 0 !== s[0] ? s[0] : {}, console.log("navigateBack--------navigate", t), 
                    n = getCurrentPages(), u = (a = "number" == typeof t ? {
                        delta: t
                    } : t).delta, c = void 0 === u ? 1 : u, o = a.query, i = void 0 === o ? {} : o, 
                    Object.keys(i).length > 0 && n[n.length - 1 - c].setData(i), e.next = 7, wx.navigateBack({
                        delta: c
                    });

                  case 7:
                    return e.abrupt("return", e.sent);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }();
    return {
        RouteType: c,
        to: h,
        navigateTo: x,
        switchTab: T,
        redirectTo: m,
        reLaunch: y,
        navigateBack: w,
        beforeEach: function(e) {
            o = e;
        },
        routeError: function(e) {
            i = e;
        }
    };
}

exports.routeInit = function(e, r) {
    var t = new o({
        routes: r
    });
    Object.defineProperty(e || wx, "$route", {
        get: function() {
            return t;
        }
    });
};