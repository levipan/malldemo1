var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.storageInit = exports.Storage = exports.Position = exports.Module = void 0;

var t = require("../../@babel/runtime/helpers/typeof"), r = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../@babel/runtime/helpers/classCallCheck"), n = (e(require("../../xapp/runtime")), 
{
    MEMORY: "memory",
    STORAGE: "storage",
    ALL: "all"
});

exports.Position = n;

var i = {
    HOME: "home",
    STORE: "store",
    ALL: "all"
};

exports.Module = i;

exports.storageInit = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = new s(t);
    Object.defineProperty(e || wx, "$data", {
        get: function() {
            return r;
        }
    });
};

var s = function e(s) {
    var c = this;
    o(this, e), this.set = function(e, t) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, a = r.position, o = void 0 === a ? n.ALL : a, s = r.module, u = void 0 === s ? i.HOME : s, g = r.expires, p = void 0 === g ? null : g, m = r.app, l = void 0 === m ? getApp() : m;
        switch (o) {
          case n.MEMORY:
            c._setMemoryData(e, t, {
                module: u,
                expires: p,
                app: l
            });
            break;

          case n.STORAGE:
            c._setStorage(e, t, {
                module: u,
                expires: p
            });
            break;

          case n.ALL:
            c._setMemoryData(e, t, {
                module: u,
                expires: p,
                app: l
            }), c._setStorage(e, t, {
                module: u,
                expires: p
            });
        }
    }, this.get = function() {
        var e = a(r.default.mark(function e(t) {
            var a, o, s, u, g, p, m, l, S, d = arguments;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a = d.length > 1 && void 0 !== d[1] ? d[1] : {}, o = d.length > 2 && void 0 !== d[2] ? d[2] : function() {}, 
                    s = null, u = a.position, g = void 0 === u ? n.ALL : u, p = a.module, m = void 0 === p ? i.HOME : p, 
                    l = a.app, S = void 0 === l ? getApp() : l, g === n.STORAGE && (g = n.ALL), e.t0 = g, 
                    e.next = e.t0 === n.MEMORY ? 8 : e.t0 === n.STORAGE ? 10 : e.t0 === n.ALL ? 14 : 20;
                    break;

                  case 8:
                    return s = c._getMemoryData(t, {
                        module: m,
                        app: S
                    }), e.abrupt("break", 20);

                  case 10:
                    return e.next = 12, c._getStorage(t, m);

                  case 12:
                    return s = e.sent, e.abrupt("break", 20);

                  case 14:
                    if ((s = c._getMemoryData(t, {
                        module: m,
                        app: S
                    })) && "{}" !== JSON.stringify(s) && "[]" !== JSON.stringify(s)) {
                        e.next = 19;
                        break;
                    }
                    return e.next = 18, c._getStorage(t, m);

                  case 18:
                    s = e.sent;

                  case 19:
                    return e.abrupt("break", 20);

                  case 20:
                    if (s || !o) {
                        e.next = 24;
                        break;
                    }
                    return e.next = 23, o();

                  case 23:
                    s = e.sent;

                  case 24:
                    return e.abrupt("return", s);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(), this.getSync = function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function() {}, a = null, o = t.position, s = void 0 === o ? n.ALL : o, u = t.module, g = void 0 === u ? i.HOME : u, p = t.app;
        switch (s === n.STORAGE && (s = n.ALL), s) {
          case n.MEMORY:
            a = c._getMemoryData(e, {
                module: g,
                app: p
            });
            break;

          case n.STORAGE:
            a = c._getStorageSync(e, g);
            break;

          case n.ALL:
            (a = c._getMemoryData(e, {
                module: g,
                app: p
            })) && "{}" !== JSON.stringify(a) && "[]" !== JSON.stringify(a) || (a = c._getStorageSync(e, g));
        }
        return !a && r && (a = r()), a;
    }, this.remove = function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = t.position, a = void 0 === r ? n.ALL : r, o = t.module, s = void 0 === o ? i.HOME : o;
        switch (a) {
          case n.MEMORY:
            c._deleteMemoryData(e, s);
            break;

          case n.STORAGE:
            c._removeStorage(e, s);
            break;

          case n.ALL:
            c._deleteMemoryData(e, s), c._removeStorage(e, s);
        }
    }, this.clear = function() {
        c._dataMap.clear(), c._expiresMap.clear(), c._clearStorage();
    }, this._setMemoryData = function(e, t, r) {
        var a = r || {}, o = a.module, n = a.expires, s = a.app;
        switch (o) {
          case i.HOME:
            c._setHomeMemoryData(e, t, n);
            break;

          case i.STORE:
            c._setStoreMemoryData(e, t, s);
            break;

          case i.ALL:
            c._setHomeMemoryData(e, t, n), c._setStoreMemoryData(e, t, s);
        }
    }, this._deleteMemoryData = function(e, t) {
        switch (t) {
          case i.HOME:
            c._deleteHomeMemoryData(e);
            break;

          case i.STORE:
            c._deleteStorageMemoryData(e);
            break;

          case i.ALL:
            c._deleteHomeMemoryData(e), c._deleteStorageMemoryData(e);
        }
    }, this._setHomeMemoryData = function(e, t, r) {
        e = "home_".concat(e), c._dataMap.set(e, t), r && c._expiresMap.set(e, Date.now() + r);
    }, this._deleteStorageMemoryData = function(e) {
        var t = getApp();
        t && delete t.globalData[e];
    }, this._deleteHomeMemoryData = function(e) {
        e = "home_".concat(e), c._dataMap.delete(e), c._expiresMap.delete(e);
    }, this._setStoreMemoryData = function(e, t, r) {
        r && (r.globalData[e] = t);
    }, this._setStorage = function(e, t, r) {
        var a = r || {}, o = a.module, n = a.expires;
        switch (o) {
          case i.HOME:
            c._setHomeStorage(e, t, n);
            break;

          case i.STORE:
            c._setStoreStorage(e, t, n);
            break;

          case i.ALL:
            c._setHomeStorage(e, t, n), c._setStoreStorage(e, t, n);
        }
    }, this._setHomeStorage = function(e, t, r) {
        return new Promise(function(a) {
            var o = t;
            r && (o = {
                _storageExpires: r + Date.now(),
                data: o
            }), wx.setStorage({
                key: "home_".concat(e),
                data: o
            }).then(function() {
                return a(!0);
            }).catch(function() {
                return a(!1);
            });
        });
    }, this._setStoreStorage = function(e, t, r) {
        return new Promise(function(r) {
            wx.setStorage({
                key: e,
                data: t
            }).then(function() {
                return r(!0);
            }).catch(function() {
                return r(!1);
            });
        });
    }, this._getMemoryData = function(e, t) {
        var r, a = t.module, o = t.app;
        switch (a) {
          case i.HOME:
            r = c._getHomeMemoryData(e);
            break;

          case i.STORE:
            r = c._getStoreMemoryData(e, o);
            break;

          case i.ALL:
            (r = c._getHomeMemoryData(e)) && "{}" !== JSON.stringify(r) && "[]" !== JSON.stringify(r) || (r = c._getStoreMemoryData(e, o));
        }
        return r || "";
    }, this._getHomeMemoryData = function(e) {
        e = "home_".concat(e);
        var t = c._expiresMap.get(e);
        return t && t < Date.now() ? (c._expiresMap.delete(e), void c._dataMap.delete(e)) : c._dataMap.get(e);
    }, this._getStoreMemoryData = function(e, t) {
        return void 0 === ((t || {}).globalData || {})[e] ? wx.getStorageSync(e) : t.globalData[e];
    }, this._getStorage = function() {
        var e = a(r.default.mark(function e(t, a) {
            var o, n;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    n = "home_".concat(t), e.t0 = a, e.next = e.t0 === i.HOME ? 4 : e.t0 === i.STORE ? 8 : e.t0 === i.ALL ? 12 : 20;
                    break;

                  case 4:
                    return e.next = 6, c._getStoragePromise(n);

                  case 6:
                    return o = e.sent, e.abrupt("break", 20);

                  case 8:
                    return e.next = 10, c._getStoragePromise(t);

                  case 10:
                    return o = e.sent, e.abrupt("break", 20);

                  case 12:
                    return e.next = 14, c._getStoragePromise(t);

                  case 14:
                    if ((o = e.sent) && "{}" !== JSON.stringify(o) && "[]" !== JSON.stringify(o)) {
                        e.next = 19;
                        break;
                    }
                    return e.next = 18, c._getStoragePromise(n);

                  case 18:
                    o = e.sent;

                  case 19:
                    return e.abrupt("break", 20);

                  case 20:
                    return e.abrupt("return", o || "");

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t, r) {
            return e.apply(this, arguments);
        };
    }(), this._getStoragePromise = function(e) {
        return new Promise(function(t) {
            wx.getStorage({
                key: e
            }).then(function(r) {
                var a = r.data;
                if (a) return a._storageExpores ? Date.now() > a._storageExpores ? (console.warn("缓存【".concat(e, "】已经失效")), 
                c.removeStorage(e), void t(void 0)) : void t(a.data) : void t(a);
                t(void 0);
            }).catch(function() {
                console.warn("storage中没有【".concat(e, "】")), t(void 0);
            });
        });
    }, this._getStorageSync = function(e, r) {
        try {
            var a, o = "home_".concat(e);
            switch (r) {
              case i.HOME:
                a = wx.getStorageSync(o);
                break;

              case i.STORE:
                a = wx.getStorageSync(e);
                break;

              case i.ALL:
                (a = wx.getStorageSync(e)) && "{}" !== JSON.stringify(a) && "[]" !== JSON.stringify(a) || (a = wx.getStorageSync(o));
            }
            if (!a) return;
            return "object" === t(a) && a._storageExpires ? Date.now() > a._storageExpires ? (console.warn("缓存【".concat(e, "】已经失效")), 
            void c._removeStorage(e)) : a.data : a;
        } catch (e) {
            e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
            return;
        }
    }, this._removeStorage = function(e, t) {
        return new Promise(function(r) {
            var a = "home_".concat(e);
            switch (t) {
              case i.HOME:
                wx.removeStorage({
                    key: a
                }).then(function() {
                    return r(!0);
                }).catch(function() {
                    return r(!1);
                });
                break;

              case i.STORE:
                wx.removeStorage({
                    key: e
                }).then(function() {
                    return r(!0);
                }).catch(function() {
                    return r(!1);
                });
                break;

              case i.ALL:
                var o = wx.removeStorage({
                    key: a
                }), n = wx.removeStorage({
                    key: e
                });
                Promise.all([ o, n ]).then(function() {
                    return r(!0);
                }).catch(function() {
                    return r(!1);
                });
            }
        });
    }, this._clearStorage = function() {
        return new Promise(function(e) {
            wx.clearStorage().then(function() {
                return e(!0);
            }).catch(function() {
                return e(!1);
            });
        });
    }, this._dataMap = new Map(), this._expiresMap = new Map(), s && Object.keys(s).forEach(function(e) {
        c._dataMap.set(e, s[e]);
    });
};

exports.Storage = s;