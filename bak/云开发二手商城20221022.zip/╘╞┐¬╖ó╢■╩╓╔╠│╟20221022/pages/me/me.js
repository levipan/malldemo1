const app = getApp();
Page({
    // 页面的初始数据
    data: {
        userInfo: null,
    },
    login() {
        wx.navigateTo({
            url: '/pages/login/login',
        })
    },
    //退出登录
    tuichu() {
        this.setData({
            userInfo: null,
        })
        app._saveUserInfo(null);
    },
    // 修改个人资料
    goChange() {
        wx.navigateTo({
            url: '/pages/change/change',
        })
    },
    // 去我的订单页
    goToMyOrder: function () {
        wx.navigateTo({
            url: '/pages/myOrder/myOrder',
        })
    },
    // 去我的评论页
    goToMyComment: function () {
        wx.navigateTo({
            url: '/pages/myComment/myComment',
        })
    },
    //去我的发布页
    goToSeller() {
        wx.navigateTo({
            url: '/pages/seller/seller',
        })
    },
    onShow() {
        var user = app.globalData.userInfo;
        console.log('me---',user)
        if (user && user.name) {
            this.setData({
                userInfo: user,
            })
        }
    },
})