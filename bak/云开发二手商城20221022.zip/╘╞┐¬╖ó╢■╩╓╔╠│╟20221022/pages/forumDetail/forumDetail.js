const db = wx.cloud.database()
const app = getApp()
let id = null
Page({
  onLoad(opt) {
    id = opt.id
    this.getDetail()
    this.getAnswer()
  },
  getDetail() {
    db.collection('forum').doc(id).get()
      .then(res => {
        console.log('详情页', res)
        this.setData({
          detail: res.data
        })
      })
  },
  // 获取回答列表
  getAnswer() {
    db.collection('answer').where({
        forumId: id
      }).get()
      .then(res => {
        this.setData({
          list: res.data
        })
      })
  },

  // 发布回答
  publish() {
    if (!app.globalData.userInfo || !app.globalData.userInfo.name) {
      wx.showToast({
        icon: 'error',
        title: '请先登录',
      })
      setTimeout(() => {
        wx.switchTab({
          url: '/pages/me/me',
        })
      }, 1000);
      return
    }
    wx.showModal({
      title: '发表回答',
      editable: true,
      success: res => {
        if (res.confirm) {
          if (res.content) {
            db.collection('answer').add({
              data: {
                forumId: id,
                content: res.content,
                name: app.globalData.userInfo.name,
                avatarUrl: app.globalData.userInfo.avatarUrl,
                _createTime: new Date().getTime() //创建的时间
              }
            }).then(res => {
              console.log('回答成功', res)
              wx.showToast({
                title: '回答成功',
              })
              this.getAnswer()
            })
          } else {
            wx.showToast({
              icon: 'error',
              title: '请输入内容',
            })
          }
        }
      }
    })
  },
  //预览图片，放大预览
  previewImg(event) {
    let index = event.currentTarget.dataset.index
    wx.previewImage({
      current: this.data.detail.imgs[index], // 当前显示图片的http链接
      urls: this.data.detail.imgs // 需要预览的图片http链接列表
    })
  },

})