const app = getApp()
const db = wx.cloud.database()
const _ = db.command
const $ = db.command.aggregate
Page({
  data: {
    tabs: [],
    tabCur: 0
  },
  //顶部选择分类条目
  tabSelect(e) {
    this.setData({
      tabCur: e.currentTarget.dataset.index,
      scrollLeft: (e.currentTarget.dataset.index - 2) * 200
    }, success => {
      this.getList()
    })
  },
  onShow() {
    this.getForum()

  },
  getForum() {
    db.collection('forum').aggregate()
      .group({
        _id: '$type',
        num: $.sum(1)
      })
      .sort({
        _id: 1
      })
      .end()
      .then(res => {
        console.log('分类数据', res)
        this.setData({
          tabs: res.list
        })
        this.getList()
      })
  },
  getList() {
    let type = this.data.tabs[this.data.tabCur]._id
    wx.cloud.callFunction({
        name: "forum",
        data: {
          action: 'getList',
          type: type
        }
      })
      .then(res => {
        console.log('列表成功', res)
        this.setData({
          list: res.result.data
        })
      })
  },
  // 去发布页
  goPublish() {
    wx.navigateTo({
      url: '/pages/publish/publish',
    })
  },
  // 去论坛详情页
  goForumDetail(e) {
    wx.navigateTo({
      url: '/pages/forumDetail/forumDetail?id=' + e.currentTarget.dataset.id,
    })
  }

})