// pages/home/home.js
const db = wx.cloud.database()
let searchKey = ''
Page({
  data: {
    list: [{
        picUrl: '/image/1.jpg'
      },
      {
        picUrl: '/image/2.jpg'
      }, {
        picUrl: '/image/3.jpg'
      }
    ],
    foodList: []
  },
  onLoad: function (options) {
    this.getTopList()
    this.getHotList()
  },
  //获取用户输入的内容
  getSearch(e) {
    // console.log(e.detail.value)
    searchKey = e.detail.value
  },
  //触发搜索事件
  goSearch() {
    console.log('触发了搜索', searchKey)
    if (searchKey && searchKey.length > 0) {
      //搜索的触发写在这里
      wx.navigateTo({
        url: '/pages/food/food?searchKey=' + searchKey,
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: '搜索词为空',
      })
    }
  },

  // 点击事件：去菜品页
  click1() {
    wx.navigateTo({
      url: '/pages/food2/food2',
    })
  },
  // 点击事件：去菜品页
  click2() {
    wx.navigateTo({
      url: '/pages/food/food',
    })
  },
  // 点击事件：去菜品页
  click3() {
    wx.navigateTo({
      url: '/pages/paihao/paihao',
    })
  },
  // 点击事件：去菜品页
  click4() {
    wx.navigateTo({
      url: '/pages/address/address',
    })
  },

  //获取首页轮播图
  getTopList() {
    db.collection('lunbotu').get()
      .then(res => {
        console.log('获取轮播图成功', res)
        if (res.data && res.data.length > 0) {
          this.setData({
            list: res.data
          })
        }
      })
      .catch(res => {
        console.log('获取轮播图失败', res)
      })
  },
  //获取热门菜品列表
  getHotList() {
    //小程序端直接调取数据库
    // db.collection('food')
    //   .where({
    //     status: "上架"
    //   })
    //   .orderBy("sell", 'desc')
    //   .limit(5)
    //   .get()
    //   .then(res => {
    //     console.log("菜品列表", res)
    //   })

    //通过云函数调用数据
    wx.cloud.callFunction({
        name: "getFoodList2"
      })
      .then(res => {
        console.log("菜品列表", res)
        this.setData({
          foodList: res.result.data
        })
      })
  }

})