Page({
  data: {
    address: "杭州西湖区腾讯",
    phone: "1234567890",
    weixin: "2501902696",
    //标记点
    markers: [{
      id: 0,
      name: "马化腾",
      address: "腾讯",
      latitude: 30.28139,
      longitude: 120.07937,
      width: 80,
      height: 80
    }]
  },
  //点击导航
  clickMap(e) {
    console.log('点击地图上的标记点', e.currentTarget.dataset.marker)
    let marker = e.currentTarget.dataset.marker
    wx.getLocation({
      type: 'wgs84',
      success(res) {
        wx.openLocation({ //地图搜索目的他
          latitude: marker.latitude,
          longitude: marker.longitude,
          name: marker.name,
          address: marker.address,
          scale: 18
        })
      },
      fail(res) {
        console.log("获取位置失败", res)
        wx.showModal({
          title: "需要授权",
          content: "需要授权位置信息，才可以实现导航，点击去设置就可以开启位置权限",
          confirmText: "去设置",
          success(res) {
            console.log("弹窗点击", res)
            if (res.confirm) {
              wx.openSetting()
            }
          }
        })
      }
    })
  },
  // 拨打电话
  callPhone(e) {
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone,
    })
  },
  copyWechat(event) {
    wx.setClipboardData({
      data: event.currentTarget.dataset.weixin,
    })
  }
})