const db = wx.cloud.database()
let searchKey = ''
Page({
  data: {
    isHiddMask: true,
    totalMoney: 0,
    totalNum: 0,
    cartList: [], //购物车数据
  },
  onLoad: function (options) {
    console.log("options", options)
    searchKey = options.searchKey
    if (searchKey) { //搜索进来的
      this.setData({
        key: searchKey
      })
    } else { //菜品浏览进来的
      searchKey = ''
      wx.setNavigationBarTitle({
        title: '菜品列表页',
      })
    }


    // 获取购物车缓存数据
    let cartList = wx.getStorageSync('cart') || []
    console.log('本地缓存的购物车数据', cartList)
    this.setData({
      cartList: cartList
    })
    this.getSearchData()
  },
  //获取用户输入的内容
  getSearch(e) {
    // console.log(e.detail.value)
    searchKey = e.detail.value
  },
  //触发搜索事件
  goSearch() {
    console.log('触发了搜索', searchKey)
    if (searchKey && searchKey.length > 0) {
      this.getSearchData()
    } else {
      wx.showToast({
        icon: 'none',
        title: '搜索词为空',
      })
    }
  },
  // 获取搜索数据
  getSearchData() {
    let cartList = this.data.cartList

    console.log('cartlist是否有值', cartList)
    db.collection('food').where({
        name: db.RegExp({
          regexp: searchKey,
          options: 'i' //不区分大小写
        })
      }).get()
      .then(res => {
        console.log('搜索成功', res)
        let list = res.data
        if (list && list.length > 0) {
          list.forEach(item => {
            if (cartList && cartList.length > 0) {
              // 查询购物车数组里面是否存在当前点击的菜品
              let result = cartList.find(cart => {
                return cart._id == item._id;
              })
              if (result) {
                item.num = result.num
              } else {
                item.num = 0
              }
            } else {
              item.num = 0
            }
          })
          this.setData({
            foodList: list
          })
          this.getTotal()
        }

      })
      .catch(res => {
        console.log('搜索失败', res)
      })
  },
  // 点击减少
  jian(e) {
    let id = e.currentTarget.dataset.id
    console.log('点击了-', e.currentTarget.dataset.id)
    let list = this.data.foodList
    let cartList = this.data.cartList

    list.forEach(item => {
      if (item._id == id) {
        if (item.num > 0) {
          item.num -= 1
          // 查询购物车数组里面是否存在当前点击的菜品
          var index = cartList.findIndex(cart => {
            return cart._id == id;
          })
          if (index > -1) {
            cartList[index].num = item.num
          }
          if (item.num == 0) { //如果点击的菜品数量为0，就移除
            cartList.splice(index, 1) //删除下标为index的元素
          }
        } else {
          wx.showToast({
            icon: 'none',
            title: '数量不能小于0',
          })
        }
      }
    })
    console.log('-----遍历以后的购物车列表', cartList)
    this.setData({
      foodList: list,
      cartList
    })
    this.getTotal()
    wx.setStorageSync('cart', cartList)
  },
  // 点击加号
  jia(e) {
    let id = e.currentTarget.dataset.id
    console.log('点击了+', e.currentTarget.dataset.id)
    let list = this.data.foodList
    console.log('当前菜品列表', list)
    let cartList = this.data.cartList
    list.forEach(item => {
      if (item._id == id) {
        item.num += 1
        if (cartList && cartList.length > 0) {
          // 查询购物车数组里面是否存在当前点击的菜品
          var result = cartList.find(cart => {
            return cart._id == id;
          })
          console.log("当前点击的菜品是否存在于购物车里", result)
          if (result) {
            result.num = item.num
          } else {
            cartList.push(item)
          }
        } else {
          cartList.push(item)
        }
      }
    })
    console.log('++++遍历以后的购物车列表', cartList)
    this.setData({
      foodList: list,
      cartList
    })
    this.getTotal()
    wx.setStorageSync('cart', cartList)
  },
  // 计算总价格和总数量
  getTotal() {
    let cartList = this.data.cartList
    let totalMoney = 0
    let totalNum = 0

    cartList.forEach(item => {
      totalNum += item.num
      totalMoney += item.num * item.price
    })
    this.setData({
      totalMoney,
      totalNum
    })
  },


  // 关闭购物车蒙层
  closeMask() {
    this.setData({
      isHiddMask: true
    })
  },
  // 打开购物车蒙层
  openMask() {
    this.setData({
      isHiddMask: false
    })
  },
  // 清空购物车
  clearCart() {
    let foodList = this.data.foodList
    foodList.forEach(item => {
      item.num = 0
    })

    this.setData({
      foodList,
      cartList: [],
      totalMoney: 0,
      totalNum: 0
    })
    wx.setStorageSync('cart', null)
  },
  // 删除购物车里的一条数据
  closeCartItem(e) {
    console.log(e.currentTarget.dataset.index)
    let index = e.currentTarget.dataset.index
    let cartList = this.data.cartList
    let cart = cartList[index]
    // 遍历菜品列表，把要删除的菜品的数量置为0
    let foodList = this.data.foodList
    foodList.forEach(item => {
      if (cart._id == item._id) {
        item.num = 0
      }
    })
    // 从购物车数组里删除当前菜品
    cartList.splice(index, 1)

    this.setData({
      foodList,
      cartList
    })
    // 重新计算总价格
    this.getTotal()
    // 把更新后的数据重新缓存
    wx.setStorageSync('cart', cartList)
  },
  // 去支付
  goOrder() {
    wx.navigateTo({
      url: '/pages/pay/pay',
    })
  }
})