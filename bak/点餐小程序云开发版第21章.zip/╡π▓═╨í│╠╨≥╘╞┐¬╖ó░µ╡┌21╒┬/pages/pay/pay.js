let app = getApp()
Page({
  data: {
    isHiddMask: true, //隐藏蒙层
    hasNum: null,
    renshu: 0,
    renshulist: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    // 选择支付方式
    payList: [
      '会员卡支付',
      '微信支付',
      '支付宝支付',
      '银行卡支付'
    ]
  },
  onShow() {
    console.log('全局存的桌号：', app.globalData.zhuohao)
    let list = wx.getStorageSync('cart') || []
    console.log('本地缓存的list', list)
    this.setData({
      list,
      hasNum: app.globalData.zhuohao
    })
    this.getTotal()
  },
  // 计算总价格和总数量
  getTotal() {
    let cartList = this.data.list
    let totalMoney = 0
    let totalNum = 0

    cartList.forEach(item => {
      totalNum += item.num
      totalMoney += item.num * item.price
    })
    this.setData({
      totalMoney,
      totalNum
    })
  },
  // 扫码识别桌号
  saoma() {
    console.log('点击了扫码识别桌号')
    // let that = this
    // wx.scanCode({
    //   success(res) {
    //     console.log(res.result)
    //     that.setData({
    //       hasNum: res.result
    //     })
    //   }
    // })

    wx.scanCode({
      success: res => {
        console.log(res.result)
        app.globalData.zhuohao = res.result
        this.setData({
          hasNum: res.result
        })
      }
    })
  },
  // 选择就餐人数
  xuanzhong(e) {
    console.log(e.currentTarget.dataset.item)
    this.setData({
      renshu: e.currentTarget.dataset.item
    })
  },
  // 获取用户输入的备注信息
  getBeizhu(e) {
    // console.log('备注', e.detail.value)
    this.setData({
      beizhu: e.detail.value
    })
  },


  // 关闭购物车蒙层
  closeMask() {
    this.setData({
      isHiddMask: true
    })
  },
  // 打开购物车蒙层
  openMask() {
    if (!this.data.hasNum) {
      wx.showToast({
        icon: 'error',
        title: '请识别桌号',
      })
    } else if (!this.data.renshu) {
      wx.showToast({
        icon: 'error',
        title: '选择就餐人数',
      })
    } else {
      this.setData({
        isHiddMask: false
      })
    }

  },
  // 提交订单
  submit() {
    // 编程小石头提醒你记得解开注释

    console.log('执行了提交订单')
    let user = wx.getStorageSync('user')
    console.log('用户信息', user)
    // 校验用户是否登陆
    if (!user) {
      wx.showToast({
        icon: 'error',
        title: '去个人中心登陆',
      })
      setTimeout(() => {
        wx.switchTab({
          url: '/pages/me/me',
        })
      }, 1000);
      return

    }

    // 提交订单
    wx.cloud.database().collection('order')
      .add({
        data: {
          name: user.nickName, //用户的昵称
          status: 0, //订单状态 -1订单取消,0新下单待上餐,1待用户评价,2订单已完成
          address: this.data.hasNum, //桌号
          beizhu: this.data.beizhu, //用户的备注
          renshu: this.data.renshu, //就餐人数
          orderList: this.data.list, //用户点了那些菜
          totalPrice: this.data.totalMoney, //总价
          time: app.getCurrentTime()
        }
      }).then(res => {
        // 增加销量
        let foods = []
        this.data.list.forEach(item => {
          let food = {}
          food._id = item._id
          food.num = item.num
          foods.push(food)
        })

        // 调用云函数，添加销量
        wx.cloud.callFunction({
          name: 'addSell',
          data: {
            foods: foods
          }
        }).then(res => {
          console.log('云函数的返回', res)
        })
        console.log('提交订单成功', res)


        // 清空购物车
        wx.setStorageSync('cart', null)

        wx.switchTab({
          url: '/pages/me/me',
        })
      }).catch(res => {
        console.log('提交订单失败', res)
      })
  },

})