const app = getApp()
const db = wx.cloud.database()
Page({
  onShow() {
    this.getNum()
  },
  // 获取今日排号数据
  getNum() {
    db.collection('paihao').doc(app.getCurrentYMD()).get()
      .then(res => {
        console.log('今日排号数据', res)
        this.setData({
          paihao: res.data
        })
      })
      .catch(res => {
        console.log('今日没有排号')
      })

  },
  // 小桌或者大桌的叫号
  jiaohao(e) {
    //  type 1代表小桌，2代表大桌
    let type = e.currentTarget.dataset.type
    console.log(type)
    wx.cloud.callFunction({
      name: "paihao",
      data: {
        action: 'admin',
        id: app.getCurrentYMD(),
        type: type
      }
    }).then(res => {
      console.log('小桌操作结果', res)
      this.getNum()
    })
  },
})