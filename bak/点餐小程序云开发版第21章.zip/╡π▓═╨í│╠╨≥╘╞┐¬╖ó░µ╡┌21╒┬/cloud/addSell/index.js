// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
    env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async (event, context) => {
    const db = cloud.database()
    const _ = db.command
    let foods = event.foods || []

    let proArr = []
    foods.forEach(food => {
        let pro = db.collection('food').doc(food._id)
            .update({
                data: {
                    sell: _.inc(food.num)
                }
            })
        proArr.push(pro)
    });

    return await Promise.all(proArr)
}