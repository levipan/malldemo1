// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
    env: cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
    if (event.type == 'get') {
        return await db.collection('order')
            .where({
                status: event.status
            }).get()
    } else if (event.type == 'update') {
        return await db.collection('order').doc(event.id)
            .update({
                data: {
                    //订单状态 -1订单取消,0新下单待上餐,1待用户评价,2订单已完成
                    status: event.status
                }
            })
    }

}