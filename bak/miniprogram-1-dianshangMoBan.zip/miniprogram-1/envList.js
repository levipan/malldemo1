const envList = [{"envId":"cloud1-1g471hgg8a9d1be7","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}