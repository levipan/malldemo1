export default {
    year: '',
    month: '',
    day: '',
    hour: '',
    minute: '',
    am: 'AM',
    pm: 'PM',
    confirm: 'confirm',
    cancel: 'cancel',
};
