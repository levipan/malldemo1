import { TdStickyProps } from './type';
declare const props: TdStickyProps;
export default props;
