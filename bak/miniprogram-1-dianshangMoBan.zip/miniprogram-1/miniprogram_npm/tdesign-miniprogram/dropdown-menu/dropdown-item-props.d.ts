import { TdDropdownItemProps } from './type';
declare const props: TdDropdownItemProps;
export default props;
