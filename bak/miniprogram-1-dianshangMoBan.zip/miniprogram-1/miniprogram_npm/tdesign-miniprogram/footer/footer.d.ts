import { SuperComponent } from '../common/src/index';
export default class Footer extends SuperComponent {
    properties: import("./type").TdFooterProps;
    data: {
        classPrefix: string;
    };
}
