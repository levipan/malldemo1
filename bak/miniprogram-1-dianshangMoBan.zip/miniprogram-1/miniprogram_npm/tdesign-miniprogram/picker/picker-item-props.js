const props = {
    format: {
        type: null,
    },
    options: {
        type: Array,
        value: [],
    },
};
export default props;
