import { TdCollapsePanelProps } from './type';
declare const props: TdCollapsePanelProps;
export default props;
