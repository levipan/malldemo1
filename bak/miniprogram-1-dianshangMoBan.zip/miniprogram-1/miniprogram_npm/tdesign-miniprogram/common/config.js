export default {
    prefix: "t",
};
