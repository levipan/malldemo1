import { TdGridItemProps } from './type';
declare const props: TdGridItemProps;
export default props;
